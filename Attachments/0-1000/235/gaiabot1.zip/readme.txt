gaiabot BETA 1.0
http://www.blizzhackers.com

The bot is made for IE.
Coded with autoit3 , on windows 98.

if not on the gaia page, the bot just wont work.
steps:
1-open IE
2-go to gaia online, any page
3-run the bot

to pause or quit, pulse esc


made on a rush ...

no real readme yet !

check the forums