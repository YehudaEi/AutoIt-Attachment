﻿// special constants
var FUNCTION = 'function';
var OBJECT = 'object';
var UNDEFINED = 'undefined';

var streamPlay = 0;         // used to track the length of time an audio stream has stopped
var streamPos = 0;          // play position for streaming audio (SWF player)
var streamDur = 0;          // duration position for streaming audio (SWF player)
var streamRestart = 0;      // used to track the number of times an audio stream has been programmatically restarted

var dirty = 0;
var product = 'screen';

//----------------------------------------------------
// Detect if the browser is IE or not.
// If it is not IE, we assume that the browser is NS.
//----------------------------------------------------
var IE = document.all?true:false


//--------------------------------------------------------------------------
// include a javascript file; so we don't have to continually reference all files in every page
function inc(filename) {
    var body;
    try {
        body = document.getElementsByTagName('head').item(0);
        script = document.createElement('script');
        script.src = filename;
        script.type = 'text/javascript';
        script.defer = true;
        body.appendChild(script)
    }
    catch (ex) {
    }
}

// include external JS libraries
inc('swf/swfobject.js');
inc('swf/swfsound.js');

// this prevents the page from scrolling to the top during form submission with client-side validation
function KillScrollToTop() {
    window.scrollTo = function() { }
}

//--------------------------------------------------------------------------
function chkDirty() {
	try {
		if (dirty == 1) {
			return '****** WARNING ******\nYou have modified this ' + product + ' but have not saved it. If you leave now, you will lose your changes! Are you sure you want to continue?';
		}
	}
	catch (ex) {
	}
}

//--------------------------------------------------------------------------
function swapImage(newImage, el) {
	try {
		el.src = newImage;
	}
	catch (ex) {
	}
}

//--------------------------------------------------------------------------
function showTM() {
	try {
		document.write('<small><sup>TM</sup></small>');
	}
	catch (ex) {
	}
}

//--------------------------------------------------------------------------
function toggleVisibility(ID) {
	try {
		if (document.getElementById(ID).style.display == '')
			document.getElementById(ID).style.display = 'none';
		else
			document.getElementById(ID).style.display = '';
	}
	catch (ex) {
	}
}

//--------------------------------------------------------------------------
function startBlink(el, interval) {
	var rv;
	
	try {
		rv = setInterval('doBlink(\'' + el + '\');', interval)
	}
	catch (ex) {
	}
	
	return rv;
}

//--------------------------------------------------------------------------
function doBlink(el) {
	var elem;
	
	try {
		elem = document.getElementById(el);
		
		elem.style.visibility = elem.style.visibility == '' ? 'hidden' : '';
	}
	catch (ex) {
	}	
}

//--------------------------------------------------------------------------
function openWindow(name, url, options) {
    try {
        window.open(url, name, options);
    }
    catch (ex) { }
}

//--------------------------------------------------------------------------
function calcHeight(name) {
    try {
        //find the height of the internal page
        var the_height = document.getElementById(name).contentWindow.document.body.scrollHeight;
        var the_width = document.getElementById(name).contentWindow.document.body.scrollWidth;

        //change the height of the iframe
        document.getElementById(name).height = the_height;
        document.getElementById(name).width = the_width;
    }
    catch (ex) { }
}

//--------------------------------------------------------
function sendToClipboard(s) {
    try {
	    if( window.clipboardData && clipboardData.setData ) {
		    clipboardData.setData("Text", s);
	    }
	    else {
		    alert("Internet Explorer required");
	    }
	}
	catch (ex) { }
}

//---------------------------------------------------------------------------------------------
function showMyTitle(obj) {	
	try {
	    if (obj.title != "")
	    {
		    if (obj.title != "")
			    bYes = confirm(obj.title);

			if (bYes)
                sendToClipboard(obj.title)
	    }
	}
	catch (ex) { }
}

function setupTagToTip(imgHelp, spanHelpText, HelpTitle) {
    var img;
    
    try {
        if (document.getElementById(imgHelp) && document.getElementById(spanHelpText)) {
            img = document.getElementById(imgHelp);
            img.onmouseover = function() { TagToTip(spanHelpText, DELAY, 400, DURATION, -1000, SHADOW, true, FOLLOWMOUSE, false, TITLE, HelpTitle); };
            img.onmouseout = function() { UnTip(); };
        }
    }
    catch (ex) {
        alert(ex.toString());
    }
}

//--------------------------------------------------------------------------
function mouseCoords(ev){
    try {
        if (IE) {
	        // grab the x-y pos.s if browser is IE  
		    tempX = event.clientX + document.documentElement.scrollLeft 
		    tempY = event.clientY + document.documentElement.scrollTop
	    }
	    else {
	        // grab the x-y pos.s if browser is NS
		    tempX = ev.pageX
		    tempY = ev.pageY
	    }  

	    return {x:tempX, y:tempY};
	}
	catch (ex) { }
}
	
//---------------------------------------------------------------------------------------------
function ShowAjaxTab(sTabID) {
    try {
        oTabPnl = document.getElementById(sTabID)
	    if (oTabPnl != null) {	
	        oTabPnl.style.display = ""
        }
    }
    catch (ex) { }
}
 
//--------------------------------------------------------------------------
function openListenWindow(sURL) {
    try {
        var agt = navigator.userAgent.toLowerCase();
        var imgWidth = 0;
        var imgHeight = 0;

        if (agt.indexOf('msie') >= 0) {
            imgWidth = 250;
            imgHeight = 115;
        }
        else if (agt.indexOf('firefox') >= 0) {
            imgWidth = 260;
            imgHeight = 100;
        }
        else if (agt.indexOf('chrome') >= 0) {
            imgWidth = 260;
            imgHeight = 116;
        }
        else {
            imgWidth = 250;
            imgHeight = 115;
        }

        listen = window.open(sURL, 'ListenWindow', 'status=no,location=no,menubar=no,toolbar=no,resizable=no,personalbar=no,directories=no,width=' + imgWidth + ',height=' + imgHeight);

        /* 
        if (listen) {
            if (listen.document.body.scrollHeight) {
                var winWidth = listen.document.body.scrollWidth;
                var winHeight = listen.document.body.scrollHeight;
            }
            else if (listen.document.documentElement.scrollHeight) {
                var winHeight = listen.document.documentElement.scrollHeight;
                var winWidth = listen.document.documentElement.scrollWidth;
            }
            else {
                var winHeight = listen.document.documentElement.offsetHeight;
                var winWidth = listen.document.documentElement.offsetWidth;
            }

            listen.window.resizeTo(winWidth, winHeight);
        }
        else {
            alert('Can\'t reference popup!');
        } */
    }
    catch (ex) { }
}

//---------------------------------------------------------------------------------------------
// checks value to confirm that it's a number
//---------------------------------------------------------------------------------------------
function IsNumber(objToVal) {
    var sNums = "0123456789";
    var cChar;
    var sText = '';
        
    try {
        sText = objToVal.value;

        for (i = 0; i < sText.length; i++) {
            cChar = sText.charAt(i);

            if (sNums.indexOf(cChar) == -1) {
                return false;
            }
        }
    }
    catch (ex) { }

    return true;
}

//---------------------------------------------------------------------------------------------
function RtnOnlyNumbers(sText) {
    var sNums = "0123456789";
    var cChar;

    var sRtn = '';

    try {
        for (i = 0; i < sText.length; i++) {
            cChar = sText.charAt(i);

            if (sNums.indexOf(cChar) > -1) {
                sRtn += cChar;
            }
        }
    }
    catch (ex) { }

    return sRtn;
}

//---------------------------------------------------------------------------------------------
function RtnOnlyPhoneNumbers(sText) {
    var sNums = "()-.[]{}0123456789";
    var cChar;

    var sRtn = '';

    try {
        for (i = 0; i < sText.length; i++) {
            cChar = sText.charAt(i);

            if (sNums.indexOf(cChar) > -1) {
                sRtn += cChar;
            }
        }
    }
    catch (ex) { }

    return sRtn;
}

//---------------------------------------------------------------------------------------------
function WhichBrowser() {
    var sRtn = "unknown";
    var sUserAgent;
    
    try {
        sUserAgent = window.navigator.userAgent.toLowerCase();

        if (sUserAgent.indexOf("msie") > -1) sRtn = "IE";
        else if (sUserAgent.indexOf("firefox") > -1) sRtn = "FF";
        else if (sUserAgent.indexOf("chrome") > -1) sRtn = "CR";
        else if (sUserAgent.indexOf("apple") > -1) sRtn = "SA";
    }
    catch (ex) { }

    return sRtn;
}


//---------------------------------------------------------------------------------------------
function CleanPhoneNumber(el) {
    var num = document.getElementById(el);
    try {
        if (typeof num != UNDEFINED) {
            num.value = RtnOnlyNumbers(num.value);
        }
    }
    catch (ex) { }
}

//--------------------------------------------------------------------------
function CreateSWF_Player(el, img, url) {
    try {
        // this function checks for the existence of Flash Player (8.0.0 minimum) and displays either an image or link
        if (typeof swfobject == OBJECT) {
            if (swfobject.hasFlashPlayerVersion('8.0.0')) {
                if (img)
                    document.getElementById(el).innerHTML = '<img class="confAction" style="cursor:pointer;" onClick="javascript:StartSWF_Player(\'' + el + '\', ' + img + ', \'' + url + '\');" src="img/general/streaming_audio_off.png" />';
                else
                    document.getElementById(el).innerHTML = '<a class="listenLink" onClick="javascript:StartSWF_Player(\'' + el + '\', ' + img + ', \'' + url + '\');">Listen</a>';
            }
            else {
                if (img)
                    document.getElementById(el).innerHTML = '<a href="http://www.adobe.com/go/getflashplayer" target="_blank"><img src="http://www.adobe.com/images/shared/download_buttons/get_flash_player.gif" alt="Get Adobe Flash player" border="0" /></a>';
                else
                    document.getElementById(el).innerHTML = '<a class="listenLink" href="http://www.adobe.com/go/getflashplayer" target="_blank">Download Flash</a>';
            }
        }
    }
    catch (ex) {
        if (typeof pkWebCallLog == UNDEFINED)
            pkWebCallLog = 'unknown';
        
        ErrorTrap_Log(window.location.toString(), 'CreateSWF_Player', pkWebCallLog, ex.toString());
    }
}

//--------------------------------------------------------------------------
function StartSWF_Player(el, img, url) {
    var step = 0;
    try {
        // initialize global variables
        streamPos = 0;
        streamDur = 0;
        streamPlay = 0;

        // this function stops a stream if there is one in progress
        // it also embeds the SWF dynamically with a callback function to begin playing the stream once it is loaded
        if (document.getElementById(el)) {
            // stop a playback if one is in progress
            if (typeof Current_SWF.ElementID != UNDEFINED && Current_SWF.ElementID != '') {
                StopSWF_Player(Current_SWF.ElementID, Current_SWF.ShowImage, Current_SWF.URL);
            }

            // save the to-be-played values to the Current_SWF object
            Current_SWF.ElementID = el;
            Current_SWF.ShowImage = img;
            Current_SWF.URL = url;

            // load the SWFSound flash engine
            var flashvars = false;
            var attributes = { id: 'swfSound_Flash' };
            var params = { menu: 'false', wmode: 'window', swLiveConnect: 'true', allowScriptAccess: 'always' };

            // document.write( '<div id="swfSound_Flash_div" style="position:absolute; left:0; top:0;"></div>' );
            var d = document, div;
            div = d.createElement('div');
            div.id = "swfSound_NoFlash";
            div.style.position = "absolute";
            div.style.left = 0;
            div.style.top = 0;
            d.getElementsByTagName('body')[0].appendChild(div);

            // make sure the flash movie is visible, otherwise the onload is not fired!
            var def = "#swfSound_Flash { left:0; position:absolute; top: 0; }";
            var ss1 = document.createElement('style');
            ss1.setAttribute("type", "text/css");
            if (ss1.styleSheet) {
                // IE
                ss1.styleSheet.cssText = def;
            }
            else {
                // W3C
                var tt1 = document.createTextNode(def);
                ss1.appendChild(tt1);
            }
            var hh1 = document.getElementsByTagName('head')[0];
            hh1.appendChild(ss1);

            // embed the swfsound SWF file
            //   the final parameter is a callback to begin playing the stream 500 ms after the SWF is loaded; the delay is to allow time for the browser to recognize the new SWF object
            swfobject.embedSWF('swf/swfsound.swf?ver=99', 'swfSound_NoFlash', '1', '1', '8.0.0', 'swf/expressInstall.swf', flashvars, params, attributes, function() { setTimeout('__PLAY_SWF();', 500); });
        }
    }
    catch (ex) {
        if (typeof pkWebCallLog == UNDEFINED)
            pkWebCallLog = 'unknown';
        
        ErrorTrap_Log(window.location.toString(), 'StartSWF_Player', pkWebCallLog, ex.toString());
    }
}

//--------------------------------------------------------------------------
function __PLAY_SWF() {
    var el, img, url;
    var step = 0;

    try {
        el = Current_SWF.ElementID;
        img = Current_SWF.ShowImage;
        url = Current_SWF.URL;

        step = 1;
        if (document.getElementById('swfSound_Flash')) {
            step = 2;
            if (typeof swfsound == OBJECT) {
                step = 3;
                if (typeof swfsound.loadSound == FUNCTION) {
                    step = 4;
                    // point the SWF player to the mp3 source
                    // loadSound: function( mp3URL, streamingMode, onLoadCallbackFunctionName, onID3CallbackFunctionName, soundBufferTime )
                    SWF_Player = swfsound.loadSound(url, true, null, null);
                    step = 5;
                    // make sure the SWF player has been loaded
                    if (SWF_Player == 0) {
                        step = 6;
                        // startSound: function( id_sound, offsetSecondsFloat, loopCount, onSoundCompleteCallbackFunctionName )
                        swfsound.startSound(SWF_Player, 0, 0, 'function () { StopSWF_Player(\'' + el + '\', ' + img + ', \'' + url + '\'); }');
                        step = 7;
                        swfsound.setPan(SWF_Player, 0); // 0 = center, -100 = left, +100 = right
                        step = 8;
                        swfsound.setVolume(SWF_Player, 100); // 0 = silence, 100 = maximum
                        step = 9;
                        upd = setInterval('updPlayPosition();', 100);
                        step = 9.5;
                        if (img) {
                            step = 10;
                            document.getElementById(el).innerHTML = '<img class="confAction" style="cursor:pointer;" onClick="javascript:StopSWF_Player(\'' + el + '\', ' + img + ', \'' + url + '\');" src="img/general/streaming_audio_on.png" />';
                            step = 10.5;
                        }
                        else {
                            step = 11;
                            document.getElementById(el).innerHTML = '<a class="listenLink" onClick="javascript:StopSWF_Player(\'' + el + '\', ' + img + ', \'' + url + '\');">Stop</a>';
                            step = 11.5;
                        }
                    }
                    else {
                        step = 12;
                    }
                }
                else {
                    step = 13;
                }
            }
            else {
                step = 14;
            }
        }
        else {
            step = 15;
        }
    }
    catch (ex) {
        alert(ex.toString());
        if (typeof pkWebCallLog == UNDEFINED)
            pkWebCallLog = 'unknown';

        ErrorTrap_Log(window.location.toString(), '__PLAY_SWF', pkWebCallLog, 'Step: ' + step + '\n' + ex.toString());
    }
}

//--------------------------------------------------------------------------
function StopSWF_Player(el, img, url) {
    try {
        // stop the interval tracking
        if (typeof updPlayPosition != UNDEFINED) {
            clearInterval(upd);
        }

        if (document.getElementById(el)) {
            // make sure the SWF player has been loaded
            if (SWF_Player == 0) {
                swfsound.stopSound(SWF_Player);

                // remove the SWF player and free the SWF_Player variable
                //   this was necessary to disconnect the stream from the web conferencing server
                //   .stopSound only stops the current stream and does not disconnect
                swfobject.removeSWF('swfSound_Flash');
                SWF_Player = undefined;

                // reset the Current_SWF object
                Current_SWF.ElementID = '';
                Current_SWF.ShowImage = '';
                Current_SWF.URL = '';

                if (img) {
                    document.getElementById(el).innerHTML = '<img class="confAction" style="cursor:pointer;" onClick="javascript:StartSWF_Player(\'' + el + '\', ' + img + ', \'' + url + '\');" src="img/general/streaming_audio_off.png" />';
                }
                else {
                    document.getElementById(el).innerHTML = '<a class="listenLink" onClick="javascript:StartSWF_Player(\'' + el + '\', ' + img + ', \'' + url + '\');">Listen</a>';
                }
            }
        }
    }
    catch (ex) {
        if (typeof pkWebCallLog == UNDEFINED)
            pkWebCallLog = 'unknown';
        
        ErrorTrap_Log(window.location.toString(), 'StopSWF_Player', pkWebCallLog, ex.toString());
    }
}

//--------------------------------------------------------------------------
function updPlayPosition() {
    var posCurr, durCurr;   // current values
    var posDiff, durDiff;   // difference values

    try {
        posCurr = swfsound.getPosition(SWF_Player);
        durCurr = swfsound.getDuration(SWF_Player)

        posDiff = posCurr - streamPos;
        durDiff = streamDur - posCurr;

        if (document.getElementById('posDiff')) {
            document.getElementById('posDiff').innerHTML = posDiff;
        }
        if (document.getElementById('durDiff')) {
            document.getElementById('durDiff').innerHTML = durDiff;
        }
        
        if (posDiff == 0 && durDiff > 0) {
            // audio is being streamed but not played
            var now = new Date();
            if (streamPlay != 0 && (now.getTime() - streamPlay.getTime() > 20000)) {
                // the stream has been stopped for more than 1 second, restart it
                streamRestart++;
                if (document.getElementById('restart')) {
                    document.getElementById('restart').innerHTML = streamRestart;
                }

                StartSWF_Player(Current_SWF.ElementID, Current_SWF.ShowImage, Current_SWF.URL);
            }
            else {
                if (document.getElementById('check')) {
                    document.getElementById('check').innerHTML = (document.getElementById('check').innerHTML * 1) + 1;
                }
            }
        }
        else {
            // the stream is playing, save a timestamp
            streamPlay = new Date();
        }

        streamPos = posCurr;
        streamDur = durCurr;
        
        if (document.getElementById('playpos')) {
            document.getElementById('playpos').innerHTML = streamPos;
        }
        if (document.getElementById('duration')) {
            document.getElementById('duration').innerHTML = streamDur;
        }
    }
    catch (ex) {
        if (typeof pkWebCallLog == UNDEFINED)
            pkWebCallLog = 'unknown';

        ErrorTrap_Log(window.location.toString(), 'updPlayPosition', pkWebCallLog, 'Position: ' + streamPlay + '\n' + 'Duration: ' + streamDur + '\n' + 'Position Diff: ' + posDiff + '\n' + 'Duration Diff: ' + durDiff + '\n' + 'Restarts: ' + streamRestart + '\n' + ex.toString());
    }
}

//--------------------------------------------------------------------------
function ErrorTrap_Log(PageName, FunctionName, pkWebCallLog, ErrorText) {
    var info, email, adminUrl, now;
    var plugins = '';
    var mimeTypes = '';

    try {
        info = '';
        email = '';
        adminUrl = '';
        now = new Date();

        if (typeof pkWebCallLog == UNDEFINED)
            pkWebCallLog = 'unknown';

        if (typeof bReceiveData == UNDEFINED)
            bReceiveData = 'n/a';

        if (typeof iLastErrorTime == UNDEFINED)
            iLastErrorTime = '';

        // throttle error messages
        if (iLastErrorTime == '' || (now.getTime() - iLastErrorTime.getTime()) > 1000) {
            // timestamp the error
            iLastErrorTime = new Date();

            ErrorText += '\n\n';

            // generate an admin site link, if possible
            if (PageName.indexOf('www.accuconference.com/customer') >= 0) {
                adminUrl = PageName.replace(/www.accuconference.com\/customer/, 'admin.accutalk.com');
                ErrorText += 'Admin Link: ' + adminUrl + '\n';
            }

            // capture the email from the page header, if possible
            if (document.getElementById('HeaderEmail')) {
                email = document.getElementById('HeaderEmail').innerHTML
                email = email.substring(email.indexOf('">') + 2, email.indexOf('<', email.indexOf('">')));
                ErrorText += 'Email Address: ' + email + '\n';
            }

            // add whether or not data was ever received and a timestamp
            ErrorText += 'bReceiveData: ' + bReceiveData + '\n';
            ErrorText += 'TimeStamp: ' + (new Date().toTimeString()) + '\n\n';
            if (document.getElementById('CommandList')) {
                ErrorText += 'Command List:' + '\n' + document.getElementById('CommandList').innerHTML + '\n\n';
            }

            // build browser info
            for (var property in navigator) {
                switch (property.toUpperCase()) {
                    case 'PLUGINS':
                        if (typeof navigator[property] == OBJECT) {
                            plugins += navigator.plugins.length + ' detected plugins.\n';
                            for (i = 0; i < navigator.plugins.length; i++) {
                                plugins += '      Name: ' + navigator[property][i].name + '\n';
                                plugins += '      Description: ' + navigator[property][i].description + '\n';
                                plugins += '      Filename: ' + navigator[property][i].finename + '\n';
                                plugins += '\n';
                            }
                        }
                        else
                            plugins = 'Nothing detected.' + '\n'
                        break;

                    default:
                        info += property + ': ' + navigator[property] + '\n';
                }
            }
            info += '\n' + 'Plugins:' + '\n' + plugins;

            // append browser info to the error text
            ErrorText += 'Browser Info:' + '\n' + info;

            // call the web service which logs the error and sends a notice
            return AccuTalkXML.JScript.ErrorService.LogError(PageName, FunctionName, pkWebCallLog, ErrorText, OnComplete, OnError);
        }
        else {
            if (typeof RecordCommand == FUNCTION) {
                RecordCommand('Too soon...log command');
            }
        }
    }
    catch (ex) {
        return AccuTalkXML.JScript.ErrorService.LogError(PageName, 'ErrorTrap_Log', pkWebCallLog, ex.toString(), OnComplete, OnError);
    }
}

//--------------------------------------------------------------------------
function OnError(error, userContext, methodName) {
    //alert('An error occurred in LogError:\n' + error.get_message() + '\n' + methodName);
}

//--------------------------------------------------------------------------
function OnComplete(arg) {
    //alert('Error logged successfully:\n' + arg);
}

//--------------------------------------------------------------------------
function AddBodyOnLoad(fn) {
    try {
        if (typeof window.addEventListener != UNDEFINED) {
            window.addEventListener("load", fn, false);
        }
        else if (typeof document.addEventListener != UNDEFINED) {
            document.addEventListener("load", fn, false);
        }
        else if (typeof window.attachEvent != UNDEFINED) {
            addListener(window, "onload", fn);
        }
        else if (typeof window.onload == FUNCTION) {
            var fnOld = window.onload;
            window.onload = function() {
                fnOld();
                fn();
            };
        }
        else {
            window.onload = fn;
        }
    }
    catch (ex) {
        return AccuTalkXML.JScript.ErrorService.LogError(window.location.toString(), 'ErrorTrap_Log', '', ex.toString(), OnComplete, OnError);
    }
}

function addListener(target, eventType, fn) {
    target.attachEvent(eventType, fn);
}

//--------------------------------------------------------------------------
function Current_SWF() {
    this.ElementID = '';
    this.ShowImage = '';
    this.URL = '';
}
