﻿#include <stdio.h>
#include <stdlib.h>
#include <mem.h>

//  Reasonable lookup table. Works only on little-endian machines.
//  Swap bytes of ushorts in this table for big-endian processors.
static const unsigned short conv[] = {
	0x3030,			// '00' --> '00'
	0x3130,			// '01' --> '01'
	0x3230,			// '02' --> '02'
	0x3330,			// '03' --> '03'
	0x3430,			// '04' --> '04'
	0x3530,			// '05' --> '05'
	0x3630,			// '06' --> '06'
	0x3730,			// '07' --> '07'
	0x3830,			// '08' --> '08'
	0x3930,			// '09' --> '09'
	0x4130,			// '10' --> '0A'
	0x4230,			// '11' --> '0B'
	0x4330,			// '12' --> '0C'
	0x4430,			// '13' --> '0D'
	0x4530,			// '14' --> '0E'
	0x4630,			// '15' --> '0F'
	0x3031,			// '16' --> '10'
	0x3131,			// '17' --> '11'
	0x3231,			// '18' --> '12'
	0x3331,			// '19' --> '13'
	0x3431,			// '20' --> '14'
	0x3531,			// '21' --> '15'
	0x3631,			// '22' --> '16'
	0x3731,			// '23' --> '17'
	0x3831,			// '24' --> '18'
	0x3931,			// '25' --> '19'
	0x4131,			// '26' --> '1A'
	0x4231,			// '27' --> '1B'
	0x4331,			// '28' --> '1C'
	0x4431,			// '29' --> '1D'
	0x4531,			// '30' --> '1E'
	0x4631,			// '31' --> '1F'
	0x3032,			// '32' --> '20'
	0x3132,			// '33' --> '21'
	0x3232,			// '34' --> '22'
	0x3332,			// '35' --> '23'
	0x3432,			// '36' --> '24'
	0x3532,			// '37' --> '25'
	0x3632,			// '38' --> '26'
	0x3732,			// '39' --> '27'
	0x3832,			// '40' --> '28'
	0x3932,			// '41' --> '29'
	0x4132,			// '42' --> '2A'
	0x4232,			// '43' --> '2B'
	0x4332,			// '44' --> '2C'
	0x4432,			// '45' --> '2D'
	0x4532,			// '46' --> '2E'
	0x4632,			// '47' --> '2F'
	0x3033,			// '48' --> '30'
	0x3133,			// '49' --> '31'
	0x3233,			// '50' --> '32'
	0x3333,			// '51' --> '33'
	0x3433,			// '52' --> '34'
	0x3533,			// '53' --> '35'
	0x3633,			// '54' --> '36'
	0x3733,			// '55' --> '37'
	0x3833,			// '56' --> '38'
	0x3933,			// '57' --> '39'
	0x4133,			// '58' --> '3A'
	0x4233,			// '59' --> '3B'
	0x4333,			// '60' --> '3C'
	0x4433,			// '61' --> '3D'
	0x4533,			// '62' --> '3E'
	0x4633,			// '63' --> '3F'
	0x3034,			// '64' --> '40'
	0x3134,			// '65' --> '41'
	0x3234,			// '66' --> '42'
	0x3334,			// '67' --> '43'
	0x3434,			// '68' --> '44'
	0x3534,			// '69' --> '45'
	0x3634,			// '70' --> '46'
	0x3734,			// '71' --> '47'
	0x3834,			// '72' --> '48'
	0x3934,			// '73' --> '49'
	0x4134,			// '74' --> '4A'
	0x4234,			// '75' --> '4B'
	0x4334,			// '76' --> '4C'
	0x4434,			// '77' --> '4D'
	0x4534,			// '78' --> '4E'
	0x4634,			// '79' --> '4F'
	0x3035,			// '80' --> '50'
	0x3135,			// '81' --> '51'
	0x3235,			// '82' --> '52'
	0x3335,			// '83' --> '53'
	0x3435,			// '84' --> '54'
	0x3535,			// '85' --> '55'
	0x3635,			// '86' --> '56'
	0x3735,			// '87' --> '57'
	0x3835,			// '88' --> '58'
	0x3935,			// '89' --> '59'
	0x4135,			// '90' --> '5A'
	0x4235,			// '91' --> '5B'
	0x4335,			// '92' --> '5C'
	0x4435,			// '93' --> '5D'
	0x4535,			// '94' --> '5E'
	0x4635,			// '95' --> '5F'
	0x3036,			// '96' --> '60'
	0x3136,			// '97' --> '61'
	0x3236,			// '98' --> '62'
	0x3336			// '99' --> '63'
};


int main(
	int argc,
	char **argv
){
#pragma pack(1)
	typedef struct {
		unsigned char v1[2];
		char c1;
		unsigned char v2[2];
		char c2;
		unsigned char v3[2];
		char c3;
		unsigned char v4[2];
		char c4;
		unsigned char v5[2];
		char c5;
		unsigned char v6[2];
		char c6;
		unsigned char v7[2];
		char c7;
		unsigned char v8[2];
		char c8;
		unsigned char v9[2];
		char c9;
		unsigned char v10[2];
		char c10;
		unsigned char v11[2];
		char c11;
		unsigned char v12[2];
		char c12;
		unsigned char v13[2];
		char c13;
		unsigned char v14[2];
		char c14;
		unsigned char v15[2];
		char c15;
		unsigned char v16[2];
		char crlf[2];
	} iBuf_T;
	typedef struct {
		char f1[6];
		unsigned short v1;
		char f2[6];
		unsigned short v2;
		char f3[6];
		unsigned short v3;
		char f4[6];
		unsigned short v4;
		char f5[6];
		unsigned short v5;
		char f6[6];
		unsigned short v6;
		char f7[6];
		unsigned short v7;
		char f8[6];
		unsigned short v8;
		char f9[6];
		unsigned short v9;
		char f10[6];
		unsigned short v10;
		char f11[6];
		unsigned short v11;
		char f12[6];
		unsigned short v12;
		char f13[6];
		unsigned short v13;
		char f14[6];
		unsigned short v14;
		char f15[6];
		unsigned short v15;
		char f16[6];
		unsigned short v16;
		char cr;
		char lf;
	} oBuf_T;
	iBuf_T ibuf;
	oBuf_T obuf;
	int ret;
	FILE *inh, *outh;
	
	memset(&obuf, '0', sizeof(obuf) - 2);
	obuf.cr = '\r';
	obuf.lf = '\n';
	if (argc < 2) return(1);
	inh = fopen(argv[1], "rb");
	outh = fopen(argv[2], "wb");
	while (1) {
		ret = fread(&ibuf, sizeof(ibuf), 1, inh);
		if (ret != 1) break;
		obuf.v1 = conv[((ibuf.v1[0] - '0') * 10) + ibuf.v1[1] - '0'];
		obuf.v2 = conv[((ibuf.v2[0] - '0') * 10) + ibuf.v2[1] - '0'];
		obuf.v3 = conv[((ibuf.v3[0] - '0') * 10) + ibuf.v3[1] - '0'];
		obuf.v4 = conv[((ibuf.v4[0] - '0') * 10) + ibuf.v4[1] - '0'];
		obuf.v5 = conv[((ibuf.v5[0] - '0') * 10) + ibuf.v5[1] - '0'];
		obuf.v6 = conv[((ibuf.v6[0] - '0') * 10) + ibuf.v6[1] - '0'];
		obuf.v7 = conv[((ibuf.v7[0] - '0') * 10) + ibuf.v7[1] - '0'];
		obuf.v8 = conv[((ibuf.v8[0] - '0') * 10) + ibuf.v8[1] - '0'];
		obuf.v9 = conv[((ibuf.v9[0] - '0') * 10) + ibuf.v9[1] - '0'];
		obuf.v10 = conv[((ibuf.v10[0] - '0') * 10) + ibuf.v10[1] - '0'];
		obuf.v11 = conv[((ibuf.v11[0] - '0') * 10) + ibuf.v11[1] - '0'];
		obuf.v12 = conv[((ibuf.v12[0] - '0') * 10) + ibuf.v12[1] - '0'];
		obuf.v13 = conv[((ibuf.v13[0] - '0') * 10) + ibuf.v13[1] - '0'];
		obuf.v14 = conv[((ibuf.v14[0] - '0') * 10) + ibuf.v14[1] - '0'];
		obuf.v15 = conv[((ibuf.v15[0] - '0') * 10) + ibuf.v15[1] - '0'];
		obuf.v16 = conv[((ibuf.v16[0] - '0') * 10) + ibuf.v16[1] - '0'];
		ret = fwrite(&obuf, sizeof(obuf), 1, outh);
	}
	fclose(inh);
	fclose(outh);
	return(0);
}
