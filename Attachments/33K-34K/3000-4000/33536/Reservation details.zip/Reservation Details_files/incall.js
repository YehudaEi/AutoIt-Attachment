﻿//
// Common JavaScript Functions
//

function schedDetailPopUp(page) {
    var target = "SchedDtl.asp";
    var w = 1024;
    var h = 768;

    if ((page.length > 0) && (page.toLowerCase().indexOf(".asp") != -1)) {
        target = page;
    }

    if (document.all || document.layers) {
        w = screen.availWidth;
        h = screen.availHeight;
    }

    var popW = 1024;
    var popH = 600;
    var leftPos = (w - popW) / 2; 
    var topPos = (h - popH) / 2;

    var wind = window.open(target, 'ScheduleDetail', 'location=0, menubar=0, scrollbars=1, resizable=1, width=' + popW + ', height=' + popH + ', top=' + topPos + ', left=' + leftPos);
    if (wind != null)
		wind.focus();
    return false;
}

function refreshParent() {
    if (window.opener && !window.opener.closed) {

        if (window.opener.location.href.toLowerCase().indexOf("searchreport.asp") == -1) {
            window.opener.location.href = window.opener.location.href;
        }

        if (window.opener.progressWindow) {
            window.opener.progressWindow.close();
        }
        history.back(-1);
    }
    else {
        window.location = "default.asp";
    }
}

