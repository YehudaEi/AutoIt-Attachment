/*
 * jQuery Tooltip plugin 1.3
 *
 * http://bassistance.de/jquery-plugins/jquery-plugin-tooltip/
 * http://docs.jquery.com/Plugins/Tooltip
 *
 * Copyright (c) 2006 - 2008 Jörn Zaefferer
 *
 * $Id: jquery.tooltip.js 5741 2008-06-21 15:22:16Z joern.zaefferer $
 * 
 * Dual licensed under the MIT and GPL licenses:
 *   http://www.opensource.org/licenses/mit-license.php
 *   http://www.gnu.org/licenses/gpl.html
 */
 
;(function($) {
	
		// the tooltip element
	var helper = {},
		// the current tooltipped element
		current,
		// the title of the current element, used for restoring
		title,
		// timeout id for ajax loads
		aID,
		// timeout id for delayed tooltips (show)
		tID,
		// timeout id for delayed tooltips (hide)
		otID,
		// flag to determine if update is in process
		updating = false,
		// flag to determine if ajax content already loaded
		ajaxLoaded = false,
		// flag for mouse tracking
		track = false;
	
	$.tooltip = {
		blocked: false,
		defaults: {
			delay: 0,
			fade: false,
			showURL: true,
			extraClass: "",
			top: 15,
			left: 15,
			fixPosition: true,
			outDelay: 1000,
			tipAccessible: true,
			ajaxBody: false,
			ajaxOptions: {},
			ajaxErrorContent: null,
			ajaxLoadingContent: null,
			id: "tooltip"
		},
		block: function() {
			$.tooltip.blocked = !$.tooltip.blocked;
		}
	};
	
	$.fn.extend({
		tooltip: function(settings) {
			settings = $.extend({}, $.tooltip.defaults, settings);
			createHelper(settings);
			var f = this.each(function() {
					$.data(this, "tooltip", settings);
					this.tOpacity = helper.parent.css("opacity");
					// copy tooltip into its own expando and remove the title
					this.tooltipText = this.title;
					$(this).removeAttr("title");
					// also remove alt attribute to prevent default tooltip in IE
					this.alt = "";
				})
				.mouseenter(save)
				.mouseleave(handleOut)
				.mousedown(handleOut)
				.click(handleOut);
				
			return f;
		},
		hideWhenEmpty: function() {
			return this.each(function() {
				$(this)[ $(this).html() ? "tShow" : "tHide" ]();
			});
		},
		url: function() {
			return this.attr('href') || this.attr('src');
		},
		updateBody: function(html) {
			helper.body.html(html);
			update.call(this);
		}
	});
	
	function handleOut(){
		clearTimeouts();
		if (!!settings && !!settings(this)) {
			if (settings(this).outDelay > 0) {
				thisObj = this;
				otID = setTimeout(function(){
					tHide.call(thisObj);
				}, settings(this).outDelay);
			} else {
				tHide.call(this);
			}
		}
	};
	
	function tShowBody() {
		clearTimeouts();
		$(current).unbind("mouseleave", handleOut);
		$(current).unbind("mouseleave", tHide);
	};
	function tHideBody() {
		$(current).unbind("mouseleave", tHide).bind("mouseleave", handleOut);
		tHide();
	};
	function createHelper(settings) {
		// there can be only one tooltip helper
		if( helper.parent )
			return;
		// create the helper, h3 for title, div for url
		helper.parent = $('<div id="' + settings.id + '"><h3></h3><div class="body"></div><div class="url"></div></div>')
			// add to document
			.appendTo(document.body)
			// hide it at first
			.hide();
			
		// apply bgiframe if available
		if ( $.fn.bgiframe )
			helper.parent.bgiframe();
		
		// save references to title and url elements
		helper.title = $('h3', helper.parent);
		helper.body = $('div.body', helper.parent);
		helper.url = $('div.url', helper.parent);
		
		if (settings.tipAccessible)
			helper.body.hover(tShowBody, tHideBody);
	};
	
	function settings(element) {
		var sett = element ? $.data(element, "tooltip") : {};
		if (!sett) {
			sett = {};
		}
		return sett;
	};
	
	function initiateShow(event) {
		if (settings(this).delay) {
			var tObj = this;
			tID = setTimeout(function(){
				tShow.call(tObj, event);
			}, settings(this).delay);
		} else {
			tShow.call(this, event);
		}
		
		// if selected, update the helper position when the mouse moves
		track = !!settings(this).track;
		if (track) {
			$(document.body).bind('mousemove', update);
		}
	}
	
	// save elements title before the tooltip is displayed
	function save(event) {
		// drop contents
		//helper.parent.hide();
		// show helper, either with timeout or on instant

		// save current
		current = this;
		title = this.tooltipText;
		clearTimeouts();
		handleContent.call(this, true);
		update.call(this, event);
		initiateShow.apply(this,$.makeArray(event));
		if (settings(this).delay) {
			var tObj = this;
			aID = setTimeout(function(){
				handleAjaxContent.call(tObj, event);
			}, settings(this).delay);
		} else {
			handleAjaxContent.call(this, event);
		}
	}
	
	function clearTimeouts() {
		if (aID) {
			clearTimeout(aID);
			aID = null;
		}
		if (tID) {
			clearTimeout(tID);
			tID = null;
		}
		// clear timeout if possible
		if (otID) {
			clearTimeout(otID);
			otID = null;
		}
	}
	
	function handleAjaxContent(event) {
		if (settings && settings(this) && settings(this).ajaxBody) {
			ajaxLoaded = false;
			var url = $(this).attr("href");
			var errorContent = settings(this).ajaxErrorContent;
			$.ajax($.extend(
				{}
				, settings(this).ajaxOptions
				, {
					url: url
					, success: function(html){
						ajaxLoaded = true;
						helper.body.html(html);
						update(event);
					}
					, error: function() {
						ajaxLoaded = true;
						helper.body.html(errorContent);
						update(event);
					}
				}));
		}
	}
	
	function handleContent(shouldDrop) {
		if (settings(this) && settings(this).ajaxBody) {
			if (!ajaxLoaded || shouldDrop)
				helper.body.html(settings(this).ajaxLoadingContent);
			helper.title.hide();
			helper.body.show();
		} else if (settings(this) && settings(this).bodyHandler) {
			helper.title.hide();
			if (shouldDrop) {
				helper.body.empty()
			} else {
				var bodyContent = settings(this).bodyHandler.call(this);
				if (bodyContent.nodeType || bodyContent.jquery) {
					helper.body.empty().append(bodyContent)
				} else {
					helper.body.html(bodyContent);
				}
			}
			helper.body.show();
		} else if ( settings(this) && settings(this).showBody ) {
			var parts = title.split(settings(this).showBody);
			helper.title.html(parts.shift()).show();
			helper.body.empty();
			for(var i = 0, part; (part = parts[i]); i++) {
				if(i > 0)
					helper.body.append("<br/>");
				helper.body.append(part);
			}
			helper.body.hideWhenEmpty();
		} else {
			helper.title.html(title).show();
			helper.body.hide();
		}
		
		// if element has href or src, add and show it, otherwise hide it
		if( settings(this) && settings(this).showURL && $(this).url() )
			helper.url.html( $(this).url().replace('http://', '') ).show();
		else 
			helper.url.hide();
	}
	
	function tShow(event) {
		if ($.tooltip.blocked) {
			return;
		}
		// add an optional class for this tip
		if (settings(this) && settings(this).extraClass)
			helper.parent.addClass(settings(this).extraClass);
		
		helper.parent.css({visibility: 'hidden'});
		if ((!jQuery.browser.msie || !$.fn.bgiframe) && settings(current) && settings(current).fade) {
			if (helper.parent.is(":animated")) {
				helper.parent.stop().show().fadeTo(settings(current).fade, current.tOpacity);
			} else {
				helper.parent.is(':visible') ? helper.parent.fadeTo(settings(current).fade, current.tOpacity) : helper.parent.fadeIn(settings(current).fade);
			}
		} else {
			helper.parent.show();
		}
		handleContent.call(this);
		update.call(this, event);
	}
	
	/**
	 * callback for mousemove
	 * updates the helper position
	 * removes itself when no current element
	 */
	function update(event)	{
		if($.tooltip.blocked || updating)
			return;
			
		if (event && event.target.tagName == "OPTION") {
			return;
		}
		updating = true;
		
		// stop updating when tracking is disabled and the tooltip is visible
		if ( (!track && helper.parent.is(":visible")) || !current) {
			$(document.body).unbind('mousemove', update)
		}
		
		var left = helper.parent[0].offsetLeft;
		var top = helper.parent[0].offsetTop;
		var right = 'auto';
		if (event && settings(current)) {
			// position the helper 15 pixel to bottom right, starting from mouse position
			left = event.pageX + (settings(current).left ? settings(current).left : 0);
			top = event.pageY + (settings(current).top ? settings(current).top : 0);
			if (settings(current).positionLeft) {
				right = $(window).width() - left;
				left = 'auto';
			}
		}
		//hack to determine base position and dimensions
		helper.parent.css({
			visibility: 'hidden',
			left: left,
			right: right,
			top: top
		});
		
		if (settings(current)) {
			var v = viewport(),
				h = helper.parent[0];
			// check horizontal position
			if (v.x + v.cx < h.offsetLeft + h.offsetWidth) {
				left -= h.offsetWidth + settings(current).left;
				if (settings(current).fixPosition) left = Math.max(left, 0);
			}
			// check vertical position
			if (v.y + v.cy < h.offsetTop + h.offsetHeight) {
				top -= h.offsetHeight + settings(current).top;
				if (settings(current).fixPosition) top = Math.max(0, top);
			}
		}
		helper.parent.css({
			visibility: 'visible',
			left: left,
			right: right,
			top: top
		});
		updating = false;
	}
	
	function viewport() {
		return {
			x: $(window).scrollLeft(),
			y: $(window).scrollTop(),
			cx: $(window).width(),
			cy: $(window).height()
		};
	}
	
	// hide helper and restore added classes and the title
	function tHide(event) {
		if($.tooltip.blocked || !!!current)
			return;
		
		var tsettings = settings(current);
		// no more current element
		current = null;
		function complete() {
			if (tsettings && tsettings.extraClass)
				helper.parent.removeClass(tsettings.extraClass);
			helper.parent.hide().css("opacity", "");
		}
		
		if ((!jQuery.browser.msie || !$.fn.bgiframe) && tsettings && tsettings.fade) {
			if (helper.parent.is(':animated'))
				helper.parent.stop().fadeTo(tsettings.fade, 0, complete);
			else
				helper.parent.stop().fadeOut(tsettings.fade, complete);
		} else {
			complete();
		}
	}
	
})(jQuery);
