﻿// Animated, Sliding, Collapsible DIV

// Animation Slide Timer Length
// Adjust these to speed/slow animation
var timerlen = 5;
var slideAniLen = 500;


var timerID = new Array();
var startTime = new Array();
var obj = new Array();
var endHeight = new Array();
var endWidth = new Array();
var moving = new Array();
var movingHor = new Array();
var dir = new Array();
var dirHor = new Array();


function slidedown(objname, objimgname){

	// Switch Image
	document.getElementById(objimgname).src = 'images/blueup.gif';	

	if(moving[objname])
		return;
 
	if(document.getElementById(objname).style.display != "none")
		return; // cannot slide down something that is already visible
 
	moving[objname] = true;
	dir[objname] = "down";
	startslide(objname);
}
 
function slideup(objname, objimgname){

	// Switch Image
	document.getElementById(objimgname).src = 'images/bluedown.gif';	

	if(moving[objname])
		return;
 
	if(document.getElementById(objname).style.display == "none")
		return; // cannot slide up something that is already hidden
 
	moving[objname] = true;
	dir[objname] = "up";
	startslide(objname);
}

function startslide(objname){
	obj[objname] = document.getElementById(objname);
 
	endHeight[objname] = parseInt(obj[objname].style.height);
	startTime[objname] = (new Date()).getTime();
 
	if(dir[objname] == "down"){
		obj[objname].style.height = "1px";
	}
 
	obj[objname].style.display = "block";
 
	timerID[objname] = setInterval('slidetick(\'' + objname + '\');',timerlen);
}

function slidetick(objname){
	var elapsed = (new Date()).getTime() - startTime[objname];
 
	if (elapsed > slideAniLen)
		endSlide(objname)
	else{
		var d =Math.round(elapsed / slideAniLen * endHeight[objname]);
		if(dir[objname] == "up")
			d = endHeight[objname] - d;
 
		obj[objname].style.height = d + "px";
	}
 
	return;
}

function endSlide(objname){
	clearInterval(timerID[objname]);
 
	if(dir[objname] == "up")
		obj[objname].style.display = "none";
 
	obj[objname].style.height = endHeight[objname] + "px";
 
	delete(moving[objname]);
	delete(timerID[objname]);
	delete(startTime[objname]);
	delete(endHeight[objname]);
	delete(obj[objname]);
	delete(dir[objname]);
 
	return;
}

function toggleSlide(objname, objimgname){
	if(document.getElementById(objname).style.display == "none"){
		// div is hidden, so let's slide down
		slidedown(objname, objimgname);
		setCookie(objname,'true','','','','');
	}
	else{
		// div is not hidden, so slide up
		slideup(objname, objimgname);
		setCookie(objname,'false','','','','');
	}
}

function ShowDiv(objname, objimgname){
	document.getElementById(objname).style.display = 'block';
	
  // Switch Image
  document.getElementById(objimgname).src = 'images/blueup.gif';		
}

//////////////////////////////////////////////////////////////////////////
//  QR2 - Right Column Horozontal Slide
//////////////////////////////////////////////////////////////////////////

function slideopen(objname, objimgname){

	// Switch Image
	document.getElementById(objimgname).src = 'images/QR2TabClose.gif';	

	if(movingHor[objname])
		return;
 
	if(document.getElementById(objname).style.display != "none")
		return; // cannot slide open something that is already visible
 
	movingHor[objname] = true;
	dirHor[objname] = "open";
	starthorizontalslide(objname);
}
 
function slideclosed(objname, objimgname){

	// Switch Image
	document.getElementById(objimgname).src = 'images/QR2TabOpen.gif';	

	if(movingHor[objname])
		return;
 
	if(document.getElementById(objname).style.display == "none")
		return; // cannot slide closed something that is already hidden
 
	movingHor[objname] = true;
	dirHor[objname] = "closed";
	starthorizontalslide(objname);
}

function starthorizontalslide(objname){
	obj[objname] = document.getElementById(objname);
 
	endWidth[objname] = parseInt(obj[objname].style.width);
	startTime[objname] = (new Date()).getTime();
 
	if(dirHor[objname] == "open"){
		obj[objname].style.width = "1px";
	}
 
	obj[objname].style.display = "block";
 
	timerID[objname] = setInterval('horslidetick(\'' + objname + '\');',timerlen);
}

function horslidetick(objname){
	var elapsed = (new Date()).getTime() - startTime[objname];
 
	if (elapsed > slideAniLen)
		endhorizontalslide(objname)
	else{
		var d =Math.round(elapsed / slideAniLen * endWidth[objname]);
		if(dirHor[objname] == "closed")
			d = endWidth[objname] - d;
 
		obj[objname].style.width = d + "px";
	}
 
	return;
}

function endhorizontalslide(objname){
	clearInterval(timerID[objname]);
 
	if(dirHor[objname] == "closed")
		obj[objname].style.display = "none";
 
	obj[objname].style.width = endWidth[objname] + "px";
 
	delete(movingHor[objname]);
	delete(timerID[objname]);
	delete(startTime[objname]);
	delete(endWidth[objname]);
	delete(obj[objname]);
	delete(dirHor[objname]);
 
	return;
}

function toggleSideSlide(objname, objimgname){
	if(document.getElementById(objname).style.display == "none"){
		// div is hidden, so let's slide open
		slideopen(objname, objimgname);
		setCookie(objname,'true','','','','');
	}
	else{
		// div is not hidden, so slide closed
		slideclosed(objname, objimgname);
		setCookie(objname,'false','','','','');
	}
}

function ShowHorizontalDiv(objname, objimgname){
	document.getElementById(objname).style.display = 'block';
	
  // Switch Image
  document.getElementById(objimgname).src = 'images/QR2TabClose.gif';		
}

