/*******************************************************************************************************************************************
 * Javascript Utility Functions
 ******************************************************************************************************************************************/
var whitespace = " \t\n\r";

function isPositiveInteger(val) {
    return !isNaN(val) && !isEmpty(val) && !(/\D/.test(val));
}

function getInteger(str, i, minlength, maxlength)
{
   for (var x = maxlength; x >= minlength; x--) 
   {
      var token = str.substring(i, i + x);
      
      if (token.length < minlength) 
      { 
         return null; 
      }
      
      if (isPositiveInteger(token)) 
      { 
         return token; 
      }
   }
   return null;
}

function isDigit(c)
{
   return ((c >= "0") && (c <= "9"));
}

function isEmpty(s)
{
   return ((s == null) || (s.length == 0));
}

function isWhitespace(s)
{
   var i;
   
   if (isEmpty(s)) 
   {
      return true;
   }
   
   for (i = 0; i < s.length; i++)
   {   
      var c = s.charAt(i);
      
      if (whitespace.indexOf(c) == -1) 
      {
         return false;
      }
   }
   
   return true;
}

function checkString(theField, theDesc) {
	if (isWhitespace(theField.value)) {
		theField.focus();
		if(theDesc) alert(theDesc);
		return false;
	} else {
		return true;
	}
}

function checkDate(theDate, dateformat) 
{
   var tempDate = new Date();
   
   tempDate = formatDate(tempDate, "yyyy/MM/dd");
   
   //alert('date = ' + theDate + '\nformat = ' + dateformat);
   
   var result = compareDates(theDate, dateformat, tempDate, "yyyy/MM/dd"); 
   
   if (result == -1)
   {
      return false;
   }
   else
   {
      return true; 
   }
}

function compareDates(date1, dateformat1, date2, dateformat2) 
{
   var d1 = getDateFromFormat(date1, dateformat1);
   var d2 = getDateFromFormat(date2, dateformat2);
   
   if (d1 == 0 || d2 == 0) 
   {
      return -1;
   }
   else if (d1 > d2) 
   {
      return 1;
   }
   
   return 0;
}

function formatDate(date, format) 
{
   format += "";
   
   var result = "";
   var i_format = 0;
   var c = "";
   var token = "";
   var y = date.getYear() + "";
   var M = date.getMonth() + 1;
   var d = date.getDate();
   var H = date.getHours();
   var m = date.getMinutes();
   var s = date.getSeconds();
   var yyyy, yy, MMM, MM, dd, hh, h, mm, ss, ampm, HH, H, KK, K, kk, k;
   // Convert real date parts into formatted versions
   var value = new Object();
   
   if (y.length < 4) 
   {
      y -= 0;
      if (y > 70)
      {
         y = "" + (y - 0 + 1900);
      }
      else
      {
         y = "" + (y - 0 + 2000);
      }
   }
   
   value["y"] = "" + y;
   value["yyyy"] = y;
   value["yy"] = y.substring(2, 4);
   value["M"] = M;
   value["MM"] = LZ(M);
   value["MMM"] = MONTH_NAMES[M - 1];
   value["d"] = d;
   value["dd"] = LZ(d);
   value["H"] = H;
   value["HH"] = LZ(H);
   
   if (H == 0)
   {
      value["h"] = 12;
   }   
   else if (H > 12)
   {
      value["h"] = H - 12;
   }
   else 
   {  
      value["h"] = H;
   }
   
   value["hh"] = LZ(value["h"]);
   
   if (H > 11)
   {
      value["K"] = H - 12;
   } 
   else 
   {
      value["K"] = H;
   }
   
   value["k"] = H + 1;
   value["KK"] = LZ(value["K"]);
   value["kk"] = LZ(value["k"]);
   
   if (H > 11) 
   { 
      value["a"] = "PM"; 
   }
   else 
   { 
      value["a"] = "AM"; 
   }
   
   value["m"] = m;
   value["mm"] = LZ(m);
   value["s"] = s;
   value["ss"] = LZ(s);
   
   while (i_format < format.length) 
   {
      c = format.charAt(i_format);
      token = "";
      
      while ((format.charAt(i_format) == c) && (i_format < format.length)) 
      {
         token += format.charAt(i_format++);
      }
      
      if (value[token] != null) 
      { 
         result = result + value[token]; 
      }
      else 
      { 
         result = result + token; 
      }
   }
   
   return result;
}

function getDateFromFormat(val, format) 
{
   var validDateSeperators = '/-. ';
   
   val = val + "";
   format = format + "";
   
   var i_val = 0;
   var i_format = 0;
   var c = "";
   var token = "";
   var token2 = "";
   var x;
   var y;
   var now = new Date();
   var year = now.getYear();
   var month = now.getMonth() + 1;
   var date = now.getDate();
   var hh = now.getHours();
   var mm = now.getMinutes();
   var ss = now.getSeconds();
   var ampm = "";
   
   while (i_format < format.length) 
   {
      // Get next token from format string
      c = format.charAt(i_format);
      token = "";
      
      while ((format.charAt(i_format) == c) && (i_format < format.length)) 
      {
         token += format.charAt(i_format++);
      }
      
      // parse off possible data seperator that is not in the format string
      if (validDateSeperators.indexOf(val.charAt(i_val)) > -1 && !(val.substring(i_val, i_val + token.length) == token))
      {
         ++i_val;
      }
      
      // Extract contents of value based on format token
      if (token == "yyyy" || token == "yy" || token == "y") 
      {
         if (token == "yyyy") 
         { 
            x = 4;
            y = 4; 
         }
         
         if (token == "yy")   
         { 
            x = 2;
            y = 2; 
         }
         
         if (token == "y")    
         { 
            x = 2;
            y = 4; 
         }
         
         year = getInteger(val, i_val, x, y);
         //alert('year = ' + year);
         
         if (year == null) 
         { 
            return 0; 
         }
         
         i_val += year.length;
         
         if (year.length==2) 
         {
            if (year > 70) 
            { 
               year = 1900 + (year - 0);
            }
            else 
            { 
               year = 2000 + (year - 0); 
            }
         }
      }
      else if (token == "MMM")
      {
         month = 0;
         for (var i = 0; i < MONTH_NAMES.length; i++) 
         {
            var month_name = MONTH_NAMES[i];
            if (val.substring(i_val, i_val + month_name.length).toLowerCase() == month_name.toLowerCase()) 
            {
               month = i + 1;
               if (month > 12) 
               { 
                  month -= 12; 
               }
               
               i_val += month_name.length;
               break;
            }
         }
         if ((month < 1) || (month > 12))
         {
            return 0;
         }
      }
      else if (token == "MM" || token == "M") 
      {
         month = getInteger(val, i_val, token.length, 2);
         //alert('month = ' + month);
         if(month == null || (month < 1) || (month > 12))
         {
            return 0;
         }
         
         i_val += month.length;
      }
      else if (token == "dd" || token == "d") 
      {
         date = getInteger(val, i_val, token.length, 2);
         //alert('date = ' + date);
         if(date == null || (date < 1) || (date > 31))
         {
            return 0;
         }
         
         i_val += date.length;
      }
      else if (token == "hh" || token == "h") 
      {
         hh = getInteger(val, i_val, token.length, 2);
         if(hh == null || (hh < 1) || (hh > 12))
         {
            return 0;
         }
         
         i_val += hh.length;
      }
      else if (token == "HH" || token == "H") 
      {
         hh = getInteger(val, i_val, token.length, 2);
         if(hh == null || (hh < 0) || (hh > 23))
         {
            return 0;
         }
         
         i_val += hh.length;
      }
      else if (token == "KK" || token == "K") 
      {
         hh = getInteger(val, i_val, token.length, 2);
         if(hh == null || (hh < 0) || (hh > 11))
         {
            return 0;
         }
         
         i_val += hh.length;
      }
      else if (token == "kk" || token == "k") 
      {
         hh = getInteger(val, i_val, token.length, 2);
         if(hh == null || (hh < 1) || (hh > 24))
         {
            return 0;
         }
         
         i_val += hh.length;
         --hh;
      }
      else if (token == "mm" || token == "m") 
      {
         mm = getInteger(val, i_val, token.length, 2);
         if(mm == null || (mm < 0) || (mm > 59))
         {
            return 0;
         }
         
         i_val += mm.length;
      }
      else if (token == "ss" || token == "s") 
      {
         ss = getInteger(val, i_val, token.length, 2);
         if(ss == null || (ss < 0) || (ss > 59))
         {
            return 0;
         }
         
         i_val += ss.length;
      }
      else if (token == "a") 
      {
         if (val.substring(i_val, i_val + 2).toLowerCase() == "am") 
         {
            ampm = "AM";
         }
         else if (val.substring(i_val, i_val + 2).toLowerCase() == "pm") 
         {
            ampm = "PM";
         }
         else 
         {
            return 0;
         }
         
         i_val += 2;
      }
      else 
      {
         if (val.substring(i_val, i_val + token.length) == token)
         {
            i_val += token.length;
         }
         // this checks for the case where the seperators do not match.
         // ie:
         // -- format = d/M/y
         // -- passed in date matches this pattern = d.M.y or d-M-y or d M y
         // any of the passed in dates would work with the passed in string format due to below code.
         else if (!(validDateSeperators.indexOf(c) > -1))
         {
            return 0;
         }
      }
   }
   
   // If there are any trailing characters left in the value, it doesn't match
   if (i_val != val.length) 
   { 
      return 0; 
   }
   
   // Is date valid for month?
   if (month == 2) 
   {
      // Check for leap year
      if ( ( (year % 4 == 0) && (year % 100 != 0) ) || (year % 400 == 0) ) 
      { // leap year
         if (date > 29)
         { 
            return 0; 
         }
      }
      else 
      { 
         if (date > 28) 
         { 
            return 0; 
         } 
      }
   }
   
   if ((month == 4) || (month == 6) || (month == 9) || (month == 11)) 
   {
      if (date > 30) 
      { 
         return 0; 
      }
   }
   
   // Correct hours value
   if (hh < 12 && ampm == "PM") 
   { 
      hh += 12; 
   }
   else if (hh > 11 && ampm == "AM") 
   { 
      hh -= 12; 
   }
   
   var newdate = new Date(year, month - 1, date, hh, mm, ss);
   
   return newdate.getTime();
}