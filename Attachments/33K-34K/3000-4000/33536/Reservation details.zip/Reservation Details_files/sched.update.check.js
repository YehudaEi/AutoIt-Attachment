function checkCapacity(resID, resType, setupID, numAttendees) {
	var ret = true;
	if (numAttendees && numAttendees > 0) {
		$j.ajax({
			url: "SchedUpdateCheck_ajax.asp",
			cache: false,
			async: false,
			dataType: "json",
			data: {
				resID: resID,
				resType: resType,
				resSetup: setupID
			},
			success: function(result) {
				if (result.capacity > 0 && result.capacity < numAttendees) {
					ret = false;
				}
			}
		});
	}
	return ret;
}

function checkSchedCapacityExt(schedID, numAttendees, resList, setupList, oldResID, oldResType, oldSetupID, resID, resType, setupID) {
	var ret = true;
	if (numAttendees && numAttendees > 0) {
		$j.ajax({
			url: "SchedUpdateCheck_ajax.asp",
			cache: false,
			async: false,
			traditional: true,
			dataType: "json",
			data: {
				schedID: schedID,
				oldResID: oldResID,
				oldResType: oldResType,
				oldResSetup: oldSetupID,
				resID: resID,
				resType: resType,
				resSetup: setupID,
				resList: resList,
				setupList: setupList
			},
			success: function(result) {
				if (result.capacity > 0 && result.capacity < numAttendees) {
					ret = false;
				}
			}
		});
	}
	return ret;
}

function checkResListCapacity(numAttendees, resList, setupList) {
	return checkSchedCapacityExt(undefined, numAttendees, resList, setupList);
}

function checkSchedCapacity(schedID, numAttendees) {
	return checkSchedCapacityExt(schedID, numAttendees);
}

function checkSchedCapacitySwitch(schedID, numAttendees, oldResID, oldResType, oldSetupID, resID, resType, setupID) {
	return checkSchedCapacityExt(schedID, numAttendees, undefined, undefined, oldResID, oldResType, oldSetupID, resID, resType, setupID);
}

function checkSchedCapacityAddl(schedID, numAttendees, resList, setupList) {
	return checkSchedCapacityExt(schedID, numAttendees, resList, setupList);
}
