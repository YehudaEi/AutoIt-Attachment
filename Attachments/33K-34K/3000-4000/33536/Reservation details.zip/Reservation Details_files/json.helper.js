﻿(function() {
	var _origParse = JSON.parse;
	JSON.parse = function(text) {
		return _origParse(text,
			function(key, value) {
				if (typeof value === "string") {
					var s = /^(\d{4})-(\d{2})-(\d{2})T(\d{2}):(\d{2}):(\d{2}(?:\.\d*)?)Z$/.exec(value);
					if (s) {
						return new Date(+s[1], +s[2] - 1, +s[3], +s[4], +s[5], +s[6]);
					}
				}

				return value;
			});
	};
})();
