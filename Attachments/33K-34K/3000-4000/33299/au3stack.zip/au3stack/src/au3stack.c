/*
	A simple stack implementation for the AutoIt scripting language
    Copyright (C) 2011  Michael Henke

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

#include <stdio.h>
#include <windows.h>
#include "AU3_Plugin_SDK\au3plugin.h"
#include "stack.h"

static void copy_plugin_var_value(AU3_PLUGIN_VAR* dest, const AU3_PLUGIN_VAR* src)
{
	char* str = NULL;
	
	switch(AU3_GetType(src))
	{
	case AU3_PLUGIN_INT32:
		AU3_SetInt32(dest, AU3_GetInt32(src));
		break;
	case AU3_PLUGIN_INT64:
		AU3_SetInt64(dest, AU3_GetInt64(src));
		break;
	case AU3_PLUGIN_DOUBLE:
		AU3_SetDouble(dest, AU3_GetDouble(src));
		break;
	case AU3_PLUGIN_STRING:
		str = AU3_GetString(src);
		AU3_SetString(dest, str);
		AU3_FreeString(str);
		break;
	case AU3_PLUGIN_HWND:
		AU3_SethWnd(dest, AU3_GethWnd(src));
		break;
	}
}

static int cmp_plugin_vars(const void* vA, const void* vB)
{
	const AU3_PLUGIN_VAR* a = *((AU3_PLUGIN_VAR**)vA);
	const AU3_PLUGIN_VAR* b = *((AU3_PLUGIN_VAR**)vB);
	int type, type_cmp;
	int len, len_cmp;
	char *sA = NULL;
	char *sB = NULL;
	int cmp;
	__int64 l_cmp;
	double d_cmp;

	type = AU3_GetType(a);
	type_cmp = type - AU3_GetType(b);
	if(type_cmp != 0)
	{
		return type_cmp;
	}
	
	switch(type)
	{
	case AU3_PLUGIN_INT32:
		return AU3_GetInt32(a) - AU3_GetInt32(b);
		break;
	case AU3_PLUGIN_INT64:
		l_cmp = AU3_GetInt64(a) - AU3_GetInt64(b);
		if(l_cmp > 0)
		{
			return 1;
		}
		else if(l_cmp < 0)
		{
			return -1;
		}
		else
		{
			return 0;
		}
		break;
	case AU3_PLUGIN_DOUBLE:
		d_cmp = AU3_GetDouble(a) - AU3_GetDouble(b);
		if(d_cmp > 0)
		{
			return 1;
		}
		else if(d_cmp < 0)
		{
			return -1;
		}
		else
		{
			return 0;
		}
		break;
	case AU3_PLUGIN_STRING:
		sA = AU3_GetString(a);
		sB = AU3_GetString(b);
		len = strlen(sA);
		len_cmp = len - strlen(sB);
		if(len_cmp != 0)
		{
			cmp = len_cmp;
		}
		else {
			cmp = memcmp(sA,sB,len);
		}
		AU3_FreeString(sA);
		AU3_FreeString(sB);
		return cmp;
		break;
	case AU3_PLUGIN_HWND:
		l_cmp = AU3_GethWnd(a) - AU3_GethWnd(b);
		if(l_cmp > 0)
		{
			return 1;
		}
		else if(l_cmp < 0)
		{
			return -1;
		}
		else
		{
			return 0;
		}
		break;
	}
	
	return 0;
}

AU3_PLUGIN_FUNC g_AU3_Funcs[] = 
{
	{"Stack_Init", 0, 0},
	{"Stack_Iter", 1, 1},
	{"Stack_Push", 2, 2},
	{"Stack_Pop", 1, 1},
	{"Stack_Get", 1, 1},
	{"Stack_GetAt", 2, 2},
	{"Stack_SetAt", 3, 3},
	{"Stack_Find", 2, 2},
	{"Stack_Sort", 1, 2},
	{"Stack_Count", 1, 1},
	{"Stack_Free", 1, 2}
};

AU3_PLUGINAPI int AU3_GetPluginDetails(int *n_AU3_NumFuncs, AU3_PLUGIN_FUNC **p_AU3_Func)
{
	/* Pass back the number of functions that this DLL supports */
	*n_AU3_NumFuncs	= sizeof(g_AU3_Funcs)/sizeof(AU3_PLUGIN_FUNC);

	/* Pack back the address of the global function table */
	*p_AU3_Func = g_AU3_Funcs;

	return AU3_PLUGIN_OK;
}

BOOL WINAPI DllMain(HANDLE hInst, ULONG ul_reason_for_call, LPVOID lpReserved)
{
	switch (ul_reason_for_call)
	{
	case DLL_PROCESS_ATTACH:
	case DLL_THREAD_ATTACH:
	case DLL_THREAD_DETACH:
	case DLL_PROCESS_DETACH:
		break;
	}
	return TRUE;
}

AU3_PLUGIN_DEFINE(Stack_Init)
{
	AU3_PLUGIN_VAR* pMyResult = NULL;
	stack_t* stack = NULL;

	stack = malloc(sizeof(stack_t));
	stack_init(stack);
	pMyResult = AU3_AllocVar();
	AU3_SetInt32(pMyResult, (int)stack);
	
	// ----------------------
	*p_AU3_Result = pMyResult;
	*n_AU3_ErrorCode = 0;
	*n_AU3_ExtCode = 0;
	
	return AU3_PLUGIN_OK;
}

/*
	@error 1 - first parameter wrong
*/
AU3_PLUGIN_DEFINE(Stack_Iter)
{
	AU3_PLUGIN_VAR* pMyResult = NULL;
	stack_t* stack = NULL;
	stack_t* newStack = NULL;
	
	if(AU3_GetType(&p_AU3_Params[0]) != AU3_PLUGIN_INT32)
	{
		*n_AU3_ErrorCode = 1;
		return AU3_PLUGIN_OK;
	}
	
	stack = (stack_t*)AU3_GetInt32(&p_AU3_Params[0]);
	newStack = malloc(sizeof(stack_t));
	*newStack = *stack;
	
	pMyResult = AU3_AllocVar();
	AU3_SetInt32(pMyResult, (int)newStack);
	
	// ----------------------
	*p_AU3_Result = pMyResult;
	*n_AU3_ErrorCode = 0;
	*n_AU3_ExtCode = 0;
	
	return AU3_PLUGIN_OK;
}

/*
	@error 1 - first parameter wrong
*/
AU3_PLUGIN_DEFINE(Stack_Push)
{
	stack_t* stack = NULL;
	AU3_PLUGIN_VAR* value = NULL;
	
	
	if(AU3_GetType(&p_AU3_Params[0]) != AU3_PLUGIN_INT32)
	{
		*n_AU3_ErrorCode = 1;
		return AU3_PLUGIN_OK;
	}
	
	stack = (stack_t*)AU3_GetInt32(&p_AU3_Params[0]);
	
	value = AU3_AllocVar();
	copy_plugin_var_value(value, &p_AU3_Params[1]);
	stack_push(stack, (void*)value);
	
	// ----------------------
	*p_AU3_Result = NULL;
	*n_AU3_ErrorCode = 0;
	*n_AU3_ExtCode = 0;
	
	return AU3_PLUGIN_OK;
}

/*
	@error 1 - first parameter wrong
	@error 2 - no value in stack
*/
AU3_PLUGIN_DEFINE(Stack_Pop)
{
	AU3_PLUGIN_VAR* pMyResult = NULL;
	stack_t* stack = NULL;
	AU3_PLUGIN_VAR* value = NULL;
	
	if(AU3_GetType(&p_AU3_Params[0]) != AU3_PLUGIN_INT32)
	{
		*n_AU3_ErrorCode = 1;
		return AU3_PLUGIN_OK;
	}
	
	stack = (stack_t*)AU3_GetInt32(&p_AU3_Params[0]);
	value = (AU3_PLUGIN_VAR*)stack_pop(stack);
	
	if(value == NULL)
	{
		pMyResult = AU3_AllocVar();
		AU3_SetInt32(pMyResult, -1);
		*n_AU3_ErrorCode = 2;
	}
	else
	{
		pMyResult = value;
		*n_AU3_ErrorCode = 0;
	}
	
	// ----------------------
	*p_AU3_Result = pMyResult;
	*n_AU3_ExtCode = 0;
	
	return AU3_PLUGIN_OK;
}

/*
	@error 1 - first parameter wrong
	@error 2 - no value in stack
*/
AU3_PLUGIN_DEFINE(Stack_Get)
{
	AU3_PLUGIN_VAR* pMyResult = NULL;
	stack_t* stack = NULL;
	AU3_PLUGIN_VAR* value = NULL;
	
	if(AU3_GetType(&p_AU3_Params[0]) != AU3_PLUGIN_INT32)
	{
		*n_AU3_ErrorCode = 1;
		return AU3_PLUGIN_OK;
	}
	
	stack = (stack_t*)AU3_GetInt32(&p_AU3_Params[0]);
	value = (AU3_PLUGIN_VAR*)stack_get(stack);
	
	pMyResult = AU3_AllocVar();
	if(value == NULL)
	{
		AU3_SetInt32(pMyResult, -1);
		*n_AU3_ErrorCode = 2;
	}
	else
	{
		copy_plugin_var_value(pMyResult, (const AU3_PLUGIN_VAR*)value);
		*n_AU3_ErrorCode = 0;
	}
	
	// ----------------------
	*p_AU3_Result = pMyResult;
	*n_AU3_ExtCode = 0;
	
	return AU3_PLUGIN_OK;
}

/*
	@error 1 - first parameter wrong
	@error 2 - second parameter wrong
	@error 3 - offset less than 0
	@error 4 - no element at offset
*/
AU3_PLUGIN_DEFINE(Stack_GetAt)
{
	AU3_PLUGIN_VAR* pMyResult = NULL;
	int offset;
	int i;
	stack_t* stack = NULL;
	stack_t iter;
	AU3_PLUGIN_VAR* value = NULL;
	AU3_PLUGIN_VAR* found = NULL;
	
	if(AU3_GetType(&p_AU3_Params[0]) != AU3_PLUGIN_INT32)
	{
		*n_AU3_ErrorCode = 1;
		return AU3_PLUGIN_OK;
	}
	
	if(AU3_GetType(&p_AU3_Params[1]) != AU3_PLUGIN_INT32)
	{
		*n_AU3_ErrorCode = 2;
		return AU3_PLUGIN_OK;
	}
	
	// only positive offset values are allowed
	offset = AU3_GetInt32(&p_AU3_Params[1]);
	if(offset < 0)
	{
		pMyResult = AU3_AllocVar();
		AU3_SetInt32(pMyResult, 0);
		*n_AU3_ErrorCode = 3;
		return AU3_PLUGIN_OK;
	}
	
	stack = (stack_t*)AU3_GetInt32(&p_AU3_Params[0]);
	iter = *stack;
	
	for(i = offset;(value = (AU3_PLUGIN_VAR*)stack_get(&iter)) != NULL;i--)
	{
		if(i==0)
		{
			found = value;
			break;
		}
	}
	
	pMyResult = AU3_AllocVar();
	if(found == NULL)
	{
		AU3_SetInt32(pMyResult, 0);
		*n_AU3_ErrorCode = 4;
	}
	else
	{
		copy_plugin_var_value(pMyResult, (const AU3_PLUGIN_VAR*)value);
		*n_AU3_ErrorCode = 0;
	}
	
	// ----------------------
	*p_AU3_Result = pMyResult;
	*n_AU3_ExtCode = 0;
	
	return AU3_PLUGIN_OK;
}

/*
	@error 1 - first parameter wrong
	@error 2 - second parameter wrong
	@error 3 - offset less than 0
	@error 4 - no element at offset
*/
AU3_PLUGIN_DEFINE(Stack_SetAt)
{
	int offset;
	int i;
	stack_t* stack = NULL;
	stack_t iter;
	AU3_PLUGIN_VAR* temp = NULL;
	int found = 4;
	
	if(AU3_GetType(&p_AU3_Params[0]) != AU3_PLUGIN_INT32)
	{
		*n_AU3_ErrorCode = 1;
		return AU3_PLUGIN_OK;
	}
	
	if(AU3_GetType(&p_AU3_Params[1]) != AU3_PLUGIN_INT32)
	{
		*n_AU3_ErrorCode = 2;
		return AU3_PLUGIN_OK;
	}

	// only positive offset values are allowed
	offset = AU3_GetInt32(&p_AU3_Params[1]);
	if(offset < 0) {	
		*n_AU3_ErrorCode = 3;
		return AU3_PLUGIN_OK;
	}
	
	stack = (stack_t*)AU3_GetInt32(&p_AU3_Params[0]);
	iter = *stack;

	for(i = offset; (temp = (AU3_PLUGIN_VAR*)stack_get(&iter)) != NULL; i--)
	{
		if(i==0)
		{
			copy_plugin_var_value(temp, &p_AU3_Params[2]);
			found = 0;
			break;
		}
	}
	
	// ----------------------
	*n_AU3_ErrorCode = found;
	*p_AU3_Result = NULL;
	*n_AU3_ExtCode = 0;
	
	return AU3_PLUGIN_OK;
}

/*
	@error 1 - first parameter wrong
*/
AU3_PLUGIN_DEFINE(Stack_Find)
{
	AU3_PLUGIN_VAR* pMyResult = NULL;
	int i, offset;
	stack_t* stack = NULL;
	stack_t iter;
	const AU3_PLUGIN_VAR* tofind = NULL;
	AU3_PLUGIN_VAR* value = NULL;
	
	if(AU3_GetType(&p_AU3_Params[0]) != AU3_PLUGIN_INT32)
	{
		*n_AU3_ErrorCode = 1;
		return AU3_PLUGIN_OK;
	}
	
	stack = (stack_t*)AU3_GetInt32(&p_AU3_Params[0]);
	iter = *stack;
	
	tofind = &p_AU3_Params[1];
	
	i = 0;
	offset = -1;
	for(;(value = (AU3_PLUGIN_VAR*)stack_get(&iter)) != NULL; i++)
	{
		if(cmp_plugin_vars((const void*) &tofind, (const void*) &value) == 0)
		{
			offset = i;
			break;
		}
	}
	
	pMyResult = AU3_AllocVar();
	AU3_SetInt32(pMyResult, offset);
	
	// ----------------------
	*p_AU3_Result = pMyResult;
	*n_AU3_ExtCode = 0;
	*n_AU3_ErrorCode = 0;
	
	return AU3_PLUGIN_OK;
}

/*
	@error 1 - first parameter wrong
	@error 2 - second parameter wrong
*/
AU3_PLUGIN_DEFINE(Stack_Sort)
{
	int i, count;
	stack_t* stack = NULL;
	AU3_PLUGIN_VAR* value = NULL;
	AU3_PLUGIN_VAR** tempArray = NULL;
	int desc = 1;
	
	if(AU3_GetType(&p_AU3_Params[0]) != AU3_PLUGIN_INT32)
	{
		*n_AU3_ErrorCode = 1;
		return AU3_PLUGIN_OK;
	}
	
	if(n_AU3_NumParams == 2)
	{
		if(AU3_GetType(&p_AU3_Params[1]) != AU3_PLUGIN_INT32)
		{
			*n_AU3_ErrorCode = 2;
			return AU3_PLUGIN_OK;
		}
		desc = (AU3_GetInt32(&p_AU3_Params[1]) == 1) ? 1 : 0;
	}
	
	stack = (stack_t*)AU3_GetInt32(&p_AU3_Params[0]);
	count = stack_count(stack);
	if(count == 0)
	{
		*n_AU3_ErrorCode = 0;
		return AU3_PLUGIN_OK;
	}
	
	// bring the stack into an array representation
	tempArray = malloc(sizeof(AU3_PLUGIN_VAR) * count);
	i = 0;
	while((value = stack_pop(stack)) != NULL)
	{
		tempArray[i] = value;
		i++;
	}
	
	// sort it
	qsort (tempArray, count, sizeof(AU3_PLUGIN_VAR*), cmp_plugin_vars);

	// bring it back into a stack representation
	stack->entries = 0;
	if(desc == 1) 
	{
		for(i = 0; i < count; i++) 
		{
			stack_push(stack, tempArray[i]);
		}
	}
	else
	{
		for(i = count - 1; i >= 0; i--) 
		{
			stack_push(stack, tempArray[i]);
		}
	}
	free(tempArray);
	
	// ----------------------
	*p_AU3_Result = NULL;
	*n_AU3_ExtCode = 0;
	*n_AU3_ErrorCode = 0;
	
	return AU3_PLUGIN_OK;
}


/*
	@error 1 - first parameter wrong
*/
AU3_PLUGIN_DEFINE(Stack_Count)
{
	AU3_PLUGIN_VAR* pMyResult = NULL;
	stack_t* stack = NULL;
	
	if(AU3_GetType(&p_AU3_Params[0]) != AU3_PLUGIN_INT32)
	{
		*n_AU3_ErrorCode = 1;
		return AU3_PLUGIN_OK;
	}
	
	stack = (stack_t*)AU3_GetInt32(&p_AU3_Params[0]);
	pMyResult = AU3_AllocVar();
	AU3_SetInt32(pMyResult, stack_count(stack));
	
	// ----------------------
	*p_AU3_Result = pMyResult;
	*n_AU3_ErrorCode = 0;
	*n_AU3_ExtCode = 0;
	
	return AU3_PLUGIN_OK;
}

/*
	@error 1 - first parameter wrong
	@error 2 - second parameter wrong
*/
AU3_PLUGIN_DEFINE(Stack_Free)
{
	AU3_PLUGIN_VAR* value = NULL;
	stack_t* stack = NULL;
	int doClear = 1;
	
	if(AU3_GetType(&p_AU3_Params[0]) != AU3_PLUGIN_INT32)
	{
		*n_AU3_ErrorCode = 1;
		return AU3_PLUGIN_OK;
	}
	
	if(n_AU3_NumParams == 2)
	{
		if(AU3_GetType(&p_AU3_Params[1]) != AU3_PLUGIN_INT32)
		{
			*n_AU3_ErrorCode = 2;
			return AU3_PLUGIN_OK;
		}
		doClear = (AU3_GetInt32(&p_AU3_Params[1]) == 1) ? 1 : 0;
	}

	stack = (stack_t*)AU3_GetInt32(&p_AU3_Params[0]);
	if(doClear)
	{
		while((value = stack_pop(stack)) != NULL)
		{
			AU3_FreeVar(value);
		}
	}
	free(stack);
	
	// ----------------------
	*p_AU3_Result = NULL;
	*n_AU3_ErrorCode = 0;
	*n_AU3_ExtCode = 0;
	
	return AU3_PLUGIN_OK;
}
