/*
	A stack implementation
    Copyright (C) 2011  Michael Henke

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

#ifndef _STACK_H
#define _STACK_H

#include <stdlib.h>

/// A simple stack
typedef struct stack_t
{
	/// number of entries
	unsigned int entries;
    /// the value of the stack
    void *value;
    /// a pointer to the next item in the stack <br>(NULL if the stack is empty)
    struct stack_t *next;
	
} stack_t;

void stack_init(stack_t* stack);
void stack_push(stack_t* stack, void* value);
void* stack_pop(stack_t* stack);
void* stack_get(stack_t* stack);
int stack_count(stack_t* stack);

#endif
