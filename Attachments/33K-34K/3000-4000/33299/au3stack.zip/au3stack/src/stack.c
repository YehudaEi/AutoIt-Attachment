/*
	A stack implementation
    Copyright (C) 2011  Michael Henke

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

#include "stack.h"

/**
    Initializes the stack
    @param stack the stack
*/
void stack_init(stack_t* stack)
{
	stack->entries = 0;
	stack->next = NULL;
	stack->value = NULL;
}

/**
    Pushs a new item onto the stack
    @param stack the stack
    @param value the new value to be put onto the stack
*/
void stack_push(stack_t* stack, void* value)
{
	stack_t* tmpstack = NULL;
	
	tmpstack = malloc(sizeof(stack_t));
	tmpstack->value = value;
	tmpstack->next = stack->next;
	tmpstack->entries = stack->entries += 1;
	stack->next = tmpstack;
}

/**
    Pops an item from the stack
    @param stack the stack
    @return the item upmost on the stack, if no item is left NULL shall be returned
*/
void* stack_pop(stack_t* stack)
{
	stack_t* tmpstack;
	void* ret = NULL;

	if(stack->next != NULL)
	{
		tmpstack = stack->next;
		ret = tmpstack->value;
		stack->next = tmpstack->next;
		free(tmpstack);
	}

	return ret;
}

/**
    Gets an item from the stack without removing it.<br>
    The stack however will point to the next item.<br>
    So the original stack should be safed before using this.<br>
    (its useful for iterating through the stack)
    @param stack the stack
    @return the item upmost on the stack, if no item is left NULL shall be returned
*/
void* stack_get(stack_t* stack)
{
	stack_t* tmpstack;
	void* ret = NULL;

	if(stack->next != NULL)
	{
		tmpstack = stack->next;
		ret = tmpstack->value;
		stack->next = tmpstack->next;
	}

	return ret;
}

int stack_count(stack_t* stack)
{
	if(stack->next != NULL)
	{
		return stack->next->entries;
	}
	else
	{
		return 0;
	}
}
