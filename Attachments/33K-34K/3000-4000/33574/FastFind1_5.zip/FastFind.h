/*
	Copyright 2011 FastFrench (fastfrench@laposte.net)

	Header file for FastFind dll. To be used for Wrappers implementation. 

	FastFind 1.5

	You can freely distribute the full FastFind package as long as you don't claim 
	this as yours. 
*/


// Exclusion area management
bool WINAPI IsExcluded(int x, int y, HWND hWnd);
void WINAPI ResetExcludedAreas();
void WINAPI AddExcludedArea(int x1, int y1, int x2, int y2);

// Color mngt
int WINAPI AddColor (int NewColor);
int WINAPI RemoveColor (int NewColor);
void WINAPI ResetColors ();


// Configuration
void WINAPI SetDebugMode(int NewMode);
void WINAPI SetHWnd(HWND NewWindowHandle, bool bClientArea);
LPCTSTR WINAPI GetLastErrorMsg();

// Single pixel functions
int WINAPI FFGetPixel(int X, int Y, int NoSnapShot);
int WINAPI ColorPixelSearch(int &XRef, int &YRef, int ColorToFind, int NoSnapShot);

// Snapshots
int WINAPI SnapShot(int aLeft, int aTop, int aRight, int aBottom, int NoSnapShot);

// Functions explicitely using the color list
int WINAPI ColorsPixelSearch(int &XRef, int &YRef, int NoSnapShot);
int WINAPI ColorsSearch(int SizeSearch, int &NbMatchMin, int &XRef, int &YRef, int NoSnapShot);

// Generic optimized function, this one will be used in most cases at the end
int WINAPI GenericColorSearch(int SizeSearch, int &NbMatchMin, int &XRef, int &YRef, int ColorToFind, int ShadeVariation, int NoSnapShot);

// Ever more powerful function, to avoid the use of dichotomy to find the best spot
int WINAPI ProgressiveSearch(int SizeSearch, int &NbMatchMin, int NbMatchMax, int &XRef, int &YRef, int ColorToFind/*-1 if several colors*/, int ShadeVariation, int NoSnapShot);

// This simple function count how many pixels exist for a given color. This one do not support color list. 
int WINAPI ColorCount(int ColorToFind, int NoSnapShot, int ShadeVariation);

// Changes detection
int WINAPI HasChanged(int NoSnapShot, int NoSnapShot2);
int WINAPI LocalizeChanges(int NoSnapShot, int NoSnapShot2, int &xMin, int &yMin, int &xMax, int &yMax, int &nbFound);

// Misc functions
LPCTSTR WINAPI GetLastErrorMsg(void);
LPCTSTR WINAPI FFVersion(void);
