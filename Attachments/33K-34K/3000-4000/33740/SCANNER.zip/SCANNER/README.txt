by Gian


I cannot scan or load all the virus database in the virusdatabase.txt
Line 1 only
line 2 cannot read
