Module Main

Public Declare Function GetTickCount Lib "kernel32" () As Long
Sub Main()

System.Console.WriteLine()
System.Console.WriteLine()
System.Console.WriteLine(GetTickCount)

End Sub
End Module'
