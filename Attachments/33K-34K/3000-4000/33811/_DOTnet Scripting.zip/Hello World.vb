module main

public sub main()

Msgbox("Hello World from DotNET Script !")

end sub
end module