This is a math UDF that can function as a much more capible replacement for the built in math UDF that comes with AutoIt
You can use the "Replace Default Math UDF" script to do this (it can also make a backup of the old one for you)

Change log:

Update 1-
All Trig and inverse trig functions can now be used in Radians, Degrees, or Gradians
Added _Sin, _Cos, _Tan, _ASin, _ACos, _ATan, _Reference, and _Simplify
Slight upgrade to _Angle

Update 2-
Added support for Minutes and Seconds to _Angle (and thus to all other trig functions)
Added _MaxLst, _MinLst, _AvgLst, _SumLst
Fixed _Factorial
Upgraded Error returns and function headers

Update 3-
Added _Min, _Max, _Degree, _Radian, _MathCheckDiv, _ATan2
Fixed _Factorial
This UDF can now function as a complete replacement for the default math include biggrin.gif
All duplicate functions will act like the default ones unless additional arguments are supplied

Update 4-
Lots of Bug-Fixes
Started adding example scripts

Update 5-
More bug fixes
Finished example scripts
Added _IsFactorial and _Bound
_IsFactorial and _IsTriangular now also function as the inverse operations of _Factorial and _Triangular 

Update 6-
Cleanup
Added _IsBound, _ASortLst, and _DSortLst
Slight bug fixes