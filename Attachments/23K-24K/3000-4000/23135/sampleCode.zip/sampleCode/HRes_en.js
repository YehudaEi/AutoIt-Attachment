
// Sub Menu Options for Menu1 (Ez Menu)
	var m1_subMenu1 = "Profile";				// Profile
	var m1_subMenu2 = "Auto Function";			// Auto Function
	var m1_subMenu3 = "f-ENGINE";				// f-ENGINE
	var m1_subMenu4 = "Fine Window";			// Fine Window	
	var m1_subMenu5 = "Wizard";					// Wizard	





//EZ Menu - Introduction
	var EZ_Menu_Title = "ez Menu";
	var EZ_Menu_Introduction_section1 = "This section describes the ez Menu and related functionalities.";


