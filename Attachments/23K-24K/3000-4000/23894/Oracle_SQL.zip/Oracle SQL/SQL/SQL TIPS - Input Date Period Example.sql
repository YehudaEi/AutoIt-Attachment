select * from TABLE 
where DATE 
		BETWEEN to_Date(('ff/ff/ffff'),'dd/mm/yyyy') 
		AND to_Date(('tt/tt/tttt'),'dd/mm/yyyy')+1