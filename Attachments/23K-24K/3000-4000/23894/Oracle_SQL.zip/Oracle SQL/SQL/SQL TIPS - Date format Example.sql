select 
	sysdate as "Sysdate Raw",
	to_char(sysdate, 'DD/MM/YY HH24:MI') as "Sysdate EU short Format",
	to_char(sysdate-0.5, 'Dy DD/Mon/YYYY HH24:MI') as "12 Hours ago EU Long Format",
	to_char(sysdate, 'MM/DD/YY HH12:MI PM') as "Sysdate US short Format",
	to_char(sysdate-0.5, 'Dy Mon DD, YYYY HH12:MI PM') as "12 Hours ago US short Format",
	to_char(sysdate, 'YEAR') as "Year, spelled out",
	to_char(sysdate, 'J') as "Julian day",
	to_char(sysdate, 'IW') as "Week of the Year",
	to_char(sysdate, 'RM') as "Roman Month"		
from 
	dual

/*  This is  an example how to format dates */