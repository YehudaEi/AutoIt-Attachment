select * from TABLE
where ITEM = '\&textTown=BRUSSELS\&text' 
