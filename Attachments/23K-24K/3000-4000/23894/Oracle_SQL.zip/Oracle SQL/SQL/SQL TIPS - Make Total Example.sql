select 
	to_char(sysdate, 'DD/MM/YY HH24:MI') as "Sysdate",
	1234 as "example number"
from 
	dual
--Settings: 
-- CALCULATE TOTAL 