<?
	include "readini.class.php";
	$ini = new readini;

	$im = imagecreatefrompng("gui.png");
	$white = imagecolorallocate($im, 255, 255, 255);

	imagettftext($im, 8, 0, 24, 17, $white, "tahomabd.ttf", $ini->ReadIniValue("info.ini", "Info", "File"));
	imagettftext($im, 10, 0, 115, 45, $white, "SSERIFE.FON", $ini->ReadIniValue("info.ini", "Info", "Title"));
	imagettftext($im, 10, 0, 115, 62, $white, "SSERIFE.FON", $ini->ReadIniValue("info.ini", "Info", "Author"));
	imagettftext($im, 10, 0, 193, 85, $white, "SSERIFE.FON", $ini->ReadIniValue("info.ini", "Info", "Time"));

	Header('Content-type: image/png');
	Header('Cache-Control: no-cache');
	Header('Pragma: no-cache');
	
	imagepng($im);
	imagedestroy($im);
?>