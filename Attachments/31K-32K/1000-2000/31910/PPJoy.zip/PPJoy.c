#include <stdio.h>
#include <conio.h>
#include <windows.h>

#include <winioctl.h>

#include "ppjioctl.h"

#define	NUM_ANALOG	8		/* Number of analog values which we will provide */
#define	NUM_DIGITAL	16		/* Number of digital values which we will provide */

#pragma pack(push,1)		/* All fields in structure must be byte aligned. */
typedef struct
{
 unsigned long	Signature;				/* Signature to identify packet to PPJoy IOCTL */
 char			NumAnalog;				/* Num of analog values we pass */
 long			Analog[NUM_ANALOG];		/* Analog values */
 char			NumDigital;				/* Num of digital values we pass */
 char			Digital[NUM_DIGITAL];	/* Digital values */
}	JOYSTICK_STATE;
#pragma pack(pop)

HANDLE				h;
char				ch;
JOYSTICK_STATE		JoyState;

DWORD				RetSize;
DWORD				rc;

long				*Analog;
char				*Digital;

char				*DevName;

//declarations
int Initialize();
int Update();
int Close();
void ResetAxes();
void ResetButtons();
void SetButton(char button, char value);
void SetAxisPercent(char axis, char value);
int GetButton(char button);
int GetAxisPercent(char axis);

int Initialize()
{
 DevName= "\\\\.\\PPJoyIOCTL1";

 /* Open a handle to the control device for the first virtual joystick. */
 /* Virtual joystick devices are names PPJoyIOCTL1 to PPJoyIOCTL16. */
 h= CreateFile(DevName,GENERIC_WRITE,FILE_SHARE_WRITE,NULL,OPEN_EXISTING,0,NULL);

 /* Make sure we could open the device! */
 if (h==INVALID_HANDLE_VALUE)
 {
  printf ("CreateFile failed with error code %d trying to open %s device\n",GetLastError(),DevName);
  return 1;
 }

 /* Initialise the IOCTL data structure */
 JoyState.Signature= JOYSTICK_STATE_V1;
 JoyState.NumAnalog= NUM_ANALOG;	/* Number of analog values */
 Analog= JoyState.Analog;			/* Keep a pointer to the analog array for easy updating */
 JoyState.NumDigital= NUM_DIGITAL;	/* Number of digital values */
 Digital= JoyState.Digital;			/* Digital array */
 
 ResetAxes();
 ResetButtons();
 Update();
}

int Update()
{
  /* Send request to PPJoy for processing. */
  /* Currently there is no Return Code from PPJoy, this may be added at a */
  /* later stage. So we pass a 0 byte output buffer.                      */
  if (!DeviceIoControl(h,IOCTL_PPORTJOY_SET_STATE,&JoyState,sizeof(JoyState),NULL,0,&RetSize,NULL))
  {
   rc= GetLastError();
   if (rc==2)
   {
    printf ("Underlying joystick device deleted. Exiting read loop\n");
   }
   printf ("DeviceIoControl error %d\n",rc);
   return rc;
  }
  return 0;
}

int Close()
{
 CloseHandle(h);
 return 0;
}

void ResetAxes()
{
  Analog[0]= Analog[1]= Analog[2]= Analog[3]= Analog[4]= Analog[5]= Analog[6]= Analog[7]= (PPJOY_AXIS_MIN+PPJOY_AXIS_MAX)/2;
}

void ResetButtons()
{
  memset (Digital,0,sizeof(JoyState.Digital));
}

void SetButton(char button, char value)
{
  Digital[button] = value;
}

void SetAxisPercent(char axis, char value)
{
	int range = PPJOY_AXIS_MAX - PPJOY_AXIS_MIN;
	int adjValue = value * range / 100 + PPJOY_AXIS_MIN;
	Analog[axis] = adjValue;
}

int GetButton(char button)
{
	return (int)(Digital[button]);
}

int GetAxisPercent(char axis)
{
	int range = PPJOY_AXIS_MAX - PPJOY_AXIS_MIN;
	int value = (int)(Analog[axis]);
	return (value - PPJOY_AXIS_MIN) * 100 / range;
}
