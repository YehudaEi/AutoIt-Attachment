#include <stdbool.h>
#include <stdlib.h>
#include <stdio.h>
#include "stack.h"

void dll_check() { printf("Works"); }

stackDataType pop(SStack **head) {
    SStack *pTop = *head;
    stackDataType vValue = pTop->vValue;
    *head = pTop->pNext;
    free(pTop);
    return vValue;
}

void push(SStack **head, stackDataType vValue) {
    SStack *pNode = malloc( sizeof(SStack) );
    pNode->vValue = vValue;
    pNode->pNext = *head;
    *head = pNode;
}
