#ifndef STACK_H
#define	STACK_H

typedef int stackDataType;

typedef struct stack {
    stackDataType vValue;
    struct stack *pNext;
} SStack;

#ifdef	__cplusplus
extern "C" {
#endif

#ifndef DLL_TEST
#define DLL_DECLARE __declspec(dllexport)
#endif

DLL_DECLARE void dll_check();
DLL_DECLARE stackDataType pop(SStack **head);
DLL_DECLARE void push(SStack **head, stackDataType vValue);

#ifdef	__cplusplus
}
#endif

#endif
