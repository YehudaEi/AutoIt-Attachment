before editing config.ini read this:

HOUR and MIN are values that determite when the program launches again.
Set HOUR to a value like 25 or larger if you want it to go forever idle. 
25 is the default value to give you time to set it with the tray menu.

REPORT is a bool*
1 = saves a text file called report.txt and in it all skipped links
0 = doesn't save a text file

TERM1 is a string value wich is the term we search for in the google result page

SEARCH is a string value wich we type in google

DELAYGOOGLE is the time in miliseconds wich we wait everytime we go to the google result page

DELAYPAGE is the time in miliseconds wich we wait at every site

SHOWIE is a bool
1=shows IE while working
0=Hides IE window while working

SHOWPROG is a bool
1=shows a progress window while working
0=doesn't show a progress window while working

MINIE is a bool
1=minimize IE before searching
0=doesn't do anything to the IE window before searching

ONLYONCE is a bool
1=ignores the time set at HOUR and MIN and launches only once
0=launches again at time set at HOUR and MIN

NOTNOW is a bool
1=doesn't run when launches, but goes idle and waits for the time set
0=runs the procedure as soon as launched, then goes idel and waits for the time set


EXPLANATIONS
BOOL(boolean value) = that means only TRUE or FALSE (1 or 0) is accepted, if you type anything else,
it will be ignored and default value is used.
