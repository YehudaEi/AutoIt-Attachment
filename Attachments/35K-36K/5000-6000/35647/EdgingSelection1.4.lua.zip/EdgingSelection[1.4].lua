-- TIME_STAMP   2011-10-30 08:36:30   v 1.4

----------------- EdgingSelection.LUA ----------------------------------
--  Edge selected text with paired chars or set an empty pair         --
--  on hit this char.                                                 --
--  Paired chars are: " ", ' ', ( ), { }, [ ]                         --
--  * Set edging always in multiple selected lines or in block        --
--    selected areas (i.e. from line 3 to 8 in columns 20 to 30).     --
--  * If caret position are left from selection hit the opening       --
--    char, on position at the end hit the closing char.              --
--  * It also works without selection, so you got empty pairs. The    --
--    opening char must hit! (like AutoCloseBraces.lua)               --
--    Hit closing char without selection inserts only this char.      --
--  * ! If you want to set empty pairs on multiple lines, you must    --
--    select 0 columns (hit SHIFT+ALT + n-times DOWN) and the         --
--    closing char must hit. Downward selection is required for this. --
--  NOTE:                                                             --
--  * If you always use an script like 'AutoCloseBraces.lua', you     --
--    must disable it.                                                --
--  * The paired mode is disabled on using OVERWRITE in editor.       --
--  * Keycodes for english and german keyboard layout implemented.    --
--    Set your language in variable "lang". For other languages add   --
--    own entries in table "tCode". To get right values uncomment the --
--    "print"-line in function "HitKey", hit the keys with pairing    --
--    chars and read values from console. All entries('SHIFT', 'RAW', --
--    'CTRL_ALT') must created, to avoid errors.                      --
--  * To exclude some file-types from this function, needs entry for  --
--    every file-typ that should excluded in "SciTEUser.properties"   --
--    "NoPairs.ext=1" (.ext with lower chars!).                       --
------------------------------------------------------------------------

----------------- create new EventClass, event: OnKey ------------------
HitKey = EventClass:new(Common)
------------------------------------------------------------------------

----------------- declare vars -----------------------------------------
-- set your language and add table with values
local lang = 'GE' -- 'EN'                                                                   -- language identifier, used in char-table

-- virtual keycode
local tCode = {}

-- german keyboard
tCode['GE'] = {}
tCode['GE']['SHIFT'] = { [50] = '"', [191] = "'", [56] = '(', [57] = ')' }                  -- chars on hit SHIFT (german)
tCode['GE']['CTRL_ALT'] = { [55] = '{', [56] = '[', [57] = ']', [48] = '}' }                -- chars on hit CTRL+ALT (german)
tCode['GE']['RAW'] = {}                                                                     -- empty table required to avoid errors

-- US/ english keyboard
tCode['EN'] = {}
tCode['EN']['SHIFT'] = { [48] = ')', [57] = '(', [219] = '{', [221] = '}', [222] = '"' }    -- chars on hit SHIFT (english)
tCode['EN']['CTRL_ALT'] = {}                                                                -- empty table required to avoid errors
tCode['EN']['RAW'] = { [219] = '[', [221] = ']', [222] = "'" }                              -- chars hit alone (english)

-- paired chars
local tPairs = {}
tPairs['Left']  = { ['('] = ')', ['{'] = '}', ['['] = ']', ['"'] = '"', ["'"] = "'" }       -- left/opening chars
tPairs['Right'] = { [')'] = '(', ['}'] = '{', [']'] = '[', ['"'] = '"', ["'"] = "'" }       -- right/closing chars

-- insert key state
local stateINS = 0
------------------------------------------------------------------------

------------------ get pairs -------------------------------------------
function sibling(_sChar)
	local leftChar, rightChar
	if tPairs['Left'][_sChar] ~= nil then
		rightChar = tPairs['Left'][_sChar]
		leftChar = tPairs['Right'][rightChar]
	elseif  tPairs['Right'][_sChar] ~= nil then
		leftChar = tPairs['Right'][_sChar]
		rightChar = tPairs['Left'][leftChar]
	end
	return leftChar, rightChar
end  --> sibling
------------------------------------------------------------------------

----------------- set edging -------------------------------------------
function EdgeSelection(_hitChar)
	local leftChar, rightChar = sibling(_hitChar)
	local selStart  = editor.SelectionStart
	local selEnd    = editor.SelectionEnd
	local firstLine = editor:LineFromPosition(selStart)
	local lastLine  = editor:LineFromPosition(selEnd)
	local sSelection aPos = {} n = 0
	local caret, sSelection, fLeft
	caret = editor.CurrentPos
	if caret <= selStart then fLeft = 1 else fLeft = 0 end -- is caret left from selection?
	if (selStart == selEnd) and (tPairs['Right'][_hitChar] ~= nil) and (_hitChar ~= "'" and _hitChar ~= '"') then return nil end
	-- store selected area (start- /endposition in used lines)
	-- from 2nd line add to position the count of chars to insert
	for i = firstLine, lastLine do
		aPos[i] = {}
		aPos[i][1] = editor:GetLineSelStartPosition(i) + n*2
		aPos[i][2] = editor:GetLineSelEndPosition(i) + n*2
		n = n +1
	end
	-- insert edging chars at start- /endposition
	editor:BeginUndoAction()
	if firstLine == lastLine then
		if fLeft == 1 then editor:InsertText(aPos[firstLine][2], rightChar) end
		if fLeft == 0 then editor:InsertText(aPos[firstLine][1], leftChar) editor:GotoPos(caret +1) end
	else
		n = 0
		for i = firstLine, lastLine do
			if fLeft == 1 and i == firstLine then
				editor:InsertText(aPos[i][2], rightChar)
			elseif fLeft == 0 and i == lastLine then
				editor:InsertText(aPos[i][1], leftChar) editor:GotoPos(caret +n*2 +1)
			else
				if fLeft == 1 and n > 0 then aPos[i][1] = aPos[i][1] -1 aPos[i][2] = aPos[i][2] -1 end
				editor:InsertText(aPos[i][2], rightChar)
				editor:InsertText(aPos[i][1], leftChar)
			end
			n = n +1
		end
	end
	editor:EndUndoAction()
end  --> EdgeSelection
------------------------------------------------------------------------

----------------- Event: OnKey -----------------------------------------
function HitKey:OnKey(_keycode, _shift, _ctrl, _alt)
--~ print('_keycode: '..tostring(_keycode)..', _shift: '..tostring(_shift)..', _ctrl: '..tostring(_ctrl)..', _alt: '..tostring(_alt))  -- DebugToConsole
	if tonumber(props['NoPairs.'..props['FileExt']:lower()]) == 1 then return nil end    -- to exclude file-types from this function
	if _keycode == 45 then if stateINS == 0 then stateINS = 1 else stateINS = 0 end end  -- on hit INSERT-key change key-state
	if stateIns == 1 then return nil end                                                 -- INSERT-key in OVERWRITE-mode
	if tCode[lang]['SHIFT'][_keycode] ~= nil and _shift == true then return EdgeSelection(tCode[lang]['SHIFT'][_keycode]) end
	if tCode[lang]['CTRL_ALT'][_keycode] ~= nil and _ctrl == true and _alt == true then return EdgeSelection(tCode[lang]['CTRL_ALT'][_keycode]) end
	if tCode[lang]['RAW'][_keycode] ~= nil then return EdgeSelection(tCode[lang]['RAW'][_keycode]) end
	return nil
end  --> HitKey
------------------------------------------------------------------------
