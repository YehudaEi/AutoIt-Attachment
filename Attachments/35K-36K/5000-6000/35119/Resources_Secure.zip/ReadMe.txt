The Files Encrypt Password is "V3000" .

The Default Encryption Method is $CALG_RC4 ; RC4 .
The AES Encryption Method in <Crypt.au3> Limited For Less Than 1MB, Bigger Than That It Will Be Corrupted ; I Think That is Bug.

To Encrypt Files Use [Crypt Files.au3], You Can Even Decrypt It .

WARNING: The Password is Case Sensitive .

If You Want To Encrypt BITMAP In $RT_BITMAP (Not In $RT_RCDATA) Then Use [Crypt Only Bitmap (BMP).au3] For Encrypt The Bitmap File .
You Can Encrypt BITMAP In $RT_RCDATA, Work Fine .

resource_test_ie_It_Can't_Be_Secure_It.au3
It Can't Be Secure It, Because It Used Directly, Else Maybe.

To Setup Resources_Secure In SciTE
Copy ' au3.user.calltips.api '       To   %ProgramFiles%\AutoIt3\SciTE\api\
Copy ' au3.userudfs.properties '  To   %ProgramFiles%\AutoIt3\SciTE\Properties\
Copy ' Resources_Secure.au3 '     To   %ProgramFiles%\AutoIt3\Include\

Enjoy iT!