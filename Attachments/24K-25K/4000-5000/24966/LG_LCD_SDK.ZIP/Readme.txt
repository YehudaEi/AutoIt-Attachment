LCD SDK translation in AutoIt

This litte UDF connects itselves with the original Logitech LCD SDK for Microsoft� Windows� (lglcd) V1.03

How To Install: If not already done, just copy the LgLcd.dll from etc dir to C:\Windows\System32 (%systemdir%)
That's all.


License:
LCD SDK translation in AutoIt

Copyright (C) 2009 Gtaspider

This program is free software; you can redistribute it and/or modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 3 of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty
of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for more details.

GPL License: http://www.gnu.org/licenses/gpl-3.0.html