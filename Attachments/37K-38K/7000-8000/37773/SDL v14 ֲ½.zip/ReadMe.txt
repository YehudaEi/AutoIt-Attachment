CREDITS!!

This UDF was written by AdmiralAlkex.

Lots of help was received from monoceres (see notes in source).
ProgAndy, Valik & wus also helpep some (see notes in source).

Images and Examples created by AdmiralAlkex.
Except Opera_AutoIt.png that was shamelessly stolen from thread 59517 in the AutoIt forums.
SDL_gfx.dll was compiled by monoceres.



FUTURE DEVELOPMENT!!

I have not finished all functions, and those that are left are quite tricky so don't count on me fixing them today.
If you want to help then feel free to write a few of the missing/broken functions and then post them on the forum or send them to me and I will update the UDF with them.



DOCUMENTATION!!

I have not written any documentation so you will have to make due with what's available for other languages.

Remember these two rules and it should be easier for you:
A. Functions generally look like this: _SDL_SomeFunc(), except in some external libraries (e.g. _SPG_SomeFunc() for the sprig lib).
B. Functions return 1 on success not 0 (changed from default behaviour to look more like AutoIt)

The best documentation I have seen so far are the SDLRef.chm (included in package) and online @ http://sdl.beuc.net/sdl.wiki/FrontPage

Documentation for multiple languages and formats can be downloaded from SDL's official website @ http://www.libsdl.org/docs.php



SUPPORT!!

If you need any help then please use the forum so others can read our posts and benefit too.
If you want to talk to me personally then please see my profile in the AutoIt forums.



LICENCE!!

You are free to do whatever you want with the scripts as long as you give credits to me for my work on this UDF.

SDL.dll was written by Sam Lantinga using "GNU Lesser General Public License (LGPL) version 2.1 or newer." you can read more here: http://www.libsdl.org/license-lgpl.php

SDL_gfx.dll was written by A. Schiffler under the LGPL Version 2.1 : http://www.fsf.org/copyleft/lgpl.html

SDL_image.dll was written by Sam Lantinga and Mattias Engdeg�rd under the LGPL Version 2.1 : http://www.gnu.org/copyleft/lesser.html

SDL_sprig.dll was written by Jonathan Dearborn under the LGPL Version 2.1 (see previous link)

SDL_sge.dll was written by Anders Lindstr�m under the LGPL Version 2.1 (see previous link)

SDL_mixer.dll was written by Sam Lantinga, Stephane Peter, and Ryan Gordon under the LGPL Version 2.1 (see previous link)

SDL_ttf.dll was written by Sam Lantinga under the LGPL Version 2.1 (see previous link)



ALSO DISTRIBUTED IN THIS PACKAGE IS:

zlib : http://www.zlib.net/
libtiff : http://gnuwin32.sourceforge.net/packages/tiff.htm
libpng : http://libpng.org/
jpeg.dll : unknown
smpeg.dll : http://icculus.org/smpeg/
libvorbisfile.dll : http://www.xiph.org/
libvorbis.dll : http://www.xiph.org/
libogg.dll : http://www.xiph.org/
freetype.dll : http://www.freetype.org/



FUN FACTS!!

There are a total of 4261 lines in the includes.
There are a total of 524 functions in the includes.
Includes are totally 157703 bytes big.



NO MORE STUFF LEFT!!

This section is a joke. Muahahahaha.