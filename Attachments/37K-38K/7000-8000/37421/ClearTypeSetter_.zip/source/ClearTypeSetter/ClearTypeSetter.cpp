#include "stdafx.h"

void EnableClearType()
{
	SystemParametersInfo(
		SPI_SETFONTSMOOTHING,
		TRUE,
		NULL,
		SPIF_SENDWININICHANGE | SPIF_UPDATEINIFILE);

	SystemParametersInfo(
		SPI_SETFONTSMOOTHINGTYPE,
		0,
		reinterpret_cast<PVOID>(FE_FONTSMOOTHINGCLEARTYPE),
		SPIF_SENDWININICHANGE | SPIF_UPDATEINIFILE);
}

int WINAPI wWinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance,
	LPWSTR lpCmdLine, int nCmdShow)
{
	EnableClearType();
	return 0;
}
