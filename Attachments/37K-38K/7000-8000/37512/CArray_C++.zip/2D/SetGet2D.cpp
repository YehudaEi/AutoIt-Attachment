#include <windows.h>
#include "CArray.h"
int WINAPI WinMain(HINSTANCE hInstance,
                   HINSTANCE hPrevInstance,
                   LPSTR lpCmdLine,
                   int nCmdShow)
{

DimArray2D<int,3,3>iArray2D;
// int ==> Data Type // 3 ==> Rows Count // 3 ==> Column Count
for (int i = 0 ; i < 3; i++)
{
for (int j = 0 ; j < 4; j++) // 4 ==> Over the Count of columns
{
BOOL Rt = iArray2D.SetAt(i,j,(i * j)); // iArray2D.SetAt(i,j,(i * j)) SetAt
if (Rt == false) // Test Errors
{
MessageBox(0,"false","BOOL",0);
} else {
MessageBox(0,"true","BOOL",0);
}
// i ==> Row Index // j ==> Column Index // (i * j) ==> vValue
}}
iArray2D.Display("SetAt");

DimArray2D<char*,3,3>vArray2D;
vArray2D(0,0,"0|0");
vArray2D(0,1,"0|1");
vArray2D(0,2,"0|2");
vArray2D(1,0,"1|0");
vArray2D(1,1,"1|1");
vArray2D(1,2,"1|2");
vArray2D(2,0,"2|0");
vArray2D(2,1,"2|1");
vArray2D(2,2,"2|2");
for (int i = 0 ; i < 3; i++)
{
for (int j = 0 ; j < 4; j++) // 4 ==> Over the Count of columns
{
char* vValue = vArray2D.GetAt(i,j);
// iArray2D.GetAt(i,j) GetAt i ==> Row Index // j ==> Column Index
//Return ==> vValue
if (GetLastError() != 0) // Test Errors
{
MessageBox(0,"Error","GetLastError",0);
} else {
MessageBox(0,vValue,"No Error",0);
}
}}
vArray2D.Display("SetAt");



DimArray2D<int,0,0>nArray2D;
// int ==> Data Type // 0 ==> Rows Count // 0 ==> Column Count
for (int i = 0 ; i < 10; i++)
{
for (int j = 0 ; j < 6; j++)
{
BOOL Rt = nArray2D.SetAtGrow(i,j,(i * j)); // iArray2D(i,j,(i * j))
// i ==> Row Index // j ==> Column Index // (i * j) ==> vValue
}}
nArray2D.Display("SetAtGrow");


return 0;
}


