#include <windows.h>
#include "CArray.h"
int WINAPI WinMain(HINSTANCE hInstance,
                   HINSTANCE hPrevInstance,
                   LPSTR lpCmdLine,
                   int nCmdShow)
{

DimArray2D<int,0,0>iArray2D;
// int ==> Data Type // 0 ==> Rows Count // 0 ==> Column Count
iArray2D.ReDim(4,4); // 4 ==> Rows Count // 4 ==> Columns Count
iArray2D.Display("ReDim(4,4)");
int RowsCount = iArray2D.UBound(1); // Dimension = 1 // Get Rows Count
int ColsCount = iArray2D.UBound(2); // Dimension = 2 // Get Columns Count
if (RowsCount == 4 && ColsCount == 4) MessageBox(0,"RowsCount = 4 // ColsCount = 4","UBound",0);

DimArray2D<int,0,5>jArray2D;
// int ==> Data Type // 0 ==> Rows Count // 5 ==> Column Count
jArray2D.ReDim(3,5); // 3 ==> Rows Count // 5 ==> Columns Count
jArray2D.Display("ReDim(3,5)");

DimArray2D<int,5,0>nArray2D;
// int ==> Data Type // 5 ==> Rows Count // 0 ==> Column Count
nArray2D.ReDim(5,3); // 5 ==> Rows Count // 3 ==> Columns Count
nArray2D.Display("ReDim(5,3)");

DimArray2D<char*,4,4>vArray2D;
// char* ==> Data Type // 4 ==> Rows Count // 4 ==> Columns Count
vArray2D(0,0,"0|0");
vArray2D(0,1,"0|1");
vArray2D(0,2,"0|2");
vArray2D(0,3,"0|3");
vArray2D(1,0,"1|0");
vArray2D(1,1,"1|1");
vArray2D(1,2,"1|2");
vArray2D(1,3,"1|3");
vArray2D(2,0,"2|0");
vArray2D(2,1,"2|1");
vArray2D(2,2,"2|2");
vArray2D(2,3,"2|3");
vArray2D(3,0,"3|0");
vArray2D(3,1,"3|1");
vArray2D(3,2,"3|2");
vArray2D(3,3,"3|3");
vArray2D.ReDim(3,2); // 3 ==> Rows Count // 2 ==> Columns Count
vArray2D.Display("ReDim(3,2)");
RowsCount = vArray2D.UBound(1); // Dimension = 1 // Get Rows Count
ColsCount = vArray2D.UBound(2); // Dimension = 2 // Get Columns Count
if (RowsCount == 3 && ColsCount == 2) MessageBox(0,"RowsCount = 3 // ColsCount = 2","UBound",0);

return 0;
}


