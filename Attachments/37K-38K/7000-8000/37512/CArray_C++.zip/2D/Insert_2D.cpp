#include <windows.h>
#include "CArray.h"
int WINAPI WinMain(HINSTANCE hInstance,
                   HINSTANCE hPrevInstance,
                   LPSTR lpCmdLine,
                   int nCmdShow)
{

DimArray2D<char*,4,4>vArray2D;
vArray2D(0,0,"0|0");
vArray2D(0,1,"0|1");
vArray2D(0,2,"0|2");
vArray2D(0,3,"0|3");
vArray2D(1,0,"1|0");
vArray2D(1,1,"1|1");
vArray2D(1,2,"1|2");
vArray2D(1,3,"1|3");
vArray2D(2,0,"2|0");
vArray2D(2,1,"2|1");
vArray2D(2,2,"2|2");
vArray2D(2,3,"2|3");
vArray2D(3,0,"3|0");
vArray2D(3,1,"3|1");
vArray2D(3,2,"3|2");
vArray2D(3,3,"3|3");
vArray2D.Display();
BOOL Rt;
 Rt = vArray2D.Insert(1,2);
//BOOL Insert(int RowIndex = 0,int RowsCount = 1,int ColuIndex = 0,int ColsCount = 0)
//Insert 2 Rows In The RowIndex 1 // RowsCount = 2 // RowIndex ==> 1 //
//int ColuIndex = 0,int ColsCount = 0
vArray2D.Display("Insert 2 Rows In The RowIndex 1");

 Rt = vArray2D.Insert(0,0,1,2);
//BOOL Insert(int RowIndex = 0,int RowsCount = 1,int ColuIndex = 0,int ColsCount = 0)
//Insert 2 Columns In The ColuIndex 1 // ColsCount = 2 // ColuIndex ==> 1
//int RowIndex = 0,int RowsCount = 0
vArray2D.Display("Insert 2 Columns In The ColuIndex 1");

 Rt = vArray2D.Insert(1,2,1,2);
//BOOL Insert(int RowIndex = 0,int RowsCount = 1,int ColuIndex = 0,int ColsCount = 0)
//Insert 2 Rows And 2 Columns In The RowIndex 1 And ColuIndex 1
//RowsCount = 2 // RowIndex ==> 1
//ColsCount = 2 // ColuIndex ==> 1
vArray2D.Display("Insert 2 Rows And 2 Columns In The RowIndex 1 And ColuIndex 1");

}

