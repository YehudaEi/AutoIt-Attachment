#include <windows.h>
#include "CArray.h"
int WINAPI WinMain(HINSTANCE hInstance,
                   HINSTANCE hPrevInstance,
                   LPSTR lpCmdLine,
                   int nCmdShow)
{

DimArray2D<char*,6,6>vArray2D;
vArray2D(0,0,"0|0");
vArray2D(0,1,"0|1");
vArray2D(0,2,"0|2");
vArray2D(0,3,"0|3");
vArray2D(0,4,"0|4");
vArray2D(0,5,"0|5");
vArray2D(1,0,"1|0");
vArray2D(1,1,"1|1");
vArray2D(1,2,"1|2");
vArray2D(1,3,"1|3");
vArray2D(1,4,"1|4");
vArray2D(1,5,"1|5");
vArray2D(2,0,"2|0");
vArray2D(2,1,"2|1");
vArray2D(2,2,"2|2");
vArray2D(2,3,"2|3");
vArray2D(2,4,"2|4");
vArray2D(2,5,"2|5");
vArray2D(3,0,"3|0");
vArray2D(3,1,"3|1");
vArray2D(3,2,"3|2");
vArray2D(3,3,"3|3");
vArray2D(3,4,"3|4");
vArray2D(3,5,"3|5");
vArray2D(4,0,"4|0");
vArray2D(4,1,"4|1");
vArray2D(4,2,"4|2");
vArray2D(4,3,"4|3");
vArray2D(4,4,"4|4");
vArray2D(4,5,"4|5");
vArray2D(5,0,"5|0");
vArray2D(5,1,"5|1");
vArray2D(5,2,"5|2");
vArray2D(5,3,"5|3");
vArray2D(5,4,"5|4");
vArray2D(5,5,"5|5");

vArray2D.Display();
BOOL Rt;
 Rt = vArray2D.Delete(1,2);
//BOOL Delete(int RowIndex = 0,int RowsCount = 1,int ColuIndex = 0,int ColsCount = 0)
//Delete 2 Rows In The RowIndex 1 // RowsCount = 2 // RowIndex ==> 1 //
//int ColuIndex = 0,int ColsCount = 0
vArray2D.Display("Delete 2 Rows In The RowIndex 1");

 Rt = vArray2D.Delete(0,0,1,2);
//BOOL Delete(int RowIndex = 0,int RowsCount = 1,int ColuIndex = 0,int ColsCount = 0)
//Delete 2 Columns In The ColuIndex 1 // ColsCount = 2 // ColuIndex ==> 1
//int RowIndex = 0,int RowsCount = 0
vArray2D.Display("Delete 2 Columns In The ColuIndex 1");

 Rt = vArray2D.Delete(1,2,1,2);
//BOOL Delete(int RowIndex = 0,int RowsCount = 1,int ColuIndex = 0,int ColsCount = 0)
//Delete 2 Rows And 2 Columns In The RowIndex 1 And ColuIndex 1
//RowsCount = 2 // RowIndex ==> 1
//ColsCount = 2 // ColuIndex ==> 1
vArray2D.Display("Delete 2 Rows And 2 Columns In The RowIndex 1 And ColuIndex 1");

}

