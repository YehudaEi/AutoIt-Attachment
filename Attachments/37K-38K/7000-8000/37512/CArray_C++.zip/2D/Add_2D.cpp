#include <windows.h>
#include "CArray.h"
int WINAPI WinMain(HINSTANCE hInstance,
                   HINSTANCE hPrevInstance,
                   LPSTR lpCmdLine,
                   int nCmdShow)
{

DimArray2D<char*,4,4>vArray2D;
vArray2D(0,0,"0|0");
vArray2D(0,1,"0|1");
vArray2D(0,2,"0|2");
vArray2D(0,3,"0|3");
vArray2D(1,0,"1|0");
vArray2D(1,1,"1|1");
vArray2D(1,2,"1|2");
vArray2D(1,3,"1|3");
vArray2D(2,0,"2|0");
vArray2D(2,1,"2|1");
vArray2D(2,2,"2|2");
vArray2D(2,3,"2|3");
vArray2D(3,0,"3|0");
vArray2D(3,1,"3|1");
vArray2D(3,2,"3|2");
vArray2D(3,3,"3|3");
vArray2D.Display();
BOOL Rt;
 Rt = vArray2D.Add(2);
//BOOL Add(int RowsCount = 1,BOOL RowsEnd = true,int ColsCount = 0,BOOL ColsEnd = true)
// Add 2 Rows In The End // RowsCount = 2 // RowsEnd ==> Default: true //
//ColsCount = 0,ColsEnd = true
vArray2D.Display("Add 2 Rows In The End");

 Rt = vArray2D.Add(0,0,2);
//BOOL Add(int RowsCount = 1,BOOL RowsEnd = true,int ColsCount = 0,BOOL ColsEnd = true)
// Add 2 Columns In The End // ColsCount = 2 // ColsEnd ==> Default: true //
//RowsCount = 0,RowsEnd = 0
vArray2D.Display("Add 2 Column In The End");

 Rt = vArray2D.Add(2,false,2,false);
//BOOL Add(int RowsCount = 1,BOOL RowsEnd = true,int ColsCount = 0,BOOL ColsEnd = true)
// Add 2 Rows And 2 Columns In The beginning
//RowsCount = 2 // RowsEnd ==> false
//ColsCount = 2 // ColsEnd ==> false
vArray2D.Display("Add 2 Rows And 2 Columns In The beginning");

}

