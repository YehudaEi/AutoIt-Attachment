#include <windows.h>
#include "CArray.h"
int WINAPI WinMain(HINSTANCE hInstance,
                   HINSTANCE hPrevInstance,
                   LPSTR lpCmdLine,
                   int nCmdShow)
{

DimArray2D<char*,1,6>vArray2D;
int* ResultsArray;
int RowIndex , ColuIndex;
vArray2D(0,0,"CHAR");
vArray2D(0,1,"WORD");
vArray2D(0,2,"INT ");
vArray2D(0,3,"BOOL");
vArray2D(0,4,"LONG");
vArray2D(0,5,"1234");
vArray2D.Display();
//Find(DataType vValue,int RowIndex = -1, int ColuIndex = -1,BOOL CaseSensitive = false)

ResultsArray = vArray2D.Find("bool");
//Find(DataType vValue,int RowIndex = -1, int ColuIndex = -1,BOOL CaseSensitive = false)
//vValue ==> bool
//RowIndex ==> -1 Default From 0 To Last RowIndex
//ColuIndex ==> -1 Default From 0 To Last ColuIndex
//BOOL CaseSensitive ==> Default false
if (ResultsArray != NULL)
{
int RowIndex = ResultsArray[0];
int ColuIndex = ResultsArray[1];
if (RowIndex == 0 && ColuIndex == 3)
MessageBox(0,"Found The bool value in Row 0 and column 3","Results",0);
} else {
MessageBox(0,"Is not found, the bool value","Error",0);
}

vArray2D.Display();
ResultsArray = vArray2D.Find("bOOL",-1,-1,true);
//Find(DataType vValue,int RowIndex = -1, int ColuIndex = -1,BOOL CaseSensitive = false)
//vValue ==> bOOL
//RowIndex ==> -1 From 0 To Last RowIndex
//ColuIndex ==> -1 From 0 To Last ColuIndex
//BOOL CaseSensitive ==> true
if (ResultsArray != NULL)
{
int RowIndex = ResultsArray[0];
int ColuIndex = ResultsArray[1];
if (RowIndex == 0 && ColuIndex == 3)
MessageBox(0,"Found The bOOL value in Row 0 and column 3","Results",0);
} else {
MessageBox(0,"Is not found, the bOOL value","Error",0);
}

vArray2D.Display();
ResultsArray = vArray2D.Find("LONG",0,4,true);
//Find(DataType vValue,int RowIndex = -1, int ColuIndex = -1,BOOL CaseSensitive = false)
//vValue ==> LONG
//RowIndex ==> From 0 To 0
//ColuIndex ==> From 0 To 4
//BOOL CaseSensitive ==> true
if (ResultsArray != NULL)
{
int RowIndex = ResultsArray[0];
int ColuIndex = ResultsArray[1];
if (RowIndex == 0 && ColuIndex == 4)
MessageBox(0,"Found The  LONG value in Row 0 and column 4","Results",0);
} else {
MessageBox(0,"Is not found, the  LONG value","Error",0);
}

vArray2D.Display();
ResultsArray = vArray2D.Find("LONG",0,2,true);
//Find(DataType vValue,int RowIndex = -1, int ColuIndex = -1,BOOL CaseSensitive = false)
//vValue ==> LONG
//RowIndex ==> From 0 To 0
//ColuIndex ==> From 0 To 2
//BOOL CaseSensitive ==> true
if (ResultsArray != NULL)
{
int RowIndex = ResultsArray[0];
int ColuIndex = ResultsArray[1];
if (RowIndex == 0 && ColuIndex == 4)
MessageBox(0,"Found The  LONG value in Row 0 and column 4","Results",0);
} else {
MessageBox(0,"Is not found, the  LONG value","Error",0);
}

}

