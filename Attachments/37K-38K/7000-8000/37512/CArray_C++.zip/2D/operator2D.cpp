#include <windows.h>
#include "CArray.h"
int WINAPI WinMain(HINSTANCE hInstance,
                   HINSTANCE hPrevInstance,
                   LPSTR lpCmdLine,
                   int nCmdShow)
{

DimArray2D<int,0,0>iArray2D;
// int ==> Data Type // 0 ==> Rows Count // 0 ==> Column Count
for (int i = 0 ; i < 21; i++)
{
for (int j = 0 ; j < 6; j++)
{
iArray2D(i,j,(i * j),true); // iArray2D(i,j,(i * j),true) operator SetAtGrow
// i ==> Row Index // j ==> Column Index // (i * j) ==> vValue // true ==> SetAtGrow
}}
iArray2D.Display("Operator SetAtGrow");

DimArray2D<char*,4,4>vArray2D;
// char* ==> Data Type // 4 ==> Rows Count // 4 ==> Columns Count
vArray2D(0,0,"0|0"); // vArray2D(0,0,"0|0") operator SetAt
// 0 ==> RowIndex // 0 ==> Column Index // "0|0" ==> vValue // Default ==> false ==> SetAt
vArray2D(0,1,"0|1");
vArray2D(0,2,"0|2");
vArray2D(0,3,"0|3");
vArray2D(1,0,"1|0");
vArray2D(1,1,"1|1");
vArray2D(1,2,"1|2");
vArray2D(1,3,"1|3");
vArray2D(2,0,"2|0");
vArray2D(2,1,"2|1");
vArray2D(2,2,"2|2");
vArray2D(2,3,"2|3");
vArray2D(3,0,"3|0");
vArray2D(3,1,"3|1");
vArray2D(3,2,"3|2");
vArray2D(3,3,"3|3");
vArray2D.Display("Operator SetAt");

for (int i = 0 ; i < 4; i++)
{
for (int j = 0 ; j < 4; j++)
{
// 4 ==> Rows Count // 4 ==> Columns Count
// i ==> Row Index // j ==> Column Index
MessageBox(0,vArray2D[i][j],"Operator GetAt",0); // vArray2D[i][j] ==> Operator GetAt
}}

vArray2D(); // Delete Last Row
vArray2D.Display("Operator Delete Last Row");
vArray2D(); // Delete Last Row
vArray2D.Display("Operator Delete Last Row");

return 0;
}


