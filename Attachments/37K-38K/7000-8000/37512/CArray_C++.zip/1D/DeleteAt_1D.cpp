#include <windows.h>
#include "CArray.h"
int WINAPI WinMain(HINSTANCE hInstance,
                   HINSTANCE hPrevInstance,
                   LPSTR lpCmdLine,
                   int nCmdShow)
{

DimArray1D<char*,6>vArray1D;
vArray1D(0,"0");
vArray1D(1,"1");
vArray1D(2,"2");
vArray1D(3,"3");
vArray1D(4,"4");
vArray1D(5,"5");

vArray1D.Display();
BOOL Rt = vArray1D.DeleteAt(4);
//BOOL DeleteAt(int RowIndex)
//Delete The RowIndex 4 //RowIndex ==> 4
vArray1D.Display("Delete The RowIndex 4");



}

