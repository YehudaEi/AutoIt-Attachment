#include <windows.h>
#include "CArray.h"
int WINAPI WinMain(HINSTANCE hInstance,
                   HINSTANCE hPrevInstance,
                   LPSTR lpCmdLine,
                   int nCmdShow)
{

DimArray1D<int,3>iArray1D;
// int ==> Data Type // 3 ==> Rows Count
for (int i = 0 ; i < 4; i++) // 4 ==> Over the Count of Rows
{
BOOL Rt = iArray1D.SetAt(i,i); // iArray1D.SetAt(i,i) SetAt
if (Rt == false) // Test Errors
{
MessageBox(0,"false","BOOL",0);
} else {
MessageBox(0,"true","BOOL",0);
}
// i ==> Row Index And vValue
}
iArray1D.Display("SetAt");

DimArray1D<char*,3>vArray1D;
vArray1D(0,"0");
vArray1D(1,"1");
vArray1D(2,"2");
for (int i = 0 ; i < 4; i++) // 4 ==> Over the Count of Rows
{
char* vValue = vArray1D.GetAt(i);
// vArray1D.GetAt(i) GetAt i ==> Row Index
//Return ==> vValue
if (GetLastError() != 0) // Test Errors
{
MessageBox(0,"Error","GetLastError",0);
} else {
MessageBox(0,vValue,"No Error",0);
}
}
vArray1D.Display("SetAt");

DimArray1D<int,0>nArray1D;
// int ==> Data Type // 0 ==> Rows Count
for (int i = 0 ; i < 10; i++)
{
BOOL Rt = nArray1D.SetAtGrow(i,i); // SetAtGrow(i,i)
// i ==> Row Index And vValue
}
nArray1D.Display("SetAtGrow");


return 0;
}


