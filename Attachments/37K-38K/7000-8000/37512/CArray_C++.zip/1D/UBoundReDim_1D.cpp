#include <windows.h>
#include "CArray.h"
int WINAPI WinMain(HINSTANCE hInstance,
                   HINSTANCE hPrevInstance,
                   LPSTR lpCmdLine,
                   int nCmdShow)
{

DimArray1D<int,0>iArray1D;
// int ==> Data Type // 0 ==> Rows Count
iArray1D.ReDim(4); // 4 ==> Rows Count
iArray1D.Display("ReDim(4)");
int RowsCount = iArray1D.UBound(); //Get Rows Count
if (RowsCount == 4) MessageBox(0,"RowsCount = 4","UBound",0);

DimArray1D<int,5>jArray1D;
// int ==> Data Type // 5 ==> Rows Count
jArray1D.ReDim(3); // 3 ==> Rows Count
jArray1D.Display("ReDim(3)");
RowsCount = jArray1D.UBound(); //Get Rows Count
if (RowsCount == 3) MessageBox(0,"RowsCount = 3","UBound",0);

DimArray1D<char*,4>vArray1D;
// char* ==> Data Type // 4 ==> Rows Count
vArray1D(0,"0");
vArray1D(1,"1");
vArray1D(2,"2");
vArray1D(3,"3");
vArray1D.ReDim(1); // 1 ==> Rows
vArray1D.Display("ReDim(1)");
RowsCount = vArray1D.UBound(); //Get Rows Count
if (RowsCount == 1) MessageBox(0,"RowsCount = 1","UBound",0);

return 0;
}


