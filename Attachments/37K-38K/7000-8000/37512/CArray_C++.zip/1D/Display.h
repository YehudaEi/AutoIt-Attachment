UINT ILVM_FIRST = 0x1000;
UINT ILVCF_FMT = 0x0001;
UINT ILVCF_WIDTH = 0x0002;
UINT ILVCF_TEXT = 0x0004;
UINT ILVIF_PARAM = 0x00000004;
UINT ILVIF_TEXT = 0x00000001;
UINT ILVM_INSERTITEMW = 0x1000 + 77;
UINT ILVM_INSERTCOLUMNW = 0x1000 + 97;
UINT ILVM_SETITEMW = 0x1000 + 76;
UINT ILVM_GETSELECTIONMARK = 0x1000 + 66;
UINT ILVM_GETITEMTEXTW = 0x1000 + 115;
UINT ILVM_GETHEADER = 0x1000 + 31;
UINT IHDM_GETITEMCOUNT = 0x1200;
UINT ILVS_SHOWSELALWAYS = 0x8;
UINT ILVM_SETEXTENDEDLISTVIEWSTYLE = (0x1000 + 54);
UINT ILVS_EX_GRIDLINES = 0x1;
UINT ILVS_EX_FULLROWSELECT = 0x20;
UINT IWS_EX_CLIENTEDGE = 0x0200;
UINT ILVS_EX_SUBITEMIMAGES = 0x00000002;
UINT ILVS_EX_FLATSB = 0x00000100;
UINT ILVS_EX_MULTIWORKAREAS = 0x00002000;
UINT ILVM_GETCOLUMNWIDTH = 0x1000 + 29;
UINT ILVS_REPORT = 0x0001;
UINT ILVS_EDITLABELS = 0x0200;
HWND SelectButton , hDisplayListView;
WCHAR* StringAddW(WCHAR* StrA,WCHAR* StrB);
int iAddColumn(HWND hWnd,WCHAR* sText,int iWidth);
int AddItem(HWND hWnd,int iIndex);
int AddSubItem(HWND hWnd,int iIndex,WCHAR* sText,int iSubItem);
LRESULT CALLBACK DisplayProc(HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam);
WCHAR* CopySelectedText(HWND hWnd);
int iAddColumn(HWND hWnd,WCHAR* sText,int iWidth)
{
typedef struct tagLVCOLUMNW
{
    UINT mask;
    int fmt;
    int cx;
    LPWSTR pszText;
    int cchTextMax;
    int iSubItem;
#if (_WIN32_IE >= 0x0300)
    int iImage;
    int iOrder;
#endif
} MLVCOLUMNW, FAR* MLPLVCOLUMNW;
int iIndex = SendMessage((HWND) SendMessage(hWnd,(UINT) ILVM_GETHEADER,0,0),(UINT) IHDM_GETITEMCOUNT,0,0);
MLVCOLUMNW iLVCOLUMNW;
ZeroMemory(&iLVCOLUMNW, sizeof(MLVCOLUMNW));
UINT iMask = ILVCF_FMT | ILVCF_WIDTH | ILVCF_TEXT;
iLVCOLUMNW.mask = iMask;
iLVCOLUMNW.fmt = 0x0000;
iLVCOLUMNW.cx = iWidth;
iLVCOLUMNW.pszText = sText;
iLVCOLUMNW.cchTextMax = wcslen(sText) * 2;
return SendMessage(hWnd,(UINT) ILVM_INSERTCOLUMNW,(LPARAM) iIndex,(WPARAM) &iLVCOLUMNW);
}

int AddItem(HWND hWnd,int iIndex)
{
typedef struct tagMLVITEMW
{
    UINT mask;
    int iItem;
    int iSubItem;
    UINT state;
    UINT stateMask;
    LPWSTR pszText;
    int cchTextMax;
    int iImage;
    LPARAM lParam;
#if (_WIN32_IE >= 0x0300)
    int iIndent;
#endif
} MLVITEMW, FAR* MLPLVITEMW;
MLVITEMW iMLVITEMW;
ZeroMemory(&iMLVITEMW, sizeof(MLVITEMW));
iMLVITEMW.mask = ILVIF_PARAM | ILVIF_PARAM;
iMLVITEMW.iItem = iIndex;
return SendMessage(hWnd,(UINT) ILVM_INSERTITEMW,(LPARAM) 0,(WPARAM) &iMLVITEMW);
}

int AddSubItem(HWND hWnd,int iIndex,WCHAR* sText,int iSubItem)
{
typedef struct tagMLVITEMW
{
    UINT mask;
    int iItem;
    int iSubItem;
    UINT state;
    UINT stateMask;
    LPWSTR pszText;
    int cchTextMax;
    int iImage;
    LPARAM lParam;
#if (_WIN32_IE >= 0x0300)
    int iIndent;
#endif
} MLVITEMW, FAR* MLPLVITEMW;
MLVITEMW iMLVITEMW;
ZeroMemory(&iMLVITEMW, sizeof(MLVITEMW));
iMLVITEMW.mask = ILVIF_TEXT;
iMLVITEMW.pszText = sText;
iMLVITEMW.iItem = iIndex;
iMLVITEMW.iSubItem = iSubItem;
iMLVITEMW.cchTextMax = wcslen(sText) * 2;
return SendMessage(hWnd,(UINT) ILVM_SETITEMW,(LPARAM) 0,(WPARAM) &iMLVITEMW);
}


LRESULT CALLBACK DisplayProc(HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam)
{
    HWND CtrlHwnd;
    switch (message)
    {
    case WM_COMMAND:
    CtrlHwnd = (HWND) lParam;
    switch (HIWORD(wParam))
    {
    case BN_CLICKED:
    if (CtrlHwnd == SelectButton)
    {
	CopySelectedText(hDisplayListView);
    }
    break;
    }
    break;
    case WM_PAINT:
        break;
    case WM_DESTROY:
        PostQuitMessage(0);
        break;
    }
    return DefWindowProc(hWnd, message, wParam, lParam);
}


WCHAR* CopySelectedText(HWND hWnd)
{
typedef struct tagMLVITEMW
{
    UINT mask;
    int iItem;
    int iSubItem;
    UINT state;
    UINT stateMask;
    LPWSTR pszText;
    int cchTextMax;
    int iImage;
    LPARAM lParam;
#if (_WIN32_IE >= 0x0300)
    int iIndent;
#endif
} MLVITEMW, FAR* MLPLVITEMW;
int iIndex = SendMessage(hWnd,(UINT) ILVM_GETSELECTIONMARK,(LPARAM) 0,(WPARAM) 0);
if (iIndex == - 1) iIndex = 0;
int Count = SendMessage((HWND) SendMessage(hWnd,(UINT) ILVM_GETHEADER,0,0),(UINT) IHDM_GETITEMCOUNT,0,0);
WCHAR* OutText = L"";
for (int iSubItem = 0; iSubItem < Count; iSubItem++)
{
MLVITEMW iMLVITEMW;
ZeroMemory(&iMLVITEMW, sizeof(MLVITEMW));
iMLVITEMW.pszText = new WCHAR[4096];
iMLVITEMW.iSubItem = iSubItem;
iMLVITEMW.cchTextMax = 4096;
SendMessage(hWnd,(UINT) ILVM_GETITEMTEXTW,(LPARAM) iIndex,(WPARAM) &iMLVITEMW);
OutText = StringAddW(OutText,iMLVITEMW.pszText);
if (iSubItem < (Count - 1)) OutText = StringAddW(OutText,L"|");
}
HGLOBAL hMemory = GlobalAlloc(GHND,((wcslen(OutText) + 1) * 2));
WCHAR* OutPtr = (WCHAR*) GlobalLock(hMemory);
wmemcpy(OutPtr,OutText,wcslen(OutText) + 1);
GlobalUnlock(hMemory);
OpenClipboard(0);
EmptyClipboard();
SetClipboardData(CF_UNICODETEXT,hMemory);
CloseClipboard();
return OutText;
}

WCHAR* StringAddW(WCHAR* StrA,WCHAR* StrB)
{
if (StrA == NULL) return StrB;
if (StrB == NULL) return StrA;
int nLen = wcslen(StrA), vLen = wcslen(StrB);
WCHAR* StrC = new WCHAR[nLen + vLen + 1];
wcscpy(StrC,StrA);
wcscpy(StrC + nLen,StrB);
StrC[nLen + vLen] = L'\0';
return StrC;
}
