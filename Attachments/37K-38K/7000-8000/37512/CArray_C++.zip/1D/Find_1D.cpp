#include <windows.h>
#include "CArray.h"
int WINAPI WinMain(HINSTANCE hInstance,
                   HINSTANCE hPrevInstance,
                   LPSTR lpCmdLine,
                   int nCmdShow)
{


DimArray1D<char*,6>vArray1D;
int Result;
vArray1D(0,"CHAR");
vArray1D(1,"WORD");
vArray1D(2,"INT ");
vArray1D(3,"BOOL");
vArray1D(4,"LONG");
vArray1D(5,"1234");
vArray1D.Display();
//Find(DataType vValue,int begin = -1, int End = -1,BOOL CaseSensitive = false)

Result = vArray1D.Find("bool");
//Find(DataType vValue,int begin = -1, int End = -1,BOOL CaseSensitive = false)
//vValue ==> bool
//begin ==> -1 Default From 0
//End ==> -1 Default To Last RowIndex
//BOOL CaseSensitive ==> Default false
if (Result != -1)
{
if (Result == 3)
MessageBox(0,"Found The  bool value in Row 3","Results",0);
} else {
MessageBox(0,"Is not found, the  bool value","Error",0);
}

vArray1D.Display();
Result = vArray1D.Find("bOOL",-1,-1,true);
//Find(DataType vValue,int begin = -1, int End = -1,BOOL CaseSensitive = false)
//vValue ==> bOOL
//begin ==> -1 Default From 0
//End ==> -1 Default To Last RowIndex
//BOOL CaseSensitive ==> true
if (Result != -1)
{
if (Result == 3)
MessageBox(0,"Found The  bOOL value in Row 3","Results",0);
} else {
MessageBox(0,"Is not found, the  bOOL value","Error",0);
}

vArray1D.Display();
Result = vArray1D.Find("LONG",0,4,true);
//Find(DataType vValue,int begin = -1, int End = -1,BOOL CaseSensitive = false)
//vValue ==> LONG
//begin ==> from RowIndex 0
//End ==> To RowIndex 4
//BOOL CaseSensitive ==> true
if (Result != -1)
{
if (Result == 4)
MessageBox(0,"Found The  LONG value in Row 4","Results",0);
} else {
MessageBox(0,"Is not found, the  LONG value","Error",0);
}

vArray1D.Display();
Result = vArray1D.Find("LONG",0,2,true);
//Find(DataType vValue,int begin = -1, int End = -1,BOOL CaseSensitive = false)
//vValue ==> LONG
//begin ==> from RowIndex 0
//End ==> To RowIndex 2
//BOOL CaseSensitive ==> true
if (Result != -1)
{
if (Result == 4)
MessageBox(0,"Found The  LONG value in Row 4","Results",0);
} else {
MessageBox(0,"Is not found, the  LONG value","Error",0);
}

}

