#include <windows.h>
#include <stdio.h>
#include <typeinfo.h>
#include <wchar.h>
#include "Display.h"

template<class DataType,int RowsCount ,int ColsCount>class DimArray2D
{
int iRowsCount,iColsCount;
DataType** Array2D;
int SizeOfType;
public:
DimArray2D(void)
{
iRowsCount = RowsCount;
iColsCount = ColsCount;
if (iRowsCount < 0) iRowsCount = 0;
if (iColsCount < 0) iColsCount = 0;
SizeOfType = sizeof(DataType);
Array2D = new DataType*[iRowsCount];
for (int i = 0; i < iRowsCount; i++)
{
Array2D[i] = new DataType[iColsCount];
RtlZeroMemory(Array2D[i],(iColsCount * SizeOfType));
}
}

void operator()(int RowIndex,int ColuIndex,DataType vValue,BOOL SetAtGrow = false)
{
if (SetAtGrow)
{
int iRowIndex = iRowsCount, iColuIndex = iColsCount;
if (RowIndex > (iRowsCount - 1)) iRowIndex = (RowIndex + 1);
if (ColuIndex > (iColsCount - 1)) iColuIndex = (ColuIndex + 1);
if (RowIndex > (iRowsCount - 1) || ColuIndex > (iColsCount - 1)) ReDim(iRowIndex,iColuIndex);
Array2D[RowIndex][ColuIndex] = vValue;
} else {
Array2D[RowIndex][ColuIndex] = vValue;
}
}

DataType* operator[](int RowIndex)
{
return Array2D[RowIndex];
}

BOOL operator()()
{
return Delete(iRowsCount - 1);
}

int UBound(int Dimension = 1)
{
if (Dimension == 1) return iRowsCount;
if (Dimension == 2) return iColsCount;
return -1;
}

BOOL ReDim(int RowsCount,int ColusCount)
{
if (RowsCount < 0 || ColusCount < 0) return false;
DataType** NewArray = new DataType*[RowsCount];
int pRowsCount = iRowsCount;
int pColusCount = iColsCount;
if (RowsCount < iRowsCount) pRowsCount = RowsCount;
if (ColusCount < iColsCount) pColusCount = ColusCount;
for (int i = 0; i < RowsCount ; i++)
{
NewArray[i] = new DataType[ColusCount];
RtlZeroMemory(NewArray[i],((ColusCount) * SizeOfType));
if (i < pRowsCount)
{
RtlMoveMemory(NewArray[i],Array2D[i],(SizeOfType * pColusCount));
delete [] Array2D[i];
}
}
delete [] Array2D;
Array2D = NewArray;
iRowsCount = RowsCount;
iColsCount = ColusCount;
return true;
}

DataType GetAt(int RowIndex,int ColuIndex)
{
if (RowIndex < 0 ||  RowIndex > (iRowsCount -1) ||
ColuIndex < 0 ||  ColuIndex > (iColsCount -1)) {
SetLastError(1);
return NULL;
}
SetLastError(0);
return Array2D[RowIndex][ColuIndex];
}

BOOL SetAt(int RowIndex,int ColuIndex,DataType vValue)
{
if (RowIndex < 0 ||  RowIndex > (iRowsCount -1) ||  ColuIndex < 0
|| ColuIndex > (iColsCount -1)) return false;
Array2D[RowIndex][ColuIndex] = vValue;
return true;
}

BOOL SetAtGrow(int RowIndex,int ColuIndex,DataType vValue)
{
if (RowIndex < 0 || ColuIndex < 0) return false;
int iRowIndex = iRowsCount, iColuIndex = iColsCount;
if (RowIndex > (iRowsCount - 1)) iRowIndex = (RowIndex + 1);
if (ColuIndex > (iColsCount - 1)) iColuIndex = (ColuIndex + 1);
if (RowIndex > (iRowsCount - 1) || ColuIndex > (iColsCount - 1)) ReDim(iRowIndex,iColuIndex);
Array2D[RowIndex][ColuIndex] = vValue;
return true;
}

BOOL Add(int RowsCount = 1,BOOL RowsEnd = true,int ColsCount = 0,BOOL ColsEnd = true)
{
if (RowsCount < 0 || ColsCount < 0) return false;
int vIndex = 0;
DataType** NewArray = new DataType*[(iRowsCount + RowsCount)];
for (int i = 0; i < (iRowsCount + RowsCount); i++)
{
if (RowsEnd ==  false && i < RowsCount)
{
NewArray[i] = new DataType[iColsCount + ColsCount];
RtlZeroMemory(NewArray[i],((iColsCount + ColsCount) * SizeOfType));
} else {
NewArray[i] = new DataType[iColsCount + ColsCount];
RtlZeroMemory(NewArray[i],((iColsCount + ColsCount) * SizeOfType));
if (ColsEnd == true)
{
if (vIndex < iRowsCount)
{
RtlMoveMemory(NewArray[i],Array2D[vIndex],(SizeOfType * iColsCount));
delete [] Array2D[vIndex];
}
} else {
if (vIndex < iRowsCount)
{
RtlMoveMemory(NewArray[i] + ColsCount,Array2D[vIndex],(SizeOfType * iColsCount));
delete [] Array2D[vIndex];
}
}
vIndex += 1;
}
}
delete [] Array2D;
Array2D = NewArray;
iRowsCount += RowsCount;
iColsCount += ColsCount;
return true;
}

BOOL Insert(int RowIndex = 0,int RowsCount = 1,int ColuIndex = 0,int ColsCount = 0)
{
if (RowIndex < 0 || ColuIndex < 0 || RowIndex > (iRowsCount -1)
|| ColuIndex > (iColsCount - 1)) return false;
int vIndex = 0;
DataType** NewArray = new DataType*[iRowsCount + RowsCount];
for (int i = 0; i < (iRowsCount + RowsCount); i++)
{
NewArray[i] = new DataType[(iColsCount + ColsCount)];
RtlZeroMemory(NewArray[i],((iColsCount + ColsCount) * SizeOfType));
if (i < RowIndex || i > RowIndex + (RowsCount - 1))
{
RtlMoveMemory(NewArray[i],Array2D[vIndex],(SizeOfType * ColuIndex));
RtlMoveMemory(NewArray[i] + (ColuIndex + ColsCount),Array2D[vIndex] + ColuIndex,
SizeOfType * (iColsCount - ColuIndex));
delete [] Array2D[vIndex];
vIndex += 1;
}
}
delete [] Array2D;
Array2D = NewArray;
iRowsCount += RowsCount;
iColsCount += ColsCount;
return true;
}

BOOL Delete(int RowIndex = 0,int RowsCount = 1,int ColuIndex = 0,int ColsCount = 0)
{
if (RowIndex < 0 || ColuIndex < 0 || RowsCount > (iRowsCount - RowIndex)
|| ColsCount > (iColsCount - ColuIndex)) return false;
int vIndex = 0;
DataType** NewArray = new DataType*[(iRowsCount - RowsCount)];
for (int i = 0 ; i < iRowsCount; i++)
{
if (i < RowIndex || i > (RowIndex + (RowsCount - 1)))
{
NewArray[vIndex] = new DataType[(iColsCount - ColsCount)];
RtlZeroMemory(NewArray[vIndex],((iColsCount - ColsCount) * SizeOfType));
RtlMoveMemory(NewArray[vIndex],Array2D[i],(SizeOfType * ColuIndex));
RtlMoveMemory(NewArray[vIndex] + ColuIndex,Array2D[i] + (ColuIndex + ColsCount),
SizeOfType * (iColsCount - (ColuIndex + ColsCount)));
delete [] Array2D[vIndex];
vIndex += 1;
}
}
delete [] Array2D;
Array2D = NewArray;
iRowsCount -= RowsCount;
iColsCount -= ColsCount;
return true;
}

int* Find(DataType vValue,int RowIndex = -1, int ColuIndex = -1,BOOL CaseSensitive = false)
{
int RtIndex[2];
if (RowIndex == -1) RowIndex = (iRowsCount - 1);
if (ColuIndex == -1) ColuIndex = (iColsCount - 1);
if (RowIndex < 0 || RowIndex > (iRowsCount - 1)
|| ColuIndex < 0 || ColuIndex > ((iColsCount -1))) return NULL;
if (typeid(DataType) == typeid(char*) || typeid(DataType) == typeid(WCHAR*))
{
if (typeid(DataType) == typeid(char*))
{
char* cValue = GetCharsA(vValue);
if (!(CaseSensitive)) cValue = StrToUpperA(GetCharsA(vValue));
for (int i = 0; i <= RowIndex; i++)
{
for (int j = 0; j <= ColuIndex; j++)
{
RtIndex[0] = i;
RtIndex[1] = j;
if (!(CaseSensitive))
{
if (strcmp(StrToUpperA(GetCharsA(Array2D[i][j])),cValue) == 0) return RtIndex;
} else {
if (strcmp(GetCharsA(Array2D[i][j]),cValue) == 0) return RtIndex;
}
}}
} else {
WCHAR* cValue = GetCharsW(vValue);
if (!(CaseSensitive)) cValue = StrToUpperW(GetCharsW(vValue));
for (int i = 0; i <= RowIndex; i++)
{
for (int j = 0; j <= ColuIndex; j++)
{
RtIndex[0] = i;
RtIndex[1] = j;
if (!(CaseSensitive))
{
if (wcscmp(StrToUpperW(GetCharsW(Array2D[i][j])),cValue) == 0) return RtIndex;
} else {
if (wcscmp(GetCharsW(Array2D[i][j]),cValue) == 0) return RtIndex;
}
}}
}
} else {
for (int i = 0; i <= RowIndex; i++)
{
for (int j = 0; j <= ColuIndex; j++)
{
RtIndex[0] = i;
RtIndex[1] = j;
if (memcmp(&Array2D[i][j],&vValue,SizeOfType) == 0) return RtIndex;
}}
}
return NULL;
}

DataType** GetBuffer()
{
return Array2D;
}

WCHAR* StrToUpperW(WCHAR* iString)
{
if (iString == NULL) return iString;
int vLen = wcslen(iString);
WCHAR* pString = new WCHAR[vLen + 1];
for (int i = 0 ; i < vLen; i++)
{pString[i] = towupper(iString[i]);}
pString[vLen] = L'\0';
return pString;
}

char* StrToUpperA(char* iString)
{
if (iString == NULL) return iString;
int vLen = strlen(iString);
char* pString = new char[vLen + 1];
for (int i = 0 ; i < vLen; i++)
{pString[i] = toupper(iString[i]);}
pString[vLen] = '\0';
return pString;
}

char* GetCharsA(DataType iString)
{
char** cString = reinterpret_cast<char**>(&iString);
return cString[0];
}

WCHAR* GetCharsW(DataType iString)
{
WCHAR** cString = reinterpret_cast<WCHAR**>(&iString);
return cString[0];
}

BOOL Display(char* Title = "Display Array2D",int LastRowIndex = 1001,int LastColuIndex = 251)
{
//return
//Success: True
//Failure: False
if (iRowsCount == 0 || iColsCount == 0) return false;
wchar_t* StrA = new wchar_t[33], *StrB = new wchar_t[33] , *VALUE = new wchar_t[1000];
HWND TrayWnd = FindWindowW(L"Shell_TrayWnd",L"");
RECT TaslpRect , DesklpRect , ClientRect;
if (TrayWnd) GetWindowRect(TrayWnd,&TaslpRect);
GetWindowRect(GetDesktopWindow(),&DesklpRect);
HMODULE HMOD = GetModuleHandle(0);
WNDCLASSEX wcex;
wcex.cbSize = sizeof(WNDCLASSEX);
wcex.style          = CS_HREDRAW | CS_VREDRAW;
wcex.lpfnWndProc    = DisplayProc;
wcex.cbClsExtra     = 0;
wcex.cbWndExtra     = 0;
wcex.hInstance      = HMOD;
wcex.hIcon          = 0;
wcex.hCursor        = 0;
wcex.hbrBackground  = (HBRUSH)GetSysColorBrush(COLOR_3DFACE);
wcex.lpszMenuName   = NULL;
wcex.lpszClassName  = "win32app";
wcex.hIconSm        = 0;
RegisterClassEx(&wcex);
HWND hWnd = CreateWindow("win32app",Title,WS_OVERLAPPEDWINDOW,0,0,1,1,0,0,HMOD,0);
DWORD dwStyle = WS_CHILD | ILVS_EX_GRIDLINES | ILVS_EX_FULLROWSELECT | ILVS_EX_SUBITEMIMAGES | ILVS_EX_FLATSB | ILVS_EX_MULTIWORKAREAS;
hDisplayListView = CreateWindowExW(0,L"SysListView32",L"",WS_CHILD | ILVS_REPORT | ILVS_EDITLABELS,0,0,1,1,hWnd,0,HMOD,0);
SendMessage(hDisplayListView,WM_SETFONT,(WPARAM) GetStockObject(17),(LPARAM) true);
SendMessage(hDisplayListView,ILVM_SETEXTENDEDLISTVIEWSTYLE,0,(LPARAM) dwStyle);
InvalidateRect(hDisplayListView,0,true);
SelectButton = CreateWindowExW(0,L"Button",L"Copy Selected",WS_TABSTOP|WS_VISIBLE|WS_CHILD|BS_NOTIFY,0,0,1,1,hWnd,0,HMOD,0);
if (iRowsCount < LastRowIndex) LastRowIndex = iRowsCount;
if (iColsCount < LastColuIndex) LastColuIndex = iColsCount;
for (int j = 1; j <= LastColuIndex; j++)
{
for (int i = 1; i <= LastRowIndex; i++)
{
delete [] VALUE;
VALUE = new wchar_t[1000];
RtlZeroMemory(VALUE,1000);
if (typeid(DataType) == typeid(char*))
{
char* iString = GetCharsA(Array2D[i - 1][j - 1]);
if (iString != NULL)
{
delete [] VALUE;
VALUE = new wchar_t[strlen(iString) + 1];
swprintf(VALUE,L"%hs",iString);
}
} else if (typeid(DataType) == typeid(WCHAR*))
{
delete [] VALUE;
VALUE = GetCharsW(Array2D[i - 1][j - 1]);
} else if (typeid(DataType) == typeid(char))
{
swprintf(VALUE,L"%c",Array2D[i - 1][j - 1]);
} else if (typeid(DataType) == typeid(WCHAR))
{
swprintf(VALUE,L"%c",Array2D[i - 1][j - 1]);
} else if (typeid(DataType) == typeid(double))
{
swprintf(VALUE,L"%G",Array2D[i - 1][j - 1]);
} else if (typeid(DataType) == typeid(float))
{
swprintf(VALUE,L"%G",Array2D[i - 1][j - 1]);
} else if (typeid(DataType) == typeid(int))
{
swprintf(VALUE,L"%d",Array2D[i - 1][j - 1]);
} else if (typeid(DataType) == typeid(UINT))
{
swprintf(VALUE,L"%u",Array2D[i - 1][j - 1]);
} else if (typeid(DataType) == typeid(long))
{
swprintf(VALUE,L"%d",Array2D[i - 1][j - 1]);
} else if (typeid(DataType) == typeid(DWORD))
{
swprintf(VALUE,L"%u",Array2D[i - 1][j - 1]);
} else if (typeid(DataType) == typeid(short))
{
swprintf(VALUE,L"%hi",Array2D[i - 1][j - 1]);
} else if (typeid(DataType) == typeid(USHORT))
{
swprintf(VALUE,L"%hu",Array2D[i - 1][j - 1]);
} else {
swprintf(VALUE,L"%p",Array2D[i - 1][j - 1]);
}
delete [] StrA;
delete [] StrB;
StrA = new wchar_t[33];
StrB = new wchar_t[33];
RtlZeroMemory(StrA,33);
RtlZeroMemory(StrB,33);
_itow(j - 1,StrB,10);
StrA = StringAddW(StrA,L"Column ");
StrA = StringAddW(StrA,StrB);
if (i == 1 && j == 1) iAddColumn(hDisplayListView,L"Row",70);
if (i == 1) iAddColumn(hDisplayListView,StrA,70);
if (j == 1)
{
delete [] StrA;
delete [] StrB;
StrA = new wchar_t[33];
StrB = new wchar_t[33];
RtlZeroMemory(StrA,33);
RtlZeroMemory(StrB,33);
_itow(i - 1,StrB,10);
StrA = StringAddW(StrA,L"[");
StrA = StringAddW(StrA,StrB);
StrA = StringAddW(StrA,L"]");
AddItem(hDisplayListView,i);
AddSubItem(hDisplayListView,i - 1,StrA,j - 1);
AddSubItem(hDisplayListView,i - 1,VALUE,j);
} else {
AddSubItem(hDisplayListView,i - 1,VALUE,j);
}
}
}
int DH = DesklpRect.bottom - DesklpRect.top;
int DW = DesklpRect.right - DesklpRect.left;
int TH = TaslpRect.bottom - TaslpRect.top;
int TW = TaslpRect.right - TaslpRect.left;
int GUIW = (70 * (LastColuIndex+ 1) + 25);
int GUIH = (25 * (LastRowIndex + 1));
if (GUIW < 250) GUIW = 230;
GUIW += 20;
if (GUIW > DW) GUIW = DW;
GUIH += 20;
if (GUIH < 250) GUIH = 230;
if (GUIH > (DH - TH)) GUIH = (DH - TH);
SetWindowPos(hWnd,0,0,0,GUIW,GUIH,0);
GetClientRect(hWnd,&ClientRect);
int CH = (ClientRect.bottom - ClientRect.top) - 35;
int CW = (ClientRect.right - ClientRect.left) - 5;
SetWindowPos(SelectButton,0,ClientRect.left + 10,ClientRect.top + (CH + 10),CW - 20,20,0);
SetWindowPos(hDisplayListView,0,ClientRect.left + 5,ClientRect.top,CW - 5,CH,0);
ShowWindow(hWnd,5);
ShowWindow(hDisplayListView,5);
ShowWindow(SelectButton,5);
MSG msg;
while (GetMessage(&msg,0,0,0))
{
if (!TranslateAccelerator(msg.hwnd,0, &msg))
{
TranslateMessage(&msg);
DispatchMessage(&msg);
}
}
return true;
}
};

template<class DataType,int RowsCount>class DimArray1D
{
int iRowsCount;
DataType* Array1D;
int SizeOfType;
public:
DimArray1D(void)
{
iRowsCount = RowsCount;
SizeOfType = sizeof(DataType);
if (iRowsCount < 0) iRowsCount = 0;
Array1D = new DataType[iRowsCount];
RtlZeroMemory(Array1D,(iRowsCount * SizeOfType));
}

void operator()(int RowIndex,DataType vValue,BOOL SetAtGrow = false)
{
if (SetAtGrow)
{
if (RowIndex > (iRowsCount - 1))
{
DataType* NewArray = new DataType[(RowIndex + 1)];
RtlZeroMemory(NewArray,((RowIndex + 1) * SizeOfType));
RtlMoveMemory(NewArray,Array1D,(SizeOfType * iRowsCount));
delete [] Array1D;
iRowsCount = (RowIndex + 1);
Array1D = NewArray;
}
Array1D[RowIndex] = vValue;
} else {
Array1D[RowIndex] = vValue;
}
}

DataType operator[](int RowIndex)
{
return Array1D[RowIndex];
}

BOOL operator()(DataType vValue)
{
return Add(vValue);
}

BOOL operator()(void)
{
return DeleteAt(iRowsCount - 1);
}

int UBound()
{
return iRowsCount;
}

BOOL ReDim(int RowsCount)
{
if (RowsCount < 0) return false;
if (RowsCount < iRowsCount) iRowsCount = RowsCount;
DataType* NewArray = new DataType[RowsCount];
RtlZeroMemory(NewArray,(RowsCount * SizeOfType));
RtlMoveMemory(NewArray,Array1D,(SizeOfType * iRowsCount));
delete [] Array1D;
Array1D = NewArray;
iRowsCount = RowsCount;
return true;
}

DataType GetAt(int RowIndex)
{
if (RowIndex < 0 || RowIndex > (iRowsCount -1))
{
SetLastError(1);
return NULL;
}
SetLastError(0);
return Array1D[RowIndex];
}

BOOL SetAt(int RowIndex,DataType vValue)
{
if (RowIndex < 0 || RowIndex > (iRowsCount -1)) return false;
Array1D[RowIndex] = vValue;
return true;
}

BOOL SetAtGrow(int RowIndex,DataType vValue)
{
if (RowIndex < 0) return false;
int iRowIndex = iRowsCount;
if (RowIndex > (iRowsCount - 1)) iRowIndex = (RowIndex + 1);
if (RowIndex > (iRowsCount - 1)) ReDim(iRowIndex);
Array1D[RowIndex] = vValue;
return true;
}

BOOL Add(DataType vValue,BOOL End = true)
{
DataType* NewArray = new DataType[iRowsCount + 1];
RtlZeroMemory(NewArray,((iRowsCount + 1) * SizeOfType));
if (End)
{
RtlMoveMemory(NewArray,Array1D,(SizeOfType * iRowsCount));
NewArray[iRowsCount] = vValue;
} else {
RtlMoveMemory(NewArray + 1,Array1D,(SizeOfType * iRowsCount));
NewArray[0] = vValue;
}
delete [] Array1D;
Array1D = NewArray;
iRowsCount += 1;
return true;
}

BOOL DeleteAt(int RowIndex)
{
if (RowIndex < 0 || RowIndex > (iRowsCount -1)) return false;
int iSize = (SizeOfType * (iRowsCount - (RowIndex + 1)));
DataType* NewArray = new DataType[iRowsCount - 1];
RtlZeroMemory(NewArray,((iRowsCount - 1) * SizeOfType));
RtlMoveMemory(NewArray,Array1D,(SizeOfType * RowIndex));
RtlMoveMemory(NewArray + RowIndex,Array1D + (RowIndex + 1),iSize);
delete [] Array1D;
Array1D = NewArray;
iRowsCount -= 1;
return true;
}

BOOL InsertAt(int RowIndex,DataType vValue)
{
if (RowIndex < 0 || RowIndex > (iRowsCount -1)) return false;
int iSize = (SizeOfType * (iRowsCount - RowIndex));
DataType* NewArray = new DataType[iRowsCount + 1];
RtlZeroMemory(NewArray,((iRowsCount + 1) * SizeOfType));
RtlMoveMemory(NewArray,Array1D,(SizeOfType * RowIndex));
RtlMoveMemory(NewArray + (RowIndex + 1),Array1D + RowIndex,iSize);
delete [] Array1D;
NewArray[RowIndex] = vValue;
Array1D = NewArray;
iRowsCount += 1;
return true;
}

int Find(DataType vValue,int begin = -1, int End = -1,BOOL CaseSensitive = false)
{
if (End == -1) End = (iRowsCount - 1);
if (begin == -1) begin = 0;
if (begin < 0 || begin > (iRowsCount -1) || End < 0
|| End > (iRowsCount -1) || End < begin) return -1;
if (typeid(DataType) == typeid(char*) || typeid(DataType) == typeid(WCHAR*))
{
if (typeid(DataType) == typeid(char*))
{
char* cValue = GetCharsA(vValue);
if (!(CaseSensitive)) cValue = StrToUpperA(GetCharsA(vValue));
for (int i = begin; i <= End; i++)
{
if (!(CaseSensitive))
{
if (strcmp(StrToUpperA(GetCharsA(Array1D[i])),cValue) == 0) return i;
} else {
if (strcmp(GetCharsA(Array1D[i]),cValue) == 0) return i;
}
}
} else {
WCHAR* cValue = GetCharsW(vValue);
if (!(CaseSensitive)) cValue = StrToUpperW(GetCharsW(vValue));
for (int i = begin; i <= End; i++)
{
if (!(CaseSensitive))
{
if (wcscmp(StrToUpperW(GetCharsW(Array1D[i])),cValue) == 0) return i;
} else {
if (wcscmp(GetCharsW(Array1D[i]),cValue) == 0) return i;
}
}
}
} else {
for (int i = begin; i <= End; i++)
{
if (memcmp(&Array1D[i],&vValue,SizeOfType) == 0) return i;
}
}
return -1;
}

DataType* GetBuffer()
{
return Array1D;
}

WCHAR* StrToUpperW(WCHAR* iString)
{
if (iString == NULL) return iString;
int vLen = wcslen(iString);
WCHAR* pString = new WCHAR[vLen + 1];
for (int i = 0 ; i < vLen; i++)
{pString[i] = towupper(iString[i]);}
pString[vLen] = L'\0';
return pString;
}

char* StrToUpperA(char* iString)
{
if (iString == NULL) return iString;
int vLen = strlen(iString);
char* pString = new char[vLen + 1];
for (int i = 0 ; i < vLen; i++)
{pString[i] = toupper(iString[i]);}
pString[vLen] = '\0';
return pString;
}

char* GetCharsA(DataType iString)
{
char** cString = reinterpret_cast<char**>(&iString);
return cString[0];
}

WCHAR* GetCharsW(DataType iString)
{
WCHAR** cString = reinterpret_cast<WCHAR**>(&iString);
return cString[0];
}

BOOL Display(char* Title = "Display Array1D",int LastRowIndex = 250000)
{
if (!(iRowsCount)) return false;
wchar_t* StrA = new wchar_t[33], *StrB = new wchar_t[33] , *VALUE = new wchar_t[1000];
HWND TrayWnd = FindWindowW(L"Shell_TrayWnd",L"");
RECT TaslpRect , DesklpRect , ClientRect;
if (TrayWnd) GetWindowRect(TrayWnd,&TaslpRect);
GetWindowRect(GetDesktopWindow(),&DesklpRect);
HMODULE HMOD = GetModuleHandle(0);
WNDCLASSEX wcex;
wcex.cbSize = sizeof(WNDCLASSEX);
wcex.style          = CS_HREDRAW | CS_VREDRAW;
wcex.lpfnWndProc    = DisplayProc;
wcex.cbClsExtra     = 0;
wcex.cbWndExtra     = 0;
wcex.hInstance      = HMOD;
wcex.hIcon          = 0;
wcex.hCursor        = 0;
wcex.hbrBackground  = (HBRUSH)GetSysColorBrush(COLOR_3DFACE);
wcex.lpszMenuName   = NULL;
wcex.lpszClassName  = "win32app";
wcex.hIconSm        = 0;
RegisterClassEx(&wcex);
HWND hWnd = CreateWindow("win32app",Title,WS_OVERLAPPEDWINDOW,0,0,1,1,0,0,HMOD,0);
DWORD dwStyle = WS_CHILD | ILVS_EX_GRIDLINES | ILVS_EX_FULLROWSELECT | ILVS_EX_SUBITEMIMAGES | ILVS_EX_FLATSB | ILVS_EX_MULTIWORKAREAS;
hDisplayListView = CreateWindowExW(0,L"SysListView32",L"",WS_CHILD | ILVS_REPORT | ILVS_EDITLABELS,0,0,1,1,hWnd,0,HMOD,0);
SendMessage(hDisplayListView,WM_SETFONT,(WPARAM) GetStockObject(17),(LPARAM) true);
SendMessage(hDisplayListView,ILVM_SETEXTENDEDLISTVIEWSTYLE,0,(LPARAM) dwStyle);
InvalidateRect(hDisplayListView,0,true);
SelectButton = CreateWindowExW(0,L"Button",L"Copy Selected",WS_TABSTOP|WS_VISIBLE|WS_CHILD|BS_NOTIFY,0,0,1,1,hWnd,0,HMOD,0);
int LastColsIndex = 1;
if (iRowsCount < LastRowIndex) LastRowIndex = iRowsCount;
for (int j = 1; j <= LastColsIndex; j++)
{
for (int i = 1; i <= LastRowIndex; i++)
{
delete [] VALUE;
VALUE = new wchar_t[1000];
RtlZeroMemory(VALUE,1000);
if (typeid(DataType) == typeid(char*))
{
char* iString = GetCharsA(Array1D[i - 1]);
if (iString != NULL)
{
delete [] VALUE;
VALUE = new wchar_t[strlen(iString) + 1];
swprintf(VALUE,L"%hs",iString);
}
} else if (typeid(DataType) == typeid(WCHAR*))
{
delete [] VALUE;
VALUE = GetCharsW(Array1D[i - 1]);
} else if (typeid(DataType) == typeid(char))
{
swprintf(VALUE,L"%c",Array1D[i - 1]);
} else if (typeid(DataType) == typeid(WCHAR))
{
swprintf(VALUE,L"%c",Array1D[i - 1]);
} else if (typeid(DataType) == typeid(double))
{
swprintf(VALUE,L"%G",Array1D[i - 1]);
} else if (typeid(DataType) == typeid(float))
{
swprintf(VALUE,L"%G",Array1D[i - 1]);
} else if (typeid(DataType) == typeid(int))
{
swprintf(VALUE,L"%d",Array1D[i - 1]);
} else if (typeid(DataType) == typeid(UINT))
{
swprintf(VALUE,L"%u",Array1D[i - 1]);
} else if (typeid(DataType) == typeid(long))
{
swprintf(VALUE,L"%d",Array1D[i - 1]);
} else if (typeid(DataType) == typeid(DWORD))
{
swprintf(VALUE,L"%u",Array1D[i - 1]);
} else if (typeid(DataType) == typeid(short))
{
swprintf(VALUE,L"%hi",Array1D[i - 1]);
} else if (typeid(DataType) == typeid(USHORT))
{
swprintf(VALUE,L"%hu",Array1D[i - 1]);
} else {
if (strstr(typeid(DataType).name(),"*") != NULL)
{
swprintf(VALUE,L"%p",Array1D[i - 1]);
} else {
swprintf(VALUE,L"%d",Array1D[i - 1]);
}
}
delete [] StrA;
delete [] StrB;
StrA = new wchar_t[33];
RtlZeroMemory(StrA,33);
StrB = new wchar_t[33];
RtlZeroMemory(StrB,33);
_itow(j - 1,StrB,10);
StrA = StringAddW(StrA,L"Column ");
StrA = StringAddW(StrA,StrB);
if (i == 1 && j == 1) iAddColumn(hDisplayListView,L"Row",70);
if (i == 1) iAddColumn(hDisplayListView,StrA,70);
if (j == 1)
{
delete [] StrA;
delete [] StrB;
StrA = new wchar_t[33];
RtlZeroMemory(StrA,33);
StrB = new wchar_t[33];
RtlZeroMemory(StrB,33);
_itow(i - 1,StrB,10);
StrA = StringAddW(StrA,L"[");
StrA = StringAddW(StrA,StrB);
StrA = StringAddW(StrA,L"]");
AddItem(hDisplayListView,i);
AddSubItem(hDisplayListView,i - 1,StrA,j - 1);
AddSubItem(hDisplayListView,i - 1,VALUE,j);
} else {
AddSubItem(hDisplayListView,i - 1,VALUE,j);
}
}
}
int DH = DesklpRect.bottom - DesklpRect.top;
int DW = DesklpRect.right - DesklpRect.left;
int TH = TaslpRect.bottom - TaslpRect.top;
int TW = TaslpRect.right - TaslpRect.left;
int GUIW = (70 + 25);
int GUIH = (25 * (LastRowIndex + 1));
if (GUIW < 250) GUIW = 230;
GUIW += 20;
if (GUIW > DW) GUIW = DW;
GUIH += 20;
if (GUIH < 250) GUIH = 230;
if (GUIH > (DH - TH)) GUIH = (DH - TH);
SetWindowPos(hWnd,0,0,0,GUIW,GUIH,0);
GetClientRect(hWnd,&ClientRect);
int CH = (ClientRect.bottom - ClientRect.top) - 35;
int CW = (ClientRect.right - ClientRect.left) - 5;
SetWindowPos(SelectButton,0,ClientRect.left + 10,ClientRect.top + (CH + 10),CW - 20,20,0);
SetWindowPos(hDisplayListView,0,ClientRect.left + 5,ClientRect.top,CW - 5,CH,0);
ShowWindow(hWnd,5);
ShowWindow(hDisplayListView,5);
ShowWindow(SelectButton,5);
MSG msg;
while (GetMessage(&msg,0,0,0))
{
if (!TranslateAccelerator(msg.hwnd,0, &msg))
{
TranslateMessage(&msg);
DispatchMessage(&msg);
}
}
return true;
}
};