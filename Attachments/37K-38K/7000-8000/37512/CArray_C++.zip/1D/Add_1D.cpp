#include <windows.h>
#include "CArray.h"
int WINAPI WinMain(HINSTANCE hInstance,
                   HINSTANCE hPrevInstance,
                   LPSTR lpCmdLine,
                   int nCmdShow)
{

DimArray1D<char*,5>vArray1D;
vArray1D(0,"0");
vArray1D(1,"1");
vArray1D(2,"2");
vArray1D(3,"3");
vArray1D(4,"4");
vArray1D.Display("");
BOOL Rt;

 Rt = vArray1D.Add("beginning",false);
//BOOL Add(DataType vValue,BOOL End = true)
// Add Value ==> beginning In The beginning // End ==> false

 Rt = vArray1D.Add("End");
//BOOL Add(DataType vValue,BOOL End = true)
// Add Value ==> End In The End // Default End ==> true

vArray1D.Display("Add");

}

