#include <windows.h>
#include "CArray.h"
int WINAPI WinMain(HINSTANCE hInstance,
                   HINSTANCE hPrevInstance,
                   LPSTR lpCmdLine,
                   int nCmdShow)
{

DimArray1D<int,0>iArray1D;
// int ==> Data Type // 0 ==> Rows Count
for (int i = 0 ; i < 21; i++)
{
iArray1D(i,i,true); // iArray1D(i,i,true) operator SetAtGrow
// i ==> Row Index And vValue // true ==> SetAtGrow
}
iArray1D.Display("Operator SetAtGrow");

DimArray1D<char*,4>vArray1D;
// char* ==> Data Type // 4 ==> Rows Count
vArray1D(0,"0"); // vArray1D(0,"0"); operator SetAt
// 0 ==> RowIndex // vValue ==> "0" // Default ==> false ==> SetAt
vArray1D(1,"1");
vArray1D(2,"2");
vArray1D(3,"3");

vArray1D.Display("Operator SetAt");

for (int i = 0 ; i < 4; i++)
{
// i ==> Row Index
MessageBox(0,vArray1D[i],"Operator GetAt",0); // vArray1D[i] ==> Operator GetAt
}

vArray1D(); // Delete Last Element
vArray1D.Display("Operator Delete Last Element");
vArray1D(); // Delete Last Element
vArray1D.Display("Operator Delete Last Element");

return 0;
}


