-- TIME_STAMP   2012-05-06 20:31:04   v 0.6

----------------------------------------------------------------------------------------------------------------------------------
-- VarGetTip
--      For variables in a separate area of the script deposited tips:
--          #region - Variables-Tip
--          ; $Variable1 This is the tip for variable 1
--          ; $Variable2 This is the tip for variable 2
--          ; $Variable3 This is the tip for variable 3
--          #endregion
--      or they are in a comment line with a tag (the "at" sign) somewhere in the script created:
--          ;@ $Variable1 This is the tip for variable 1
--      or direct after creation of a variable in the next line with '-1' refers to this:
--          $Variable
--          ;-1 here my tip for $Variable
--
--      or tip for functions:
--          In following line after function-headline write your tip:
--             Func _SomeFunc()
--                 ;-f Tip for this function\nSecond line of this tip
--          Output:
--             _SomeFunc( )
--             Tip for this function
--             Second line of this tip
--
--      It can also be variables of the same name used on several occasions (in different functions).
--      The creation of the tips have to be done within the same range of validity (in the same function or global).
--      The script is looking for tips for the current variable in the current scope.
--      It will always output the variable name and scope (if tip exists)
--          $VarBefore  [ Global ]
--          This is the tip for $VarBefore
--      or
--          $iSelf  [ Local: Func _Testfunc() ]
--          This is the tip for $iSelf
--
--      You can create multiline tips by using "\n" to mark the line break
--      i.e.
--          ;@ $VariableXY comment1\ncomment2\ncomment3
--      output:
--          $VariableXY
--          comment1
--          comment2
--          comment3
--
--      Save the script as "..\SciTE\LUA\VarGetTip.lua"
--
--      In "SciTEUser.properties" will create a hotkey to invoke the function
--          command.name.37.*.au3=Variables Tip
--          command.37.*.au3=dofile $(SciteDefaultHome)/Lua/VarGetTip.lua
--          command.mode.37.*.au3=subsystem:lua,savebefore:no
--          command.shortcut.37.*.au3=Ctrl+Alt+V
--
--      In addition, create a properties value that determines whether output to console or Calltip
--          Variables.Tip.CallTip.*.au3=1          (1=as CallTip, 0=output to console)
--
--      Usage
--      - Place the cursor on the variable/function-call (or touching them)
--      - Call the Hotkey
--      - If existing a tip, it will shown as calltip or written to console
----------------------------------------------------------------------------------------------------------------------------------


local function GetVarFromCursor()
	local iCaret = editor.CurrentPos
	local iTmp = iCaret
	local sSel = string.char(editor.CharAt[iCaret])
	if (string.byte(sSel) == 13) or (sSel == ' ') or (sSel == ',') then
		iCaret = iCaret -1
	end
	local sLeft = string.char(editor.CharAt[iTmp-1])
	local iLine = editor:LineFromPosition(iCaret)
	local iLine1stPos = editor:PositionFromLine(iLine)
	local iDiffPos = iCaret - iLine1stPos +1
	local sLine = editor:GetLine(iLine)
	local sPatternNormal = '%$[%w_]+%s*[^[]'
	local function SearchVar(_sLine, _sPattern, _iCursor)
		local tVars = {}
		local iMatchStart iMatchEnd = 0
		while true do
			iMatchStart, iMatchEnd = _sLine:find(_sPattern, iMatchEnd +1)
			if iMatchStart == nil then break end
			table.insert(tVars, {iMatchStart, iMatchEnd})
		end
		if table.getn(tVars) > 0 then
			for i = 1, table.getn(tVars) do
				if ( _iCursor >= tVars[i][1] ) and ( _iCursor <= tVars[i][2] ) then
					return string.sub(_sLine, tVars[i][1], tVars[i][2])
				end
			end
		end
		return nil
	end
	local sVarUnderCursor
	local fLeftVar = false fRightVar = false
	if sLeft:find('[%w_$]') ~= nil then
		fLeftVar = true
	else
		if sSel == '$' then fRightVar = true end
	end
	if not fLeftVar and not fRightVar then return '' end
	sVarUnderCursor = SearchVar(sLine, sPatternNormal, iDiffPos)
	if sVarUnderCursor == nil then return '' end
	if sVarUnderCursor:find('%.$') then return '' end
	sVarUnderCursor = sVarUnderCursor:sub(sVarUnderCursor:find('%$[%w_]+'))
	return sVarUnderCursor, iCaret
end -- GetVarFromCursor()

local GetFuncFromCursor = function()
	local iCaret = editor.CurrentPos
	local sSel = string.char(editor.CharAt[iCaret])
	if (string.byte(sSel) == 13) or (sSel == ' ') or (sSel == ',') then return '' end
	local sLine = editor:GetLine(editor:LineFromPosition(iCaret))
	if string.char(editor.CharAt[iCaret -1]) ~= ' ' then editor:WordLeft() end
	editor:WordRightExtend()
	local sCurrWord = editor:GetSelText()
	editor:SetSel(iCaret, iCaret)
	if sCurrWord:find('[^%w_)]') then return '' end
	if sLine:find(sCurrWord..'%s*%b()') then
		return sCurrWord, iCaret
	else
		return ''
	end
end -- GetFuncFromCursor()

local Output = function(sText1, sText2)
	if tonumber(props['Variables.Tip.CallTip.*.au3']) == 1 then
		if sText2 ~= nil then sText1 = sText1..'\n'..sText2:gsub('\\n', '\n') end
		editor:CallTipShow(editor.CurrentPos, sText1)
	else
		print('!> '..sText1)
		if sText2 ~= nil then print('>> '..sText2:gsub('\\n', '\n>> ')) end
	end
end -- Output

local GetAllTip = function()
	local tTip = {}
	local s = editor:GetText()
	-- var declared in line before
	for p, tip in s:gmatch('()\n[\t%s]*;%-1%s*([^\r\n]+)') do
		local _, _, var = editor:GetLine(editor:LineFromPosition(p) -1):find('(%$[%w_]+)')
		table.insert(tTip, {var,tip,p,'global'})
	end
	-- tip set with "at"-tag
	for p, var, tip in s:gmatch('()\n[\t%s]*;@%s-(%$[%w_]+)%s([^\r\n]+)') do
		table.insert(tTip, {var,tip,p,'global'})
	end
	-- tip set in region
	local tReg = {}
	for p in s:gmatch("()#[Rr]egion %- [Vv]ariables%-[Tt]ip") do
		table.insert(tReg, p)
	end
	if table.getn(tReg) > 0 then
		for i=1,table.getn(tReg) do
			local line = editor:LineFromPosition(tReg[i])
			while not editor:GetLine(line):find('#[Ee]nd[Rr]egion') do
				line = line +1
				local _, _, var, tip = editor:GetLine(line):find(';%s-(%$[%w_]+)%s([^\r\n]+)')
				if var then table.insert(tTip, {var,tip,tReg[i],'global'}) end
			end
		end
	end
	-- function tips
	for p, tip in s:gmatch('()\n[\t%s]*;%-f%s*([^\r\n]+)') do
		local _, _, sFunc = editor:GetLine(editor:LineFromPosition(p) -1):find('([%w_]+)%s*%b()')
		table.insert(tTip, {sFunc,tip,p,sFunc})
	end
	return tTip
end -- GetAllTip

local GetFuncs = function()  -- all declared functions (position start, position end, function name)
	local tFuncs = {}
	for iStart, sFunc in editor:GetText():gmatch('()[Ff][Uu][Nn][Cc]%s+([%w_]+)%s*%b()') do
		local iLine, iEnd = editor:LineFromPosition(iStart)
		while true do
			iLine = iLine +1
			iEnd = editor:GetLine(iLine):find('[Ee][Nn][Dd][Ff][Uu][Nn][Cc]')
			if iEnd ~= nil then break end
		end
		table.insert(tFuncs, {iStart, editor:PositionFromLine(iLine), sFunc})
	end
	return tFuncs
end -- GetFuncs


local varCurr, varPos = GetVarFromCursor()
local fIsFuncTip = false
if varCurr == '' then
	varCurr, varPos = GetFuncFromCursor()
	if varCurr ~= '' then fIsFuncTip = true end
end
local tFuncs, tTip, fMatch, fMatchFunc, fInFunc = GetFuncs(), GetAllTip(), false, false

local GetTip = function(_var, _scope)  -- get tip for variable in this scope
	_scope = _scope or 'global'
	for i=1,table.getn(tTip) do
		if tTip[i][1]:lower() == _var:lower() and tTip[i][4] == _scope then return tTip[i][2] end
	end
	return nil
end -- GetTip

if table.getn(tTip) > 0 and table.getn(tFuncs) > 0 then  -- attache tip to function
	for i=1,table.getn(tTip) do
		for j=1,table.getn(tFuncs) do
			if tTip[i][3] >= tFuncs[j][1] and tTip[i][3] <= tFuncs[j][2] then
				tTip[i][4] = tFuncs[j][3]
				break
			end
		end
	end
end

local IsVarInFunc = function(_var, _pos)
	if table.getn(tFuncs) == 0 then return false, nil end
	for i=1,table.getn(tFuncs) do
		if _pos >= tFuncs[i][1] and _pos <= tFuncs[i][2] then
			return true, tFuncs[i][3]  -- return: true/false, function name
		end
	end
	return false, nil
end -- IsVarInFunc

if table.getn(tTip) == 0 then
	Output('No tips existent!')
else
	if varCurr == '' then
		Output('Cursor is not positioned on a variable\nor a function!')
	else
		local sTip
		local fInFunc, sFunc = IsVarInFunc(varCurr, varPos)
		if fInFunc then
			sTip =  GetTip(varCurr, sFunc)
			if sTip ~= nil then
				Output(varCurr..'  [ Local: Func '..sFunc..'() ]', sTip)
			else
				sTip =  GetTip(varCurr, 'global')
				if sTip ~= nil then
					Output(varCurr..'  [ Global ]', sTip)
				else
					Output(varCurr, 'No tip for this variable is available!')
				end
			end
		elseif fIsFuncTip then
			sTip =  GetTip(varCurr, varCurr)
			if sTip ~= nil then
				Output(varCurr..'( )', sTip)
			else
				Output(varCurr..'( )', 'No tip for this function is available!')
			end
		else
			sTip =  GetTip(varCurr, 'global')
			if sTip ~= nil then
				Output(varCurr..'  [ Global ]', sTip)
			else
				Output(varCurr, 'No tip for this variable is available!')
			end
		end
	end
end
----------------------------------------------------------------------------------------------------------------------------------
