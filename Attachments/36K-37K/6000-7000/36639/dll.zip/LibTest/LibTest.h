#ifndef __LIBTEST_H__
#define __LIBTEST_H__

#include <windows.h>

#define DLL_EXPORT __declspec(dllexport)
//#define DLL_EXPORT __declspec(dllexport) __stdcall

#ifdef __cplusplus
extern "C"
{
#endif

int DLL_EXPORT addition(int integer1, int integer2);

#ifdef __cplusplus
}
#endif

#endif // __MAIN_H__
