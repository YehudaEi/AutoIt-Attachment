#include "LibTest.h"
#include <stdio.h>

int DLL_EXPORT addition(int integer1, int integer2) {
    char str[100];

    sprintf(str, "%d + %d = %d", integer1, integer2, integer1 + integer2);
    MessageBox(NULL, str, TEXT("In DLL"), MB_OK);
    return integer1 + integer2;
}

BOOL WINAPI DllMain(HINSTANCE hinstDLL, DWORD fdwReason, LPVOID lpvReserved)
{
    switch (fdwReason)
    {
        case DLL_PROCESS_ATTACH:
            // Gets called when you call DLLOpen()
            // attach to process
            // return FALSE to fail DLL load
            break;

        case DLL_PROCESS_DETACH:
            // Gets called when you call DLLClose()
            // detach from process
            break;

        case DLL_THREAD_ATTACH:
            // attach to thread
            break;

        case DLL_THREAD_DETACH:
            // detach from thread
            break;
    }
    return TRUE; // succesful
}
