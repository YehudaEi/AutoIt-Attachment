#include <stdio.h>
#include <stdlib.h>
#include <windows.h>

int main(int argc, char *argv[]) {
    HINSTANCE DLLHandle;
    typedef  int(*f_ptr)(int, int);
    f_ptr addition;

    DLLHandle = LoadLibrary("LibTest.dll");
    if (DLLHandle == NULL) {
        printf("Error loading DLL\r\n");
        return 1;
    }
    addition = (f_ptr)GetProcAddress(DLLHandle,"addition");
    if (addition == NULL) {
        printf("Error function addition not found\r\n");
        FreeLibrary(DLLHandle);
        return 2;
    }
    int resultat = 0;
    resultat = addition(3,7);
    printf("%d + %d = %d\r\n", 3, 7, resultat);
    FreeLibrary(DLLHandle);
    return  0;
}
