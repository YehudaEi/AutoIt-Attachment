Installing:
Extract the 32-bit or 64-bit binaries (depending on your OS) to a folder, e.g.
C:\Program Files\RBTray.  Double click RBTray.exe to start it.  If you want it
to automatically start after you reboot, create a shortcut to RBTray.exe in
your Start menu's Startup group.

Using:
Right click on any program's minimize button to minimize it to the tray.  To
restore, single-click the program's icon in the tray.

Exiting:
Right click on any tray icon created by RBTray and click Exit RBTray in the
popup menu.  Or run RBTray.exe with the --exit parameter.
