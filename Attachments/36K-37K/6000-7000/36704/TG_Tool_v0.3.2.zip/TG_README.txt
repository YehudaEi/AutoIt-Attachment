TG_Tools Software versions

PURPOSE
--the software is a hotkey software
--when the hotkeys are pressed, it will paste the template file contents to wherever the mouse is without having to open a file, copy contents and paste it

KUDOS AND VERY HIGH THANKS TO AUTOIT EXPERTS
--can't say enough about AUTOIT
--I am not a programmer at all but the above allowed me to create exactly what I wanted to do (for now anyway)
--Holger-this OUTSTANDING, I could not have done this without your expertise and dedication
--this includes other AutoIT examples - ModernMenuRaw.au3, Minime, ModernMenuLib_with_Tray are OUTSTANDING examples of knowledge of programming and mentors that are willing to share their work to let inexperienced programmers learn from their knowledge


v0.1
	--started basics design, VERY HIGH KUDOS to previous developers
	--started with basic concepts, think of what I want for the tray menu
	--thoughts that wanted to create a hotkey application, make templates, links to open the text files to edit them
	--capability to copy file contents and paste them no matter where my mouse is
	--a few other links in another menu to allow me to access tools, hyperlinks, exe, etc 
	
	
v0.2
	--add hyperlinks to 3 different links
	--enabled tray to open template files CA1,2,3....0
	--got basic links to open up
	
v0.3
	--got the colors and icons functional
	--put in basic html links to show how to open web page link


