#include <windows.h>
#define EXPORT extern "C" __declspec(dllexport) __stdcall

// DLL initialization
BOOL APIENTRY
DllMain(HANDLE hModule, DWORD dwReason, LPVOID lpReserved)
{
        return TRUE;
}

// Defined Functions to be available to other processes
EXPORT char* MyMessageBox(char* String)
{
        MessageBox(NULL, String, "I am called correctly!", MB_OK);
        return String;
}

EXPORT int Add(int a, int b)
{
       return a + b;
}

EXPORT int Sub(int a, int b)
{
       return a - b;
}
