======================
 Easy Cursor Location
       by Wake
*Updated on 04/06/2007 ~~~ By Salazarcheats*
======================


Easy tool for use with autoit. It shows the location of your mouse cursor.


Features:
 - Shows the current cursor/mouse location.
 - Stores the location of your cursor by pressing "F4"
 - Possible to clear the stored locations by pressing "F3"
 - It is possible to changes the hotkeys in de "settings.ini"
 - Its also possible to change the location of the window.




============================================
        This program is written in:
    http://www.autoitscript.com/autoit3/
============================================