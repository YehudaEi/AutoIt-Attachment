/*
Compile with GNU C:
>gcc MakeCUI.c -limagehlp -Wl,-O2 -o "MakeCUI.exe"

Compile with Tiny C:
imagehlp.h and imagehlp.def are not included with tcc but you can build imagehlp.def with tiny_impdef
and use imagehlp.h form gcc/mingw headers.
>tcc MakeCUI.c -limagehlp -lkernel32

Compile with Borland C++ 5:
>bcc32 -O2 -w-8008 MakeCUI.c

*/

#include <stdio.h>
#include <stdlib.h>
#include <windows.h>
#include <imagehlp.h>

// Definitions for late bindings
BOOL (__stdcall *_MapAndLoad)(LPSTR, LPSTR, PLOADED_IMAGE, BOOL, BOOL);
BOOL (__stdcall *_UnMapAndLoad)(PLOADED_IMAGE);
BOOL (__stdcall *_TouchFileTimes)(HANDLE, PVOID);

#define CheckError(condition, iErr, zErr) if (condition) {ReportError(iErr, zErr);}

void ReportError(int iErr, char *zErr) {
    fputs(zErr,stderr);
    if (iErr > 0) {
        exit(iErr);
    }
}

void DoLateBindings (void) {
    /*
      Current msdn (msdn2.microsoft.com) says that MapAndLoad and UnMapAndLoad are present
      on Win9x but my old WIN32.HLP says its present since NT4 and available as redistributable
      for 9x ...
    */
    HINSTANCE hImagehlp;

    hImagehlp = LoadLibrary("imagehlp.dll");
    CheckError(!hImagehlp, 5, "imagehlp.dll not found.");
    _MapAndLoad = GetProcAddress(hImagehlp,"MapAndLoad");
    _UnMapAndLoad = GetProcAddress(hImagehlp,"UnMapAndLoad");
    _TouchFileTimes = GetProcAddress(hImagehlp,"TouchFileTimes");
    CheckError(((!_MapAndLoad)||(!_UnMapAndLoad)), 6,"imagehlp.dll not compatible.");
}

int main(int argc, char *argv[]) {
    if (argc == 2) {
        LOADED_IMAGE li;
        PIMAGE_NT_HEADERS inh;

        DoLateBindings();
        // Load file and map into memory
        CheckError(!_MapAndLoad(argv[1], "", &li, FALSE, FALSE),2,"Error loading image");
        inh = li.FileHeader;
        // Check for valid PE signature
        if (inh->Signature == 17744 ) // "PE\0\0"
        {
            // Signature ok
            // Modify the subsytem flag in the in memory image
            inh->OptionalHeader.Subsystem = IMAGE_SUBSYSTEM_WINDOWS_CUI;

            /*
              TouchFileTimes is only available since Win2k so only use
              it when its available
            */
            CheckError(!_TouchFileTimes, 0, "TouchFileTimes not supported by imagehlp.dll");
            if (_TouchFileTimes) {
                CheckError(!_TouchFileTimes(li.hFile,NULL), 0, "TouchFileTimes failed.");
            }

            // Save changes and free memory
            CheckError(!_UnMapAndLoad(&li), 4, "Error Writing Image.");

            // Modification sucessfull
            puts("Subsytem changed to CUI");
            return 0;
        } else {
            // Signature not ok
            // Unmap and free memory
            _UnMapAndLoad(&li);
            CheckError(TRUE,3,"Invalid Signature.");
        }
    } else {
        // Wrong Parameter Count
        printf("Usage: %s <exefile>\n",argv[0]);
    }
    return 1;
}
