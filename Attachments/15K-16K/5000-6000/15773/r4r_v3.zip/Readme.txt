...r4r Media Player...         (July 2007)



Info: 
	A lightweight media player created with Autoit v3.2.4.9.(http://www.autoitscript.com/autoit3/).
	
	I started this project to learn Autoit3 scripting. Therefore, this is experimental. Use at your own risk.
This is tested on a Windows XP SP2 machine.
Check here for more info: http://www.autoitscript.com/forum/index.php?showtopic=48542

	Features:

	. Play/pause, stop, skip tracks.
	. Random play, Loop track.
	. Volume control
	. Seek function.
	. Import PLS and M3U playlists.
	. Load single/multiple media files by folder/subfolder.
	. Lyric search. (The player will automatically search for the lyrics of the songs you play if the Lyric window is open.
					You will have two options, either search on absolutelyrics.com or azlyrics.com. (more soon)
					Lyrics found are automatically stored in a folder in the install folder
					so it don't have to search again for lyrics already found.)
	. Skins! You can change skins through the right-click context menu.
	. Drag & drop single/multiple files/folders including playlists.
	. Play Videos. (Only *.asf and *.wmv have been tested however. Press Alt+F to toggle fullscreen playback)

	The following filetypes can now be loaded:
	*.cda; *.mp3; *.wav; *.wma;*.asf; *.mpg; *.wmv; *.avi
	(more will be added or removed.)
	
	The player uses MCI, an API for controlling multimedia peripherals to play the various media files.
A media file may or may not be supported depending on MCI device installed on your system.
This means that the player can play virtually any media filetype that you Windows system supports.
For more information about MCI see http://msdn2.microsoft.com/en-us/library/ms704979.aspx.



How to use:
	Just extract the files (r4r.exe and the 'skin' folder) into a directory. Execute r4r. At fir
	
		
		
License:		
	This is FREEWARE. You can use it for FREE, for as long as you like.
You may reproduce and distribute an unlimited number of copies of this player provided that 
each copy shall be a true and complete copy, including all documents.



Disclaimer:
	A user of this (r4r media player) software acknowledges that he or she is 
receiving this software on an "as is" basis and the user is not relying on the accuracy 
or functionality of the software for any purpose. The user further acknowledges that any use of 
this software will be at the user's own risk and the copyright owner accepts no responsibility 
whatsoever arising from the use or application of the software. 
 
 
 
Author: RONRIEL 
(ronriel@yahoo.com)