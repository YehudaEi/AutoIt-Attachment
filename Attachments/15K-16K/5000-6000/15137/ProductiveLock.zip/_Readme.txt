When run, CTRL+ALT+L will "Lock" your computer.  The default password (easily configurable)
is left-click, right-click, CTRL, ALT.  Experiment with it!

(If you intend to experiment, you should uncomment the #hidetrayicon)

Once you have it the way you like it, I recommend compiling it and dumping it in your Startup 
folder or writing a startup registry key.

Enjoy!

-TehBeyond


--------------*Notes*----------------
The compiled version included can be decompiled with a blank passphrase.

productivelockread.au3 is intended to be read and understood.
productivelockshort.au3 is designed to be compiled.  (the includes are taken out)

the sound file is nice to have in the compiled script so that you the Lock launched with Windows.