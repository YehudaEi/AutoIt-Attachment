
    Readme for AutoPaste v. 1.0

  Latest version: http://www.FavesSoft.com/hotkeys.html

  AutoPaste is my variation on AutoIt3 code orininally
  posted on AutoIt3 Forum

  http://www.autoitscript.com/forum/index.php?showtopic=96816

  The purpose of the program is to allow you to select source in
  a browser or whatever and via a hotkey, save it to a file.

  If you browse to the above forum topic you may find smaller
  and simpler variations on the same theme.  Since I already
  had hotkey select dialogs with Vista eye candy, I used those
  in this program.

  The About dialog shows the current hotkeys.  By default
  Shift F8 opens the Save dialog, and Alt F8 edits the last
  file saved with the editor registered for that file type.

  The About dlg times out in 10 seconds but if you hold the left mouse
  button down it will stay open until the mouse button is released.


  Notes: 

  When usig the file save dialog, to prevent an extension
  from being added, put a dot ('.') at the end of the filename.
  As example, to save as filename TEST type TEST.(the word
  TEST followed by a dot)in the control.  Otherwise the
  default extension of the last saved file type will be added.

  To have the save dialog fill in a default filename from the
  active window title, set AutoName=1 in the .ini file.  To
  disable this, set AutoName=0.

  If you press the hotkey to edit the last saved file and nothing
  happens, chances are the last file save gave an error or no
  file was saved in the current session.

  The .ini file saves the last save folder location.  If the folder
  should be deleted before the file save dialog is invoked again,
  you will get an error about the location being inaccessible. Just
  ignore the error and create or navigate to a folder as desired.

  MilesAhead

  