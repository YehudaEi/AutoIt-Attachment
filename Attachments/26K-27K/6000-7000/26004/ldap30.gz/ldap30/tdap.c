/*
 * Sensus Consulting Ltd (C) 1997
 * Matt Newman
 *
 * ldap.c - Bindings to Netscape LDAP SDK
 *
 */

#include "tcl.h"
#ifdef _WIN32
#include <windows.h>
#endif
#include "lber.h"
#include "ldap.h"

#ifndef TDAP_MODULE
#define TDAP_MODULE "ldap"
#endif

#ifdef DEBUG
extern int ldap_debug = 99;
extern int lber_debug = 99;
#endif
#ifdef NSLDAP
#define TDAP_ERROR(ld)	ldap_err2string( ldap_get_lderrno(ld,NULL,NULL))
#else
#define ldap_memfree( dn )	free( (char*)dn)
#define TDAP_ERROR(ld)	ldap_err2string( ld->ld_errno)
#endif
/*
 * Internal Routines
 */
static int	LdapCmd _ANSI_ARGS_((ClientData clientData,
		    Tcl_Interp *interp, int objc, Tcl_Obj *CONST objv[]));
static int	LdapObjCmd _ANSI_ARGS_((ClientData clientData,
		    Tcl_Interp *interp, int objc, Tcl_Obj *CONST objv[]));
static void	LdapObjDelete _ANSI_ARGS_(( ClientData data));

static struct timeval timeout = {
	120, 0
};

static Tcl_Obj *
Entry2List(Tcl_Interp *interp, LDAP *ld, LDAPMessage *e,
		   int attrsonly, int namesonly)
{
	BerElement	*ber;
	Tcl_Obj		*listPtr, *subListPtr;
	char		*dn = NULL, *attr;
	char		**vals;
	int			i;


	dn = ldap_get_dn( ld, e );
	if (namesonly) {
		if (dn != NULL) {
			listPtr = Tcl_NewStringObj( dn, -1);
			ldap_memfree(dn);
			return listPtr;
		} else {
			return Tcl_NewStringObj("",-1);
		}
	}
	listPtr = Tcl_NewListObj(0, (Tcl_Obj **) NULL);
	if (dn != NULL) {
		if (!attrsonly) {
			Tcl_ListObjAppendElement(interp, listPtr,
				Tcl_NewStringObj( "dn", -1));
		}
		Tcl_ListObjAppendElement(interp, listPtr,
			Tcl_NewStringObj( dn, -1));
		ldap_memfree( dn );
	}
	for ( attr = ldap_first_attribute( ld, e, &ber );
		attr != NULL; attr = ldap_next_attribute( ld, e, ber ) ) {
		
		Tcl_ListObjAppendElement(interp, listPtr,
			Tcl_NewStringObj( attr, -1));
		if (attrsonly) {
			ldap_memfree( attr );
			continue;
		}
		/* each attribute in LDAP can have a list of values */
		subListPtr = Tcl_NewListObj(0, (Tcl_Obj **) NULL);
		if ((vals = ldap_get_values( ld, e, attr)) != NULL ) {
			for ( i = 0; vals[i] != NULL; i++ ) {
				Tcl_ListObjAppendElement(interp, subListPtr,
					Tcl_NewStringObj( vals[i], -1));
			}
			ldap_value_free( vals );
		}
		Tcl_ListObjAppendElement(interp, listPtr, subListPtr);
		ldap_memfree( attr );
	}
	if ( ber != NULL ) {
		ber_free( ber, 0 );
	}
	return listPtr;
}

static char*
ParentDN( char* dn)
{
	char	*parent, **rdns;
	int		i, len;

	if (dn == (char *)0 || *dn == '\0') {
		return (char *)strdup("");
	}
	if ((rdns = ldap_explode_dn( dn, 0)) == NULL) {
		return NULL;
	}
	len = 1;
	for (i=1;rdns[i] != NULL;i++) {
		len += (2 + strlen(rdns[i]));	/* room from ", " and RDN */
	}
	if ((parent = (char *)malloc(len)) == (char *)0) {
		ldap_value_free(rdns);
		return (char *)NULL;
	}
	/* construct parent dn from RDNS */
	*parent = '\0';
	for (i=1;rdns[i]!=NULL;i++) {
		if (i > 1) {
			(void)strcat( parent, ", ");
		}
		(void)strcat( parent, rdns[i]);
	}
	ldap_value_free(rdns);
	return parent;
}

/*
 * Creates a new Tcl command, bound to a LDAP *
 * handle.
 */
static int
LdapCmd(dummy, interp, objc, objv)
    ClientData dummy;
    Tcl_Interp *interp;
    int		objc;
    Tcl_Obj	*CONST objv[];
{
	LDAP	*ld;
	char	inst[BUFSIZ];
	char	*opt, *host = "";
	int		idx, port = LDAP_PORT;
#ifdef LDAP_VERSION3
	int	version = LDAP_VERSION3;
#else
	int	version = 2;
#endif
	static int count = 0;

	for (idx = 1;(objc - idx) > 0;idx += 2) {
		opt = Tcl_GetStringFromObj(objv[idx], (int *) NULL);
		if (opt[0] != '-')
			break;
		if (strcmp( "-timeout", opt)==0) {
			if (Tcl_GetIntFromObj(interp,objv[idx+1],
					(int *)&timeout.tv_sec) != TCL_OK)
				return TCL_ERROR;
		} else if (strcmp( "-version", opt)==0) {
			if (Tcl_GetIntFromObj(interp,objv[idx+1],
					(int *)&version) != TCL_OK)
				return TCL_ERROR;
		} else {
			Tcl_AppendResult(interp, "bad option \"", opt,
				"\": must be -timeout or -version", (char*)NULL);
			return TCL_ERROR;
		}
	}
	if ((objc - idx) > 2) {
		Tcl_WrongNumArgs(interp, 2, objv, "?-timeout sec? ?host? ?port?");
		return TCL_ERROR;
	}
	if ((objc - idx) > 0) {
		host = Tcl_GetStringFromObj(objv[idx], (int *) NULL);
	}
	if ((objc - idx) > 1 &&
		Tcl_GetIntFromObj(interp, objv[idx+1], &port) != TCL_OK)
		return TCL_ERROR;

	/* get a handle to an LDAP connection */
	if ( (ld = ldap_init( host, port )) == NULL ) {
		Tcl_AppendResult(interp, "couldn't create ldap session: ",
			Tcl_PosixError(interp), (char *) NULL);
		return TCL_ERROR;
	}
#ifdef NSLDAP
	if (timeout.tv_sec > 0) {
		ldap_set_option( ld, LDAP_OPT_TIMELIMIT, (void *)&timeout.tv_sec);
	}
#ifdef LDAP_VERSION3
	ldap_set_option( ld, LDAP_OPT_REFERRALS, LDAP_OPT_OFF);
	ldap_set_option( ld, LDAP_OPT_PROTOCOL_VERSION, &version );
#endif
#endif
	sprintf(inst, "ldap%d", count++);

	Tcl_CreateObjCommand( interp, inst, LdapObjCmd,
		(ClientData)ld, (Tcl_CmdDeleteProc *)LdapObjDelete);
	Tcl_SetResult( interp, inst, TCL_VOLATILE);
	return TCL_OK;
}

/*
 * Process operations on a valid LDAP handle.
 */
static int
LdapObjCmd(data, interp, objc, objv)
    ClientData data;
    Tcl_Interp *interp;
    int		objc;
    Tcl_Obj	*CONST objv[];
{
	LDAP	*ld = (LDAP *)data;
	int		index;
    static char *options[] = {
		"add", "bind", "compare", "delete", "join", "modify",
			"modrdn", "parent", "search", "split", "url", NULL
	};
    enum options {
		TDAP_ADD, TDAP_BIND, TDAP_COMPARE, TDAP_DELETE, TDAP_JOIN, TDAP_MODIFY,
			TDAP_MODRDN, TDAP_PARENT, TDAP_SEARCH, TDAP_SPLIT, TDAP_URL
    };	  
    if (objc < 2) {
		Tcl_WrongNumArgs(interp, 1, objv, "option ?arg arg ...?");
		return TCL_ERROR;
    }    
    if (Tcl_GetIndexFromObj(interp, objv[1], options, "option", 0,
	    &index) != TCL_OK) {
		return TCL_ERROR;
    }
    switch ((enum options) index) {
	case TDAP_ADD: {
		/*
		 * add dn ?fld valList? ...
		 */
		LDAPMod	*mod, **moda;
		char	*dn = NULL;
		int		i, ret = TCL_OK;

		if (objc < 3 || (objc % 2) == 0) {
			Tcl_WrongNumArgs(interp, 2, objv, "dn ?fld valList? ...");
			return TCL_ERROR;
		}
		dn = Tcl_GetStringFromObj(objv[2], (int *) NULL);

		mod = (LDAPMod *)malloc( ((objc - 3)/2 + 1)*sizeof(LDAPMod));
		moda = (LDAPMod **)malloc( ((objc - 3)/2 + 1)*sizeof(LDAPMod*));
		for (i = 0;i < (objc - 3)/2;i++) {
			char	*attr, *val;
			int		vlen;

			attr = Tcl_GetStringFromObj(objv[2*i + 3], (int *) NULL);
			val = Tcl_GetStringFromObj(objv[2*i + 4], (int *) NULL);

			mod[i].mod_op = LDAP_MOD_ADD;
			mod[i].mod_type = attr;
			Tcl_SplitList(interp, val, &vlen, &mod[i].mod_values);

			moda[i] = &mod[i];
		}
		moda[i] = NULL;

		if ( ldap_add_s (ld, dn, moda) != LDAP_SUCCESS) {
			Tcl_AppendResult(interp, "ldap_add: ",
				TDAP_ERROR(ld), (char *) NULL);
			ret = TCL_ERROR;
		}
		for (i=0;moda[i];i++) {
			Tcl_Free( (char*)moda[i]->mod_values);
		}
		free( mod);
		free( moda);

		return ret;
	}	/*TDAP_ADD*/
	case TDAP_BIND: {
		char	*dn = NULL;
		char	*pw = NULL;

		if (objc > 4) {
			Tcl_WrongNumArgs(interp, 2, objv, "?dn? ?pw?");
			return TCL_ERROR;
		}
		if (objc > 2)
			dn = Tcl_GetStringFromObj(objv[2], (int *) NULL);
		if (objc > 3)
			pw = Tcl_GetStringFromObj(objv[3], (int *) NULL);

		if (ldap_simple_bind_s(ld, dn, pw) != LDAP_SUCCESS) {
			Tcl_AppendResult(interp, "couldn't bind ldap session: ",
				TDAP_ERROR(ld), (char *) NULL);
			return TCL_ERROR;
		}
		return TCL_OK;
	}	/*TDAP_BIND*/
	case TDAP_COMPARE: {
		/*
		 * compare dn attr value
		 */
		char	*dn, *attr, *value;
		int		rc;

		if (objc != 5) {
			Tcl_WrongNumArgs(interp, 2, objv, "dn attr value");
			return TCL_ERROR;
		}
		dn = Tcl_GetStringFromObj(objv[2], (int *) NULL);
		attr = Tcl_GetStringFromObj(objv[3], (int *) NULL);
		value = Tcl_GetStringFromObj(objv[4], (int *) NULL);

		rc = ldap_compare_s (ld, dn, attr, value);
		if (rc == LDAP_COMPARE_TRUE) {
			Tcl_SetResult( interp, "1", TCL_STATIC);
			return TCL_OK;
		} else if (rc == LDAP_COMPARE_FALSE) {
			Tcl_SetResult( interp, "0", TCL_STATIC);
			return TCL_OK;
		} else {
			Tcl_AppendResult(interp, "ldap_compare: ",
				TDAP_ERROR(ld), (char *) NULL);
			return TCL_ERROR;
		}
	}	/*TDAP_COMPARE*/
	case TDAP_DELETE: {
		/*
		 * delete dn
		 */
		char	*dn;

		if (objc != 3) {
			Tcl_WrongNumArgs(interp, 2, objv, "dn");
			return TCL_ERROR;
		}
		dn = Tcl_GetStringFromObj(objv[2], (int *) NULL);

		if ( ldap_delete_s (ld, dn) != LDAP_SUCCESS) {
			Tcl_AppendResult(interp, "ldap_delete: ",
				TDAP_ERROR(ld), (char *) NULL);
			return TCL_ERROR;
		}
		return TCL_OK;
	}	/*TDAP_DELETE*/
	case TDAP_JOIN: {
		/*
		 * join rdnlist
		 */
		char	*dn, *tmp;
		Tcl_Obj **lobjv;
		int		i, lobjc;

		if (objc != 3) {
			Tcl_WrongNumArgs(interp, 2, objv, "rdnlist");
			return TCL_ERROR;
		}
		tmp = Tcl_GetStringFromObj(objv[2], (int *) NULL);
		if (Tcl_ListObjGetElements(interp, objv[2], &lobjc, &lobjv) != TCL_OK)
			return TCL_ERROR;
		/* allocate enough space for dn */
		dn = Tcl_Alloc( strlen(tmp) + lobjc*2);
		dn[0] = '\0';
		for (i=0;i<lobjc;i++) {
			if (i!=0) {
				strcat( dn, ", ");
			}
			strcat( dn, Tcl_GetStringFromObj(lobjv[i], (int*)NULL));
		}
		Tcl_SetResult( interp, dn, TCL_DYNAMIC);
		return TCL_OK;
	}	/*TDAP_JOIN*/
	case TDAP_MODIFY: {
		/*
		 * modify dn
		 *			?add: fld valList ...?
		 *			?mod: fld valList...?
		 *			?del: fld ...?
		 */
		LDAPMod	*mod, **moda;
		char	*dn;
		int		i, mode, count, ret = TCL_OK;

		if (objc < 4) {
mod_err:
			Tcl_WrongNumArgs(interp, 2, objv, "dn ?add: fld vals ...? ?mod: fld vals ...? ?del: fld ...?");
			return TCL_ERROR;
		}
		dn = Tcl_GetStringFromObj(objv[2], (int *) NULL);

		/*
		 * Validate arguments, and count number of descrete changes
		 */
		mode = -1;
		for (count=0,i=3;i < objc;i++) {
			char	*opt;

			opt = Tcl_GetStringFromObj(objv[i], (int *) NULL);
			if (strcmp( opt, "add:")==0) {
				mode = LDAP_MOD_ADD;
				continue;
			}
			if (strcmp( opt, "mod:")==0) {
				mode = LDAP_MOD_REPLACE;
				continue;
			}
			if (strcmp( opt, "del:")==0) {
				mode = LDAP_MOD_DELETE;
				continue;
			}
			switch (mode) {
			case LDAP_MOD_ADD:
			case LDAP_MOD_REPLACE:
				if (objc - i < 2) {
					goto mod_err;
				}
				i++;
				count++;
				break;
			case LDAP_MOD_DELETE:
				count++;
				break;
			default:
				goto mod_err;
			}
		}
		if (count == 0)
			return TCL_OK;

		mod = (LDAPMod *)malloc( (count + 1)*sizeof(LDAPMod));
		moda = (LDAPMod **)malloc( (count + 1)*sizeof(LDAPMod*));
		/*
		 * Process arguments, and generate the LDAPMod array.
		 */
		mode = -1;
		for (count=0,i=3;i < objc;i++) {
			char	*opt, *attr, *val;
			int		vlen;

			opt = Tcl_GetStringFromObj(objv[i], (int *) NULL);
			if (strcmp( opt, "add:")==0) {
				mode = LDAP_MOD_ADD;
				continue;
			}
			if (strcmp( opt, "mod:")==0) {
				mode = LDAP_MOD_REPLACE;
				continue;
			}
			if (strcmp( opt, "del:")==0) {
				mode = LDAP_MOD_DELETE;
				continue;
			}
			attr = Tcl_GetStringFromObj(objv[i], (int *) NULL);
			switch (mode) {
			case LDAP_MOD_ADD:
			case LDAP_MOD_REPLACE:
				val = Tcl_GetStringFromObj(objv[i+1], (int *) NULL);

				mod[count].mod_op = mode;
				mod[count].mod_type = attr;
				Tcl_SplitList(interp, val, &vlen, &mod[count].mod_values);

				moda[count] = &mod[count];
				/* skip val */
				i++;
				count++;
				break;
			case LDAP_MOD_DELETE:
				mod[count].mod_op = mode;
				mod[count].mod_type = attr;
				mod[count].mod_values = NULL;

				moda[count] = &mod[count];

				count++;
				break;
			}
		}
		moda[count] = NULL;

		if ( ldap_modify_s (ld, dn, moda) != LDAP_SUCCESS) {
			Tcl_AppendResult(interp, "ldap_modify: ",
				TDAP_ERROR(ld), (char *) NULL);
			ret = TCL_ERROR;
		}
		for (i=0;moda[i];i++) {
			if (moda[i]->mod_values != NULL)
				Tcl_Free( (char*)moda[i]->mod_values);
		}
		free( mod);
		free( moda);

		return ret;
	}	/*TDAP_MODIFY*/
	case TDAP_MODRDN: {
		/*
		 * modrdn dn rdn ?retain?
		 */
		char	*dn, *rdn;
		int		retain = 0;

		if (objc < 4 || objc > 5) {
			Tcl_WrongNumArgs(interp, 2, objv, "dn rdn ?retain?");
			return TCL_ERROR;
		}
		dn = Tcl_GetStringFromObj(objv[2], (int *) NULL);
		rdn = Tcl_GetStringFromObj(objv[3], (int *) NULL);
		if (objc == 5 &&
			Tcl_GetBooleanFromObj(interp,objv[4], &retain) != TCL_OK)
			return TCL_ERROR;

		if (ldap_modrdn2_s(ld, dn, rdn, retain) != LDAP_SUCCESS) {
			Tcl_AppendResult(interp, "ldap_modrdn2: ",
				TDAP_ERROR(ld), (char *) NULL);
			return TCL_ERROR;
		}
		return TCL_OK;
	}	/*TDAP_MODRDN*/
	case TDAP_PARENT: {
		/*
		 * parent dn
		 */
		char	*dn, *pdn;

		if (objc != 3) {
			Tcl_WrongNumArgs(interp, 2, objv, "dn");
			return TCL_ERROR;
		}
		dn = Tcl_GetStringFromObj(objv[2], (int *) NULL);
		pdn = ParentDN( dn);
		
		if (pdn == NULL) {
			Tcl_AppendResult(interp, "badly formed dn: ", dn, (char *) NULL);
			return TCL_ERROR;
		} else {
			Tcl_SetResult( interp, pdn, TCL_DYNAMIC);
			return TCL_OK;
		}
	}	/*TDAP_PARENT*/
	case TDAP_SEARCH: {
		static char *scopeOpts[] = {
			"base", "onelevel", "subtree", NULL
		};
		LDAPMessage	*result, *e;
		char	*base, *filter, *opt;
		char	**attrs = NULL;
		int		scope = LDAP_SCOPE_BASE;
		int		attrsonly = 0;
		int		namesonly = 0;
		int		idx, msgid, rc;
		Tcl_Obj *listPtr;

		for (idx = 2;(objc - idx) > 1;idx += 2) {
			opt = Tcl_GetStringFromObj(objv[idx], (int *) NULL);
			if (opt[0] != '-')
				break;
			if (strcmp( "-scope", opt)==0) {
				if (Tcl_GetIndexFromObj(interp, objv[idx+1], scopeOpts, "scope", 0,
					&scope) != TCL_OK) {
					return TCL_ERROR;
				}
			} else if (strcmp( "-attrs", opt)==0) {
				if (Tcl_GetBooleanFromObj(interp,objv[idx+1], &attrsonly) != TCL_OK)
					return TCL_ERROR;
			} else if (strcmp( "-names", opt)==0) {
				if (Tcl_GetBooleanFromObj(interp,objv[idx+1], &namesonly) != TCL_OK)
					return TCL_ERROR;
				if (namesonly)
					attrsonly = 1;
			} else {
				Tcl_AppendResult(interp, "bad option \"", opt,
					"\": must be -attrs, -names or -scope", (char*)NULL);
				return TCL_ERROR;
			}
		}
		if ((objc - idx) < 1) {
			Tcl_WrongNumArgs(interp, 2, objv, "?options? base ?filter? ?attrs ...?");
			return TCL_ERROR;
		}
		base = Tcl_GetStringFromObj(objv[idx], (int *) NULL);
		if ((objc - idx) > 1)
			filter = Tcl_GetStringFromObj(objv[idx+1], (int *) NULL);
		else
			filter = "objectClass=*";

		idx += 2;
		if (idx < objc) {
			int j;

			attrs = (char**)malloc( (objc-idx+1)*sizeof(char*));
			for (j = 0;idx < objc;idx++,j++) {
				attrs[j] = Tcl_GetStringFromObj(objv[idx], (int *) NULL);
			}
			attrs[j] = NULL;
		}
#if 0
rc = ldap_search_ext_s( ld, BASEDN, SCOPE, FILTER, NULL, 0, NULL, NULL, NULL, 0, &result );
#endif
		msgid = ldap_search( ld, base, scope, filter,
				attrs, attrsonly);
		if (attrs != NULL)
			free( (char*)attrs);
		if (msgid == -1 ) {
			Tcl_AppendResult(interp, "couldn't search ldap session: ",
				TDAP_ERROR(ld), (char *) NULL);
			return TCL_ERROR;
		}

		listPtr = Tcl_NewListObj(0, (Tcl_Obj **) NULL);
		while ((rc = ldap_result(ld, msgid, 0, &timeout, &result))
			== LDAP_RES_SEARCH_ENTRY) {
			/* for each entry print out name + all attrs and values */
			for (e = ldap_first_entry( ld, result );e != NULL;
				e = ldap_next_entry( ld, e ) ) {
				Tcl_ListObjAppendElement(interp, listPtr, 
					Entry2List( interp, ld, e, attrsonly, namesonly));
			}
			ldap_msgfree(result);
		}
		/* Must free final result */
		ldap_msgfree(result);
		if (rc == -1 || rc == 0) {
			Tcl_DecrRefCount(listPtr);
			if (rc == -1) {
				Tcl_AppendResult(interp, "couldn't retrieve search results: ",
					TDAP_ERROR(ld), (char *) NULL);
			} else {
				Tcl_AppendResult(interp, "couldn't retrieve search results: timeout",
					(char *) NULL);
			}
			return TCL_ERROR;
		} else {
			Tcl_SetObjResult(interp, listPtr);
			return TCL_OK;
		}
	}	/*TDAP_SEARCH*/
	case TDAP_SPLIT: {
		/*
		 * modify dn
		 *			?add: fld valList ...?
		 *			?mod: fld valList...?
		 *			?del: fld ...?
		 */
		Tcl_Obj *listPtr;
		char	*dn, **rdns;
		int		flag = 0, i;

		if (objc < 3 || objc > 4) {
			Tcl_WrongNumArgs(interp, 2, objv, "dn ?friendly?");
			return TCL_ERROR;
		}
		dn = Tcl_GetStringFromObj(objv[2], (int *) NULL);
		if (objc == 4 && Tcl_GetBooleanFromObj(interp, objv[3], &flag) != TCL_OK)
			return TCL_ERROR;

		if ((rdns = ldap_explode_dn( dn, flag)) == NULL) {
			return TCL_OK;
		}
		listPtr = Tcl_NewListObj(0, (Tcl_Obj **) NULL);
		for (i=0;rdns[i] != NULL;i++) {
			Tcl_ListObjAppendElement(interp, listPtr, 
				Tcl_NewStringObj( rdns[i], -1));
		}
		ldap_value_free(rdns);
		Tcl_SetObjResult(interp, listPtr);
		return TCL_OK;
	}	/*TDAP_SPLIT*/
	case TDAP_URL: {
		LDAPMessage	*result, *e;
		char	*url;
		int		msgid, rc;
		Tcl_Obj *listPtr;

		if (objc != 3) {
			Tcl_WrongNumArgs(interp, 2, objv, "url");
			return TCL_ERROR;
		}
		url = Tcl_GetStringFromObj(objv[2], (int *) NULL);
		/* Perfrom actual LDAP search */
		msgid = ldap_url_search( ld, url, 0);
		if (msgid == -1 ) {
			Tcl_AppendResult(interp, "couldn't search ldap session: ",
				TDAP_ERROR(ld), (char *) NULL);
			return TCL_ERROR;
		}

		listPtr = Tcl_NewListObj(0, (Tcl_Obj **) NULL);
		while ((rc = ldap_result(ld, msgid, 0, &timeout, &result))
			== LDAP_RES_SEARCH_ENTRY) {
			/* for each entry print out name + all attrs and values */
			for (e = ldap_first_entry( ld, result );e != NULL;
				e = ldap_next_entry( ld, e ) ) {
				Tcl_ListObjAppendElement(interp, listPtr, 
					Entry2List( interp, ld, e, 0, 0));
			}
			ldap_msgfree(result);
		}
		if (rc == -1 || rc == 0) {
			Tcl_DecrRefCount(listPtr);
			if (rc == -1) {
				Tcl_AppendResult(interp, "couldn't retrieve search results: ",
					TDAP_ERROR(ld), (char *) NULL);
			} else {
				Tcl_AppendResult(interp, "couldn't retrieve search results: timeout",
					(char *) NULL);
			}
			return TCL_ERROR;
		} else {
			Tcl_SetObjResult(interp, listPtr);
			return TCL_OK;
		}
	}	/*TDAP_URL*/
	}; /*switch*/
	/*NOTREACHED*/
}

static void
LdapObjDelete( data)
	ClientData data;
{
	LDAP	*ld = (LDAP*)data;

	ldap_unbind(ld);
}

DLLEXPORT int
Ldap_Init(interp)
	Tcl_Interp *interp;
{
	Tcl_CreateObjCommand(interp, "ldap", LdapCmd,
		      (ClientData) NULL, (Tcl_CmdDeleteProc *) NULL);

    if (Tcl_PkgProvide(interp, TDAP_MODULE, TDAP_VERSION) != TCL_OK) {
		return TCL_ERROR;
    }
	return TCL_OK;
}

