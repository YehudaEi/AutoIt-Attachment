
#define TEST_SUCCESS                   0
#define TEST_ERR_INIT                  -3001
#define TEST_ERR_INIT_FAILED           -3002

typedef enum {
  TEST_CBK_LOGIN_SUCCESS,                      
  TEST_CBK_LOGOUT_SUCCESS,                       
} TestCbkTypeEnum;

typedef struct {
   char                 mUsername[128];      
   char                 mPassword[128];       
} TestLoginInfo;

typedef struct{
   int                  mEventType;                    //callback event type
} TestCallbackEvent;

#ifdef __cplusplus
extern "C" {
#endif
typedef void (*TestCallback) (const TestCallbackEvent *CallbackEvent);

__declspec(dllexport)int TestCall_Init(void);
__declspec(dllexport)int TestCall_Cleanup(void);

__declspec(dllexport)int TestCall_Login(TestLoginInfo* pInfo, TestCallback Callback);
__declspec(dllexport)int TestCall_Logout(void);

#ifdef __cplusplus
}
#endif
