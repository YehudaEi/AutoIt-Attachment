...::: 883 Titanium v1 :::...
created by 883 aka Kuki
my website	883design.cjb.net
devart profile	883design.deviantart.com
email		kuki@883design.cjb.net
_________________________________________

This is my first self titled skin.  There's not much to say about it, I was experimenting with the a metal pipe and new styles, then decided to make a whole skin.
Why that name?  To be honest, I don't know :), it's metal and sounds cool.  
Inspiration?  A japanese comic.  Eva, you dig? :)
Make sure you check out the vol/bal bar, enjoy.

all windows:	yes
cursors:		no
transparencies:	yes
programs:		psp7
skinning time:	3 days

-Kuki


(C) ALL GRAPHICS BY KUKI.  Please, 
- DO NOT pass this skin as your work
- DO NOT publish this skin without my permission
- DO NOT use elements of my skins for your own projects
- you may edit this skin for PERSONAL USE ONLY

_________________________________________
07:18 4/22/02     883 OUT.