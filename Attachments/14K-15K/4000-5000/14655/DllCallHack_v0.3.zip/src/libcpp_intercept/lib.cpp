/****************************************************************************/
/** intercept.cpp                                                          **/
/** ---------------------------------------------------------------------- **/
/** Example of interception of an API or any DLL function call             **/
/** ---------------------------------------------------------------------- **/
/** The method shown here may be very impressive in conjunction with       **/
/** CreateRemoteThread API                                                 **/
/** ---------------------------------------------------------------------- **/
/** July 23, 1998 by Oleg Kagan                                            **/
/****************************************************************************/

//============================================================================
#include <windows.h>
#pragma hdrstop

// Switch all optimizations off 
// (Visual C specific... For any other compiler do the same thing)
//============================================================================
#pragma optimize("", off)

//============================================================================
#define MakePtr(Type, Base, Offset) ((Type)(DWORD(Base) + (DWORD)(Offset)))

//============================================================================
BOOL InterceptDllCall(

	HMODULE hLocalModule, 
	const char* c_szDllName,
	const char* c_szApiName,
	PVOID pApiNew,
	PVOID* p_pApiOrg,
	PVOID pApiToChange
	
){
    PIMAGE_DOS_HEADER pDOSHeader = (PIMAGE_DOS_HEADER)hLocalModule;
    PIMAGE_NT_HEADERS pNTHeader;
    PIMAGE_IMPORT_DESCRIPTOR pImportDesc;
    DWORD dwProtect;
	BOOL bSuccess = FALSE;
    
    DWORD dwAddressToIntercept; 

	if (pApiToChange) {
		dwAddressToIntercept = (DWORD)pApiToChange;
	}
	else {
		dwAddressToIntercept = (DWORD)GetProcAddress(
			GetModuleHandle((char*)c_szDllName), (char*)c_szApiName
		) /*GetProcAddress*/;
	} /*iff*/;

    if (IsBadReadPtr(hLocalModule, sizeof(PIMAGE_NT_HEADERS)))
        return FALSE;
    
    if (pDOSHeader->e_magic != IMAGE_DOS_SIGNATURE)
        return FALSE;
    
    pNTHeader = MakePtr(PIMAGE_NT_HEADERS, pDOSHeader, pDOSHeader->e_lfanew);
    if (pNTHeader->Signature != IMAGE_NT_SIGNATURE)
        return FALSE;
    
    pImportDesc = MakePtr(
		PIMAGE_IMPORT_DESCRIPTOR, hLocalModule, 
        pNTHeader->OptionalHeader.DataDirectory[
			IMAGE_DIRECTORY_ENTRY_IMPORT
		] /*pNTHeader->OptionalHeader.DataDirectory*/.VirtualAddress
	) /*MakePtr*/;
    
    if (pImportDesc == (PIMAGE_IMPORT_DESCRIPTOR)pNTHeader) return FALSE;
    
	while (pImportDesc->Name) {
		PIMAGE_THUNK_DATA pThunk;
    
		pThunk = MakePtr(
			PIMAGE_THUNK_DATA, hLocalModule, pImportDesc->FirstThunk
		) /*MakePtr*/;
    
		while (pThunk->u1.Function) {
			if ((DWORD)pThunk->u1.Function == dwAddressToIntercept) {	
				if (
					!IsBadWritePtr(
						(PVOID)&pThunk->u1.Function, sizeof(PVOID)
					) /*!IsBadWritePtr*/
				){
					if (p_pApiOrg) 
						*p_pApiOrg = (PVOID)pThunk->u1.Function;
					pThunk->u1.Function = (DWORD)pApiNew;
					bSuccess = TRUE;
				}
				else {
					if (
						VirtualProtect(
							(PVOID)&pThunk->u1.Function, sizeof(PVOID),
							PAGE_EXECUTE_READWRITE, &dwProtect
						) /*VirtualProtect*/
					){
						DWORD dwNewProtect;

						if (p_pApiOrg) 
							*p_pApiOrg = (PVOID)pThunk->u1.Function;
						pThunk->u1.Function = (DWORD)pApiNew;
						bSuccess = TRUE;

						dwNewProtect = dwProtect;
						VirtualProtect(
							(PVOID)&pThunk->u1.Function, sizeof(PVOID),
							dwNewProtect, &dwProtect
						) /*VirtualProtect*/;
					} /*if*/
				} /*iff*/
			} /*if*/
			pThunk++;
		} /*while*/
		pImportDesc++;
	} /*while*/

    return bSuccess;
} /*InterceptDllCall(HMODULE, const char*, const char*, PVOID,PVOID*,PVOID)*/

//============================================================================

BOOL InterceptDllCallA(

	HMODULE hLocalModule, 
	const char* c_szDllName,
	const char* c_szApiName,
	void* pApiNew,
	void** p_pApiOrg,
	void* pApiToChange
	
){
	if (
		!(
			(c_szDllName && *c_szDllName && c_szApiName && *c_szApiName) || 
			pApiToChange
		) /*!*/ ||
		IsBadReadPtr(hLocalModule, sizeof(PIMAGE_NT_HEADERS))
	) return FALSE;

    DWORD p_dwAddrToIntercept; 

	if (pApiToChange) {
		p_dwAddrToIntercept = DWORD(pApiToChange);
	}
	else {
		p_dwAddrToIntercept = (DWORD)GetProcAddress(
			GetModuleHandle((char*)c_szDllName), (char*)c_szApiName
		) /*GetProcAddress*/;
	} /*iff*/;

	BOOL bSuccess = FALSE;

    PIMAGE_DOS_HEADER pDOSHeader = PIMAGE_DOS_HEADER(hLocalModule);
	if (pDOSHeader->e_magic != IMAGE_DOS_SIGNATURE) return FALSE;

    PIMAGE_NT_HEADERS pNTHeader = MakePtr(
		PIMAGE_NT_HEADERS, pDOSHeader, pDOSHeader->e_lfanew
	) /*pNTHeader*/;
    if (pNTHeader->Signature != IMAGE_NT_SIGNATURE) return FALSE;
    
    PIMAGE_IMPORT_DESCRIPTOR pImportDesc = MakePtr(
		PIMAGE_IMPORT_DESCRIPTOR, hLocalModule, 
        pNTHeader->OptionalHeader.DataDirectory[
			IMAGE_DIRECTORY_ENTRY_IMPORT
		] /*pNTHeader->OptionalHeader.DataDirectory*/.VirtualAddress
	) /*pImportDesc*/;
    if (pImportDesc == PIMAGE_IMPORT_DESCRIPTOR(pNTHeader)) return FALSE;
    
	while (pImportDesc->Name) {
		PIMAGE_THUNK_DATA pThunk = MakePtr(
			PIMAGE_THUNK_DATA, hLocalModule, pImportDesc->FirstThunk
		) /*pThunk*/;
    
		while (pThunk->u1.Function) {
			if (pThunk->u1.Function == p_dwAddrToIntercept) {	
				if (
					!IsBadWritePtr(
						(LPVOID)(&pThunk->u1.Function), sizeof(DWORD)
					) /*!IsBadWritePtr*/
				){
					if (p_pApiOrg) *p_pApiOrg = PVOID(pThunk->u1.Function);
					pThunk->u1.Function = DWORD(pApiNew);
					bSuccess = TRUE;
				}
				else {
					DWORD dwProtect;
					if (
						VirtualProtect(
							&(pThunk->u1.Function), sizeof(DWORD),
							PAGE_EXECUTE_READWRITE, &dwProtect
						) /*VirtualProtect*/
					){
						DWORD dwNewProtect;

						if (p_pApiOrg) {
							*p_pApiOrg = PVOID(pThunk->u1.Function);
						} /*if*/
						pThunk->u1.Function = (DWORD)pApiNew;
						bSuccess = TRUE;

						dwNewProtect = dwProtect;
						VirtualProtect(
							&(pThunk->u1.Function), sizeof(DWORD),
							dwNewProtect, &dwProtect
						) /*VirtualProtect*/;
					} /*if*/
				} /*iff*/
			} /*if*/
			++pThunk;
		} /*while (pThunk->u1.Function)*/
		++pImportDesc;
	} /*while (pImportDesc->Name)*/

    return bSuccess;
} /*InterceptDllCallA(HMODULE, const char*, const char*, void*,void**,void*)*/
