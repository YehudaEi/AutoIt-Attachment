Thanks for downloading Blox Online Radio. This zip file should only contain two files, Readme.txt, and BloxRadio.exe.

The exe does not harm your computer in any way. It does not write to the registry.
This program will download a file called, "stations.txt" into your temporary directory during each application startup, or when you manually decide to update the station list.

If you want another radio station to be added to the current list, then please  send me an email with the following information:

Radio Station Name
Streaming URL

to chris95219@gmail.com.


To beging using, all you have to do is select the radio station you would like to listen to and click the "play" button. This will start streaming the radio station. The status of the stream is shown towards the bottom of the window. For extended options you can right click on the tray icon.

---------------------------------------------------------
http://blox.no-ip.org/downloads.php