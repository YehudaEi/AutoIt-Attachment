#include <malloc.h>
#include <gl/glut.h>
#include "mesh.h"

CMeshRepository g_MeshRepository;

/****************************************************************************
 * CMeshRepository
 *
 ****************************************************************************/
void CMeshRepository::SetGroupPtr2First( void )
{
	if( GroupsPtr->PreviousNode != NULL )
	{
		while ( GroupsPtr->PreviousNode != NULL )
		{
			GroupsPtr = GroupsPtr->PreviousNode;
		}
	}
}

//----------------------------------------------------------------------------
tagOBJECT* CMeshRepository::CheckIfObjExists( const char* Name )
{
	tagOBJECT *RetVal = NULL;

    if( ObjectsPtr != NULL )
	{
		tagOBJECT *Temp = ObjectsPtr;
		while ( Temp != NULL )
		{
			if( strcmp( Temp->Name, Name ) == 0 )
			{
				RetVal = Temp;
				break;
			}
			Temp = Temp->NextNode;
		}
	}

	return RetVal;
}

//----------------------------------------------------------------------------
tagGROUP* CMeshRepository::CheckIfGroupExists( const char* Name )
{
	tagGROUP *RetVal = NULL;

    if( GroupsPtr != NULL )
	{
		SetGroupPtr2First( );
		tagGROUP *Temp = GroupsPtr;
		while ( Temp != NULL )
		{
			if( strcmp( Temp->GroupName, Name ) == 0 )
			{
				RetVal = Temp;
				break;
			}
			Temp = Temp->NextNode;
		}
	}

	return RetVal;
}

//----------------------------------------------------------------------------
int CMeshRepository::AddObject( const char* Name )
{
    int RetVal = 1;

     //add new object
    if( CheckIfObjExists( Name ) == NULL )
    {
		tagOBJECT *NewObject, *Temp;
		NewObject = new tagOBJECT;

		//feeds NewObject
        NewObject->FaceCounter = 0;
		NewObject->LineCounter = 0;
		NewObject->GlSphereCounter = 0;
		NewObject->GlConeCounter = 0;
        strncpy( NewObject->Name, Name, sizeof( NewObject->Name ) );
		NewObject->Rotate.X = 0;
		NewObject->Rotate.Y = 0;
		NewObject->Rotate.Z = 0;
		NewObject->Translate.X = 0;
		NewObject->Translate.Y = 0;
		NewObject->Translate.Z = 0;
		NewObject->Group = NULL;
		NewObject->PreviousNode = NULL;
		NewObject->NextNode = NULL;

		if( ObjectsPtr == NULL )
		{
			ObjectsPtr = NewObject;
		}
		else
		{
			Temp = ObjectsPtr;

			// We know this is not NULL - list not empty!
			while ( Temp->NextNode != NULL )
			{
				Temp = Temp->NextNode;
			}
			//Is NULL? then feeds
			NewObject->PreviousNode = Temp;
			Temp->NextNode = NewObject;
		}

        RetVal = 0;
    }

    return RetVal;
}

//----------------------------------------------------------------------------
int CMeshRepository::DeleteObject( const char* Name )
{
    int RetVal = 1;

    if( ObjectsPtr != NULL )
	{
		tagOBJECT *Previous, *Next, *TargetObject;
		TargetObject = CheckIfObjExists( Name );
		if( TargetObject != NULL )
		{
			if( TargetObject->PreviousNode != NULL )
			{
				if( TargetObject->NextNode != NULL )
				{
					//realloc if not start or end item
					//
					Previous = TargetObject->PreviousNode;
					Next = TargetObject->NextNode;

					Previous->NextNode = Next;
					Next->PreviousNode = Previous;
				}
				else
				{
					//working on end item
					//
					tagOBJECT *Temp;
					Temp = TargetObject->PreviousNode;
					Temp->NextNode = NULL;
				}
			}
			else
			{
				//working on start item
				//
				tagOBJECT *Temp;
				if( TargetObject->NextNode != NULL )
				{
					Temp = TargetObject->NextNode;
					Temp->PreviousNode = NULL;
					ObjectsPtr = Temp;
				}
				else
				{
					ObjectsPtr = NULL;
				}
			}

			delete TargetObject;
			RetVal = 0;
		}
	}

    return RetVal;
}

//----------------------------------------------------------------------------
void CMeshRepository::TranslateObject( const char* Name, const TPOS3D NewPos )
{
	tagOBJECT *TargetObject = CheckIfObjExists( Name );
    if( TargetObject != NULL )
    {
		TargetObject->Translate = NewPos;
	}
}

//----------------------------------------------------------------------------
void CMeshRepository::RotateObject( const char* Name, const TPOS3D Angles )
{
	tagOBJECT *TargetObject = CheckIfObjExists( Name );
    if( TargetObject != NULL )
    {
		TargetObject->Rotate = Angles;
	}
}

//----------------------------------------------------------------------------
int CMeshRepository::CreateGroup( const char* GroupName )
{
    int RetVal = 1;

     //add new object
    if( CheckIfGroupExists( GroupName ) == NULL )
    {
		tagGROUP *NewGroup, *Temp;
		NewGroup = new tagGROUP;

		//feeds NewObject
        strncpy( NewGroup->GroupName, GroupName, sizeof( NewGroup->GroupName ) );
		NewGroup->Rotate.X = 0;
		NewGroup->Rotate.Y = 0;
		NewGroup->Rotate.Z = 0;
		NewGroup->Translate.X = 0;
		NewGroup->Translate.Y = 0;
		NewGroup->Translate.Z = 0;
		NewGroup->FatherGroup = NULL;
		NewGroup->PreviousNode = NULL;
		NewGroup->NextNode = NULL;

		if( GroupsPtr == NULL )
		{
			GroupsPtr = NewGroup;
		}
		else
		{
			SetGroupPtr2First( );
			Temp = GroupsPtr;

			// We know this is not NULL - list not empty!
			while ( Temp->NextNode != NULL )
			{
				Temp = Temp->NextNode;
			}
			//Is NULL? then feeds
			NewGroup->PreviousNode = Temp;
			Temp->NextNode = NewGroup;
		}

        RetVal = 0;
    }

    return RetVal;
}

//----------------------------------------------------------------------------
int CMeshRepository::SetToGroup( const char* GroupName, const char* Name )
{
    int RetVal = 1;

	tagGROUP *TargetGroup = CheckIfGroupExists( GroupName );
    if( TargetGroup != NULL )
	{
		tagOBJECT *TargetObject = CheckIfObjExists( Name );
		if( TargetObject != NULL )
		{
			TargetObject->Group = TargetGroup;
		}
		else
		{
			tagGROUP *ChildGroup = CheckIfGroupExists( Name );
			if( ChildGroup != NULL )
			{
				ChildGroup->FatherGroup = TargetGroup;
			}
		}
		RetVal = 0;
	}

	return RetVal;
}

//----------------------------------------------------------------------------
void CMeshRepository::TranslateGroup( const char* Name, const TPOS3D NewPos )
{
	tagGROUP *TargetGroup = CheckIfGroupExists( Name );
    if( TargetGroup != NULL )
    {
		TargetGroup->Translate = NewPos;
	}
}

//----------------------------------------------------------------------------
void CMeshRepository::RotateGroup( const char* Name, const TPOS3D Angles )
{
	tagGROUP *TargetGroup = CheckIfGroupExists( Name );
    if( TargetGroup != NULL )
    {
		TargetGroup->Rotate = Angles;
	}
}

//----------------------------------------------------------------------------
int CMeshRepository::AddLine( const char* Name, const TLINE Line )
{
    int RetVal = 1;

	tagOBJECT *TargetObject = CheckIfObjExists( Name );
    if( TargetObject != NULL )
    {
		//pointer to line repository
		long LineSize = sizeof( TLINE );
		long LastSize = LineSize * TargetObject->LineCounter;
		long NewSize = LastSize + LineSize;
		if( TargetObject->LineCounter > 0 )
		{
			TargetObject->Lines = (TLINE*) realloc( TargetObject->Lines, NewSize );
		}
		else
		{
			TargetObject->Lines = (TLINE*) malloc( NewSize );
		}

		//add new line
		TLINE* LineRepository = (TLINE*) ( TargetObject->Lines + TargetObject->LineCounter );
		memcpy( LineRepository, &Line, LineSize );
		(TargetObject->LineCounter)++;
		RetVal = 0;
	}

	return RetVal;
}

//----------------------------------------------------------------------------
int CMeshRepository::AddTriangle( const char* Name, const TTRIANGLE Triangle )
{
    int RetVal = 1;

	tagOBJECT *TargetObject = CheckIfObjExists( Name );
    if( TargetObject != NULL )
    {
		//pointer to triangle repository
		long TriangleSize = sizeof( TTRIANGLE );
		long LastSize = TriangleSize * TargetObject->FaceCounter;
		long NewSize = LastSize + TriangleSize;
		if( TargetObject->FaceCounter > 0 )
		{
			TargetObject->Triangles = (TTRIANGLE*) realloc( TargetObject->Triangles, NewSize );
		}
		else
		{
			TargetObject->Triangles = (TTRIANGLE*) malloc( NewSize );
		}

		//add new triangle
		TTRIANGLE* TriangleRepository = (TTRIANGLE*) ( TargetObject->Triangles + TargetObject->FaceCounter );
		memcpy( TriangleRepository, &Triangle, TriangleSize );
		(TargetObject->FaceCounter)++;
		RetVal = 0;
	}

	return RetVal;
}

//----------------------------------------------------------------------------
int CMeshRepository::AddGlSphere( const char* Name, const TGLSPHERE GlSphere )
{
    int RetVal = 1;

     //add new Sphere
	tagOBJECT *TargetObject = CheckIfObjExists( Name );
    if( TargetObject != NULL )
    {
		//pointer to sphere repository
		long GlSphereSize = sizeof( TGLSPHERE );
		long LastSize = GlSphereSize * TargetObject->GlSphereCounter;
		long NewSize = LastSize + GlSphereSize;
		if( TargetObject->GlSphereCounter > 0 )
		{
			TargetObject->GlSpheres = (TGLSPHERE*) realloc( TargetObject->GlSpheres, NewSize );
		}
		else
		{
			TargetObject->GlSpheres = (TGLSPHERE*) malloc( NewSize );
		}

		//add new sphere
		TGLSPHERE* SphereRepository = (TGLSPHERE*) ( TargetObject->GlSpheres + TargetObject->GlSphereCounter );
		memcpy( SphereRepository, &GlSphere, GlSphereSize );
		(TargetObject->GlSphereCounter)++;
		RetVal = 0;
	}

	return RetVal;
}

//----------------------------------------------------------------------------
int CMeshRepository::AddGlCone( const char* Name, const TGLCONE GlCone )
{
    int RetVal = 1;

     //add new cone
	tagOBJECT *TargetObject = CheckIfObjExists( Name );
    if( TargetObject != NULL )
    {
		//pointer to cone repository
		long GlConeSize = sizeof( TGLCONE );
		long LastSize = GlConeSize * TargetObject->GlConeCounter;
		long NewSize = LastSize + GlConeSize;
		if( TargetObject->GlConeCounter > 0 )
		{
			TargetObject->GlCones = (TGLCONE*) realloc( TargetObject->GlCones, NewSize );
		}
		else
		{
			TargetObject->GlCones = (TGLCONE*) malloc( NewSize );
		}

		//add new cone
		TGLCONE* ConeRepository = (TGLCONE*) ( TargetObject->GlCones + TargetObject->GlConeCounter );
		memcpy( ConeRepository, &GlCone, GlConeSize );
		(TargetObject->GlConeCounter)++;
		RetVal = 0;
	}

	return RetVal;
}

//----------------------------------------------------------------------------
void CMeshRepository::PrintTriangles( tagOBJECT* ObjectPtr )
{
	if( ObjectPtr->FaceCounter > 0 )
	{
		double NormalX, NormalY, NormalZ, Red, Green, Blue, Alpha;
		for( int j = 0; j < ObjectPtr->FaceCounter; j++ )
		{
			Red = ObjectPtr->Triangles[j].Color.Red;
			Green = ObjectPtr->Triangles[j].Color.Green;
			Blue = ObjectPtr->Triangles[j].Color.Blue;
			Alpha = ObjectPtr->Triangles[j].Color.Alpha;
			glColor4f( Red, Green, Blue, Alpha );

			glBegin( GL_TRIANGLES );
			NormalX = ObjectPtr->Triangles[j].Normal.X;
			NormalY = ObjectPtr->Triangles[j].Normal.Y;
			NormalZ = ObjectPtr->Triangles[j].Normal.Z;
			glNormal3f( NormalX, NormalY, NormalZ );

            for( int k = 0; k < 3; k++ )
            {
                glVertex3f( ObjectPtr->Triangles[j].Vertex[k].X, ObjectPtr->Triangles[j].Vertex[k].Y, ObjectPtr->Triangles[j].Vertex[k].Z );
            }

			glEnd();
		}
	}
}

//----------------------------------------------------------------------------
void CMeshRepository::PrintLines( tagOBJECT* ObjectPtr )
{
	if( ObjectPtr->LineCounter > 0 )
	{
		double Red, Green, Blue, Alpha;
		for( int j = 0; j < ObjectPtr->LineCounter; j++ )
		{
			if( ObjectPtr->Lines[j].Shaded == false )
			{
				glDisable( GL_LIGHTING ); //disable light
			}
			Red = ObjectPtr->Lines[j].Color.Red;
			Green = ObjectPtr->Lines[j].Color.Green;
			Blue = ObjectPtr->Lines[j].Color.Blue;
			Alpha = ObjectPtr->Lines[j].Color.Alpha;
			glColor4f( Red, Green, Blue, Alpha );

			glBegin( GL_LINES );

			for( int k = 0; k < 2; k++ )
			{
				glVertex3f( ObjectPtr->Lines[j].Vertex[k].X, ObjectPtr->Lines[j].Vertex[k].Y, ObjectPtr->Lines[j].Vertex[k].Z );
			}

			glEnd();
			glEnable( GL_LIGHTING ); //enable light
		}
	}
}

//----------------------------------------------------------------------------
void CMeshRepository::PrintGlSpheres( tagOBJECT* ObjectPtr )
{
	if( ObjectPtr->GlSphereCounter > 0 )
	{
		double Red, Green, Blue, Alpha;
		for( int j = 0; j < ObjectPtr->GlSphereCounter; j++ )
		{
			Red = ObjectPtr->GlSpheres[j].Color.Red;
			Green = ObjectPtr->GlSpheres[j].Color.Green;
			Blue = ObjectPtr->GlSpheres[j].Color.Blue;
			Alpha = ObjectPtr->GlSpheres[j].Color.Alpha;
			glColor4f( Red, Green, Blue, Alpha );

			double X = ObjectPtr->GlSpheres[j].Vertex.X;
			double Y = ObjectPtr->GlSpheres[j].Vertex.Y;
			double Z = ObjectPtr->GlSpheres[j].Vertex.Z;

			glTranslatef ( X, Y, Z );
			glutSolidSphere( ObjectPtr->GlSpheres[j].Radius, ObjectPtr->GlSpheres[j].Slices, ObjectPtr->GlSpheres[j].Stacks );

		}
	}
}

//----------------------------------------------------------------------------
void CMeshRepository::PrintGlCones( tagOBJECT* ObjectPtr )
{
	if( ObjectPtr->GlConeCounter > 0 )
	{
		double Red, Green, Blue, Alpha;
		for( int j = 0; j < ObjectPtr->GlConeCounter; j++ )
		{
			Red = ObjectPtr->GlCones[j].Color.Red;
			Green = ObjectPtr->GlCones[j].Color.Green;
			Blue = ObjectPtr->GlCones[j].Color.Blue;
			Alpha = ObjectPtr->GlCones[j].Color.Alpha;
			glColor4f( Red, Green, Blue, Alpha );

			double X = ObjectPtr->GlCones[j].Base.X;
			double Y = ObjectPtr->GlCones[j].Base.Y;
			double Z = ObjectPtr->GlCones[j].Base.Z;

			glTranslatef ( X, Y, Z );
			glutSolidCone( ObjectPtr->GlCones[j].Radius, ObjectPtr->GlCones[j].Height, ObjectPtr->GlCones[j].Slices, ObjectPtr->GlCones[j].Stacks );

		}
	}
}

//----------------------------------------------------------------------------
void CMeshRepository::PrintMesh( tagOBJECT* Mesh )
{
	//show single objects
	if( Mesh != NULL )
	{
		glPushMatrix();

		glTranslatef ( Mesh->Translate.X, Mesh->Translate.Y, Mesh->Translate.Z );

		glRotatef( Mesh->Rotate.X, 1, 0, 0 );
		glRotatef( Mesh->Rotate.Y, 0, 1, 0 );
		glRotatef( Mesh->Rotate.Z, 0, 0, 1 );

		PrintTriangles( Mesh );
		PrintLines( Mesh );
		PrintGlSpheres( Mesh );
		PrintGlCones( Mesh );

		glPopMatrix( );
	}
}

//----------------------------------------------------------------------------
void CMeshRepository::PrintSingleMeshes( void )
{
	tagOBJECT *Meshs = ObjectsPtr;
	while ( Meshs != NULL )
	{
		if( Meshs->Group == NULL )
		{
			PrintMesh( Meshs );
		}
		Meshs = Meshs->NextNode;
		Sleep( 0 );
	}
}

//----------------------------------------------------------------------------
void CMeshRepository::PrintGroups( tagGROUP *RootGroup )
{
	tagGROUP *Temp = GroupsPtr;
	while ( Temp != NULL )
	{
		if( Temp->FatherGroup == RootGroup )
		{
			glPushMatrix();

			glTranslatef ( Temp->Translate.X, Temp->Translate.Y, Temp->Translate.Z );

			glRotatef( Temp->Rotate.X, 1, 0, 0 );
			glRotatef( Temp->Rotate.Y, 0, 1, 0 );
			glRotatef( Temp->Rotate.Z, 0, 0, 1 );

			tagOBJECT *Meshs = ObjectsPtr;
			while ( Meshs != NULL )
			{
				if( Meshs->Group == Temp )
				{
					PrintMesh( Meshs );
				}
				Meshs = Meshs->NextNode;
			}

			PrintGroups( Temp );

			glPopMatrix();
		}
		Temp = Temp->NextNode;
		Sleep( 0 );
	}
}

//----------------------------------------------------------------------------
CMeshRepository::CMeshRepository( void )
{
	ObjectsPtr = NULL;
	GroupsPtr = NULL;
}

//----------------------------------------------------------------------------
