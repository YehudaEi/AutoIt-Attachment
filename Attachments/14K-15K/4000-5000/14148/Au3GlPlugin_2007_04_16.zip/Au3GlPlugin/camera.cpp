#include "camera.h"

CCameraConfig g_CameraConfig;

/****************************************************************************
 * CCameraConfig
 *
 ****************************************************************************/
void CCameraConfig::SetCamera( const double EyeX, const double EyeY, const double EyeZ, const double TargetX, const double TargetY, const double TargetZ )
{
    EyePos.X = EyeX;
    EyePos.Y = EyeY;
    EyePos.Z = EyeZ;
    Target.X = TargetX;
    Target.Y = TargetY;
    Target.Z = TargetZ;
}

//----------------------------------------------------------------------------
void CCameraConfig::SetCameraUp( const double X, const double Y, const double Z )
{
    Up.X = X;
    Up.Y = Y;
    Up.Z = Z;
}

//----------------------------------------------------------------------------
void CCameraConfig::DefineView( void )
{
	glMatrixMode( GL_PROJECTION );
	glLoadIdentity( );

	// Perspective projection
	gluPerspective( Angle, fAspect, Near, Far );

	glMatrixMode( GL_MODELVIEW );
	glLoadIdentity();
	glEnable( GL_DEPTH_TEST );

	// observer and tarjet positions
	gluLookAt( EyePos.X, EyePos.Y, EyePos.Z, Target.X, Target.Y, Target.Z, Up.X, Up.Y, Up.Z );
}

//----------------------------------------------------------------------------
void CCameraConfig::SetFreqPerSecond( const int FreqPerSecond )
{
    int FPS = FreqPerSecond;
    if( FreqPerSecond > 1000 ) FPS = 1000;
    if( FreqPerSecond < 1 ) FPS = 1;
    WaitFrameTime = int( 1000 / FPS );
}

//----------------------------------------------------------------------------
CCameraConfig::CCameraConfig( void )
{
    //Set camera defaults
    fAspect = 1;
    Near = 0.1;
    Far = 1000;
    Angle = 45;
    SetCameraUp( 0, 1, 0 );
    SetCamera( 0, 0, 0, 0, 0, 0 );
    SetFreqPerSecond( 30 );
}
