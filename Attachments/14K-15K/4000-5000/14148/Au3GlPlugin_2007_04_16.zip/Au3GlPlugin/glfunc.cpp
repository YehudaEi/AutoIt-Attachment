#include <gl/glut.h>
#include "glfunc.h"
#include "mesh.h"
#include "light.h"
#include "camera.h"
#include "ambient.h"

CWindowConfig g_WinConfig;

/****************************************************************************
 * CWindowConfig
 *
 ****************************************************************************/
void CWindowConfig::DefineGlWindow( int NewWidth, int NewHeigh, char* NewWinTitle )
{
    Width = NewWidth;
    Heigh = NewHeigh;
    strncpy( Title, NewWinTitle, sizeof( Title) );
}

//----------------------------------------------------------------------------
void CWindowConfig::CreateGlWindow( )
{
	glutInitDisplayMode( GLUT_DOUBLE | GLUT_RGB | GLUT_DEPTH );
	glutInitWindowSize( Width, Heigh );
	glutCreateWindow( Title );
}

//----------------------------------------------------------------------------
CWindowConfig::CWindowConfig( void )
{
	Width = 300;
	Heigh = 300;
	strncpy( Title, "", sizeof( Title ) );
}

/****************************************************************************
 * Normal Functions
 *
 ****************************************************************************/
void TimerFunction( int value )
{
	glutPostRedisplay();
	glutTimerFunc( g_CameraConfig.WaitFrameTime, TimerFunction, value );
}

//----------------------------------------------------------------------------
// callback function to draw
void __Draw(void)
{
    g_AmbientConfig.SetClearColour( );
	glClear( GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT );
	glMatrixMode( GL_MODELVIEW );

	g_MeshRepository.PrintSingleMeshes( );
	g_MeshRepository.PrintGroups( NULL );

	g_CameraConfig.DefineView( );
	g_LightManage.SetLights( );

    glutSwapBuffers();
}

//----------------------------------------------------------------------------
// callback function to rezize window
void __WindowResize( GLsizei Width, GLsizei Heigh )
{
	if ( Heigh == 0 ) Heigh = 1;
	glViewport( 0, 0, Width, Heigh );
	g_CameraConfig.fAspect = (GLfloat) Width / (GLfloat) Heigh;

	g_CameraConfig.DefineView( );
}

//----------------------------------------------------------------------------
void __Test( void )
{
    //
}

//----------------------------------------------------------------------------
// Main routine - thread callback
DWORD __stdcall __MainLoop( void* Param )
{
    g_WinConfig.CreateGlWindow( );

	glutDisplayFunc( __Draw );
	glutReshapeFunc( __WindowResize );
	glutIdleFunc( __Test );
	glutTimerFunc( g_CameraConfig.WaitFrameTime, TimerFunction, 0 );
	g_AmbientConfig.SetAmbient( );
	glutMainLoop( );

	return 0;
}

//----------------------------------------------------------------------------
HANDLE _StartMainLoop( void )
{
    DWORD ThreadId = (DWORD) NULL;
    return CreateThread( NULL, 0, __MainLoop, NULL, 0, &ThreadId );
}

//----------------------------------------------------------------------------

