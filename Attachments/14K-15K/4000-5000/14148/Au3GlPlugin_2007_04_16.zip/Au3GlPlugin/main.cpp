#include <windows.h>
#include "AU3_Plugin_SDK\au3plugin.h"
#include "glfunc.h"
#include "mesh.h"
#include "light.h"
#include "camera.h"
#include "ambient.h"

#ifdef BUILD_DLL
    #define DLL_EXPORT __declspec(dllexport)
#else
    #define DLL_EXPORT
#endif


/*
// a sample exported function
void DLL_EXPORT SomeFunction(const LPCSTR sometext)
{
    MessageBoxA(0, sometext, "DLL Message", MB_OK | MB_ICONINFORMATION);
}*/

/****************************************************************************
 * Function List
 *
 * This is where you define the functions available to AutoIt.  Including
 * the function name (Must be the same case as your exported DLL name), the
 * minimum and maximum number of parameters that the function takes.
 *
 ****************************************************************************/
/* "FunctionName", min_params, max_params */
AU3_PLUGIN_FUNC g_AU3_Funcs[] =
{
	{ "DefineGlWindow", 3, 3 },
	{ "SetClearColor", 3, 3 },
	{ "SetCamera", 6, 6 },
	{ "SetCameraUp", 3, 3 },
	{ "SetCameraView", 2, 2 },
	{ "SetFPS", 1, 1 },
    { "GlMainLoop", 0, 0 },
	{ "CreateGroup", 1, 1 },
	{ "SetToGroup", 2, 2 },
	{ "TranslateGroup", 4, 4 },
	{ "RotateGroup", 4, 4 },
	{ "AddObject", 1, 1 },
	{ "DelObject", 1, 1 },
	{ "AddLine", 11, 12 },
	{ "AddTriangle", 17, 17 },
	{ "AddGlSphere", 11, 11 },
	{ "AddGlCone", 12, 12 },
	{ "TranslateObject", 4, 4 },
	{ "RotateObject", 4, 4 },
	{ "CreateLight", 4, 4 },
	{ "SetLightAmbient", 4, 4 },
	{ "SetLightDiffuse", 4, 4 },
	{ "SetLightSpecular", 4, 4 },
	{ "SetLightPosition", 4, 4 }
};

/****************************************************************************
 * AU3_GetPluginDetails()
 *
 * This function is called by AutoIt when the plugin dll is first loaded to
 * query the plugin about what functions it supports.  DO NOT MODIFY.
 *
 ****************************************************************************/
AU3_PLUGINAPI int AU3_GetPluginDetails(int *n_AU3_NumFuncs, AU3_PLUGIN_FUNC **p_AU3_Func)
{
	/* Pass back the number of functions that this DLL supports */
	*n_AU3_NumFuncs	= sizeof(g_AU3_Funcs)/sizeof(AU3_PLUGIN_FUNC);

	/* Pack back the address of the global function table */
	*p_AU3_Func = g_AU3_Funcs;

	return AU3_PLUGIN_OK;
}

/****************************************************************************
 * DllMain()
 ****************************************************************************/
BOOL WINAPI DllMain(HINSTANCE hinstDLL, DWORD fdwReason, LPVOID lpvReserved)
{
    switch (fdwReason)
    {
        case DLL_PROCESS_ATTACH:
            // attach to process
            // return FALSE to fail DLL load
            break;

        case DLL_PROCESS_DETACH:
            // detach from process
            break;

        case DLL_THREAD_ATTACH:
            // attach to thread
            break;

        case DLL_THREAD_DETACH:
            // detach from thread
            break;
    }

    return TRUE; // succesful
}

/****************************************************************************
 * Auto It Functions
 ****************************************************************************/

/****************************************************************************
 * CreateGlWindow()
 *
 * CreateGlWindow( Width, Heigh, "WinTitle" )
 *
 ****************************************************************************/
AU3_PLUGIN_DEFINE( DefineGlWindow )
{
	/* The inputs to a plugin function are:
	 *		n_AU3_NumParams		- The number of parameters being passed
	 *		p_AU3_Params		- An array of variant like variables used by AutoIt
	 *
	 * The outputs of a plugin function are:
	 *		p_AU3_Result		- A pointer to a variant variable for the result
	 *		n_AU3_ErrorCode		- The value for @Error
	 *		n_AU3_ExtCode		- The value for @Extended
	 */

	AU3_PLUGIN_VAR	*pMyResult;
    int             Width, Heigh;
	char			*Title;

    Width   = AU3_GetInt32(&p_AU3_Params[0]);
    Heigh   = AU3_GetInt32(&p_AU3_Params[1]);
	Title	= AU3_GetString(&p_AU3_Params[2]);

	/* set window parameters */
	g_WinConfig.DefineGlWindow( Width, Heigh, Title );

	/* Free temporary storage */
	AU3_FreeString( Title );

	/* Allocate and build the return variable */
	pMyResult = AU3_AllocVar();
	AU3_SetInt32(pMyResult, 0);


	/* Pass back the result, error code and extended code.
	 * Note: AutoIt is responsible for freeing the memory used in p_AU3_Result
	 */
	*p_AU3_Result		= pMyResult;
	*n_AU3_ErrorCode	= 0;
	*n_AU3_ExtCode		= 0;

	return AU3_PLUGIN_OK;
}

/****************************************************************************
 * SetClearColor()
 *
 * SetClearColor( Red, Green, Blue )
 *
 ****************************************************************************/
AU3_PLUGIN_DEFINE( SetClearColor )
{

	AU3_PLUGIN_VAR	*pMyResult;
    float            Red, Green, Blue;

    Red   = AU3_GetDouble(&p_AU3_Params[0]);
    Green = AU3_GetDouble(&p_AU3_Params[1]);
    Blue  = AU3_GetDouble(&p_AU3_Params[2]);

	g_AmbientConfig.SetClearColor( Red, Green, Blue, 1.0 );

	/* Allocate and build the return variable */
	pMyResult = AU3_AllocVar();
	AU3_SetInt32(pMyResult, 0);


	/* Pass back the result, error code and extended code.
	 * Note: AutoIt is responsible for freeing the memory used in p_AU3_Result
	 */
	*p_AU3_Result		= pMyResult;
	*n_AU3_ErrorCode	= 0;
	*n_AU3_ExtCode		= 0;

	return AU3_PLUGIN_OK;
}

/****************************************************************************
 * SetCamera()
 *
 * SetCamera( EyeX, EyeY, EyeZ, TargetX, TargetY, TargetZ )
 *
 ****************************************************************************/
AU3_PLUGIN_DEFINE( SetCamera )
{

	AU3_PLUGIN_VAR	*pMyResult;
    double            EyeX, EyeY, EyeZ, TargetX, TargetY, TargetZ;

    EyeX    = AU3_GetDouble(&p_AU3_Params[0]);
    EyeY    = AU3_GetDouble(&p_AU3_Params[1]);
    EyeZ    = AU3_GetDouble(&p_AU3_Params[2]);
    TargetX = AU3_GetDouble(&p_AU3_Params[3]);
    TargetY = AU3_GetDouble(&p_AU3_Params[4]);
    TargetZ = AU3_GetDouble(&p_AU3_Params[5]);

	g_CameraConfig.SetCamera( EyeX, EyeY, EyeZ, TargetX, TargetY, TargetZ );

	/* Allocate and build the return variable */
	pMyResult = AU3_AllocVar();
	AU3_SetInt32(pMyResult, 0);


	/* Pass back the result, error code and extended code.
	 * Note: AutoIt is responsible for freeing the memory used in p_AU3_Result
	 */
	*p_AU3_Result		= pMyResult;
	*n_AU3_ErrorCode	= 0;
	*n_AU3_ExtCode		= 0;

	return AU3_PLUGIN_OK;
}

/****************************************************************************
 * SetCameraUp()
 *
 * SetCameraUp( X, Y, Z )
 *
 ****************************************************************************/
AU3_PLUGIN_DEFINE( SetCameraUp )
{

	AU3_PLUGIN_VAR	*pMyResult;
    double            X, Y, Z;

    X    = AU3_GetDouble(&p_AU3_Params[0]);
    Y    = AU3_GetDouble(&p_AU3_Params[1]);
    Z    = AU3_GetDouble(&p_AU3_Params[2]);

	g_CameraConfig.SetCameraUp( X, Y, Z );

	/* Allocate and build the return variable */
	pMyResult = AU3_AllocVar();
	AU3_SetInt32(pMyResult, 0);


	/* Pass back the result, error code and extended code.
	 * Note: AutoIt is responsible for freeing the memory used in p_AU3_Result
	 */
	*p_AU3_Result		= pMyResult;
	*n_AU3_ErrorCode	= 0;
	*n_AU3_ExtCode		= 0;

	return AU3_PLUGIN_OK;
}

/****************************************************************************
 * SetCameraView()
 *
 * SetCameraView( Near, Far )
 *
 ****************************************************************************/
AU3_PLUGIN_DEFINE( SetCameraView )
{

	AU3_PLUGIN_VAR	*pMyResult;
    double            Near, Far;

    Near = AU3_GetDouble(&p_AU3_Params[0]);
    Far  = AU3_GetDouble(&p_AU3_Params[1]);

	g_CameraConfig.Near = Near;
	g_CameraConfig.Far = Far;

	/* Allocate and build the return variable */
	pMyResult = AU3_AllocVar();
	AU3_SetInt32(pMyResult, 0);


	/* Pass back the result, error code and extended code.
	 * Note: AutoIt is responsible for freeing the memory used in p_AU3_Result
	 */
	*p_AU3_Result		= pMyResult;
	*n_AU3_ErrorCode	= 0;
	*n_AU3_ExtCode		= 0;

	return AU3_PLUGIN_OK;
}

/****************************************************************************
 * SetFPS()
 *
 * SetFPS( FramesPerSecond )
 *
 ****************************************************************************/
AU3_PLUGIN_DEFINE( SetFPS )
{

	AU3_PLUGIN_VAR	*pMyResult;
    int             FreqPerSecond;

    FreqPerSecond = AU3_GetInt32(&p_AU3_Params[0]);

    g_CameraConfig.SetFreqPerSecond( FreqPerSecond );

	/* Allocate and build the return variable */
	pMyResult = AU3_AllocVar();
	AU3_SetInt32(pMyResult, 0);


	/* Pass back the result, error code and extended code.
	 * Note: AutoIt is responsible for freeing the memory used in p_AU3_Result
	 */
	*p_AU3_Result		= pMyResult;
	*n_AU3_ErrorCode	= 0;
	*n_AU3_ExtCode		= 0;

	return AU3_PLUGIN_OK;
}

/****************************************************************************
 * GlMainLoop()
 *
 ****************************************************************************/
AU3_PLUGIN_DEFINE( GlMainLoop )
{
	AU3_PLUGIN_VAR	*pMyResult;

    _StartMainLoop( );

	/* Allocate and build the return variable */
	pMyResult = AU3_AllocVar();
	AU3_SetInt32(pMyResult, 0);


	/* Pass back the result, error code and extended code.
	 * Note: AutoIt is responsible for freeing the memory used in p_AU3_Result
	 */
	*p_AU3_Result		= pMyResult;
	*n_AU3_ErrorCode	= 0;
	*n_AU3_ExtCode		= 0;

	return AU3_PLUGIN_OK;
}

/****************************************************************************
 * CreateGroup()
 *
 * CreateGroup( Name )
 *
 ****************************************************************************/
AU3_PLUGIN_DEFINE( CreateGroup )
{

	AU3_PLUGIN_VAR	*pMyResult;
    char            *Name;

	Name	= AU3_GetString(&p_AU3_Params[0]);

	int RetVal = g_MeshRepository.CreateGroup( Name );

	/* Allocate and build the return variable */
	pMyResult = AU3_AllocVar();
	AU3_SetInt32(pMyResult, 0);


	/* Pass back the result, error code and extended code.
	 * Note: AutoIt is responsible for freeing the memory used in p_AU3_Result
	 */
	*p_AU3_Result		= pMyResult;
	*n_AU3_ErrorCode	= RetVal;
	*n_AU3_ExtCode		= 0;

	return AU3_PLUGIN_OK;
}

/****************************************************************************
 * SetToGroup()
 *
 * SetToGroup( Group, Object/Group )
 *
 ****************************************************************************/
AU3_PLUGIN_DEFINE( SetToGroup )
{

	AU3_PLUGIN_VAR	*pMyResult;
    char            *GroupName, *Name;

	GroupName = AU3_GetString(&p_AU3_Params[0]);
	Name      = AU3_GetString(&p_AU3_Params[1]);

	int RetVal = g_MeshRepository.SetToGroup( GroupName, Name );

	/* Allocate and build the return variable */
	pMyResult = AU3_AllocVar();
	AU3_SetInt32(pMyResult, 0);


	/* Pass back the result, error code and extended code.
	 * Note: AutoIt is responsible for freeing the memory used in p_AU3_Result
	 */
	*p_AU3_Result		= pMyResult;
	*n_AU3_ErrorCode	= RetVal;
	*n_AU3_ExtCode		= 0;

	return AU3_PLUGIN_OK;
}

/****************************************************************************
 * TranslateGroup()
 *
 * TranslateGroup( Name, X, Y, Z )
 *
 ****************************************************************************/
AU3_PLUGIN_DEFINE( TranslateGroup )
{

	AU3_PLUGIN_VAR	*pMyResult;
    char            *Name;
	double          X, Y, Z;

	Name	= AU3_GetString(&p_AU3_Params[0]);

	X     = AU3_GetDouble(&p_AU3_Params[1]);
	Y     = AU3_GetDouble(&p_AU3_Params[2]);
	Z     = AU3_GetDouble(&p_AU3_Params[3]);

	TPOS3D NewPos;
	NewPos.X = X;
	NewPos.Y = Y;
	NewPos.Z = Z;

	g_MeshRepository.TranslateGroup( Name, NewPos );

	/* Allocate and build the return variable */
	pMyResult = AU3_AllocVar();
	AU3_SetInt32(pMyResult, 0);


	/* Pass back the result, error code and extended code.
	 * Note: AutoIt is responsible for freeing the memory used in p_AU3_Result
	 */
	*p_AU3_Result		= pMyResult;
	*n_AU3_ErrorCode	= 0;
	*n_AU3_ExtCode		= 0;

	return AU3_PLUGIN_OK;
}

/****************************************************************************
 * RotateGroup()
 *
 * RotateGroup( Name, X, Y, Z )
 *
 ****************************************************************************/
AU3_PLUGIN_DEFINE( RotateGroup )
{

	AU3_PLUGIN_VAR	*pMyResult;
    char            *Name;
	double          X, Y, Z;

	Name	= AU3_GetString(&p_AU3_Params[0]);

	X     = AU3_GetDouble(&p_AU3_Params[1]);
	Y     = AU3_GetDouble(&p_AU3_Params[2]);
	Z     = AU3_GetDouble(&p_AU3_Params[3]);

	TPOS3D Angles;
	Angles.X = X;
	Angles.Y = Y;
	Angles.Z = Z;

	g_MeshRepository.RotateGroup( Name, Angles );

	/* Allocate and build the return variable */
	pMyResult = AU3_AllocVar();
	AU3_SetInt32(pMyResult, 0);


	/* Pass back the result, error code and extended code.
	 * Note: AutoIt is responsible for freeing the memory used in p_AU3_Result
	 */
	*p_AU3_Result		= pMyResult;
	*n_AU3_ErrorCode	= 0;
	*n_AU3_ExtCode		= 0;

	return AU3_PLUGIN_OK;
}

/****************************************************************************
 * AddObject()
 *
 * AddObject( Name )
 *
 ****************************************************************************/
AU3_PLUGIN_DEFINE( AddObject )
{

	AU3_PLUGIN_VAR	*pMyResult;
    char            *Name;

	Name	= AU3_GetString(&p_AU3_Params[0]);

	int RetVal = g_MeshRepository.AddObject( Name );

	/* Allocate and build the return variable */
	pMyResult = AU3_AllocVar();
	AU3_SetInt32(pMyResult, 0);


	/* Pass back the result, error code and extended code.
	 * Note: AutoIt is responsible for freeing the memory used in p_AU3_Result
	 */
	*p_AU3_Result		= pMyResult;
	*n_AU3_ErrorCode	= RetVal;
	*n_AU3_ExtCode		= 0;

	return AU3_PLUGIN_OK;
}

/****************************************************************************
 * DelObject()
 *
 * DelObject( Name )
 *
 ****************************************************************************/
AU3_PLUGIN_DEFINE( DelObject )
{

	AU3_PLUGIN_VAR	*pMyResult;
    char            *Name;

	Name	= AU3_GetString(&p_AU3_Params[0]);

	int RetVal = g_MeshRepository.DeleteObject( Name );

	/* Allocate and build the return variable */
	pMyResult = AU3_AllocVar();
	AU3_SetInt32(pMyResult, 0);


	/* Pass back the result, error code and extended code.
	 * Note: AutoIt is responsible for freeing the memory used in p_AU3_Result
	 */
	*p_AU3_Result		= pMyResult;
	*n_AU3_ErrorCode	= RetVal;
	*n_AU3_ExtCode		= 0;

	return AU3_PLUGIN_OK;
}

/****************************************************************************
 * AddLine()
 *
 * AddLine( Name, Xv1, Yv1, Zv1, Xv2, Yv2, Zv2, Red, Green, Blue, Alpha )
 *
 ****************************************************************************/
AU3_PLUGIN_DEFINE( AddLine )
{

	AU3_PLUGIN_VAR	*pMyResult;
    char            *Name;
	int				iShaded;
	TLINE Line;

	Name	= AU3_GetString(&p_AU3_Params[0]);

    Line.Vertex[0].X = AU3_GetDouble(&p_AU3_Params[1]);
    Line.Vertex[0].Y = AU3_GetDouble(&p_AU3_Params[2]);
    Line.Vertex[0].Z = AU3_GetDouble(&p_AU3_Params[3]);

    Line.Vertex[1].X = AU3_GetDouble(&p_AU3_Params[4]);
    Line.Vertex[1].Y = AU3_GetDouble(&p_AU3_Params[5]);
    Line.Vertex[1].Z = AU3_GetDouble(&p_AU3_Params[6]);

	Line.Color.Red   = AU3_GetDouble(&p_AU3_Params[7]);
	Line.Color.Green = AU3_GetDouble(&p_AU3_Params[8]);
	Line.Color.Blue  = AU3_GetDouble(&p_AU3_Params[9]);
	Line.Color.Alpha = AU3_GetDouble(&p_AU3_Params[10]);

	iShaded =          AU3_GetInt32(&p_AU3_Params[11]);
	Line.Shaded = false;
	if( iShaded > 0 )
	{
		Line.Shaded = true;
	}

	int RetVal = g_MeshRepository.AddLine( Name, Line );

	/* Allocate and build the return variable */
	pMyResult = AU3_AllocVar();
	AU3_SetInt32(pMyResult, 0);


	/* Pass back the result, error code and extended code.
	 * Note: AutoIt is responsible for freeing the memory used in p_AU3_Result
	 */
	*p_AU3_Result		= pMyResult;
	*n_AU3_ErrorCode	= RetVal;
	*n_AU3_ExtCode		= 0;

	return AU3_PLUGIN_OK;
}

/****************************************************************************
 * AddTriangle()
 *
 * AddTriangle( Name, Xv1, Yv1, Zv1, Xv2, Yv2, Zv2, Xv3, Yv3, Zv3, Xn, Yn, Zn, Red, Green, Blue, Alpha )
 *
 ****************************************************************************/
AU3_PLUGIN_DEFINE( AddTriangle )
{

	AU3_PLUGIN_VAR	*pMyResult;
    char            *Name;
	TTRIANGLE Triangle;
	Name	= AU3_GetString(&p_AU3_Params[0]);

    Triangle.Vertex[0].X = AU3_GetDouble(&p_AU3_Params[1]);
    Triangle.Vertex[0].Y = AU3_GetDouble(&p_AU3_Params[2]);
    Triangle.Vertex[0].Z = AU3_GetDouble(&p_AU3_Params[3]);

    Triangle.Vertex[1].X = AU3_GetDouble(&p_AU3_Params[4]);
    Triangle.Vertex[1].Y = AU3_GetDouble(&p_AU3_Params[5]);
    Triangle.Vertex[1].Z = AU3_GetDouble(&p_AU3_Params[6]);

    Triangle.Vertex[2].X = AU3_GetDouble(&p_AU3_Params[7]);
    Triangle.Vertex[2].Y = AU3_GetDouble(&p_AU3_Params[8]);
    Triangle.Vertex[2].Z = AU3_GetDouble(&p_AU3_Params[9]);

    Triangle.Normal.X = AU3_GetDouble(&p_AU3_Params[10]);
    Triangle.Normal.Y = AU3_GetDouble(&p_AU3_Params[11]);
    Triangle.Normal.Z = AU3_GetDouble(&p_AU3_Params[12]);
	Triangle.Color.Red   = AU3_GetDouble(&p_AU3_Params[13]);
	Triangle.Color.Green = AU3_GetDouble(&p_AU3_Params[14]);
	Triangle.Color.Blue  = AU3_GetDouble(&p_AU3_Params[15]);
	Triangle.Color.Alpha = AU3_GetDouble(&p_AU3_Params[16]);

	int RetVal = g_MeshRepository.AddTriangle( Name, Triangle );

	/* Allocate and build the return variable */
	pMyResult = AU3_AllocVar();
	AU3_SetInt32(pMyResult, 0);


	/* Pass back the result, error code and extended code.
	 * Note: AutoIt is responsible for freeing the memory used in p_AU3_Result
	 */
	*p_AU3_Result		= pMyResult;
	*n_AU3_ErrorCode	= RetVal;
	*n_AU3_ExtCode		= 0;

	return AU3_PLUGIN_OK;
}

/****************************************************************************
 * AddGlSphere()
 *
 * AddGlSphere( Name, X, Y, Z, Radius, Slices, Stacks, Red, Green, Blue, Alpha )
 *
 ****************************************************************************/
AU3_PLUGIN_DEFINE( AddGlSphere )
{

	AU3_PLUGIN_VAR	*pMyResult;
    char           *Name;
	TGLSPHERE       GlSphere;

	Name = AU3_GetString(&p_AU3_Params[0]);

    GlSphere.Vertex.X = AU3_GetDouble(&p_AU3_Params[1]);
    GlSphere.Vertex.Y = AU3_GetDouble(&p_AU3_Params[2]);
    GlSphere.Vertex.Z = AU3_GetDouble(&p_AU3_Params[3]);

    GlSphere.Radius = AU3_GetDouble(&p_AU3_Params[4]);
    GlSphere.Slices = AU3_GetInt32(&p_AU3_Params[5]);
    GlSphere.Stacks = AU3_GetInt32(&p_AU3_Params[6]);

	GlSphere.Color.Red   = AU3_GetDouble(&p_AU3_Params[7]);
	GlSphere.Color.Green = AU3_GetDouble(&p_AU3_Params[8]);
	GlSphere.Color.Blue  = AU3_GetDouble(&p_AU3_Params[9]);
	GlSphere.Color.Alpha = AU3_GetDouble(&p_AU3_Params[10]);

	int RetVal = g_MeshRepository.AddGlSphere( Name, GlSphere );

	/* Allocate and build the return variable */
	pMyResult = AU3_AllocVar();
	AU3_SetInt32(pMyResult, 0);


	/* Pass back the result, error code and extended code.
	 * Note: AutoIt is responsible for freeing the memory used in p_AU3_Result
	 */
	*p_AU3_Result		= pMyResult;
	*n_AU3_ErrorCode	= RetVal;
	*n_AU3_ExtCode		= 0;

	return AU3_PLUGIN_OK;
}

/****************************************************************************
 * AddGlCone()
 *
 * AddGlCone( Name, X, Y, Z, Radius, Height, Slices, Stacks, Red, Green, Blue, Alpha )
 *
 ****************************************************************************/
AU3_PLUGIN_DEFINE( AddGlCone )
{

	AU3_PLUGIN_VAR	*pMyResult;
    char           *Name;
	TGLCONE         GlCone;

	Name = AU3_GetString(&p_AU3_Params[0]);

    GlCone.Base.X = AU3_GetDouble(&p_AU3_Params[1]);
    GlCone.Base.Y = AU3_GetDouble(&p_AU3_Params[2]);
    GlCone.Base.Z = AU3_GetDouble(&p_AU3_Params[3]);

    GlCone.Radius = AU3_GetDouble(&p_AU3_Params[4]);
    GlCone.Height = AU3_GetDouble(&p_AU3_Params[5]);
    GlCone.Slices = AU3_GetInt32(&p_AU3_Params[6]);
    GlCone.Stacks = AU3_GetInt32(&p_AU3_Params[7]);

	GlCone.Color.Red   = AU3_GetDouble(&p_AU3_Params[8]);
	GlCone.Color.Green = AU3_GetDouble(&p_AU3_Params[9]);
	GlCone.Color.Blue  = AU3_GetDouble(&p_AU3_Params[10]);
	GlCone.Color.Alpha = AU3_GetDouble(&p_AU3_Params[11]);

	int RetVal = g_MeshRepository.AddGlCone( Name, GlCone );

	/* Allocate and build the return variable */
	pMyResult = AU3_AllocVar();
	AU3_SetInt32(pMyResult, 0);

	/* Pass back the result, error code and extended code.
	 * Note: AutoIt is responsible for freeing the memory used in p_AU3_Result
	 */
	*p_AU3_Result		= pMyResult;
	*n_AU3_ErrorCode	= RetVal;
	*n_AU3_ExtCode		= 0;

	return AU3_PLUGIN_OK;
}

/****************************************************************************
 * TranslateObject()
 *
 * TranslateObject( Name, X, Y, Z )
 *
 ****************************************************************************/
AU3_PLUGIN_DEFINE( TranslateObject )
{

	AU3_PLUGIN_VAR	*pMyResult;
    char            *Name;
	double          X, Y, Z;

	Name	= AU3_GetString(&p_AU3_Params[0]);

	X     = AU3_GetDouble(&p_AU3_Params[1]);
	Y     = AU3_GetDouble(&p_AU3_Params[2]);
	Z     = AU3_GetDouble(&p_AU3_Params[3]);

	TPOS3D NewPos;
	NewPos.X = X;
	NewPos.Y = Y;
	NewPos.Z = Z;

	g_MeshRepository.TranslateObject( Name, NewPos );

	/* Allocate and build the return variable */
	pMyResult = AU3_AllocVar();
	AU3_SetInt32(pMyResult, 0);


	/* Pass back the result, error code and extended code.
	 * Note: AutoIt is responsible for freeing the memory used in p_AU3_Result
	 */
	*p_AU3_Result		= pMyResult;
	*n_AU3_ErrorCode	= 0;
	*n_AU3_ExtCode		= 0;

	return AU3_PLUGIN_OK;
}

/****************************************************************************
 * RotateObject()
 *
 * RotateObject( Name, X, Y, Z )
 *
 ****************************************************************************/
AU3_PLUGIN_DEFINE( RotateObject )
{

	AU3_PLUGIN_VAR	*pMyResult;
    char            *Name;
	double          X, Y, Z;

	Name	= AU3_GetString(&p_AU3_Params[0]);

	X     = AU3_GetDouble(&p_AU3_Params[1]);
	Y     = AU3_GetDouble(&p_AU3_Params[2]);
	Z     = AU3_GetDouble(&p_AU3_Params[3]);

	TPOS3D Angles;
	Angles.X = X;
	Angles.Y = Y;
	Angles.Z = Z;

	g_MeshRepository.RotateObject( Name, Angles );

	/* Allocate and build the return variable */
	pMyResult = AU3_AllocVar();
	AU3_SetInt32(pMyResult, 0);


	/* Pass back the result, error code and extended code.
	 * Note: AutoIt is responsible for freeing the memory used in p_AU3_Result
	 */
	*p_AU3_Result		= pMyResult;
	*n_AU3_ErrorCode	= 0;
	*n_AU3_ExtCode		= 0;

	return AU3_PLUGIN_OK;
}

/****************************************************************************
 * CreateLight()
 *
 * CreateLight( Number, X, Y, Z );
 *
 ****************************************************************************/
AU3_PLUGIN_DEFINE( CreateLight )
{

	AU3_PLUGIN_VAR	*pMyResult;
	int             Number;
    TPOS3D          Position;

    Number      = AU3_GetInt32(&p_AU3_Params[0]);
    Position.X  = AU3_GetDouble(&p_AU3_Params[1]);
    Position.Y  = AU3_GetDouble(&p_AU3_Params[2]);
    Position.Z  = AU3_GetDouble(&p_AU3_Params[3]);

    int RetVal = g_LightManage.CreateLight( Number, Position );

	/* Allocate and build the return variable */
	pMyResult = AU3_AllocVar();
	AU3_SetInt32(pMyResult, 0);


	/* Pass back the result, error code and extended code.
	 * Note: AutoIt is responsible for freeing the memory used in p_AU3_Result
	 */
	*p_AU3_Result		= pMyResult;
	*n_AU3_ErrorCode	= RetVal;
	*n_AU3_ExtCode		= 0;

	return AU3_PLUGIN_OK;
}

/****************************************************************************
 * SetLightAmbient()
 *
 * SetLightAmbient( LightNumber, Red, Green, Blue );
 *
 ****************************************************************************/
AU3_PLUGIN_DEFINE( SetLightAmbient )
{

	AU3_PLUGIN_VAR	*pMyResult;
	int             LightNumber;
    TRGBA           Colour;

    LightNumber     = AU3_GetInt32(&p_AU3_Params[0]);
    Colour.Red      = AU3_GetDouble(&p_AU3_Params[1]);
    Colour.Green    = AU3_GetDouble(&p_AU3_Params[2]);
    Colour.Blue     = AU3_GetDouble(&p_AU3_Params[3]);
    Colour.Alpha    = 1.0;

    int RetVal = g_LightManage.SetLightAmbient( LightNumber, Colour );

	/* Allocate and build the return variable */
	pMyResult = AU3_AllocVar();
	AU3_SetInt32(pMyResult, 0);


	/* Pass back the result, error code and extended code.
	 * Note: AutoIt is responsible for freeing the memory used in p_AU3_Result
	 */
	*p_AU3_Result		= pMyResult;
	*n_AU3_ErrorCode	= RetVal;
	*n_AU3_ExtCode		= 0;

	return AU3_PLUGIN_OK;
}

/****************************************************************************
 * SetLightDiffuse()
 *
 * SetLightDiffuse( LightNumber, Red, Green, Blue );
 *
 ****************************************************************************/
AU3_PLUGIN_DEFINE( SetLightDiffuse )
{

	AU3_PLUGIN_VAR	*pMyResult;
	int             LightNumber;
    TRGBA           Colour;

    LightNumber     = AU3_GetInt32(&p_AU3_Params[0]);
    Colour.Red      = AU3_GetDouble(&p_AU3_Params[1]);
    Colour.Green    = AU3_GetDouble(&p_AU3_Params[2]);
    Colour.Blue     = AU3_GetDouble(&p_AU3_Params[3]);
    Colour.Alpha    = 1.0;

    int RetVal = g_LightManage.SetLightDiffuse( LightNumber, Colour );

	/* Allocate and build the return variable */
	pMyResult = AU3_AllocVar();
	AU3_SetInt32(pMyResult, 0);


	/* Pass back the result, error code and extended code.
	 * Note: AutoIt is responsible for freeing the memory used in p_AU3_Result
	 */
	*p_AU3_Result		= pMyResult;
	*n_AU3_ErrorCode	= RetVal;
	*n_AU3_ExtCode		= 0;

	return AU3_PLUGIN_OK;
}

/****************************************************************************
 * SetLightSpecular()
 *
 * SetLightSpecular( LightNumber, Red, Green, Blue );
 *
 ****************************************************************************/
AU3_PLUGIN_DEFINE( SetLightSpecular )
{

	AU3_PLUGIN_VAR	*pMyResult;
	int             LightNumber;
    TRGBA           Colour;

    LightNumber     = AU3_GetInt32(&p_AU3_Params[0]);
    Colour.Red      = AU3_GetDouble(&p_AU3_Params[1]);
    Colour.Green    = AU3_GetDouble(&p_AU3_Params[2]);
    Colour.Blue     = AU3_GetDouble(&p_AU3_Params[3]);
    Colour.Alpha    = 1.0;

    int RetVal = g_LightManage.SetLightSpecular( LightNumber, Colour );

	/* Allocate and build the return variable */
	pMyResult = AU3_AllocVar();
	AU3_SetInt32(pMyResult, 0);


	/* Pass back the result, error code and extended code.
	 * Note: AutoIt is responsible for freeing the memory used in p_AU3_Result
	 */
	*p_AU3_Result		= pMyResult;
	*n_AU3_ErrorCode	= RetVal;
	*n_AU3_ExtCode		= 0;

	return AU3_PLUGIN_OK;
}

/****************************************************************************
 * SetLightPosition()
 *
 * SetLightPosition( LightNumber, X, Y, Z );
 *
 ****************************************************************************/
AU3_PLUGIN_DEFINE( SetLightPosition )
{

	AU3_PLUGIN_VAR	*pMyResult;
	int             LightNumber;
    TPOS3D          Position;

    LightNumber     = AU3_GetInt32(&p_AU3_Params[0]);
    Position.X      = AU3_GetDouble(&p_AU3_Params[1]);
    Position.Y      = AU3_GetDouble(&p_AU3_Params[2]);
    Position.Z      = AU3_GetDouble(&p_AU3_Params[3]);

    int RetVal = g_LightManage.SetLightPosition( LightNumber, Position );

	/* Allocate and build the return variable */
	pMyResult = AU3_AllocVar();
	AU3_SetInt32(pMyResult, 0);


	/* Pass back the result, error code and extended code.
	 * Note: AutoIt is responsible for freeing the memory used in p_AU3_Result
	 */
	*p_AU3_Result		= pMyResult;
	*n_AU3_ErrorCode	= RetVal;
	*n_AU3_ExtCode		= 0;

	return AU3_PLUGIN_OK;
}

