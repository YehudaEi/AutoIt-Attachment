#ifndef __MESH_H
#define __MESH_H

#include "types.h"

//----------------------------------------------------------------------------
typedef struct
{
    TRGBA Color;
	TPOS3D Vertex[3];
	TPOS3D Normal;
} TTRIANGLE;

//----------------------------------------------------------------------------
typedef struct
{
    TRGBA Color;
	TPOS3D Vertex[2];
	bool Shaded;
} TLINE;

//----------------------------------------------------------------------------
typedef struct
{
    TRGBA Color;
	TPOS3D Vertex;
	double Radius;
	long Slices;
	long Stacks;
} TGLSPHERE;

//----------------------------------------------------------------------------
typedef struct
{
    TRGBA Color;
	TPOS3D Base;
	double Radius;
	double Height;
	long Slices;
	long Stacks;
} TGLCONE;

//----------------------------------------------------------------------------
typedef struct tagGROUP
{
	char GroupName[256];

	TPOS3D Translate;
	TPOS3D Rotate;

	tagGROUP* FatherGroup;

	//for linked list
	tagGROUP *PreviousNode;
	tagGROUP *NextNode;
} TtagGROUP;

//----------------------------------------------------------------------------
typedef struct tagOBJECT
{
	char Name[256];
	//triangles
	long FaceCounter;
	TTRIANGLE *Triangles;
	//lines
	long LineCounter;
	TLINE *Lines;
	//spheres
	long GlSphereCounter;
	TGLSPHERE *GlSpheres;
	//cones
	long GlConeCounter;
	TGLCONE *GlCones;

	TPOS3D Translate;
	TPOS3D Rotate;

	tagGROUP* Group; //object group

	//for linked list
	tagOBJECT *PreviousNode;
	tagOBJECT *NextNode;
} TtagOBJECT;

//----------------------------------------------------------------------------
class CMeshRepository
{
    private:
		tagOBJECT *ObjectsPtr;
		tagGROUP *GroupsPtr;

		//functions
		void SetGroupPtr2First( void );
		tagOBJECT* CheckIfObjExists( const char* Name );
		tagGROUP*  CheckIfGroupExists( const char* GroupName );

		//show
		void PrintTriangles( tagOBJECT* ObjectPtr );
		void PrintLines( tagOBJECT* ObjectPtr );
		void PrintGlSpheres( tagOBJECT* ObjectPtr );
		void PrintGlCones( tagOBJECT* ObjectPtr );
		void PrintMesh( tagOBJECT* Mesh );

    public:
        //FUNCTIONS

		//manage objects
        int AddObject( const char* Name );
		int DeleteObject( const char* Name );

		//set positions
		void TranslateObject( const char* Name, const TPOS3D NewPos );
		void RotateObject( const char* Name, const TPOS3D Angles );

		//manage groups
		int CreateGroup( const char* GroupName );
		int SetToGroup( const char* GroupName, const char* Name );

		//set positions
		void TranslateGroup( const char* Name, const TPOS3D NewPos );
		void RotateGroup( const char* Name, const TPOS3D Angles );

		//manage meshes
		int AddLine( const char* Name, const TLINE Line );
        int AddTriangle( const char* Name, const TTRIANGLE Triangle );
		int AddGlSphere( const char* Name, const TGLSPHERE GlSphere );
		int AddGlCone( const char* Name, const TGLCONE GlCone );

		//show
		void PrintGroups( tagGROUP *RootGroup );
		void PrintSingleMeshes( void );

        //constructor
        CMeshRepository( void );
};

//----------------------------------------------------------------------------

extern CMeshRepository g_MeshRepository;

#endif
