#ifndef __GLFUNC_H
#define __GLFUNC_H

#include <windows.h>
#include "types.h"

/****************************************************************************
 * classes
 *
 ****************************************************************************/
class CWindowConfig
{
    private:
        int Width, Heigh;
        char Title[200];
    public:
        //functions
        void DefineGlWindow( int Width, int Heigh, char* WinTitle );
        void CreateGlWindow( );

        //constructor
        CWindowConfig( void );
};

/****************************************************************************
 * global variables
 *
 ****************************************************************************/
extern CWindowConfig g_WinConfig;

/****************************************************************************
 * prototipes
 *
 ****************************************************************************/
void _DefaultConfig( void );
void _DefineGlWindow( int Width, int Heigh, char* WinTitle );
HANDLE _StartMainLoop( );

#endif

//----------------------------------------------------------------------------
