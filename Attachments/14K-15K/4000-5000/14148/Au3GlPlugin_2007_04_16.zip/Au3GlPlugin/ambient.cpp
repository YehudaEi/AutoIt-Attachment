#include <gl/glut.h>
#include "ambient.h"

CAmbientConfig g_AmbientConfig;

/****************************************************************************
 * CAmbientConfig
 *
 ****************************************************************************/
void CAmbientConfig::SetClearColor( float Red, float Green, float Blue, float Alpha )
{
    ClearColor.Red = Red;
    ClearColor.Green = Green;
    ClearColor.Blue = Blue;
    ClearColor.Alpha = Alpha;
}

//----------------------------------------------------------------------------
void CAmbientConfig::SetAmbient( void )
{
	glEnable(GL_DEPTH_TEST);
	glClearDepth(1.0);
	glDepthFunc(GL_LEQUAL);
	glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
	glEnable(GL_BLEND);
	glAlphaFunc(GL_GREATER,0.1);
	glEnable(GL_ALPHA_TEST);
	glEnable(GL_TEXTURE_2D);
	glEnable(GL_CULL_FACE);

	SetClearColour( );
}

//----------------------------------------------------------------------------
void CAmbientConfig::SetClearColour( void )
{
    glClearColor( ClearColor.Red, ClearColor.Green, ClearColor.Blue, ClearColor.Alpha ); //bg color
}

//----------------------------------------------------------------------------
CAmbientConfig::CAmbientConfig( void )
{
    //ClearColor defaults
    SetClearColor( 0.0, 0.0, 0.0, 1.0 );
}
