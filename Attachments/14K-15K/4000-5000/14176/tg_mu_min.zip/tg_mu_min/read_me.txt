This file was download from THE GAME download section at http://www.thegame.gr



Instructions

Run the file tg_mu_minimizer.exe before MU Client.
After your enter the game, just press F12 to get in full window mode or F11 to minimize window


==================================================================================



THE GAME
http://www.thegame.gr

==================================================================================





