			RuneScape AutoMiner v1.0


Introduction:
Welcome to RuneScape AutoMiner's helpfile. You're already one step
into the right direction: You are reading this manual. This manual
is a short guide to how you should use this AutoMiner.


Steps:
1.	Start RuneScape and log in, head for a mining area and get a pickaxe.
2.	Start the AutoMiner.
3.	Select the Color of the Ore you want to mine.
	(Rightclick the word Color and a menu will drop down)
	(Note: Some Colors/Ores are still not supported)
4.	Move the AutoMiner over the ores that you want to mine. And
	set the required 'Scan Size'. (Area the script will look in
	for this color you've just set)
5.	Set the 2 timers: One controling the interval between checks,
	the other controling the time before another check is done while
	mining.
6.	Either click 'Start' or press Ctrl + z
7.	Sit back, hopefully relax.
8.	Wait until you have the required amount of ores (likely, a full inventory).
9.	Return to the bank, go to the mining zone and repeat the process from step 6.


Hotkeys:
Ctrl + Alt + x		Emergency Exit (used for debugging)

Ctrl + z		Starts the autominer.
Ctrl + x		Stops the autominer. (Pause)

Ctrl + a		Puts the AutoMiner in the left top corner.
			When pressed again it moves the AutoMiner back to the original position.


Footnote:
The RuneScape AutoMiner, you will likely have found with this document,
and this help file are fully owned by Jos van Egmond (Manadar). All
rights restricted, except study.