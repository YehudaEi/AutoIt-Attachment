Public Class SampleControls

End Class
