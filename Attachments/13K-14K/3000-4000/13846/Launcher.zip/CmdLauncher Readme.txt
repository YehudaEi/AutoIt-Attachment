Command  Launcher v1.0

What it Does?
	- Let you define "Commands" (Word or Phrase, not Hot Keys neither menus) wich permit you to launch one or more items at the same time.
What is an item? 
	- Whatever Application, File, Document, Folder, special folder, web address and email address that can be executed by itself or is associated to other Applications.

How can I invoke the program after Running?
	- Press the keys Win+Spacebar to invoque Command Launcher

How can I define a "Command"?
	- there are two ways:
	- 1) Select one or more items  (by Control Click or Shift Click on each or by gragging a text) like you usually do when you want to Copy/Paste,
	then Press the Hotkey Ctrl+Shift+v and an "Edit Command" dialog box will appear, with the included items. Simply define a name for the command and Click OK button. 
	You can still use the Hotkey Ctrl+Shift+v while the "Edit Command" dialog box is Shown, all the new items will be added to the "Launch items list"
	- 2) Invoke the "Command Launcher" (Pressing Win+Spacebar) Write the name of the New Coomand in the InputBox (Command) or leave it Empty and Click the "Add" button.
	
How can I add more Items?
	- While the "Edit Command" dialog box is Visible you can click on the "Add" button to add items manually \ or you can still select more Items from other applications
	and Paste to the "Launch item list" with the Hotkey Ctrl+Shift+v
	
How can I Launch a defined Command?
	- Simply invoke the "Command Launcher", Write a few chars in the Inputbox (Command) until you see your command displayed in the list of "filtered command".
	Press the Down Arrow until you get to the "Command" you wish to Execute and Press Enter key or Click the "Execute" Button
	
How can I Launch a Special Folder?

	- Add a New Command or Edit an old one to display the "Edit Command" dialog box.
	- Click the "Add" button and will appear an "Edit Item" dialog box.
	- In the "Item Type" Combobox select "Special Folder"
	- In the "Special Folder" Combobox select the folder you wish to open when launching the Command
	- Click Ok button
	- Define a Command Name in "Command" Inputbox (if not Defined yet)
	- Click Ok button
	- Invoke the new or edited "Command"

How to Quit from "Command Launcher"?
	- Press the HotKey Win+x

Why you think I can use this launcher ?
	- If want to access your favorite apps with a mnemonic name
	- if you want to see your favorite the domestic news in internet with few keystrokes
	- if you like to open many forums at the same time
	- if need to open many files, folders and applications at the same time.
	- if you want to send an email quickly
	- if you forgot many HotKeys
	- if you hate to navigate in the "start menu" or in large menu launcher programs.
	- if you like simply but Powerful Utilities.
	then you will like "Command Launcher"
	
Note: There are many good Applications launcher, I don't want to underestimate the effort of many programmers but I was looking for a "free" program launcher
like this one, and I didn't find nothing similar, so I decided to write my own and its free for everyone.

Many thanks to all the people that contribute with valuable code in the AutoIt Forums.