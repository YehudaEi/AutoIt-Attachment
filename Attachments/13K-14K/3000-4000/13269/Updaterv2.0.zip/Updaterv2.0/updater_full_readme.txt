#####################################################################################################################
####################################                                            #####################################
####################################         Updater_full v2.0 by X1GTT         #####################################
####################################                                            ##################################### 
#####################################################################################################################


Updater_full is a tool that can execute a number of update or backup tasks, allowing
"Scheduled Tasks", running in the background, running with command-line options and
logging of each action.


An "update task" can be : 

Update/Copy/Backup files and directories from a source folder to a destination folder.

It will create files and subdirs in the destination folder if they do not exist yet.

It will copy "newer" files to the destination folder.

It will prompt the user if it finds "older" files in the source directory.

Before the actual copy, all the file time differences are shown in a listview with checkboxes.
You can then eventually "uncheck" the files you don't want to copy to the destination folder.
Using the "Start Update" button will start the actual filecopy process. 

Possible use :

- update/copy/backup your autoitscripts,pictures,.mp3,.avi folders on an external harddisk or
  memory stick.
- make regular/scheduled backup copies of your important data to external (virtual) drives.
- prepare an "upload" folder that contains only "newer files" that needs to be uploaded to your website.



Usage :

1. INSTALL :
------------
Unzip the Updaterv2.0.zip
You should have these files :

Updater\updater_full.exe
Updater\updater_full.au3
Updater\up.ico
Updater\down.ico
Updater\flip.ico
Updater\updater_full_readme.txt


2. EXECUTE updater_full.exe (getting started) :
-----------------------------------------------

From the File menu choose "Add a new Task. <INS>" :

Fill in a Taskname eg. "data backup".
Use the "source" and "destination" buttons.
They open a directory selector box.
Choose a source directory 
Choose a destination directory.
they can also be on a virtual drive, external harddisk, USB memory stick etc ...
Use the "OK" button to confirm.

Repeat the above to add other update/copy/backup tasks.

Push the "Start compare" button.
Updater_full will compare the sources and destinations of all the selected Tasks.
It will show the newer files and/or the file date/time differences between
the source directory (+ subdirs) and the destination directory (+ subdirs) in the
bottom listview.

You can now use the checkboxes in this listview to unselect the files you don't want to copy from
the source directory structure to the destination directory structure.

Pushing "Start update" will start the actual FileCopy from the source directory structure to
the destination directory structure (Overwrite + create non existing directories).



#####################################################################################################################


Graphical User Interface guide :

The GUI has 2 Listviews.

The top listview shows the Tasks in the order in which they will be processed.
a Task number is shown next to the check-boxes.
You can change this order by selecting a task and using the green up and down buttons.
Only "checked" tasks will be processed.
You can check and uncheck each task or use the small (un)check all buttons.
You can select a task (e.g.: for deletion) by clicking on it.
SHIFT-click and CTRL-click will also work for task selection.
The "Start compare" button will start comparing the source and destination of all the
checked Tasks in the order of the Task number.
During compare : a green progressbar is shown.
The compare will ONLY COMPARE the files of the source structure with the destination
structure. It wil NOT COPY or DO ANYTHING to your files !


The bottom listview will be filled during the compare operation.
It will show all the newer/changed files found.
Newer files are those that don't have a destination date.
The space needed for each file is shown in the rightmost column.
When the compare is finished, a detailed taskinfo popup is shown.
Press "OK".
Default all the files are "checked" and will be copied when using the
"Start Update" button.
You can check and uncheck each file individually or use the small (un)check all buttons.
THE FILES ARE COPIED only when pushing the "Start Update" button. !
As long as you didn't push this button : NOTHING HAS BEEN DONE YET !
During copy : The file(s) that were copied will disappear from the list.
You end up with an empty list if all is done. 


File-menu :
___________


- Add a new Task <INS>
-----------------------------
This should be the first thing to do when starting Updater_full for the first time.
A popup will appear.
You can fill in an appropiate Taskname and select the source and destination directories.

The "source" and "destination" buttons will bring up a directory selector box.
In the "destination" directory box, you can also create a new folder if needed.
source and destination can be swapped.
Edit and add : see next menu item.
All input is safed to the Updater.ini file.


- Edit a selected Task.
-----------------------------
Select an existing task.
You can edit the Taskname, source and destination directories.

Checkbox "Edit and add" :
Starting from an existing Task, you can change the Taskname, swap/change the
source and destination paths and create the result as a new task.


- Remove Task(s). <DEL>
-----------------------
Will remove all the selected Tasks.
a confirmation box will appear.


- Copy source file(s) to ...
-----------------------------
Will be enabled only when the "compare" has run and there are results in the bottom listview from
at least one Task.
A popup will appear.
This feature can copy all the selected source file(s) from one selected Task to a different destination than
the compare destination.
Use : copy all the "newer or updated files" to a subdirectory that needs to be uploaded to your website.


- Exit
-------
Will exit Updater_full
The window close tab will do the same.



Options-menu :
______________


- File time compare precision
-----------------------------
The "Start compare" will compare the source file last modified date/time with the destination
last modified file date/time.
Default, the time compare accuracy is 3 seconds but this can be changed here to an accuracy of only 1 second.
The default value is recommended for FAT systems.
NTFS can be more accurate.


- Set default source/destination dir
------------------------------------
A popup will appear. Here you can SET the default source and destination directories.
This setting will LIMIT the choice of source and destination dirs to only the dir structure
below the default settings when adding a new task.


- Don't show taskinfo after compare
-----------------------------------
Default when the compare operation is finished a detailed taskinfo popup is shown with the number of
new/changed files and the total space needed for the operation.
Check this option if you want to skip the taskinfo popup.
The detailed taskinfo can also be viewed by using the "show taskinfo" button.


- Don't show progressbar during compare
---------------------------------------
If checked : no green progressbar is shown during the compare process.


- Auto start update after compare
---------------------------------
Default when the compare is finished the user must use the "Start Update" button to
actually start copying.
When this option is checked : the Update is done automatically after the compare.
Use with caution ! 



Log-menu :
__________


- Show log
----------
Will open the <computername>_update_log.txt in "notepad.exe"
and navigate to the last log entry.


- No logging
------------
Default setting.
No logging will be done from the moment this is checked.



- Basic logging
---------------
Basic logging will be done from the moment this is checked.
This option will only log the number of newer/changed files per Task
and the Totals.
Also some /silent mode (see advanved) operations are logged.
errors are also logged.


- Detailed logging
------------------
Detailed logging will be done from the moment this is checked.
This option will log all compare and update actions.
This will also log ALL the Filecopies !
all /silent mode operations are logged.
all errors are logged.
caution : This kind of logging can produce a rapid growing logfile !


Help-menu :
__________


- Show readme.txt
-----------------
Open this updater_full_readme.txt with notepad.exe 


#####################################################################################################################


Advanced use :

- command-line options :

Updater_full can be run in a hidden window and can be scheduled in "Scheduled Tasks"
For this to work, Updater_full must be started with command-line options.
These are the valid command-line options (spaces are important !):

c:\Updaterv2.0\updater_full.exe /silent

The tool will run in a hidden window and do all the Tasks that were checked the last time
updater_full was run in normal windowed mode.

c:\Updaterv2.0\updater_full.exe /silent /all

The tool will run in a hidden window and do ALL the Tasks, whether they were previously checked or not.

c:\Updaterv2.0\updater_full.exe /silent 1 2 3

The tool will run in a hidden window and does the Tasks number 1,2 and 3 whether they were previously checked
or not.
The order is not important : 

c:\Updaterv2.0\updater_full.exe /silent 2 3 1

does exactly the same than the above. : first task number 1 is done, then task number 2 and task number 3 is last.
rule : lower tasks numbers are done first in /silent mode.

other possible variant :

c:\Updaterv2.0\updater_full.exe /silent 8 10 13



- Logging :

The logfile name : <computername>_update_log.txt
When the compare process encounters a source file that is older than the destination file,
the user is prompted if this file should be added to the copy list (bottom listview).
When in /silent mode this question is not asked but a log entry is made in "basic" and "detailed" logging.
Not in the "no logging" mode !

#####################################################################################################################

History
-------
- Updater v2.0
Added logging + log menu
Added run in hidden window + command-line options

- Updater v1.7
Added option to change file time compare precision.
Minor bugfixes.

- Updater v1.6
Added option menu
Added Taskinfo

- Updater v1.5
check the Source and Destination path to make sure they are not the same.
Added menu items
Newer .ini file recovers data from previous version of the .ini file.

- Updater v1.4
Changed the .ini file from static to dynamic growing and shrinking.
Removed buttons on the GUI and added menu items instead.
  
- Updater v1.3
The .ini file full of "-1" problem should be solved now by using Gafrost's GuiListView v1.63 include
Added : when message "Skipping this update : Source drive not ready" the program continues after 10 seconds.

- Updater v1.2
Corrected : the subdir from a "non-checked" file was wrongfully created on the destination drive.
Added the "Config" menu to set a default source/destination drive or directory.
Added a source/destination drive status check.(drive must be "READY")
Added a FAT/NTFS drive filesystem check : if no FAT drive is involved, file compare
time accuracy is up to the second.
Display the source dir in the listview immediately after it is choosen from
the dir selector box.

- Updater v1.1
The message "The source file is older than the destination file" will not appear if
the difference is less than 3 seconds.
To Ignore the FAT/NTFS timestamp issues of "2 second difference".
 




