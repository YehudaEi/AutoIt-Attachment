
CREATE TABLE IF NOT EXISTS `au3Table` (
  `id` int(11) NOT NULL auto_increment,
  `last_name` varchar(30) NOT NULL default '',
  `first_name` varchar(30) NOT NULL default '',
  `comment` varchar(255) NOT NULL default '',
  `date` date NOT NULL default '0000-00-00',
  PRIMARY KEY  (`id`)
) TYPE=MyISAM AUTO_INCREMENT=100 ;

INSERT INTO `au3Table` VALUES (101, 'Baker', 'Greg', 'Nice guy this Greg.', '2004-10-30');
INSERT INTO `au3Table` VALUES (102, 'Bush', 'George', 'Not so nice a guy this Bush.', '2007-11-18');
INSERT INTO `au3Table` VALUES (103, 'Williams', 'Barbara', 'Good writter of fiction.', '2006-12-30');
INSERT INTO `au3Table` VALUES (104, 'Adams', 'Evonne', 'Cute!', '2006-10-15');
