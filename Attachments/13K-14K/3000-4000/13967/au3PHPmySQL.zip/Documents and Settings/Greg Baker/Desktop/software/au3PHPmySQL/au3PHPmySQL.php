<?php

	/* DATEBASE CONFIGURATION */

	require( "/home/gypsyt3/offsite/au3PHPmySQL.inc" );

	//require( "/home/.../au3PHPmySQL.inc" );
	// I always keep the DB configuration data out of the public html.
	// That file looks like this example:
	//	$dbHost   = "localhost";
	//	$dbName   = "db name";
	//	$dbUser   = "db user name";
	//	$dbPasswd = "db password";
	//	$DBH      = "";


	// Example action: dump the data records
	if( $HTTP_GET_VARS && isset($HTTP_GET_VARS['action']) && $HTTP_GET_VARS['action'] == "dump" ) {

		db_connect();
		$query = " SELECT * FROM au3Table ";
		$data = mysql_query( $query ) or die("ERROR: Bad select [" . $query . "]");

		if( mysql_num_rows( $data ) ) {

			while( $row = mysql_fetch_array( $data, MYSQL_NUM ) )
				echo array2string( $row ) . "\n";

		} else {

			die("ERROR: No returned data [" . $query . "]");

		}

		mysql_free_result( $data );

		mysql_close();

	} else {

		echo "ERROR: Bad action requested [" . $HTTP_GET_VARS['action'] . "].";

	}


	exit(0);

//---------------------------- Utility Functions

function array2string( $a ) {
	for($n=count($a),$s="",$i=0;$i<$n;$i++)$s .= ($i?",":"").$a[$i];
	return( $s );
}

function db_connect() {  // connect to db
	global $dbHost, $dbName, $dbUser, $dbPasswd, $DBH;
	if (! $DBH ) {
		if (! $DBH = mysql_connect($dbHost, $dbUser, $dbPasswd)) {
			$error  = "ERROR: Can't connect to $dbHost as $dbUser";
			$error .= "MySQL Error: " . mysql_error();
			die($error);
		}
		if (! mysql_select_db($dbName, $DBH)) {
			$error  = "ERROR: Unable to select database $dbName";
			$error .= "MySQL Error: " . mysql_error();
			mysql_close();
			die($error);
		}
	}
}

?>