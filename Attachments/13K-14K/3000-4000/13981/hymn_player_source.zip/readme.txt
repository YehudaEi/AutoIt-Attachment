Hymn Player
by rush4hire (rush4hire.com)
Official Home Page:  http://www.rush4hire.com/hymn_player/
This is a program to play midi files and syncronized text in a karaoke fashion.
It will be especially useful if you want to sing hymns at home or if you have a small church and you don't have a piano or pianist. ;)

The hymns are from the SDA hymnal from http://www.digitalhymnal.org/
When the project was started there where 250 hymns encoded and in midi of the 695 in the hymnal.

--- INSTRUCTIONS ---

This program is very easy to use.

To get the menu just right click.  Pick a song to play and it will play it and show the lyrics.

If there is a .hpt file (Hymn Player Timing) in the timing folder matching the .mid file, you will see the .mid file name in green.  When the tune plays, it will sync the lyrics with the music.

If there is no .hpt file, then it will play anyway and you can keep hitting the right arrow key ( --> ) to move the highlighter along the words in timing with the tune.
This will create a new .hpt file so the next time you play that tune you will see it go through the words much like a karaoke player.

You can set the font and color and everything about the text.  You can set a background image, or just have a color.


--- TIPS ---
- If you don't want to see the words being highlighted as the song plays, just set the highlight font the same as the default.
- To reset to defaults, just delete the .ini file and restart the program.
- I will put more timing files here where I get a chance: http://www.rush4hire.com/hymn_player/timing.zip

--- NOTE ---
- Remember this is brand new, and still under construction.
  It's being developed by an individual and not a major software company.
  If you want to see major improvements in these programs, just give the author some feedback and encouragement :)

Also the Background tab might be bugged still. Just choose a picture, don't mess with the radio buttons,
But no harm will come if you do.

--- CREDITS ---
Jim - Head author of AutoIt platform - www.autoitscript.com
The other contributers to AutoIt and SciTE
Holger Kotsch - for his IconFileScanner 1.2
Gary Frost - for font and color picker
Guys who took the cloud pics
http://www.digitalhymnal.org/


--- CHANGELOG ---
March x, 2007
- Started

March x, 2007
- Everything works but I wanted
- to make a scrolling background (still haven't)
- a nice system for setting fonts and colors
- floating text (without it's own background)

April 5, 2007
- first release.



--- TODO ---
1. add database functionality, then we can:
-- Choose which verses to play
-- load faster
-- search engine
-- keep track of largest font size for each song
-- list view to sort songs by title, number, rating, or most often played, or wether they have timing files or not
-- save fonts for each song

2. Add more background effects like:
-- switch images with a blur effect
-- video
-- scrolling background image.
-- designable templates, graphics or visualitions
-- adjust wether to resize image or not. (getbmpwidth/hight)

3. Settings features like
-- Undo button!! in case you mess up your fonts / colors
-- Adjustable hotkeys like space for pause and F2 for picking a color with the mouse
-- reload default settings
-- reload settings from ini

4. Playlist feature (playlists from files)

5. Resources.
-- OCR conversion method to convert scanned or photo images of hymn pages and then..
-- create a midi file and text out of that. so you don't even need to play it on the keyboard.

6. Misc
-- Different style for words that are done singing

