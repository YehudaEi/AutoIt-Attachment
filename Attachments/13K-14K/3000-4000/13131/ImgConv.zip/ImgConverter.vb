Imports System.IO
Imports System.Runtime.InteropServices
Imports System.Text.RegularExpressions
Imports ImgTool.ScreenShot

<ComClass(ImgConverter.ClassId, ImgConverter.InterfaceId, ImgConverter.EventsId), ComVisible(True)> _
Public Class ImgConverter

#Region "COM GUIDs"
    ' These  GUIDs provide the COM identity for this class 
    ' and its COM interfaces. If you change them, existing 
    ' clients will no longer be able to access the class.
    Public Const ClassId As String = "1f35d8e2-581e-4381-8298-4e4d8ef9fa21"
    Public Const InterfaceId As String = "d1d054e4-dff8-4ebd-a85c-88b9da23771c"
    Public Const EventsId As String = "137a05de-5b20-4c71-b297-467920b818fb"
#End Region

    ' A creatable COM class must have a Public Sub New() 
    ' with no parameters, otherwise, the class will not be 
    ' registered in the COM registry and cannot be created 
    ' via CreateObject.
    Public Sub New()
        MyBase.New()
    End Sub

    Public Sub Test()
        MsgBox("ImgTool.ImgConverter.Test() subroutine", MsgBoxStyle.OkOnly, "ImgTool.ImgConverter test")
    End Sub

    <ComVisible(True)> _
    Public Function ScreenShot(ByVal source As String, ByVal dest As String) As Boolean
        Dim img As Bitmap
        If source.ToLower = "clipboard" Then
            img = FromClipboard()
        ElseIf source.ToLower = "screen" Then
            img = GetScreen()
        ElseIf rxRect.IsMatch(source) Then
            img = GetRect(Rect_by_RegEx(source))
        Else
            Return SetLastError("ArgumentException: source for screenshot must be ""screen"", ""clipboard"", rectangle ""LTWH(n,n,n,n)"", or rectangle ""LTRB(n,n,n,n)""." & _
            vbCrLf & "Value: " & source & _
            vbCrLf & "Expression: " & rxRect.ToString())
        End If
        img.Tag = source
        Return imgProcess(img, dest, False)
    End Function

    <ComVisible(True)> _
    Public Function Convert(ByVal sourcefile As String, ByVal destfile As String, ByVal deleteoriginal As Boolean) As Boolean
        Dim img As Image
        If sourcefile.ToLower = "clipboard" Then
            img = FromClipboard()
            deleteoriginal = False ' you can't delete the clipboard!
        Else ' interpret as filename
            Try
                img = Bitmap.FromFile(sourcefile)
            Catch ex As OutOfMemoryException
                Return SetLastError("SourceFile - OutOfMemoryException: Either the file does not have a valid image format, or GDI+ does not support the pixel format of the file.")
            Catch ex As FileNotFoundException
                Return SetLastError("SourceFile - FileNotFoundException: The specified file does not exist.")
            End Try
        End If
        img.Tag = sourcefile
        Return imgProcess(img, destfile, deleteoriginal)
    End Function

    <ComVisible(False)> _
    Private Function imgProcess(ByVal img As Bitmap, ByVal destfile As String, ByVal deleteoriginal As Boolean) As Boolean
        Try
            img.Save(destfile)
        Catch ex As ArgumentNullException
            Return SetLastError("DestFile - ArgumentNullException: Destination filename is null.")
        Catch ex As ExternalException
            Return SetLastError("DestFile - ExternalException: Either the image was saved with the wrong image format, or the image was saved to the same file it was created from.")
        End Try

        ' If the delete fails, LastError is written but it doesn't fail the 
        ' operation because the more critical part was accomplished
        If deleteoriginal Then
            Me.deleteOriginal(img.Tag)
        End If
        Return True
    End Function

    <ComVisible(False)> _
    Private Function deleteOriginal(ByVal infile As String) As Boolean
        Try
            File.Delete(infile)
        Catch ex As ArgumentNullException
            SetLastError("DeleteOriginal - ArgumentNullException: Path is a null reference")
        Catch ex As ArgumentException
            SetLastError("DeleteOriginal - ArgumentException: Path is a zero-length string, contains only white space, or contains one or more invalid characters as defined by InvalidPathChars.")
        Catch ex As DirectoryNotFoundException
            SetLastError("DeleteOriginal - DirectoryNotFoundException: The specified path is invalid, (for example, it is on an unmapped drive).")
        Catch ex As PathTooLongException
            SetLastError("DeleteOriginal - PathTooLongException: The specified path, file name, or both exceed the system-defined maximum length. For example, on Windows-based platforms, paths must be less than 248 characters, and file names must be less than 260 characters.")
        Catch ex As IOException
            SetLastError("DeleteOriginal - IOException: The specified file is in use.")
        Catch ex As NotSupportedException
            SetLastError("DeleteOriginal - NotSupportedException: path is in an invalid format.")
        Catch ex As UnauthorizedAccessException
            SetLastError("DeleteOriginal - Either the caller does not have the required permission, the specified path is a directory, or the file specified is read-only.")
        End Try
    End Function
    <ComVisible(False)> _
    Private Function GetFormat(ByVal outfile As String) As Drawing.Imaging.ImageFormat
        Dim fmt As Imaging.ImageFormat = Imaging.ImageFormat.Png
        Select Case True
            Case outfile.EndsWith(".jpg") Or outfile.EndsWith(".jpeg") : fmt = Imaging.ImageFormat.Jpeg
            Case outfile.EndsWith(".gif") : fmt = Imaging.ImageFormat.Gif
            Case outfile.EndsWith(".bmp") : fmt = Imaging.ImageFormat.Bmp
            Case outfile.EndsWith(".png") : fmt = Imaging.ImageFormat.Png
            Case outfile.EndsWith(".emf") : fmt = Imaging.ImageFormat.Emf
            Case outfile.EndsWith(".wmf") : fmt = Imaging.ImageFormat.Wmf
            Case outfile.EndsWith(".exif") : fmt = Imaging.ImageFormat.Exif
            Case outfile.EndsWith(".mbmp") : fmt = Imaging.ImageFormat.MemoryBmp
            Case outfile.EndsWith(".tif") Or outfile.EndsWith("tiff") : fmt = Imaging.ImageFormat.Tiff
        End Select
        Return fmt
    End Function

    <ComVisible(False)> _
    Private Function FromClipboard() As Bitmap
        Dim img As Image
        If Clipboard.ContainsImage() Then
            img = Clipboard.GetImage()
        Else
            SetLastError("SourceFile - ClipboardException: The clipboard does not contain an image. Current screen used instead.")
            img = GetScreen()
        End If
        Return New Bitmap(img)
    End Function

#Region "LastError"
    <ComVisible(True)> _
    Public Function GetLastError() As String
        Dim _err As String = _lastError
        _lastError = ""
        Return _err
    End Function
    <ComVisible(False)> _
    Private Function SetLastError(ByVal msg As String) As Boolean
        _lastError = msg
        Return False
    End Function
    Private _lastError As String = ""
#End Region

End Class


