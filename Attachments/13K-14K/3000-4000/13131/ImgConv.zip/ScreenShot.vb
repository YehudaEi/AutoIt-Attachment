Imports System.IO
Imports System.Runtime.InteropServices
Imports System.Text.RegularExpressions
Module ScreenShot
    <ComVisible(False)> _
        Friend rxRect As New Regex("(?<mode>LT(?<m>RB|WH))\((?<L>\d+),(?<T>\d+),(?<W>\d+),(?<H>\d+)\)", RegexOptions.IgnoreCase)

    <ComVisible(False)> _
    Friend Function Rect_by_RegEx(ByVal input As String) As Rectangle
        Dim rct As Match = rxRect.Match(input) ' test for the match before calling this function!
        Dim r As Rectangle
        Dim L, T, W, H As Integer
        If Not Integer.TryParse(rct.Groups("L").Value, L) Then L = Screen.PrimaryScreen.Bounds.Left
        If Not Integer.TryParse(rct.Groups("T").Value, T) Then T = Screen.PrimaryScreen.Bounds.Top
        If Not Integer.TryParse(rct.Groups("W").Value, W) Then W = Screen.PrimaryScreen.Bounds.Width
        If Not Integer.TryParse(rct.Groups("H").Value, H) Then H = Screen.PrimaryScreen.Bounds.Height

        If rct.Groups("mode").Value.ToUpper = "LTRB" Then
            r = New Rectangle(L, T, W - L, H - T)
        Else ' mode = LTWH
            r = New Rectangle(L, T, W, H)
        End If
        Return r
    End Function

    <ComVisible(False)> _
    Friend Function GetRect(ByVal rect As Rectangle) As Bitmap
        ' A screenshot of a button
        ' Obtaining the button device context through its handle
        Dim hWnd As System.IntPtr = GetDesktopWindow()
        Dim hdcWindow As IntPtr = GetDC(hWnd)
        Dim rct As New RECT
        Dim pt As New POINTAPI
        pt.y = rect.Top
        pt.x = rect.Left
        ScreenToClient(hdcWindow, pt)
        rct.Left = pt.x
        rct.Top = pt.y

        Dim b As New Bitmap(rect.Width, rect.Height, Imaging.PixelFormat.Format32bppArgb)

        Dim g As Graphics = Graphics.FromImage(b)
        Dim hdc As IntPtr = g.GetHdc()
        BitBlt(hdc.ToInt32, 0, 0, rect.Width, rect.Height, hdcWindow.ToInt32, rct.Left, rct.Top, SRCCOPY)

        ReleaseDC(hWnd, hdcWindow)
        g.ReleaseHdc(hdc)
        g.Dispose()
        Return b
    End Function

    <ComVisible(False)> _
    Friend Function GetScreen() As Bitmap
        ' Obtaining the desktop handle to take a screenshot of the entire screen
        Dim hWndDesktop As IntPtr = GetDesktopWindow()

        ' Obtaining the window size
        Dim rct As RECT : GetWindowRect(hWndDesktop, rct)
        Dim Width As Int32 = rct.Right - rct.Left
        Dim Height As Int32 = rct.Bottom - rct.Top

        ' Coordinates in the client coordinate system
        Dim pt As New POINTAPI
        pt.y = rct.Top
        pt.x = rct.Left
        ScreenToClient(hWndDesktop, pt)
        rct.Left = pt.x
        rct.Top = pt.y

        ' The bitmap object, in which the screenshot will be held
        Dim b As New Bitmap(Width, Height, Imaging.PixelFormat.Format32bppArgb)

        ' Creating a graphics object
        Dim g As Graphics = Graphics.FromImage(b)

        ' Obtaining the screen device context
        Dim hdcWindow As IntPtr = GetDC(hWndDesktop)

        ' Obtaining the graphics device context
        Dim hdc As IntPtr = g.GetHdc()

        BitBlt(hdc.ToInt32, 0, 0, Width, Height, hdcWindow.ToInt32, rct.Left, rct.Top, SRCCOPY)

        ' Releasing resources
        ReleaseDC(hWndDesktop, hdcWindow)
        g.ReleaseHdc(hdc)

        ' Placing the screenshot in the graphics object
        Return b
    End Function
End Module
