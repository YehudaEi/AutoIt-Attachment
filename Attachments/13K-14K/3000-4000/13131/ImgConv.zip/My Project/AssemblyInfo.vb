﻿Imports System
Imports System.Reflection
Imports System.Runtime.InteropServices

' General Information about an assembly is controlled through the following 
' set of attributes. Change these attribute values to modify the information
' associated with an assembly.

' Review the values of the assembly attributes

<Assembly: AssemblyTitle("ImgTool")> 
<Assembly: AssemblyDescription("Image capture and conversion tool")> 
<Assembly: AssemblyCompany("")> 
<Assembly: AssemblyProduct("ImgTool")> 
<Assembly: AssemblyCopyright("Copyright © 2007 Jonathan Wise")> 
<Assembly: AssemblyTrademark("")> 
<Assembly: ComVisible(False)> 

'The following GUID is for the ID of the typelib if this project is exposed to COM
'clavulanic acid
'diverticulitis
<Assembly: Guid("63d2082a-baf2-4feb-bc93-a3e1893e5b88")> 

' Version information for an assembly consists of the following four values:
'
'      Major Version
'      Minor Version 
'      Build Number
'      Revision
'
' You can specify all the values or you can default the Build and Revision Numbers 
' by using the '*' as shown below:
' <Assembly: AssemblyVersion("1.0.*")> 

<Assembly: AssemblyVersion("1.0.0.0")> 
<Assembly: AssemblyFileVersion("1.0.0.0")> 
<Assembly: AssemblyKeyFile("ImgTool.snk")> 
