Module API
    Friend Declare Function GetDesktopWindow Lib "user32.dll" () As IntPtr

    Friend Structure POINTAPI
        Public x As Int32
        Public y As Int32
    End Structure

    Friend Structure RECT
        Public Left As Int32
        Public Top As Int32
        Public Right As Int32
        Public Bottom As Int32
    End Structure

    ''' <summary>
    ''' The GetWindowRect function retrieves the dimensions of the bounding rectangle of the specified window. 
    ''' </summary>
    ''' <param name="hWnd">Identifies the window.</param>
    ''' <param name="lpRect">Points to a RECT structure that receives the screen coordinates of the upper-left and lower-right corners of the window.</param>
    ''' <returns></returns>
    ''' <remarks>The dimensions are given in screen coordinates that are relative to the upper-left corner of the screen.</remarks>
    Friend Declare Function GetWindowRect Lib "user32.dll" _
        (ByVal hWnd As IntPtr, ByRef lpRect As RECT) As Int32

    Function WindowGetRect(ByVal hWnd As IntPtr) As Rectangle
        Dim lpRect As New RECT
        If GetWindowRect(hWnd, lpRect) <> 0 Then
            Return New Rectangle(lpRect.Left, lpRect.Top, lpRect.Right - lpRect.Left, lpRect.Bottom - lpRect.Top)
        Else
            Throw New ArgumentException("The provided hwnd is not valid")
        End If
    End Function

    Friend Declare Function ScreenToClient Lib "user32.dll" _
        (ByVal hWnd As IntPtr, ByRef lpPoint As POINTAPI) As Int32

    ''' <summary>
    ''' The GetDC function retrieves a handle of a display device context (DC) for the client area of the specified window. The display device context can be used in subsequent GDI functions to draw in the client area of the window.
    ''' </summary>
    ''' <param name="hWnd">Identifies the window whose device context is to be retrieved.</param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Friend Declare Function GetDC Lib "user32.dll" (ByVal hWnd As IntPtr) As IntPtr

    ''' <summary>
    ''' The BitBlt function performs a bit-block transfer of the color data corresponding to a rectangle of pixels from the specified source device context into a destination device context.
    ''' </summary>
    ''' <param name="hDestDC">Identifies the destination device context.</param>
    ''' <param name="x">Specifies the logical x-coordinate of the upper-left corner of the destination rectangle.</param>
    ''' <param name="y">Specifies the logical y-coordinate of the upper-left corner of the destination rectangle.</param>
    ''' <param name="nWidth">Specifies the logical width of the source and destination rectangles.</param>
    ''' <param name="nHeight">Specifies the logical height of the source and the destination rectangles.</param>
    ''' <param name="hSrcDC">Identifies the source device context.</param>
    ''' <param name="xSrc">Specifies the logical x-coordinate of the upper-left corner of the source rectangle.</param>
    ''' <param name="ySrc">Specifies the logical y-coordinate of the upper-left corner of the source rectangle.</param>
    ''' <param name="dwRop">Specifies a raster-operation code. These codes define how the color data for the source rectangle is to be combined with the color data for the destination rectangle to achieve the final color. The following list shows some common raster operation codes:
    ''' <list type = "table">
    ''' <listheader><term>Value</term><description>Definition</description></listheader>
    ''' <item><term>BLACKNESS</term><description>Fills the destination rectangle using the color associated with index 0 in the physical palette. (This color is black for the default physical palette.)</description></item>
    ''' <item><term>DSTINVERT</term><description>Inverts the destination rectangle.</description></item>
    ''' <item><term>MERGECOPY</term><description>Merges the colors of the source rectangle with the specified pattern by using the Boolean AND operator.</description></item>
    ''' <item><term>MERGEPAINT</term><description>Merges the colors of the inverted source rectangle with the colors of the destination rectangle by using the Boolean OR operator.</description></item>
    ''' <item><term>NOTSRCCOPY</term><description>Copies the inverted source rectangle to the destination.</description></item>
    ''' <item><term>NOTSRCERASE</term><description>Combines the colors of the source and destination rectangles by using the Boolean OR operator and then inverts the resultant color.</description></item>
    ''' <item><term>PATCOPY</term><description>Copies the specified pattern into the destination bitmap.</description></item>
    ''' <item><term>PATINVERT</term><description>Combines the colors of the specified pattern with the colors of the destination rectangle by using the Boolean XOR operator.</description></item>
    ''' <item><term>PATPAINT</term><description>Combines the colors of the pattern with the colors of the inverted source rectangle by using the Boolean OR operator. The result of this operation is combined with the colors of the destination rectangle by using the Boolean OR operator.</description></item>
    ''' <item><term>SRCAND</term><description>Combines the colors of the source and destination rectangles by using the Boolean AND operator.</description></item>
    ''' <item><term>SRCCOPY</term><description>Copies the source rectangle directly to the destination rectangle.</description></item>
    ''' <item><term>SRCERASE</term><description>Combines the inverted colors of the destination rectangle with the colors of the source rectangle by using the Boolean AND operator.</description></item>
    ''' <item><term>SRCINVERT</term><description>Combines the colors of the source and destination rectangles by using the Boolean XOR operator.</description></item>
    ''' <item><term>SRCPAINT</term><description>Combines the colors of the source and destination rectangles by using the Boolean OR operator.</description></item>
    ''' <item><term>WHITENESS</term><description>Fills the destination rectangle using the color associated with index 1 in the physical palette. (This color is white for the default physical palette.)</description></item>
    ''' </list></param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Friend Declare Function BitBlt Lib "gdi32" Alias "BitBlt" _
        (ByVal hDestDC As Integer, ByVal x As Integer, _
        ByVal y As Integer, ByVal nWidth As Integer, _
        ByVal nHeight As Integer, ByVal hSrcDC As Integer, _
        ByVal xSrc As Integer, ByVal ySrc As Integer, _
        ByVal dwRop As Integer) As Integer

    Friend Declare Function GetWindowDC Lib "user32" Alias "GetWindowDC" _
        (ByVal hwnd As Integer) As IntPtr

    Friend Declare Function ReleaseDC Lib "user32.dll" _
        (ByVal hWnd As IntPtr, ByVal hdc As IntPtr) As Int32

    Friend Declare Function StretchBlt Lib "gdi32.dll" _
        (ByVal hdc As IntPtr, ByVal x As Int32, _
        ByVal y As Int32, ByVal nWidth As Int32, _
        ByVal nHeight As Int32, ByVal hSrcDC As IntPtr, _
        ByVal xSrc As Int32, ByVal ySrc As Int32, _
        ByVal nSrcWidth As Int32, ByVal nSrcHeight As Int32, _
        ByVal dwRop As Int32) As Int32

    Friend Const SRCCOPY As Int32 = &HCC0020
End Module
