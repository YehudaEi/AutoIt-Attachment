<?
#
#	AutoIT to MySQL via PHP Example (passing variables)
#	variable.php -> Return example with 2 variables sent
#	02-27-07
#	By xwinterx@roadrunner.com
#	
#	Summary: PHP Page to return data to an AutoIT script based on a PHP page
#	accessed via a url with no passed variables. This is very basic and is used
#	for demostrational purposes only. Syntax may not be correct for your version
#	of PHP. Refer to your PHP version's user guide for correct syntax.


# Creates connection to MySQL host, gives error if host not found and terminates PHP script
# "user" will be the username used by your database to log in with
# "password" will be the password for that user name
$connection = mysql_connect("localhost", "user", "password") or die("~host error~");

# Selects MySQL database, gives error if db not found and terminates PHP script
# "database_name" is the name of your database to access
$database = mysql_select_db("database_name", $connection) or die("~db error~");

# Executes a MySQL query from a table for an "id".
# $vtable is the table name passed via url from your AutoIT application
# $id is a field in your table that provides a unique value such as an email address
#	or incrementing UID established by your MySQL server automatically on row creation.
# $id is passed via url from your AutoIT application.
$query = mysql_query("SELECT * FROM ". $vtable ." WHERE id= '". $vid. "'") or die("~invalid login~");

# Fetches all the data from your query and assigns it to an array variable
$row = mysql_fetch_array($query);

# Extracts all of the data from the row. There are several ways of doing this, however
# I prefer this method because you get to work with your actual row varibles instead of
# array references.
extract($row);

# Echoes or "prints" your data to your application in a string format. Because of all the
# info returned by the great HTTP UDF for AutoIt, I use "~" to separate out my data then
# StringSplit() it within my AutoIT application.
# "$id" represents my "id" field
# "$name" represents my "name" field that holds someone's name
# "$email" represents my "email" field that holds that person's e-mail address
echo "~" . $id. "~" . $name . "~" . $email . "~";

# Closes the connection to your database. Important to do this so your server doesn't have
# alot of connections left open.
mysql_close($connection);

?>