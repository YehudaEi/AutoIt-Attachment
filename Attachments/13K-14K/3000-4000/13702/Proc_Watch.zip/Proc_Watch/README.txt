
Run Proc_Watch.exe for instructions.

If you want the program to run at system startup, you can use the
add_to_startup.reg, but you will need to append your process list
to the end of the registry entry.

The source code is Proc_Watch.au3 which is compiled with
http://www.autoitscript.com/.

