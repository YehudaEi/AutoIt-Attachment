using System;
using System.Collections.Generic;
using System.Text;

namespace AnAppADay.Utils
{

    public static class Utility
    {

        public static void ShowMessage(string message)
        {
            System.Windows.Forms.MessageBox.Show(message);
        }

    }

}
