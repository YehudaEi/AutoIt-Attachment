The patterns.txt file doesn't have any error check so it must be formatted correctly for it to work

Each pattern must be a perfect square (i.e. same height as width)

Each pattern must be seperated by a newline
There must be no extra characters in the file

pattern key is as follows

m = a square which can be flagged as a mine
u = square that can be uncovered
9 = a covered square
b = a border square (haven't tested this)
x = an uncovered square
k = a square ignored by the pattern / used to make patterns perfectly square