#include <windows.h>
#include <stdio.h>
#include <conio.h>
#include "smart.h"


int main(int argc, char *argv[]) 
{
	printf("Hardware Serial HDD v1.0 - Napalm\n\nPlease enter drive letter:");
	char szVolumeLetter[32];
	char szPhysicalDrive[64];
	sprintf(szPhysicalDrive, "\\\\.\\%s:", gets(szVolumeLetter));
	HANDLE hPhysicalDriveIOCTL = CreateFile(szPhysicalDrive, GENERIC_READ | GENERIC_WRITE,
		FILE_SHARE_READ | FILE_SHARE_WRITE, NULL, OPEN_EXISTING, 0, NULL);
	if(hPhysicalDriveIOCTL != INVALID_HANDLE_VALUE)
	{
		DWORD dwBytesReturned = 0;
	    
		// Get Physical Drive Information
		VOLUME_DISK_EXTENTS vdExtents;
		ZeroMemory(&vdExtents, sizeof(vdExtents));
		if(!DeviceIoControl(hPhysicalDriveIOCTL, IOCTL_VOLUME_GET_VOLUME_DISK_EXTENTS, NULL, 0,
			&vdExtents, sizeof(vdExtents), &dwBytesReturned, NULL)){
			printf("Error volumes that span multiple disks are not supported!\n");
			CloseHandle(hPhysicalDriveIOCTL);
			return 1;
		}

		// Get SMART version information
		GETVERSIONINPARAMS gvopVersionParams;
		ZeroMemory(&gvopVersionParams, sizeof(gvopVersionParams));
		if(!DeviceIoControl(hPhysicalDriveIOCTL, SMART_GET_VERSION, NULL, 0,
			&gvopVersionParams, sizeof(gvopVersionParams), &dwBytesReturned, NULL)){
			printf("Error cannot get SMART version information from device!\n");
			CloseHandle(hPhysicalDriveIOCTL);
		return 1;
		}
        
		if(gvopVersionParams.bIDEDeviceMap > 0)
		{
			// Setup SMART request
			SENDCMDINPARAMS InParams = {
				IDENTIFY_BUFFER_SIZE, { 0, 1, 1, 0, 0, ((vdExtents.Extents[0].DiskNumber & 1) ? 0xB0 : 0xA0),
				((gvopVersionParams.bIDEDeviceMap >> vdExtents.Extents[0].DiskNumber & 0x10) ? ATAPI_ID_CMD : ID_CMD) },
				(BYTE)vdExtents.Extents[0].DiskNumber
			};
			
			DWORD dwBufSize = sizeof(SENDCMDOUTPARAMS) + IDENTIFY_BUFFER_SIZE;
			PSENDCMDOUTPARAMS pbtIDOutCmd = (PSENDCMDOUTPARAMS) new BYTE[dwBufSize];
			ZeroMemory(pbtIDOutCmd, dwBufSize);
			
			// Get SMART information
			if(DeviceIoControl(hPhysicalDriveIOCTL, SMART_RCV_DRIVE_DATA, &InParams, sizeof(SENDCMDINPARAMS),
				pbtIDOutCmd, dwBufSize, &dwBytesReturned, NULL))
			{
				// Little Endian To Big Endian
				USHORT *pIDSector = (USHORT*)pbtIDOutCmd->bBuffer;
				for(int nShort = 10; nShort < 21; nShort++)
					pIDSector[nShort] = (((pIDSector[nShort] & 0x00FF) << 8) + ((pIDSector[nShort] & 0xFF00) >> 8));
				
				// Get Drive Serial Number
				LPSTR lpszSerialNumber1 = new CHAR[21];
				ZeroMemory(lpszSerialNumber1, 21);
				RtlCopyMemory(lpszSerialNumber1, &pIDSector[10], 20);
				
				// Remove those horrible spaces caused because of endianess
				// and print out the serial
				LPSTR lpszSerialNumber2 = lpszSerialNumber1;
				while(*lpszSerialNumber2 == ' ') lpszSerialNumber2++;
				printf("Physical Serial: %s\n\n", lpszSerialNumber2);
				delete lpszSerialNumber1;
			}
			delete pbtIDOutCmd;
		
		}else{
			printf("Error!\n");
			CloseHandle(hPhysicalDriveIOCTL);
			return 1;
		}
		CloseHandle (hPhysicalDriveIOCTL);
		
		printf("Press any key to exit...\n");
		getch();
	}
	
	return 0;
}

