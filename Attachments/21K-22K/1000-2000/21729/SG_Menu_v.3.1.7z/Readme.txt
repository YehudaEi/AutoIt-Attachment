SG-Menu creates a customizable menu to launch your most used applications. It sits in the tray when running. You may use the mouse to navigate the menus. You may also use a hotkey to bring the menu to where your mouse is, much like a context menu appears when you right mouse click. The application uses a file called SG-Menu.ini to structure itself. This file has certain syntax that is explained within it.

To initially set up SG-Menu, I have created a Menu-Build program. It looks at the SG-Menu-Build.ini file to build the initial SG-Menu.ini. This build.ini file can be edited before creation of the SG-Menu.ini, so that you may choose which menus/sub-menus/items will be included on initial build. The build.ini file has certain syntax that is explained within it.

I would recommend experimenting with both the initial build and the resulting menu. After you understand how it is using the .ini files, you should be able to achieve a comprehensive build.ini, which will do most of the work towards building your resulting menu.ini. This makes it possible to archive the build.ini file for future use if you re-install your OS, or sending it to a friend who wishes to use this application also.

I suggest reading in this order:
Readme.txt
SG-Template1.txt
SG-Build.ini

Enjoy.
MrWoo