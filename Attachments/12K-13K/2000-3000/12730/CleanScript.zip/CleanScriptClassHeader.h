#include <cstdlib>
#include <iostream>
#include <sstream>
#include <string>
#include <stdio.h>
#include <fstream>
#include <ctime>
#include <cctype>
#include <algorithm>
#include <iomanip> //zum beeinflussen des ausgabeformats
using namespace std;

//Autoitsourcefileclass
class autoitsourcefile
{
    public:
        autoitsourcefile(char * filename);
        ~autoitsourcefile();
        void read_to_array();
        void output_current_lines();
        void search_includes_and_add_to_lines(char * ,char * );
        long write_to_file(char * dest_path); //returns size of written file
        void remove_comments();
        void remove_upheaval();
        void remove_regions();
        void remove_unused_functions(int durchgaenge,char * cout_);
        void remove_unused_vars(char * cout_);
        void delete_empty_lines();
        void show_statistic();
        void transform_lines();
        //string linestransformated[50000];
    private:
        ifstream work_file;
        string lines[25000];
        string lines_transformated[25000];
        int line_nr;
        int includet_file_number;
        string includet_files[500];
        int func_nr;
        int var_nr;
        int deleted_funcs;
        int deleted_vars;


        double time_includes, time_start_includes;
        double time_comments, time_start_comments;
        double time_upheavals, time_start_upheavals;
        double time_regions, time_start_regions;
        double time_vars, time_start_vars;
        double time_funcs, time_start_funcs;
        double time_empty_lines, time_start_empty_lines;
        double time_full, time_start_full;
};

//constructor --> opens the source file and sets the vars
autoitsourcefile::autoitsourcefile(char * filename)
{
    work_file.open(filename);
    line_nr=0;
    includet_file_number=0;
    func_nr=0;
    var_nr=0;
    deleted_funcs=0;
    deleted_vars=0;

    time_includes=0.0;
    time_comments=0.0;
    time_regions=0.0;
    time_vars=0.0;
    time_funcs=0.0;
    time_empty_lines=0.0;

    time_full=0.0;
    time_start_full=clock();
}

//destructor --> does nothing
autoitsourcefile::~autoitsourcefile()
{
}

//read_to_array --> read source file
void autoitsourcefile::read_to_array()
{
    string temp_line;
    while (getline(work_file, temp_line) )
    {
        lines[++line_nr] = temp_line;
    }
}

//output_current_lines --> output lines in console
void autoitsourcefile::output_current_lines()
{
    for (int i=1;i<=line_nr;i++)
    {
        cout<<lines[i]<<endl;
    }
}

//search_includes_and_add_to_lines --> searches includes and adds their lines to array
void autoitsourcefile::search_includes_and_add_to_lines(char * includespath,char * scriptdir)
{
    time_start_includes=clock();
    string lines_inc[50000];

    int line_nr_inc;
    string filename_full_path;
    string include_filename;
    includet_file_number=0;
    for (int k=1; k<=line_nr;k++)
    {
        string templine=lines[k];
        transform (templine.begin(),templine.end(), templine.begin(),(int(*)(int)) toupper);
        if (templine.find("#INCLUDE")!= -1) //Zeile von tabs und leerzeichen befreien
        {
            while(templine.find(" ")!= -1)
            {
            templine.replace(templine.find(" "), 1, "");
            }
            while(templine.find("\t")!= -1)
            {
            templine.replace(templine.find("\t"), 1, "");
            }
            if (templine.substr(0, 13) == "#INCLUDE-ONCE")
            {
            lines[k]="";
            templine="";
            }
            else if (templine.substr(0, 8) == "#INCLUDE")
            {
                if (templine.find("<") != -1)
                {
                    int inc_pos1 = templine.find("<");
                    int inc_pos2 = templine.find(">");
                    include_filename = templine.substr(inc_pos1+1, inc_pos2 - inc_pos1-1);

                    cout << "found #include: " << include_filename << "\n";

                    filename_full_path = "";
                    filename_full_path.append(includespath);
                    filename_full_path.append("\\");
                    filename_full_path.append(include_filename);
                }
                else
                {
                    int inc_pos1 = templine.find("\"");
                    int inc_pos2 = templine.length() - 1;
                    include_filename = templine.substr(inc_pos1+1, inc_pos2 - inc_pos1-1);

                    cout << "found #include: " << include_filename << "\n";

                    filename_full_path = "";
                    filename_full_path.append(scriptdir);
                    filename_full_path.append("\\");
                    filename_full_path.append(include_filename);
                }

                int file_includet=0;
                if(includet_file_number>0)
                {
                    for(int h=1;h<=includet_file_number;h++)
                    {
                        if (filename_full_path==includet_files[h])
                        {
                            cout<<filename_full_path<<" file already includet\n";
                            file_includet=1;
                            lines[k]="";
                            templine="";
                            break;
                            //system("PAUSE");
                        }
                    }
                }


                if (file_includet==0)
                {
                    includet_files[++includet_file_number]=filename_full_path;
                    cout << "start: search/read: " << filename_full_path << "...\n";
                    ifstream include_file(filename_full_path.c_str());
                    string temp_line = "";
                    string lines_tmp[50000];
                    line_nr_inc = 0;
                    //lines_inc[1] = ";Include-Start: " + filename;
                    while (getline(include_file, temp_line) )
                    {
                        lines_inc[++line_nr_inc] = temp_line;

                    }
                    lines_inc[++line_nr_inc] = "";

                    // lines in lines_tmp retten
                    for (int g=1; g<=line_nr; g++)
                    {
                        lines_tmp[g] = lines[g];

                    }
                    for (int g=0; g<=49999; g++)
                    {
                        lines[g] = "";
                    }

                    // tmp und inc in lines verschmelzen
                    // Zeilen vor Include zur�ck
                    for (int g=1; g<k; g++)
                    {
                        lines[g] = lines_tmp[g];
                    }
                    // Include einbauen
                    for (int g=1; g<=line_nr_inc; g++)
                    {
                        lines[k+g] = lines_inc[g];
                    //cout << lines[g+k] << "\n";
                    }
                    // Rest anh�ngen
                    for (int g=k+1; g<=line_nr; g++)
                    {
                        lines[g + line_nr_inc ] = lines_tmp[g];
                    }
                    // line_nr auf neue Gesamtdateil�nge setzen
                    line_nr = line_nr+line_nr_inc;

                    cout << "finished: read " << include_filename << "\n";
                    k--; //die Zeile wo #include stand nochmal durchsuchen, falls im includeten file ganz oben wieder #include steht
                }
            }
        }
    }
    time_includes+= clock() - time_start_includes;
    time_includes=time_includes/CLOCKS_PER_SEC;

    //transform_lines(); erst nach comments entfernung durchf�hren
}

//write_to_file --> writes the lines into the dest file
long autoitsourcefile::write_to_file(char * dest_path)
{
    ofstream w_file;
    w_file.open(dest_path);
    for (int i=1; i<=line_nr; i++)
    {
        w_file.write(lines[i].c_str(), lines[i].length() );
        w_file.write("\n", 1 );
    }
    w_file.close();
    cout << "file written.\n\n";
    // Gr��e feststellen
    long size;
    ifstream _file(dest_path);
    _file.seekg(0, ios::end);
    size = _file.tellg();
    return size;
}

//transform_lines --> removes tabs and empties and transforms lines to Uppercase
void autoitsourcefile::transform_lines()
{
    for (int z=1; z<=line_nr; z++)
    {
        lines_transformated[z]=lines[z];
        while(lines_transformated[z].find(" ")!=-1)
        {
            lines_transformated[z].replace( lines_transformated[z].find(" "), 1, "");
        }
        while(lines_transformated[z].find("\t")!=-1)
        {
            lines_transformated[z].replace( lines_transformated[z].find("\t"), 1, "");
        }
        transform (lines_transformated[z].begin(),lines_transformated[z].end(), lines_transformated[z].begin(),(int(*)(int)) toupper);
    }
}

//remove_comments --> removes comments
void autoitsourcefile::remove_comments()
{
    time_start_comments=clock();
    int einfach_string_offen=0;
    int doppelt_string_offen=0;
    int position_comment_start;
    int position_comment_end;


    cout << "start: remove comments...\n";
    for (int i=1; i<=line_nr; i++)
    {
    // einzeilige Kommentare
        if (lines[i].find(";")!= -1)
        {
            einfach_string_offen=0;
            doppelt_string_offen=0;
            for (int p=0;p<=lines[i].length();p++)
            {
                if (lines[i].substr(p,1)== "'" && doppelt_string_offen==0 && einfach_string_offen==0)//schaun ob sich die zeichen nur in einem string befinden
                {
                    einfach_string_offen=1;
                }
                else
                {
                    if (lines[i].substr(p,1)== "'" && einfach_string_offen==1)//schaun ob sich die zeichen nur in einem string befinden
                    {
                        einfach_string_offen=0;
                    }
                }
                if (lines[i].substr(p,1)== "\"" && doppelt_string_offen==0 && einfach_string_offen==0)//schaun ob sich die zeichen nur in einem string befinden
                {
                    doppelt_string_offen=1;
                }
                else
                {
                    if (lines[i].substr(p,1)== "\"" && doppelt_string_offen==1)//schaun ob sich die zeichen nur in einem string befinden
                    {
                        doppelt_string_offen=0;
                    }
                }
                if(doppelt_string_offen==0 && einfach_string_offen==0)
                {
                    if (lines[i].substr(p,1)== ";" )
                    {
                        lines[i]=lines[i].substr(0,p);
                        break;
                    }
                }
            }

        }

        // Mehrzeilige Kommentare (#cs-#ce)
        position_comment_start = lines[i].find("#cs");

        if (position_comment_start != -1)
        {
            lines[i] = lines[i].substr(0, position_comment_start);
            int j = i;
            do
            {
                j++;
                position_comment_end = lines[j].find("#ce");
                lines[j] = "";
            }
            while (position_comment_end == -1);
        }
        // Mehrzeilige Kommentare (#comments-start-#comments-end)
        position_comment_start= lines[i].find("#comments-start");

        if (position_comment_start != -1)
        {
            lines[i] = lines[i].substr(0, position_comment_start);
            int j = i;
            do
            {
                j++;
                position_comment_end = lines[j].find("#comments-end");
                lines[j] = "";
            }
            while (position_comment_end == -1);
        }
    }
    cout << "finished: remove comments\n\n";
    time_comments+= clock() - time_start_comments;
    time_comments=time_comments/CLOCKS_PER_SEC;
}

//remove_upheaval --> removes upheavals
void autoitsourcefile::remove_upheaval()
{
    time_start_upheavals=clock();
    cout << "start: remove upheavals...\n";


    //Zeilenumbr�che mit _ entfernen --> in eine Zeile schreiben
    for (int o=1; o<=line_nr; o++)
    {
        //zun�chst Leerzeichen/tabs am Zeilenende entfernen
        while (lines[o].length()>0)
        {
            if (lines[o].substr(lines[o].length()-1,1)==" " || lines[o].substr(lines[o].length()-1,1)=="\t" )
            {
                lines[o]=lines[o].substr(0,lines[o].length()-1);
            }
            else
            break;
        }
    }


    for (int o=line_nr; o>=0; o--)
    {
        if (lines[o].length()>0)
        {
            if (lines[o].substr(lines[o].length()-1,1)=="_")
            {
                lines[o]=lines[o].substr(0,lines[o].length()-1);
                lines[o].append(lines[o+1]);
                lines[o+1]="";
            }
        }
    }
    cout << "finished: remove upheavals\n\n";
    time_upheavals+= clock() - time_start_upheavals;
    time_upheavals=time_upheavals/CLOCKS_PER_SEC;


}

//remove_regions --> removes region keywords
void autoitsourcefile::remove_regions()
{
     time_start_regions=clock();
     cout << "start: remove regions...\n";


    for (int o=1; o<=line_nr; o++)
    {
        if (lines_transformated[o].substr(0, 7) == "#REGION")
        {

            //system("PAUSE");
            lines_transformated[o]="";
            lines[o]="";
        }
        else if (lines_transformated[o].substr(0, 10) == "#ENDREGION")
        {
            lines_transformated[o]="";
            lines[o]="";
        }
    }



    cout << "finished: remove regions\n\n";
    time_regions+= clock() - time_start_regions;
    time_regions=time_regions/CLOCKS_PER_SEC;
}

//remove_unused_functions --> searches all functions and if not used deletes them
void autoitsourcefile::remove_unused_functions(int durchgaenge,char * cout_)
{
    time_start_funcs=clock();
    cout << "start: remove unused functions...\n";
    string funcs[10000];
    int funcs_start[10000];

    if (durchgaenge==1)
    {
        cout << "1 Run\n";
    }
    else
    {
        cout << durchgaenge << " Runs\n";
    }
    for (int l=1; l<=durchgaenge;l++)
    {
        func_nr=0;
        cout <<endl<< "Run: " << l << "\n";
        cout << "search: searching functions...\n";
        // alle Funktionen auflisten
        for (int t=1; t<=line_nr; t++)
        {
            if (lines_transformated[t].substr(0, 4) == "FUNC")
            {
                int pos = lines_transformated[t].find("(");
                funcs[++func_nr] = lines_transformated[t].substr(4, pos-4);
                funcs_start[func_nr] = t;
                if (*cout_=='C')
                {
                    cout << "found function: " << func_nr << ":  " << funcs[func_nr] <<endl;
                }
                else if(t%50==0)
                {
                    cout<<".";
                }
            }
        }

        cout <<endl<< "finihed: searching functions\n";

        // Funktionsaufrufe suchen
        int called = 0;


        string appended_func;
        string appended_func_bracket;

        for (int p=1; p<=func_nr; p++)
        {
            called=0;
            //cout << "p: " << p << "\n";
            appended_func="\"";
            appended_func.append(funcs[p]);
            appended_func.append("\"");
            appended_func_bracket=funcs[p];
            appended_func_bracket.append("(");

            for (int r=1; r<=line_nr; r++)
            {
                if (lines_transformated[r].find(appended_func_bracket) != -1 || lines_transformated[r].find(appended_func) != -1)
                {
                    if (funcs_start[p] != r)
                    {
                        called = 1;
                        break;
                    }
                }
            }
            if (called == 0)
            {
                deleted_funcs++;
                if (*cout_=='C')
                {
                    cout<<"delete function (functionnr.: " << p << "): " << funcs[p] <<endl;
                }
                else if(p%50==0)
                {
                    cout<<".";
                }

                int del_line = funcs_start[p];
                while (lines_transformated[del_line].find("ENDFUNC") == -1)
                {
                    lines[del_line] = "";
                    lines_transformated[del_line]="";
                    del_line++;
                }
                lines[del_line] = "";
                lines_transformated[del_line]="";
            }
        }
    }
    cout << "finished: remove unused functions\n\n";
    time_funcs+= clock() - time_start_funcs;
    time_funcs=time_funcs/CLOCKS_PER_SEC;
}

//remove_unused_vars --> searches all variables and if not used deletes them
void autoitsourcefile::remove_unused_vars(char * cout_)
{
    time_start_vars=clock();

    string vars[10000];
    int vars_start[10000];
    cout << "start: remove unused variables...\n";


    //vars auflisten
    //DONE Zeilenumbruch mit _  deklaration in n�chster zeile zb:   local $a _
    //                                                                    ,$b wird nicht entdeckt -->erledigt

    int write_var= 1;
    int klammer_auf= 0;
    int eckige_klammer_auf=0;
    int einfach_string_offen=0;
    int doppelt_string_offen=0;
    string temp_var;
    string lines_transformated_eine_zeile;

    cout<<"start: searching variables...\n\n";
    for (int t=1; t<=line_nr; t++)
    {
        einfach_string_offen=0;
        doppelt_string_offen=0;
        klammer_auf= 0;
        eckige_klammer_auf=0;
        if(lines_transformated[t].find("ENUM") == -1)   //ENUM-Zeilen auslassen, w�rde zu bugs f�hren
            {
            if (lines_transformated[t].find("DIM") == 0 || lines_transformated[t].find("LOCAL") == 0 || lines_transformated[t].find("GLOBAL") == 0 || lines_transformated[t].find("CONST") == 0)
            {
                temp_var="";
                write_var= 1;
                for (int p=0;p<=lines_transformated[t].length();p++)
                {
                    if (lines_transformated[t].substr(p,1)== "'" && doppelt_string_offen==0 && einfach_string_offen==0)//schaun ob sich die zeichen nur in einem string befinden
                    {
                        einfach_string_offen=1;
                    }
                    else if (lines_transformated[t].substr(p,1)== "'" && einfach_string_offen==1)//schaun ob sich die zeichen nur in einem string befinden
                    {
                        einfach_string_offen=0;
                    }

                    else if (lines_transformated[t].substr(p,1)== "\"" && doppelt_string_offen==0 && einfach_string_offen==0)//schaun ob sich die zeichen nur in einem string befinden
                    {
                        doppelt_string_offen=1;
                    }
                    else if (lines_transformated[t].substr(p,1)== "\"" && doppelt_string_offen==1)//schaun ob sich die zeichen nur in einem string befinden
                    {
                        doppelt_string_offen=0;
                    }

                    else if(doppelt_string_offen==0 && einfach_string_offen==0)
                    {
                        if (lines_transformated[t].substr(p,1)== "(" )
                        {
                            klammer_auf++;
                        }
                        else if (lines_transformated[t].substr(p,1)== ")" )
                        {
                            klammer_auf--;
                        }
                        else if (lines_transformated[t].substr(p,1)== "[" )
                        {
                            eckige_klammer_auf++;
                        }
                        else if (lines_transformated[t].substr(p,1)== "]" )
                        {
                            eckige_klammer_auf--;
                        }

                        else if (klammer_auf==0 && eckige_klammer_auf==0)// && lines_transformated[t].substr(p,1)!= "]" && lines_transformated[t].substr(p,1)!= ")")
                        {
                            if (lines_transformated[t].substr(p,1)== "," || lines_transformated[t].substr(p,1)== "=" || lines_transformated[t].substr(p,1)== "[")
                            {
                                if (write_var==1)
                                {
                                    vars[var_nr]=temp_var;
                                    vars_start[var_nr]=t;
                                    if (*cout_=='C')
                                    {
                                        cout << "found variable: " << var_nr << ":  " << vars[var_nr] <<endl;
                                    }
                                    else if(t%50==0)
                                    {
                                        cout<<".";
                                    }
                                    var_nr++;
                                }
                                if (lines_transformated[t].substr(p,1)== "=" || lines_transformated[t].substr(p,1)== "[")write_var=0;
                                if (lines_transformated[t].substr(p,1)== ",")
                                {write_var= 1;
                                temp_var="";}
                            }
                            else
                            {
                                temp_var.append(lines_transformated[t].substr(p,1));
                                if(temp_var=="DIM" || temp_var=="LOCAL" || temp_var=="GLOBAL" || temp_var=="CONST") temp_var=""; //TODO Enum Problem
                                //cout<<temp_var<<endl;
                            }
                        }
                    }
                }
                if (write_var==1)
                {
                    vars[var_nr]=temp_var;
                    if (*cout_=='C')
                    cout << "found variable: " << var_nr << ":  " << vars[var_nr] <<endl;
                    else if(t%50==0)
                    cout<<".";
                    var_nr++;
                }
            }
        }
    }
    cout<<endl<<"finished: searching variables\n";




    int called=0;
    for (int p=1; p<=var_nr; p++)
    {
        //cout<<"bei variable: " << p << " von " << var_nr<<endl;
        called=0;
        //cout << "p: " << p << "\n";
        for (int r=1; r<=line_nr; r++)
        {

            if (lines_transformated[r].find(vars[p]) != -1)
            {
                if (vars_start[p] != r) // problem bei Global $cout=5, $s=$cout
                {
                    called = 1;
                    break;
                }
            }
        }
        // system("PAUSE");
        //cout << "Funktion " << funcs[p] << "(" << p << ") untersucht.\n";
        if (called == 0)
        {

            deleted_vars++;
            if (*cout_=='C')
            cout<<"delete variable (variablenr.: " << p << "): " << vars[p] <<endl;
            else if(p%50==0)
            cout<<".";

            if (p>1 && p<var_nr)
            {
                if(vars_start[p]!=vars_start[p+1] && vars_start[p]!=vars_start[p-1])//dann ganze Zeile l�schen
                {

                    lines[vars_start[p]] = "";
                    lines_transformated[vars_start[p]]="";
                    vars_start[p]=-1;
                }
                else //eine variable die benutzt wird ist in der gleichen Zeile
                {

                    string lines_transformated_eine_zeile=lines[vars_start[p]];
                    transform (lines_transformated_eine_zeile.begin(),lines_transformated_eine_zeile.end(), lines_transformated_eine_zeile.begin(),(int(*)(int)) toupper);
                    int start_pos_var_in_line=lines_transformated_eine_zeile.find(vars[p]); //DONE: Gefahr, dass eine Variable in einem string vorkommt oder teil einer l�ngeren variable ist -->besteht weiterhin, aber sinnvolle variablen namen zb aus gui constants kommen kaum in einem string vor und wenn werden sie einfach nicht gel�scht, minimaler platzeinsparungsverlust aber kein verlust der funktionalit�t des skriptes
                    //starte l�schen an dieser position bzw. wenn eine variable davorsteht noch (vars_start[p-1]=var_sstart[p]) am "," beginnen zu l�schen
                    if (vars_start[p]==vars_start[p-1])//finde Kommaposition direkt vor der variable //Variable in der gleichen Zeile fall eins: davor ist eine, in diesem fall wird auch noch untersucht ob sich auch hinten eine befindet
                    {
                        start_pos_var_in_line--;
                        while(lines_transformated_eine_zeile.substr(start_pos_var_in_line,1)!=",")
                        {
                            lines_transformated_eine_zeile.substr(start_pos_var_in_line,1);
                            start_pos_var_in_line--;
                        }
                        //cout<<"starte abschnitt bei pos: " << start_pos_var_in_line << " (" << lines_transformated_eine_zeile.substr(start_pos_var_in_line,1) << ") bei der variablen: "<< vars[p]<<endl;
                        if (vars_start[p]!=vars_start[p+1])
                        {
                            //bis zum ende abschneiden
                            lines[vars_start[p]]=lines[vars_start[p]].substr(0,start_pos_var_in_line);
                        }
                        else
                        {
                            int start_pos_naechste_var_in_line=lines_transformated_eine_zeile.find(vars[p+1]);
                            start_pos_naechste_var_in_line--;
                            while(lines_transformated_eine_zeile.substr(start_pos_naechste_var_in_line,1)!=",")
                            {
                                lines_transformated_eine_zeile.substr(start_pos_naechste_var_in_line,1);
                                start_pos_naechste_var_in_line--;
                            }

                            lines[vars_start[p]].replace( start_pos_var_in_line,start_pos_naechste_var_in_line-start_pos_var_in_line,"");

                        }
                    }
                    else if (vars_start[p]!=vars_start[p-1])//es muss eine variable danach geben in der zeile //Fall zwei vorne befindet sich keine var, da else fall muss hinten eine sein
                    {
                        int start_pos_naechste_var_in_line=lines_transformated_eine_zeile.find(vars[p+1]);
                        start_pos_naechste_var_in_line--;
                        while(lines_transformated_eine_zeile.substr(start_pos_naechste_var_in_line,1)!=",")
                        {
                            lines_transformated_eine_zeile.substr(start_pos_naechste_var_in_line,1);
                            start_pos_naechste_var_in_line--;
                        }
                        lines[vars_start[p]].replace( start_pos_var_in_line,start_pos_naechste_var_in_line-start_pos_var_in_line+1,"");
                    }

                //als n�chstes die position des kommas direkt vor der n�chsten variablen suchen; wenn keine weitere var in der zeile bis zum ende l�schen
                }
            }
            else if(p==1)
            {
                if(vars_start[p]!=vars_start[p+1])//dann ganze Zeile l�schen
                {
                    //cout<<"Variable wird geloescht (Var. nr.: " << p << "): " << vars[p] <<endl;
                    lines[vars_start[p]] = "";
                    lines_transformated[vars_start[p]]="";
                    vars_start[p]=-1;
                }
                else //eine variable die benutzt wird ist in der gleichen Zeile
                {

                    string lines_transformated_eine_zeile=lines[vars_start[p]];
                    transform (lines_transformated_eine_zeile.begin(),lines_transformated_eine_zeile.end(), lines_transformated_eine_zeile.begin(),(int(*)(int)) toupper);
                    int start_pos_var_in_line=lines_transformated_eine_zeile.find(vars[p]); //DONE: Gefahr, dass eine Variable in einem string vorkommt oder teil einer l�ngeren variable ist
                    //starte l�schen an dieser position bzw. wenn eine variable davorsteht noch (vars_start[p-1]=var_sstart[p]) am "," beginnen zu l�schen



                    //cout<<"starte abschnitt bei pos: " << start_pos_var_in_line << " (" << lines_transformated_eine_zeile.substr(start_pos_var_in_line,1) << ") bei der variablen: "<< vars[p]<<endl;

                    int start_pos_naechste_var_in_line=lines_transformated_eine_zeile.find(vars[p+1]);
                    start_pos_naechste_var_in_line--;
                    while(lines_transformated_eine_zeile.substr(start_pos_naechste_var_in_line,1)!=",")
                    {

                        lines_transformated_eine_zeile.substr(start_pos_naechste_var_in_line,1);
                        start_pos_naechste_var_in_line--;
                    }

                    lines[vars_start[p]].replace( start_pos_var_in_line,start_pos_naechste_var_in_line-start_pos_var_in_line+1,"");
                }
            }
            else if(p==var_nr)
            {
                if(vars_start[p]!=vars_start[p-1])//dann ganze Zeile l�schen  -->vars_start bei l�schen auf -1 setzen
                {
                    //cout<<"Variable wird geloescht (Var. nr.: " << p << "): " << vars[p] <<endl;
                    lines[vars_start[p]] = "";
                    lines_transformated[vars_start[p]]="";
                    vars_start[p]=-1;
                }
                else //eine variable die benutzt wird ist in der gleichen Zeile
                {
                    string lines_transformated_eine_zeile=lines[vars_start[p]];
                    transform (lines_transformated_eine_zeile.begin(),lines_transformated_eine_zeile.end(), lines_transformated_eine_zeile.begin(),(int(*)(int)) toupper);
                    int start_pos_var_in_line=lines_transformated_eine_zeile.find(vars[p]); //DONE: Gefahr, dass eine Variable in einem string vorkommt oder teil einer l�ngeren variable ist
                    //starte l�schen an dieser position bzw. wenn eine variable davorsteht noch (vars_start[p-1]=var_sstart[p]) am "," beginnen zu l�schen
                    if (vars_start[p]==vars_start[p-1])//finde Kommaposition direkt vor der variable //Variable in der gleichen Zeile fall eins: davor ist eine, in diesem fall wird auch noch untersucht ob sich auch hinten eine befindet
                    {
                        start_pos_var_in_line--;
                        while(lines_transformated_eine_zeile.substr(start_pos_var_in_line,1)!=",")
                        {
                            lines_transformated_eine_zeile.substr(start_pos_var_in_line,1);
                            start_pos_var_in_line--;
                        }
                        //cout<<"starte abschnitt bei pos: " << start_pos_var_in_line << " (" << lines_transformated_eine_zeile.substr(start_pos_var_in_line,1) << ") bei der variablen: "<< vars[p]<<endl;

                        //bis zum ende abschneiden
                        lines[vars_start[p]]=lines[vars_start[p]].substr(0,start_pos_var_in_line);
                    }
                }
            }
        }
    }
    cout <<endl<< "finished: remove unused variables\n\n";
    time_vars+= clock() - time_start_vars;
    time_vars=time_vars/CLOCKS_PER_SEC;
}

//delete_empty_lines --> removes empty lines for write_to_file()
void autoitsourcefile::delete_empty_lines()
{
    // leere Zeilen weg
    time_start_empty_lines=clock();
    cout << "start: remove empty lines...\n";
    int line_nr_write = 0;
    for (int i=1; i<=line_nr; i++)
    {
        int empty = 1;
        if (lines[i].length() != 0)
        {
            for (int j=0; j <= lines[i].length() - 1; j++)
            {
                if (lines[i].substr(j, 1) != "\t" && lines[i].substr(j, 1) != " ") empty = 0;
            }
        }
        // �bertragen, wenn leer
        if (empty == 0)
        {
            lines[++line_nr_write] = lines[i];
        }
    }
    line_nr=line_nr_write;
    cout << "finished: remove empty lines\n\n";
    time_empty_lines+= clock() - time_start_empty_lines;
    time_empty_lines=time_empty_lines/CLOCKS_PER_SEC;
}

//show_statistic --> shows the results of the work
void autoitsourcefile::show_statistic()
{
    time_full+= clock() - time_start_full;
    time_full=time_full/CLOCKS_PER_SEC;


    cout<< left << setw(30)<<"time read includes:" << setw(6)<< fixed << setprecision(3) << right << time_includes << " seconds" << endl;
    cout<< left << setw(30)<<"time remove comments:" << setw(6)<< fixed << setprecision(3) << right << time_comments << " seconds" << endl;
    cout<< left << setw(30)<<"time remove upheavals (_):" << setw(6)<< fixed << setprecision(3) << right << time_upheavals << " seconds" << endl;
    cout<< left << setw(30)<<"time remove regions:" << setw(6)<< fixed << setprecision(3) << right << time_regions << " seconds" << endl;
    cout<< left << setw(30)<<"time remove unused vars:" << setw(6)<< fixed << setprecision(3) << right << time_vars << " seconds" << endl;
    cout<< left << setw(30)<<"time remove unused functions:" << setw(6)<< fixed << setprecision(3) << right << time_funcs << " seconds" << endl;
    cout<< left << setw(30)<<"time remove empty lines:" << setw(6)<< fixed << setprecision(3) << right << time_empty_lines << " seconds" << endl;
    cout<< left << setw(30)<<"time complete:" << setw(6)<< fixed << setprecision(3) << right << time_full << " seconds" << endl << endl;

    cout << left << setw(20)<<"includet files: " << includet_file_number << endl << endl;


    cout << left << setw(20)<<"deleted vars: " << deleted_vars << endl;
    cout << left << setw(20)<<"deleted functions: " << deleted_funcs << endl << endl;
}
