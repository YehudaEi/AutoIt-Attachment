#include "CleanScriptClassHeader.h"
/* peethebee (18:11:50 14/11/2006)
meine aktuelle Idee: Aut2Exe.exe umbenennen und durch eine so benannte CS-Version ersetzen

 peethebee (18:12:17 14/11/2006)
die nimmt Params entgegen, macht ihr Zeug, tauscht den Dateinamen, und ruft dann die alte Aut2Exe auf...*/


using namespace std;

long size_before;
long size_after;

int main(int argc, char *argv[])
{
    autoitsourcefile file(argv[1]);
    file.read_to_array();
    //autoitsourcefile.output_current_lines();
    file.search_includes_and_add_to_lines(argv[4],argv[3]);//includepath (beta/normal-includes und @scriptdir)
    size_before=file.write_to_file(argv[2]);
    if (argv[5][0] == 'C')//it's always 'C'
    {
        file.remove_comments();
    }
    file.remove_upheaval();
    file.transform_lines();
    file.remove_regions();
    if (argv[5][1] == 'F')
    {
         file.remove_unused_functions(atoi(argv[6]),argv[7]);//number runs as int, art of cout
    }

    if (argv[5][2] == 'G')
    {
         file.remove_unused_vars(argv[7]);// art of cout
    }
    file.delete_empty_lines();
    size_after=file.write_to_file(argv[2]);
    file.show_statistic();

    cout << left << setw(30) << "file size without optimation: " << setw(6) << right <<  size_before << " bytes\n";
    cout << left << setw(30) << "file size with optimation: " << setw(6) << right << size_after << " bytes\n";
    cout << left << setw(30) << "improvement: " << setw(6) << fixed << setprecision(0) << right << ((float)size_before - (float)size_after) / (float)size_before * 100 << " %\n\n";
    cout <<"Finished!!!" << endl << endl;

    system("PAUSE");
    return EXIT_SUCCESS;
}
