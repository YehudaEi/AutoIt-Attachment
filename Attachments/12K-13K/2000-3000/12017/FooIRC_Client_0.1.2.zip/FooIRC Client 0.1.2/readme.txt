FooIRC Client 0.1.2
(This is a premature release of FooIRC Client. It is unstable and buggy.)

HOW TO USE:
+ Click on the "#" icon to connect to a server and a channel.

WHAT CURRENTLY WORKS:
+ Connecting to a channel on an irc server and communicate with others on that channel.
+ Using many irc commands. (However, this irc client does not yet properly parse all irc command outputs)
+ Color options.

TODO:
+ Properly parse and output text such as when people leave the channel, or are kicked, private messages, etc...
+ Settings and other windows.
+ Lots of other stuff. Clean code up.
+ Test IRC client on other channels and servers.
+ Changing nick while connected (needs to send new nick to server, if connected).
+ Give a parting message when leaving, if connected.
+ Create a generic/default output parser that will parse raw irc data into a more readable form.

BUGS:
+ Issues with sending password for user... (I'm not sure if it actually works yet.)