// Magic Japboard resources header

#define IDR_LOGOBMP 		1

#define IDR_ICON 			1
#define IDR_ROMAJI 			2
#define IDR_HIRAGANA 		3
#define IDR_KATAKANA 		4

#define IDD_MAIN 			1
#define IDD_HELP 			2
#define IDD_ABOUT 			3

#define IDR_OK 				2

#define IDR_TRAYMENU 		1
#define IDR_TRAYROMAJI 		2
#define IDR_TRAYHIRAGANA 	3
#define IDR_TRAYKATAKANA 	4
#define IDR_TRAYHELP	 	5
#define IDR_TRAYABOUT 		6
#define IDR_TRAYEXIT 		7
