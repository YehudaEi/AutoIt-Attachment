// MJK main module

#include "magicjap.h"
#include "winmain.h"

static BOOL bActivated = FALSE;
static int iMode = MODE_ROMAJI;
static LETTER_DATA stLetterData = {0};
static char szTemp[10] = {0};
static BOOL bNowQuote = FALSE;
static BOOL bNT;

void Initialize (void) {
	OSVERSIONINFO stVersion;
	bNT = TRUE;

	GetVersionEx (&stVersion);
	if ((stVersion.dwMajorVersion == 4) && (stVersion.dwMinorVersion != 0))
		bNT = FALSE;

	return;
}
void Activate (HWND hWin) {
	SetHotkeys (hWin, TRUE);
	bActivated = TRUE;
}
void Deactivate (HWND hWin) {
	SetHotkeys (hWin, FALSE);
	bActivated = FALSE;
}

BOOL HandleHotkey (HWND hWin, WPARAM wParam) {
	char szLocalTemp[10];
	char chNowChar;
	BOOL bTransformable;

	// Special hotkeys //
	switch (wParam) {
		case VK_ROMAJI:
			iMode = MODE_ROMAJI;
			Deactivate (hWin);
			SetTrayIcon (hWin, iMode);
			return TRUE;
		case VK_HIRAGANA:
			iMode = MODE_HIRAGANA;
			Activate (hWin);
			SetTrayIcon (hWin, iMode);
			return TRUE;
		case VK_KATAKANA:
			iMode = MODE_KATAKANA;
			Activate (hWin);
			SetTrayIcon (hWin, iMode);
			return TRUE;
		case VK_BACK:
		case VK_DELETE:
			if (strlen(szTemp) == 0) {
				Deactivate (hWin);
				SendKey (wParam);
				Activate (hWin);
			}
			sprintf (szTemp, "");
			return TRUE;
	}
	
	// Check if it's activated //
	if ((! bActivated) || (iMode == MODE_ROMAJI)) {
		Deactivate (hWin);
		SendKey (wParam);
		Activate (hWin);
		return TRUE;
	}

	// Update the temp string //
	chNowChar = tolower (MapVirtualKey (wParam, 2));
	sprintf (szLocalTemp, "%c", chNowChar);
	strcat (szTemp, szLocalTemp);
	bTransformable = StringToLetterData (&stLetterData, szTemp);

	// Transformable string //
	if (bTransformable) {

		// Incomplete string //
		if (stLetterData.bWait)
			return TRUE;

		// Exception string //
		else if (stLetterData.bException) {
			if (stLetterData.bSpecial)
				SendUnicodeString (stLetterData.wszString);
			else
				SendUnicode (stLetterData.wchLetter);

			// Delete the first char //
			strcpy (szLocalTemp, (szTemp + stLetterData.iExceptionDelete));
			strcpy (szTemp, szLocalTemp);

			// See if the second one is transformable //
			bTransformable = StringToLetterData (&stLetterData, szTemp);
			if (! bTransformable) {
				Deactivate (hWin);
				SendString (szTemp);
				Activate (hWin);
				sprintf (szTemp, "");
			}
		}

		// Complete string //
		else {
			if (stLetterData.bSpecial)
				SendUnicodeString (stLetterData.wszString);
			else
				SendUnicode (stLetterData.wchLetter);
			sprintf (szTemp, "");
		}

	}
	
	// Something else //
	else {
		Deactivate (hWin);
		SendString (szTemp);
		Activate (hWin);
		sprintf (szTemp, "");
	}

	return TRUE;
}

BOOL StringToLetterData (PLETTER_DATA pLetterData, char * szString) {
	char chFirstChar;
	char chSecondChar;
	char chThirdChar;
	char chFourthChar;
	char chFifthChar;
	int iLen;
	
	// Don't crash with null pointers //
	LETTER_DATA stLocalLetterData;
	if (! pLetterData) pLetterData = &stLocalLetterData;

	// Get the characters //
	chFirstChar = tolower (szString[0]);
	chSecondChar = tolower (szString[1]);
	chThirdChar = tolower (szString[2]);
	chFourthChar = tolower (szString[3]);
	chFifthChar = tolower (szString[4]);
	iLen = strlen (szString);

	// Reset the letter data structure //
	LabelLogicStart:
	pLetterData->bWait = FALSE;
	pLetterData->bSpecial = FALSE;
	pLetterData->bException = FALSE;
	pLetterData->iExceptionDelete = 0;
	pLetterData->wchLetter = FALSE;

	switch (chFirstChar) {
		// Vows //
		case 'a':
			pLetterData->wchLetter = LETTER_A;
			break;
		case 'i':
			pLetterData->wchLetter = LETTER_I;
			break;
		case 'u':
			pLetterData->wchLetter = LETTER_U;
			break;
		case 'e':
			pLetterData->wchLetter = LETTER_E;
			break;
		case 'o':
			pLetterData->wchLetter = LETTER_O;
		break;

		// Ka family //	
		case 'k':
			if (iLen == 1) pLetterData->bWait = TRUE;
			switch (chSecondChar) {
				case 'a':
					pLetterData->wchLetter = LETTER_KA;
					break;
				case 'i':
					pLetterData->wchLetter = LETTER_KI;
					break;
				case 'u':
					pLetterData->wchLetter = LETTER_KU;
					break;
				case 'e':
					pLetterData->wchLetter = LETTER_KE;
					break;
				case 'o':
					pLetterData->wchLetter = LETTER_KO;
					break;
				// Special strings //
				case 'k':
					if (iLen == 2) pLetterData->bWait = TRUE;
					switch (chThirdChar) {
						case 'a':
							pLetterData->bSpecial = TRUE;
							swprintf (pLetterData->wszString, sizeof(pLetterData->wszString), L"%lc%lc", LETTER_SMALLTSU, LETTER_KA);
							break;
						case 'i':
							pLetterData->bSpecial = TRUE;
							swprintf (pLetterData->wszString, sizeof(pLetterData->wszString), L"%lc%lc", LETTER_SMALLTSU, LETTER_KI);
							break;
						case 'u':
							pLetterData->bSpecial = TRUE;
							swprintf (pLetterData->wszString, sizeof(pLetterData->wszString), L"%lc%lc", LETTER_SMALLTSU, LETTER_KU);
							break;
						case 'e':
							pLetterData->bSpecial = TRUE;
							swprintf (pLetterData->wszString, sizeof(pLetterData->wszString), L"%lc%lc", LETTER_SMALLTSU, LETTER_KE);
							break;
						case 'o':
							pLetterData->bSpecial = TRUE;
							swprintf (pLetterData->wszString, sizeof(pLetterData->wszString), L"%lc%lc", LETTER_SMALLTSU, LETTER_KO);
							break;
						case ' ': // Single KU //
							pLetterData->bSpecial = TRUE;
							swprintf (pLetterData->wszString, sizeof(pLetterData->wszString), L"%lc%lc ", LETTER_SMALLTSU, LETTER_KU);
							break;
					}
					break;
				case 'y':
					if (iLen == 2) pLetterData->bWait = TRUE;
					switch (chThirdChar) {
						case 'a':
							pLetterData->bSpecial = TRUE;
							swprintf (pLetterData->wszString, sizeof(pLetterData->wszString), L"%lc%lc", LETTER_KI, LETTER_SMALLYA);
							break;
						case 'u':
							pLetterData->bSpecial = TRUE;
							swprintf (pLetterData->wszString, sizeof(pLetterData->wszString), L"%lc%lc", LETTER_KI, LETTER_SMALLYU);
							break;
						case 'o':
							pLetterData->bSpecial = TRUE;
							swprintf (pLetterData->wszString, sizeof(pLetterData->wszString), L"%lc%lc", LETTER_KI, LETTER_SMALLYO);
							break;
						break;
					}
					break;
				case ' ': // Single KU //
					pLetterData->bSpecial = TRUE;
					swprintf (pLetterData->wszString, sizeof(pLetterData->wszString), L"%lc ", LETTER_KU);
					break;
				default:
					pLetterData->bException = TRUE;
					pLetterData->iExceptionDelete = 1;
					pLetterData->wchLetter = LETTER_KU;
				break;
			}
		break;

		// Ga family //
		case 'g':
			if (iLen == 1) pLetterData->bWait = TRUE;
			switch (chSecondChar) {
				case 'a':
					pLetterData->wchLetter = LETTER_GA;
					break;
				case 'i':
					pLetterData->wchLetter = LETTER_GI;
					break;
				case 'u':
					pLetterData->wchLetter = LETTER_GU;
					break;
				case 'e':
					pLetterData->wchLetter = LETTER_GE;
					break;
				case 'o':
					pLetterData->wchLetter = LETTER_GO;
					break;
				// Special strings //
				case 'g':
					if (iLen == 2) pLetterData->bWait = TRUE;
					switch (chThirdChar) {
						case 'a':
							pLetterData->bSpecial = TRUE;
							swprintf (pLetterData->wszString, sizeof(pLetterData->wszString), L"%lc%lc", LETTER_SMALLTSU, LETTER_GA);
							break;
						case 'i':
							pLetterData->bSpecial = TRUE;
							swprintf (pLetterData->wszString, sizeof(pLetterData->wszString), L"%lc%lc", LETTER_SMALLTSU, LETTER_GI);
							break;
						case 'u':
							pLetterData->bSpecial = TRUE;
							swprintf (pLetterData->wszString, sizeof(pLetterData->wszString), L"%lc%lc", LETTER_SMALLTSU, LETTER_GU);
							break;
						case 'e':
							pLetterData->bSpecial = TRUE;
							swprintf (pLetterData->wszString, sizeof(pLetterData->wszString), L"%lc%lc", LETTER_SMALLTSU, LETTER_GE);
							break;
						case 'o':
							pLetterData->bSpecial = TRUE;
							swprintf (pLetterData->wszString, sizeof(pLetterData->wszString), L"%lc%lc", LETTER_SMALLTSU, LETTER_GO);
							break;
						case ' ': // Single GU //
							pLetterData->bSpecial = TRUE;
							swprintf (pLetterData->wszString, sizeof(pLetterData->wszString), L"%lc%lc ", LETTER_SMALLTSU, LETTER_GU);
							break;
					}
					break;
				case 'y':
					if (iLen == 2) pLetterData->bWait = TRUE;
					switch (chThirdChar) {
						case 'a':
							pLetterData->bSpecial = TRUE;
							swprintf (pLetterData->wszString, sizeof(pLetterData->wszString), L"%lc%lc", LETTER_GI, LETTER_SMALLYA);
							break;
						case 'u':
							pLetterData->bSpecial = TRUE;
							swprintf (pLetterData->wszString, sizeof(pLetterData->wszString), L"%lc%lc", LETTER_GI, LETTER_SMALLYU);
							break;
						case 'o':
							pLetterData->bSpecial = TRUE;
							swprintf (pLetterData->wszString, sizeof(pLetterData->wszString), L"%lc%lc", LETTER_GI, LETTER_SMALLYO);
							break;
						break;
					}
					break;
				case ' ': // Single GU //
					pLetterData->bSpecial = TRUE;
					swprintf (pLetterData->wszString, sizeof(pLetterData->wszString), L"%lc ", LETTER_GU);
					break;
				default:
					pLetterData->bException = TRUE;
					pLetterData->iExceptionDelete = 1;
					pLetterData->wchLetter = LETTER_GU;
				break;
			}
		break;

		// Sa family //
		case 's':
			if (iLen == 1) pLetterData->bWait = TRUE;
			switch (chSecondChar) {
				case 'a':
					pLetterData->wchLetter = LETTER_SA;
					break;
				case 'i':
					pLetterData->wchLetter = LETTER_SI;
					break;
				case 'u':
					pLetterData->wchLetter = LETTER_SU;
					break;
				case 'e':
					pLetterData->wchLetter = LETTER_SE;
					break;
				case 'o':
					pLetterData->wchLetter = LETTER_SO;
					break;
				// Special strings //
				case 'h':
					if (iLen == 2) pLetterData->bWait = TRUE;
					switch (chThirdChar) {
						case 'y':
							if (iLen == 3) pLetterData->bWait = TRUE;
							switch (chFourthChar) {
								case 'a':
									pLetterData->bSpecial = TRUE;
									swprintf (pLetterData->wszString, sizeof(pLetterData->wszString), L"%lc%lc", LETTER_SHI, LETTER_SMALLYA);
									break;
								case 'i':
									pLetterData->wchLetter = LETTER_SHI;
									break;
								case 'e':
									pLetterData->bSpecial = TRUE;
									swprintf (pLetterData->wszString, sizeof(pLetterData->wszString), L"%lc%lc", LETTER_SHI, LETTER_SMALLE);
									break;
								case 'u':
									pLetterData->bSpecial = TRUE;
									swprintf (pLetterData->wszString, sizeof(pLetterData->wszString), L"%lc%lc", LETTER_SHI, LETTER_SMALLYU);
									break;
								case 'o':
									pLetterData->bSpecial = TRUE;
									swprintf (pLetterData->wszString, sizeof(pLetterData->wszString), L"%lc%lc", LETTER_SHI, LETTER_SMALLYO);
									break;
								break;
							}
							break;
						case 'a':
							pLetterData->bSpecial = TRUE;
							swprintf (pLetterData->wszString, sizeof(pLetterData->wszString), L"%lc%lc", LETTER_SHI, LETTER_SMALLYA);
							break;
						case 'i':
							pLetterData->wchLetter = LETTER_SHI;
							break;
						case 'e':
							pLetterData->bSpecial = TRUE;
							swprintf (pLetterData->wszString, sizeof(pLetterData->wszString), L"%lc%lc", LETTER_SHI, LETTER_SMALLE);
							break;
						case 'u':
							pLetterData->bSpecial = TRUE;
							swprintf (pLetterData->wszString, sizeof(pLetterData->wszString), L"%lc%lc", LETTER_SHI, LETTER_SMALLYU);
							break;
						case 'o':
							pLetterData->bSpecial = TRUE;
							swprintf (pLetterData->wszString, sizeof(pLetterData->wszString), L"%lc%lc", LETTER_SHI, LETTER_SMALLYO);
							break;
						break;
					}
					break;
				case 's':
					if (iLen == 2) pLetterData->bWait = TRUE;
					switch (chThirdChar) {
						case 'h':
							if (iLen == 3) pLetterData->bWait = TRUE;
							switch (chFourthChar) {
								case 'a':
									pLetterData->bSpecial = TRUE;
									swprintf (pLetterData->wszString, sizeof(pLetterData->wszString), L"%lc%lc%lc", LETTER_SMALLTSU, LETTER_SHI, LETTER_SMALLYA);
									break;
								case 'i':
									pLetterData->bSpecial = TRUE;
									swprintf (pLetterData->wszString, sizeof(pLetterData->wszString), L"%lc%lc", LETTER_SMALLTSU, LETTER_SHI, LETTER_SHI);
									break;
								case 'u':
									pLetterData->bSpecial = TRUE;
									swprintf (pLetterData->wszString, sizeof(pLetterData->wszString), L"%lc%lc%lc", LETTER_SMALLTSU, LETTER_SHI, LETTER_SMALLYU);
									break;
								case 'e':
									pLetterData->bSpecial = TRUE;
									swprintf (pLetterData->wszString, sizeof(pLetterData->wszString), L"%lc%lc%lc", LETTER_SMALLTSU, LETTER_SHI, LETTER_SMALLE);
									break;
								case 'o':
									pLetterData->bSpecial = TRUE;
									swprintf (pLetterData->wszString, sizeof(pLetterData->wszString), L"%lc%lc%lc", LETTER_SMALLTSU, LETTER_SHI, LETTER_SMALLYO);
									break;
								case 'y':
									if (iLen == 4) pLetterData->bWait = TRUE;
									switch (chFifthChar) {
										case 'a':
											pLetterData->bSpecial = TRUE;
											swprintf (pLetterData->wszString, sizeof(pLetterData->wszString), L"%lc%lc%lc", LETTER_SMALLTSU, LETTER_SHI, LETTER_SMALLYA);
											break;
										case 'u':
											pLetterData->bSpecial = TRUE;
											swprintf (pLetterData->wszString, sizeof(pLetterData->wszString), L"%lc%lc%lc", LETTER_SMALLTSU, LETTER_SHI, LETTER_SMALLYU);
											break;
										case 'e':
											pLetterData->bSpecial = TRUE;
											swprintf (pLetterData->wszString, sizeof(pLetterData->wszString), L"%lc%lc%lc", LETTER_SMALLTSU, LETTER_SHI, LETTER_SMALLE);
											break;
										case 'o':
											pLetterData->bSpecial = TRUE;
											swprintf (pLetterData->wszString, sizeof(pLetterData->wszString), L"%lc%lc%lc", LETTER_SMALLTSU, LETTER_SHI, LETTER_SMALLYO);
										break;
									}
								break;
							}
							break;
						case 'a':
							pLetterData->bSpecial = TRUE;
							swprintf (pLetterData->wszString, sizeof(pLetterData->wszString), L"%lc%lc", LETTER_SMALLTSU, LETTER_SA);
							break;
						case 'i':
							pLetterData->bSpecial = TRUE;
							swprintf (pLetterData->wszString, sizeof(pLetterData->wszString), L"%lc%lc", LETTER_SMALLTSU, LETTER_SHI);
							break;
						case 'u':
							pLetterData->bSpecial = TRUE;
							swprintf (pLetterData->wszString, sizeof(pLetterData->wszString), L"%lc%lc", LETTER_SMALLTSU, LETTER_SU);
							break;
						case 'e':
							pLetterData->bSpecial = TRUE;
							swprintf (pLetterData->wszString, sizeof(pLetterData->wszString), L"%lc%lc", LETTER_SMALLTSU, LETTER_SE);
							break;
						case 'o':
							pLetterData->bSpecial = TRUE;
							swprintf (pLetterData->wszString, sizeof(pLetterData->wszString), L"%lc%lc", LETTER_SMALLTSU, LETTER_SO);
							break;
						case ' ': // Single SU //
							pLetterData->bSpecial = TRUE;
							swprintf (pLetterData->wszString, sizeof(pLetterData->wszString), L"%lc%lc ", LETTER_SMALLTSU, LETTER_SU);
							break;
					}
					break;
				case 'y':
					if (iLen == 2) pLetterData->bWait = TRUE;
					switch (chThirdChar) {
						case 'a':
							pLetterData->bSpecial = TRUE;
							swprintf (pLetterData->wszString, sizeof(pLetterData->wszString), L"%lc%lc", LETTER_SHI, LETTER_SMALLYA);
							break;
						case 'u':
							pLetterData->bSpecial = TRUE;
							swprintf (pLetterData->wszString, sizeof(pLetterData->wszString), L"%lc%lc", LETTER_SHI, LETTER_SMALLYU);
							break;
						case 'e':
							pLetterData->bSpecial = TRUE;
							swprintf (pLetterData->wszString, sizeof(pLetterData->wszString), L"%lc%lc", LETTER_SHI, LETTER_SMALLE);
							break;
						case 'o':
							pLetterData->bSpecial = TRUE;
							swprintf (pLetterData->wszString, sizeof(pLetterData->wszString), L"%lc%lc", LETTER_SHI, LETTER_SMALLYO);
							break;
						break;
					}
					break;
				case ' ': // Single SU //
					pLetterData->bSpecial = TRUE;
					swprintf (pLetterData->wszString, sizeof(pLetterData->wszString), L"%lc ", LETTER_SU);
					break;
				default:
					pLetterData->bException = TRUE;
					pLetterData->iExceptionDelete = 1;
					pLetterData->wchLetter = LETTER_SU;
				break;
			}
		break;

		// Za family //
		case 'z':
			if (iLen == 1) pLetterData->bWait = TRUE;
			switch (chSecondChar) {
				case 'a':
					pLetterData->wchLetter = LETTER_ZA;
					break;
				case 'i':
					pLetterData->wchLetter = LETTER_ZI;
					break;
				case 'u':
					pLetterData->wchLetter = LETTER_ZU;
					break;
				case 'e':
					pLetterData->wchLetter = LETTER_ZE;
					break;
				case 'o':
					pLetterData->wchLetter = LETTER_ZO;
					break;
				// Special strings //
				case 'z':
					if (iLen == 2) pLetterData->bWait = TRUE;
					switch (chThirdChar) {
						case 'a':
							pLetterData->bSpecial = TRUE;
							swprintf (pLetterData->wszString, sizeof(pLetterData->wszString), L"%lc%lc", LETTER_SMALLTSU, LETTER_ZA);
							break;
						case 'i':
							pLetterData->bSpecial = TRUE;
							swprintf (pLetterData->wszString, sizeof(pLetterData->wszString), L"%lc%lc", LETTER_SMALLTSU, LETTER_ZI);
							break;
						case 'u':
							pLetterData->bSpecial = TRUE;
							swprintf (pLetterData->wszString, sizeof(pLetterData->wszString), L"%lc%lc", LETTER_SMALLTSU, LETTER_ZU);
							break;
						case 'e':
							pLetterData->bSpecial = TRUE;
							swprintf (pLetterData->wszString, sizeof(pLetterData->wszString), L"%lc%lc", LETTER_SMALLTSU, LETTER_ZE);
							break;
						case 'o':
							pLetterData->bSpecial = TRUE;
							swprintf (pLetterData->wszString, sizeof(pLetterData->wszString), L"%lc%lc", LETTER_SMALLTSU, LETTER_ZO);
							break;
						case ' ': // Single ZU //
							pLetterData->bSpecial = TRUE;
							swprintf (pLetterData->wszString, sizeof(pLetterData->wszString), L"%lc%lc ", LETTER_SMALLTSU, LETTER_ZU);
							break;
					}
					break;
				case 'y':
					if (iLen == 2) pLetterData->bWait = TRUE;
					switch (chThirdChar) {
						case 'a':
							pLetterData->bSpecial = TRUE;
							swprintf (pLetterData->wszString, sizeof(pLetterData->wszString), L"%lc%lc", LETTER_ZI, LETTER_SMALLYA);
							break;
						case 'u':
							pLetterData->bSpecial = TRUE;
							swprintf (pLetterData->wszString, sizeof(pLetterData->wszString), L"%lc%lc", LETTER_ZI, LETTER_SMALLYU);
							break;
						case 'o':
							pLetterData->bSpecial = TRUE;
							swprintf (pLetterData->wszString, sizeof(pLetterData->wszString), L"%lc%lc", LETTER_ZI, LETTER_SMALLYO);
							break;
						break;
					}
					break;
				case ' ': // Single ZU //
					pLetterData->bSpecial = TRUE;
					swprintf (pLetterData->wszString, sizeof(pLetterData->wszString), L"%lc ", LETTER_ZU);
					break;
				default:
					pLetterData->bException = TRUE;
					pLetterData->iExceptionDelete = 1;
					pLetterData->wchLetter = LETTER_ZU;
				break;
			}
		break;

		// Ta family //
		case 't':
			if (iLen == 1) pLetterData->bWait = TRUE;
			switch (chSecondChar) {
				case 'a':
					pLetterData->wchLetter = LETTER_TA;
					break;
				case 'i':
					pLetterData->wchLetter = LETTER_CHI;
					break;
				case 's':
					if (iLen == 2) pLetterData->bWait = TRUE;
					if (chThirdChar == 'u')
						pLetterData->wchLetter = LETTER_TSU;
					break;
				case 'u':
					pLetterData->wchLetter = LETTER_TU;
					break;
				case 'e':
					pLetterData->wchLetter = LETTER_TE;
					break;
				case 'o':
					pLetterData->wchLetter = LETTER_TO;
					break;
				// Special strings //
				case 't':
					if (iLen == 2) pLetterData->bWait = TRUE;
					switch (chThirdChar) {
						case 's':
							if (iLen == 3) pLetterData->bWait = TRUE;
							if (chFourthChar == 'u') {
								pLetterData->bSpecial = TRUE;
								swprintf (pLetterData->wszString, sizeof(pLetterData->wszString), L"%lc%lc", LETTER_SMALLTSU, LETTER_TSU);
							}
							break;
						case 'a':
							pLetterData->bSpecial = TRUE;
							swprintf (pLetterData->wszString, sizeof(pLetterData->wszString), L"%lc%lc", LETTER_SMALLTSU, LETTER_TA);
							break;
						case 'i':
							pLetterData->bSpecial = TRUE;
							swprintf (pLetterData->wszString, sizeof(pLetterData->wszString), L"%lc%lc", LETTER_SMALLTSU, LETTER_CHI);
							break;
						case 'u':
							pLetterData->bSpecial = TRUE;
							swprintf (pLetterData->wszString, sizeof(pLetterData->wszString), L"%lc%lc", LETTER_SMALLTSU, LETTER_TSU);
							break;
						case 'e':
							pLetterData->bSpecial = TRUE;
							swprintf (pLetterData->wszString, sizeof(pLetterData->wszString), L"%lc%lc", LETTER_SMALLTSU, LETTER_TE);
							break;
						case 'o':
							pLetterData->bSpecial = TRUE;
							swprintf (pLetterData->wszString, sizeof(pLetterData->wszString), L"%lc%lc", LETTER_SMALLTSU, LETTER_TO);
							break;
						case ' ': // Single TO //
							pLetterData->bSpecial = TRUE;
							swprintf (pLetterData->wszString, sizeof(pLetterData->wszString), L"%lc%lc ", LETTER_SMALLTSU, LETTER_TO);
							break;
					}
					break;
				case 'y':
					if (iLen == 2) pLetterData->bWait = TRUE;
					switch (chThirdChar) {
						case 'a':
							pLetterData->bSpecial = TRUE;
							swprintf (pLetterData->wszString, sizeof(pLetterData->wszString), L"%lc%lc", LETTER_CHI, LETTER_SMALLYA);
							break;
						case 'u':
							pLetterData->bSpecial = TRUE;
							swprintf (pLetterData->wszString, sizeof(pLetterData->wszString), L"%lc%lc", LETTER_CHI, LETTER_SMALLYU);
							break;
						case 'o':
							pLetterData->bSpecial = TRUE;
							swprintf (pLetterData->wszString, sizeof(pLetterData->wszString), L"%lc%lc", LETTER_CHI, LETTER_SMALLYO);
							break;
						break;
					}
					break;
				case ' ': // Single TO //
					pLetterData->bSpecial = TRUE;
					swprintf (pLetterData->wszString, sizeof(pLetterData->wszString), L"%lc ", LETTER_TO);
					break;
				default:
					pLetterData->bException = TRUE;
					pLetterData->iExceptionDelete = 1;
					pLetterData->wchLetter = LETTER_TO;
				break;
			}
		break;

		// Da family //
		case 'd':
			if (iLen == 1) pLetterData->bWait = TRUE;
			switch (chSecondChar) {
				case 'a':
					pLetterData->wchLetter = LETTER_DA;
					break;
				case 'i':
					pLetterData->wchLetter = LETTER_JI;
					break;
				case 'z':
					if (iLen == 2) pLetterData->bWait = TRUE;
					if (chThirdChar == 'u')
						pLetterData->wchLetter = LETTER_DZU;
					break;
				case 'u':
					pLetterData->wchLetter = LETTER_DU;
					break;
				case 'e':
					pLetterData->wchLetter = LETTER_DE;
					break;
				case 'o':
					pLetterData->wchLetter = LETTER_DO;
					break;
				// Special strings //
				case 'd':
					if (iLen == 2) pLetterData->bWait = TRUE;
					switch (chThirdChar) {
						case 'z':
							if (iLen == 3) pLetterData->bWait = TRUE;
							if (chFourthChar == 'u') {
								pLetterData->bSpecial = TRUE;
								swprintf (pLetterData->wszString, sizeof(pLetterData->wszString), L"%lc%lc", LETTER_SMALLTSU, LETTER_DZU);
							}
							break;
						case 'a':
							pLetterData->bSpecial = TRUE;
							swprintf (pLetterData->wszString, sizeof(pLetterData->wszString), L"%lc%lc", LETTER_SMALLTSU, LETTER_DA);
							break;
						case 'i':
							pLetterData->bSpecial = TRUE;
							swprintf (pLetterData->wszString, sizeof(pLetterData->wszString), L"%lc%lc", LETTER_SMALLTSU, LETTER_DI);
							break;
						case 'u':
							pLetterData->bSpecial = TRUE;
							swprintf (pLetterData->wszString, sizeof(pLetterData->wszString), L"%lc%lc", LETTER_SMALLTSU, LETTER_DZU);
							break;
						case 'e':
							pLetterData->bSpecial = TRUE;
							swprintf (pLetterData->wszString, sizeof(pLetterData->wszString), L"%lc%lc", LETTER_SMALLTSU, LETTER_DE);
							break;
						case 'o':
							pLetterData->bSpecial = TRUE;
							swprintf (pLetterData->wszString, sizeof(pLetterData->wszString), L"%lc%lc", LETTER_SMALLTSU, LETTER_DO);
							break;
						case ' ': // Single DO //
							pLetterData->bSpecial = TRUE;
							swprintf (pLetterData->wszString, sizeof(pLetterData->wszString), L"%lc%lc ", LETTER_SMALLTSU, LETTER_DO);
							break;
					}
					break;
				case 'y':
					if (iLen == 2) pLetterData->bWait = TRUE;
					switch (chThirdChar) {
						case 'a':
							pLetterData->bSpecial = TRUE;
							swprintf (pLetterData->wszString, sizeof(pLetterData->wszString), L"%lc%lc", LETTER_DI, LETTER_SMALLYA);
							break;
						case 'u':
							pLetterData->bSpecial = TRUE;
							swprintf (pLetterData->wszString, sizeof(pLetterData->wszString), L"%lc%lc", LETTER_DI, LETTER_SMALLYU);
							break;
						case 'o':
							pLetterData->bSpecial = TRUE;
							swprintf (pLetterData->wszString, sizeof(pLetterData->wszString), L"%lc%lc", LETTER_DI, LETTER_SMALLYO);
							break;
						break;
					}
					break;
				case ' ': // Single DO //
					pLetterData->bSpecial = TRUE;
					swprintf (pLetterData->wszString, sizeof(pLetterData->wszString), L"%lc ", LETTER_DO);
					break;
				default:
					pLetterData->bException = TRUE;
					pLetterData->iExceptionDelete = 1;
					pLetterData->wchLetter = LETTER_DO;
				break;
			}
		break;

		// Na family //
		case 'n':
			if (iLen == 1) pLetterData->bWait = TRUE;
			switch (chSecondChar) {
				case ' ': // Single n
					pLetterData->bSpecial = TRUE;
					swprintf (pLetterData->wszString, sizeof(pLetterData->wszString), L"%lc ", LETTER_N);
					break;
				case 'a':
					pLetterData->wchLetter = LETTER_NA;
					break;
				case 'i':
					pLetterData->wchLetter = LETTER_NI;
					break;
				case 'u':
					pLetterData->wchLetter = LETTER_NU;
					break;
				case 'e':
					pLetterData->wchLetter = LETTER_NE;
					break;
				case 'o':
					pLetterData->wchLetter = LETTER_NO;
					break;
				// Special strings //
/*				case 'n':
					if (iLen == 2) pLetterData->bWait = TRUE;
					switch (chThirdChar) {
						case 'a':
							pLetterData->bSpecial = TRUE;
							swprintf (pLetterData->wszString, sizeof(pLetterData->wszString), L"%lc%lc", LETTER_SMALLTSU, LETTER_NA);
							break;
						case 'i':
							pLetterData->bSpecial = TRUE;
							swprintf (pLetterData->wszString, sizeof(pLetterData->wszString), L"%lc%lc", LETTER_SMALLTSU, LETTER_NI);
							break;
						case 'u':
							pLetterData->bSpecial = TRUE;
							swprintf (pLetterData->wszString, sizeof(pLetterData->wszString), L"%lc%lc", LETTER_SMALLTSU, LETTER_NU);
							break;
						case 'e':
							pLetterData->bSpecial = TRUE;
							swprintf (pLetterData->wszString, sizeof(pLetterData->wszString), L"%lc%lc", LETTER_SMALLTSU, LETTER_NE);
							break;
						case 'o':
							pLetterData->bSpecial = TRUE;
							swprintf (pLetterData->wszString, sizeof(pLetterData->wszString), L"%lc%lc", LETTER_SMALLTSU, LETTER_NO);
							break;
						case ' ':
							pLetterData->bSpecial = TRUE;
							swprintf (pLetterData->wszString, sizeof(pLetterData->wszString), L"%lc%lc ", LETTER_SMALLTSU, LETTER_N);
							break;
						default:
							pLetterData->bSpecial = TRUE;
							swprintf (pLetterData->wszString, sizeof(pLetterData->wszString), L"%lc%lc", LETTER_SMALLTSU, LETTER_N);
							pLetterData->bException = TRUE;
							pLetterData->iExceptionDelete = 2;
							break;
						break;
					}
					break;
*/				case 'y':
					if (iLen == 2) pLetterData->bWait = TRUE;
					switch (chThirdChar) {
						case 'a':
							pLetterData->bSpecial = TRUE;
							swprintf (pLetterData->wszString, sizeof(pLetterData->wszString), L"%lc%lc", LETTER_NI, LETTER_SMALLYA);
							break;
						case 'u':
							pLetterData->bSpecial = TRUE;
							swprintf (pLetterData->wszString, sizeof(pLetterData->wszString), L"%lc%lc", LETTER_NI, LETTER_SMALLYU);
							break;
						case 'o':
							pLetterData->bSpecial = TRUE;
							swprintf (pLetterData->wszString, sizeof(pLetterData->wszString), L"%lc%lc", LETTER_NI, LETTER_SMALLYO);
							break;
						break;
					}
					break;
				default:
					pLetterData->bException = TRUE;
					pLetterData->iExceptionDelete = 1;
					pLetterData->wchLetter = LETTER_N;
				break;
			}
		break;

		// Ha family //
		case 'h':
			if (iLen == 1) pLetterData->bWait = TRUE;
			switch (chSecondChar) {
				case 'a':
					pLetterData->wchLetter = LETTER_HA;
					break;
				case 'i':
					pLetterData->wchLetter = LETTER_HI;
					break;
				case 'u':
					pLetterData->wchLetter = LETTER_HU;
					break;
				case 'e':
					pLetterData->wchLetter = LETTER_HE;
					break;
				case 'o':
					pLetterData->wchLetter = LETTER_HO;
					break;
				// Special strings //
				case 'h':
					if (iLen == 2) pLetterData->bWait = TRUE;
					switch (chThirdChar) {
						case 'a':
							pLetterData->bSpecial = TRUE;
							swprintf (pLetterData->wszString, sizeof(pLetterData->wszString), L"%lc%lc", LETTER_SMALLTSU, LETTER_HA);
							break;
						case 'i':
							pLetterData->bSpecial = TRUE;
							swprintf (pLetterData->wszString, sizeof(pLetterData->wszString), L"%lc%lc", LETTER_SMALLTSU, LETTER_HI);
							break;
						case 'u':
							pLetterData->bSpecial = TRUE;
							swprintf (pLetterData->wszString, sizeof(pLetterData->wszString), L"%lc%lc", LETTER_SMALLTSU, LETTER_HU);
							break;
						case 'e':
							pLetterData->bSpecial = TRUE;
							swprintf (pLetterData->wszString, sizeof(pLetterData->wszString), L"%lc%lc", LETTER_SMALLTSU, LETTER_HE);
							break;
						case 'o':
							pLetterData->bSpecial = TRUE;
							swprintf (pLetterData->wszString, sizeof(pLetterData->wszString), L"%lc%lc", LETTER_SMALLTSU, LETTER_HO);
							break;
					}
					break;
				case 'y':
					if (iLen == 2) pLetterData->bWait = TRUE;
					switch (chThirdChar) {
						case 'a':
							pLetterData->bSpecial = TRUE;
							swprintf (pLetterData->wszString, sizeof(pLetterData->wszString), L"%lc%lc", LETTER_HI, LETTER_SMALLYA);
							break;
						case 'u':
							pLetterData->bSpecial = TRUE;
							swprintf (pLetterData->wszString, sizeof(pLetterData->wszString), L"%lc%lc", LETTER_HI, LETTER_SMALLYU);
							break;
						case 'o':
							pLetterData->bSpecial = TRUE;
							swprintf (pLetterData->wszString, sizeof(pLetterData->wszString), L"%lc%lc", LETTER_HI, LETTER_SMALLYO);
							break;
						break;
					}
				break;
			}
		break;
		
		// Ba family //
		case 'b':
			if (iLen == 1) pLetterData->bWait = TRUE;
			switch (chSecondChar) {
				case 'a':
					pLetterData->wchLetter = LETTER_BA;
					break;
				case 'i':
					pLetterData->wchLetter = LETTER_BI;
					break;
				case 'u':
					pLetterData->wchLetter = LETTER_BU;
					break;
				case 'e':
					pLetterData->wchLetter = LETTER_BE;
					break;
				case 'o':
					pLetterData->wchLetter = LETTER_BO;
					break;
				// Special strings //
				case 'b':
					if (iLen == 2) pLetterData->bWait = TRUE;
					switch (chThirdChar) {
						case 'a':
							pLetterData->bSpecial = TRUE;
							swprintf (pLetterData->wszString, sizeof(pLetterData->wszString), L"%lc%lc", LETTER_SMALLTSU, LETTER_BA);
							break;
						case 'i':
							pLetterData->bSpecial = TRUE;
							swprintf (pLetterData->wszString, sizeof(pLetterData->wszString), L"%lc%lc", LETTER_SMALLTSU, LETTER_BI);
							break;
						case 'u':
							pLetterData->bSpecial = TRUE;
							swprintf (pLetterData->wszString, sizeof(pLetterData->wszString), L"%lc%lc", LETTER_SMALLTSU, LETTER_BU);
							break;
						case 'e':
							pLetterData->bSpecial = TRUE;
							swprintf (pLetterData->wszString, sizeof(pLetterData->wszString), L"%lc%lc", LETTER_SMALLTSU, LETTER_BE);
							break;
						case 'o':
							pLetterData->bSpecial = TRUE;
							swprintf (pLetterData->wszString, sizeof(pLetterData->wszString), L"%lc%lc", LETTER_SMALLTSU, LETTER_BO);
							break;
						case ' ': // Single BU //
							pLetterData->bSpecial = TRUE;
							swprintf (pLetterData->wszString, sizeof(pLetterData->wszString), L"%lc%lc ", LETTER_SMALLTSU, LETTER_BU);
							break;
					}
					break;
				case 'y':
					if (iLen == 2) pLetterData->bWait = TRUE;
					switch (chThirdChar) {
						case 'a':
							pLetterData->bSpecial = TRUE;
							swprintf (pLetterData->wszString, sizeof(pLetterData->wszString), L"%lc%lc", LETTER_BI, LETTER_SMALLYA);
							break;
						case 'u':
							pLetterData->bSpecial = TRUE;
							swprintf (pLetterData->wszString, sizeof(pLetterData->wszString), L"%lc%lc", LETTER_BI, LETTER_SMALLYU);
							break;
						case 'o':
							pLetterData->bSpecial = TRUE;
							swprintf (pLetterData->wszString, sizeof(pLetterData->wszString), L"%lc%lc", LETTER_BI, LETTER_SMALLYO);
							break;
						break;
					}
					break;
				case ' ': // Single BU //
					pLetterData->bSpecial = TRUE;
					swprintf (pLetterData->wszString, sizeof(pLetterData->wszString), L"%lc ", LETTER_BU);
					break;
				default:
					pLetterData->bException = TRUE;
					pLetterData->iExceptionDelete = 1;
					pLetterData->wchLetter = LETTER_BU;
				break;
			}
		break;

		// Pa family //
		case 'p':
			if (iLen == 1) pLetterData->bWait = TRUE;
			switch (chSecondChar) {
				case 'a':
					pLetterData->wchLetter = LETTER_PA;
					break;
				case 'i':
					pLetterData->wchLetter = LETTER_PI;
					break;
				case 'u':
					pLetterData->wchLetter = LETTER_PU;
					break;
				case 'e':
					pLetterData->wchLetter = LETTER_PE;
					break;
				case 'o':
					pLetterData->wchLetter = LETTER_PO;
					break;
				// Special strings //
				case 'p':
					if (iLen == 2) pLetterData->bWait = TRUE;
					switch (chThirdChar) {
						case 'a':
							pLetterData->bSpecial = TRUE;
							swprintf (pLetterData->wszString, sizeof(pLetterData->wszString), L"%lc%lc", LETTER_SMALLTSU, LETTER_PA);
							break;
						case 'i':
							pLetterData->bSpecial = TRUE;
							swprintf (pLetterData->wszString, sizeof(pLetterData->wszString), L"%lc%lc", LETTER_SMALLTSU, LETTER_PI);
							break;
						case 'u':
							pLetterData->bSpecial = TRUE;
							swprintf (pLetterData->wszString, sizeof(pLetterData->wszString), L"%lc%lc", LETTER_SMALLTSU, LETTER_PU);
							break;
						case 'e':
							pLetterData->bSpecial = TRUE;
							swprintf (pLetterData->wszString, sizeof(pLetterData->wszString), L"%lc%lc", LETTER_SMALLTSU, LETTER_PE);
							break;
						case 'o':
							pLetterData->bSpecial = TRUE;
							swprintf (pLetterData->wszString, sizeof(pLetterData->wszString), L"%lc%lc", LETTER_SMALLTSU, LETTER_PO);
							break;
						case ' ': // Single PU //
							pLetterData->bSpecial = TRUE;
							swprintf (pLetterData->wszString, sizeof(pLetterData->wszString), L"%lc%lc ", LETTER_SMALLTSU, LETTER_PU);
							break;
					}
					break;
				case 'y':
					if (iLen == 2) pLetterData->bWait = TRUE;
					switch (chThirdChar) {
						case 'a':
							pLetterData->bSpecial = TRUE;
							swprintf (pLetterData->wszString, sizeof(pLetterData->wszString), L"%lc%lc", LETTER_PI, LETTER_SMALLYA);
							break;
						case 'u':
							pLetterData->bSpecial = TRUE;
							swprintf (pLetterData->wszString, sizeof(pLetterData->wszString), L"%lc%lc", LETTER_PI, LETTER_SMALLYU);
							break;
						case 'o':
							pLetterData->bSpecial = TRUE;
							swprintf (pLetterData->wszString, sizeof(pLetterData->wszString), L"%lc%lc", LETTER_PI, LETTER_SMALLYO);
							break;
						break;
					}
					break;
				case ' ': // Single PU //
					pLetterData->bSpecial = TRUE;
					swprintf (pLetterData->wszString, sizeof(pLetterData->wszString), L"%lc ", LETTER_PU);
					break;
				default:
					pLetterData->bException = TRUE;
					pLetterData->iExceptionDelete = 1;
					pLetterData->wchLetter = LETTER_PU;
				break;
			}
		break;
		
		// Ma family //
		case 'm':
			if (iLen == 1) pLetterData->bWait = TRUE;
			switch (chSecondChar) {
				case 'a':
					pLetterData->wchLetter = LETTER_MA;
					break;
				case 'i':
					pLetterData->wchLetter = LETTER_MI;
					break;
				case 'u':
					pLetterData->wchLetter = LETTER_MU;
					break;
				case 'e':
					pLetterData->wchLetter = LETTER_ME;
					break;
				case 'o':
					pLetterData->wchLetter = LETTER_MO;
					break;
				// Special strings //
				case 'm':
					if (iLen == 2) pLetterData->bWait = TRUE;
					switch (chThirdChar) {
						case 'a':
							pLetterData->bSpecial = TRUE;
							swprintf (pLetterData->wszString, sizeof(pLetterData->wszString), L"%lc%lc", LETTER_SMALLTSU, LETTER_MA);
							break;
						case 'i':
							pLetterData->bSpecial = TRUE;
							swprintf (pLetterData->wszString, sizeof(pLetterData->wszString), L"%lc%lc", LETTER_SMALLTSU, LETTER_MI);
							break;
						case 'u':
							pLetterData->bSpecial = TRUE;
							swprintf (pLetterData->wszString, sizeof(pLetterData->wszString), L"%lc%lc", LETTER_SMALLTSU, LETTER_MU);
							break;
						case 'e':
							pLetterData->bSpecial = TRUE;
							swprintf (pLetterData->wszString, sizeof(pLetterData->wszString), L"%lc%lc", LETTER_SMALLTSU, LETTER_ME);
							break;
						case 'o':
							pLetterData->bSpecial = TRUE;
							swprintf (pLetterData->wszString, sizeof(pLetterData->wszString), L"%lc%lc", LETTER_SMALLTSU, LETTER_MO);
							break;
						case ' ': // Single MU //
							pLetterData->bSpecial = TRUE;
							swprintf (pLetterData->wszString, sizeof(pLetterData->wszString), L"%lc%lc ", LETTER_SMALLTSU, LETTER_MU);
							break;
					}
					break;
				case 'y':
					if (iLen == 2) pLetterData->bWait = TRUE;
					switch (chThirdChar) {
						case 'a':
							pLetterData->bSpecial = TRUE;
							swprintf (pLetterData->wszString, sizeof(pLetterData->wszString), L"%lc%lc", LETTER_MI, LETTER_SMALLYA);
							break;
						case 'u':
							pLetterData->bSpecial = TRUE;
							swprintf (pLetterData->wszString, sizeof(pLetterData->wszString), L"%lc%lc", LETTER_MI, LETTER_SMALLYU);
							break;
						case 'o':
							pLetterData->bSpecial = TRUE;
							swprintf (pLetterData->wszString, sizeof(pLetterData->wszString), L"%lc%lc", LETTER_MI, LETTER_SMALLYO);
							break;
						break;
					}
					break;
				case ' ': // Single MU //
					pLetterData->bSpecial = TRUE;
					swprintf (pLetterData->wszString, sizeof(pLetterData->wszString), L"%lc ", LETTER_MU);
					break;
				default:
					pLetterData->bException = TRUE;
					pLetterData->iExceptionDelete = 1;
					pLetterData->wchLetter = LETTER_MU;
				break;
			}
		break;

		// Ya family //
		case 'y':
			if (iLen == 1) pLetterData->bWait = TRUE;
			switch (chSecondChar) {
				case 'a':
					pLetterData->wchLetter = LETTER_YA;
					break;
				case 'u':
					pLetterData->wchLetter = LETTER_YU;
					break;
				case 'o':
					pLetterData->wchLetter = LETTER_YO;
					break;
				// Special strings //
				case 'y':
					if (iLen == 2) pLetterData->bWait = TRUE;
					switch (chThirdChar) {
						case 'a':
							pLetterData->bSpecial = TRUE;
							swprintf (pLetterData->wszString, sizeof(pLetterData->wszString), L"%lc%lc", LETTER_SMALLTSU, LETTER_YA);
							break;
						case 'u':
							pLetterData->bSpecial = TRUE;
							swprintf (pLetterData->wszString, sizeof(pLetterData->wszString), L"%lc%lc", LETTER_SMALLTSU, LETTER_YU);
							break;
						case 'o':
							pLetterData->bSpecial = TRUE;
							swprintf (pLetterData->wszString, sizeof(pLetterData->wszString), L"%lc%lc", LETTER_SMALLTSU, LETTER_YO);
							break;
					}
				break;
			}
		break;

		// Ra family //
		case 'l':
		case 'r':
			if (iLen == 1) pLetterData->bWait = TRUE;
			switch (chSecondChar) {
				case 'a':
					pLetterData->wchLetter = LETTER_RA;
					break;
				case 'i':
					pLetterData->wchLetter = LETTER_RI;
					break;
				case 'u':
					pLetterData->wchLetter = LETTER_RU;
					break;
				case 'e':
					pLetterData->wchLetter = LETTER_RE;
					break;
				case 'o':
					pLetterData->wchLetter = LETTER_RO;
					break;
				// Special strings //
				case 'l':
				case 'r':
					if (iLen == 2) pLetterData->bWait = TRUE;
					switch (chThirdChar) {
						case 'a':
							pLetterData->bSpecial = TRUE;
							swprintf (pLetterData->wszString, sizeof(pLetterData->wszString), L"%lc%lc", LETTER_SMALLTSU, LETTER_RA);
							break;
						case 'i':
							pLetterData->bSpecial = TRUE;
							swprintf (pLetterData->wszString, sizeof(pLetterData->wszString), L"%lc%lc", LETTER_SMALLTSU, LETTER_RI);
							break;
						case 'u':
							pLetterData->bSpecial = TRUE;
							swprintf (pLetterData->wszString, sizeof(pLetterData->wszString), L"%lc%lc", LETTER_SMALLTSU, LETTER_RU);
							break;
						case 'e':
							pLetterData->bSpecial = TRUE;
							swprintf (pLetterData->wszString, sizeof(pLetterData->wszString), L"%lc%lc", LETTER_SMALLTSU, LETTER_RE);
							break;
						case 'o':
							pLetterData->bSpecial = TRUE;
							swprintf (pLetterData->wszString, sizeof(pLetterData->wszString), L"%lc%lc", LETTER_SMALLTSU, LETTER_RO);
							break;
						case ' ': // Single RU //
							pLetterData->bSpecial = TRUE;
							swprintf (pLetterData->wszString, sizeof(pLetterData->wszString), L"%lc%lc ", LETTER_SMALLTSU, LETTER_RU);
							break;
					}
					break;
				case 'y':
					if (iLen == 2) pLetterData->bWait = TRUE;
					switch (chThirdChar) {
						case 'a':
							pLetterData->bSpecial = TRUE;
							swprintf (pLetterData->wszString, sizeof(pLetterData->wszString), L"%lc%lc", LETTER_RI, LETTER_SMALLYA);
							break;
						case 'u':
							pLetterData->bSpecial = TRUE;
							swprintf (pLetterData->wszString, sizeof(pLetterData->wszString), L"%lc%lc", LETTER_RI, LETTER_SMALLYU);
							break;
						case 'o':
							pLetterData->bSpecial = TRUE;
							swprintf (pLetterData->wszString, sizeof(pLetterData->wszString), L"%lc%lc", LETTER_RI, LETTER_SMALLYO);
							break;
						break;
					}
					break;
				case ' ': // Single RU //
					pLetterData->bSpecial = TRUE;
					swprintf (pLetterData->wszString, sizeof(pLetterData->wszString), L"%lc ", LETTER_RU);
					break;
				default:
					pLetterData->bException = TRUE;
					pLetterData->iExceptionDelete = 1;
					pLetterData->wchLetter = LETTER_RU;
				break;
			}
		break;

		// Wa family //
		case 'w':
			if (iLen == 1) pLetterData->bWait = TRUE;
			switch (chSecondChar) {
				case 'a':
					pLetterData->wchLetter = LETTER_WA;
					break;
				case 'i':
					pLetterData->wchLetter = LETTER_WI;
					break;
				case 'e':
					pLetterData->wchLetter = LETTER_WE;
					break;
				case 'o':
					pLetterData->wchLetter = LETTER_WO;
					break;
				// Special strings //
				case 'w':
					if (iLen == 2) pLetterData->bWait = TRUE;
					switch (chThirdChar) {
						case 'a':
							pLetterData->bSpecial = TRUE;
							swprintf (pLetterData->wszString, sizeof(pLetterData->wszString), L"%lc%lc", LETTER_SMALLTSU, LETTER_WA);
							break;
						case 'i':
							pLetterData->bSpecial = TRUE;
							swprintf (pLetterData->wszString, sizeof(pLetterData->wszString), L"%lc%lc", LETTER_SMALLTSU, LETTER_WI);
							break;
						case 'e':
							pLetterData->bSpecial = TRUE;
							swprintf (pLetterData->wszString, sizeof(pLetterData->wszString), L"%lc%lc", LETTER_SMALLTSU, LETTER_WE);
							break;
						case 'o':
							pLetterData->bSpecial = TRUE;
							swprintf (pLetterData->wszString, sizeof(pLetterData->wszString), L"%lc%lc", LETTER_SMALLTSU, LETTER_WO);
							break;
					}
					break;
				case 'y':
					if (iLen == 2) pLetterData->bWait = TRUE;
					switch (chThirdChar) {
						case 'a':
							pLetterData->bSpecial = TRUE;
							swprintf (pLetterData->wszString, sizeof(pLetterData->wszString), L"%lc%lc", LETTER_WI, LETTER_SMALLYA);
							break;
						case 'u':
							pLetterData->bSpecial = TRUE;
							swprintf (pLetterData->wszString, sizeof(pLetterData->wszString), L"%lc%lc", LETTER_WI, LETTER_SMALLYU);
							break;
						case 'o':
							pLetterData->bSpecial = TRUE;
							swprintf (pLetterData->wszString, sizeof(pLetterData->wszString), L"%lc%lc", LETTER_WI, LETTER_SMALLYO);
							break;
						break;
					}
				break;
			}
		break;

		// Some other letters //
		case 'c':
			if (iLen == 1) pLetterData->bWait = TRUE;
			switch (chSecondChar) {
				case 'c':
					if (iLen == 2) pLetterData->bWait = TRUE;
					switch (chThirdChar) {
						case 'h':
							if (iLen == 3) pLetterData->bWait = TRUE;
							switch (chFourthChar) {
								case 'a':
									pLetterData->bSpecial = TRUE;
									swprintf (pLetterData->wszString, sizeof(pLetterData->wszString), L"%lc%lc%lc", LETTER_SMALLTSU, LETTER_CHI, LETTER_SMALLYA);
									break;
								case 'i':
									pLetterData->bSpecial = TRUE;
									swprintf (pLetterData->wszString, sizeof(pLetterData->wszString), L"%lc%lc", LETTER_SMALLTSU, LETTER_CHI);
									break;
								case 'u':
									pLetterData->bSpecial = TRUE;
									swprintf (pLetterData->wszString, sizeof(pLetterData->wszString), L"%lc%lc%lc", LETTER_SMALLTSU, LETTER_CHI, LETTER_SMALLYU);
									break;
								case 'e':
									pLetterData->bSpecial = TRUE;
									swprintf (pLetterData->wszString, sizeof(pLetterData->wszString), L"%lc%lc%lc", LETTER_SMALLTSU, LETTER_CHI, LETTER_SMALLE);
									break;
								case 'o':
									pLetterData->bSpecial = TRUE;
									swprintf (pLetterData->wszString, sizeof(pLetterData->wszString), L"%lc%lc%lc", LETTER_SMALLTSU, LETTER_CHI, LETTER_SMALLYO);
									break;
								case 'y':
									if (iLen == 4) pLetterData->bWait = TRUE;
									switch (chFifthChar) {
										case 'a':
											pLetterData->bSpecial = TRUE;
											swprintf (pLetterData->wszString, sizeof(pLetterData->wszString), L"%lc%lc%lc", LETTER_SMALLTSU, LETTER_CHI, LETTER_SMALLYA);
											break;
										case 'i':
											pLetterData->bSpecial = TRUE;
											swprintf (pLetterData->wszString, sizeof(pLetterData->wszString), L"%lc%lc", LETTER_SMALLTSU, LETTER_CHI);
											break;
										case 'u':
											pLetterData->bSpecial = TRUE;
											swprintf (pLetterData->wszString, sizeof(pLetterData->wszString), L"%lc%lc%lc", LETTER_SMALLTSU, LETTER_CHI, LETTER_SMALLYU);
											break;
										case 'e':
											pLetterData->bSpecial = TRUE;
											swprintf (pLetterData->wszString, sizeof(pLetterData->wszString), L"%lc%lc%lc", LETTER_SMALLTSU, LETTER_CHI, LETTER_SMALLE);
											break;
										case 'o':
											pLetterData->bSpecial = TRUE;
											swprintf (pLetterData->wszString, sizeof(pLetterData->wszString), L"%lc%lc%lc", LETTER_SMALLTSU, LETTER_CHI, LETTER_SMALLYO);
										break;
									}
								break;
							}
							break;
						case 'a':
							pLetterData->bSpecial = TRUE;
							swprintf (pLetterData->wszString, sizeof(pLetterData->wszString), L"%lc%lc", LETTER_SMALLTSU, LETTER_WA);
							break;
						case 'i':
							pLetterData->bSpecial = TRUE;
							swprintf (pLetterData->wszString, sizeof(pLetterData->wszString), L"%lc%lc", LETTER_SMALLTSU, LETTER_WI);
							break;
						case 'e':
							pLetterData->bSpecial = TRUE;
							swprintf (pLetterData->wszString, sizeof(pLetterData->wszString), L"%lc%lc", LETTER_SMALLTSU, LETTER_WE);
							break;
						case 'o':
							pLetterData->bSpecial = TRUE;
							swprintf (pLetterData->wszString, sizeof(pLetterData->wszString), L"%lc%lc", LETTER_SMALLTSU, LETTER_WO);
							break;
					}
					break;
				case 'h':
					if (iLen == 2) pLetterData->bWait = TRUE;
					switch (chThirdChar) {
						case 'a':
							pLetterData->bSpecial = TRUE;
							swprintf (pLetterData->wszString, sizeof(pLetterData->wszString), L"%lc%lc", LETTER_CHI, LETTER_SMALLYA);
							break;
						case 'i':
							pLetterData->wchLetter = LETTER_CHI;
							break;
						case 'u':
							pLetterData->bSpecial = TRUE;
							swprintf (pLetterData->wszString, sizeof(pLetterData->wszString), L"%lc%lc", LETTER_CHI, LETTER_SMALLYU);
							break;
						case 'e':
							pLetterData->bSpecial = TRUE;
							swprintf (pLetterData->wszString, sizeof(pLetterData->wszString), L"%lc%lc", LETTER_CHI, LETTER_SMALLE);
							break;
						case 'o':
							pLetterData->bSpecial = TRUE;
							swprintf (pLetterData->wszString, sizeof(pLetterData->wszString), L"%lc%lc", LETTER_CHI, LETTER_SMALLYO);
							break;
						break;
					}
					break;
				default:
					chFirstChar = 'k';
					goto LabelLogicStart;
			}
			break;
		case 'f':
			if (iLen == 1) pLetterData->bWait = TRUE;
			if (chSecondChar == 'u')
				pLetterData->wchLetter = LETTER_FU;
			pLetterData->wchLetter = FALSE;
			break;
		case 'j':
			if (iLen == 1) pLetterData->bWait = TRUE;
			switch (chSecondChar) {
				case 'a':
					pLetterData->bSpecial = TRUE;
					swprintf (pLetterData->wszString, sizeof(pLetterData->wszString), L"%lc%lc", LETTER_JI, LETTER_SMALLYA);
					break;
				case 'i':
					pLetterData->wchLetter = LETTER_JI;
					break;
				case 'u':
					pLetterData->bSpecial = TRUE;
					swprintf (pLetterData->wszString, sizeof(pLetterData->wszString), L"%lc%lc", LETTER_JI, LETTER_SMALLYU);
					break;
				case 'e':
					pLetterData->bSpecial = TRUE;
					swprintf (pLetterData->wszString, sizeof(pLetterData->wszString), L"%lc%lc", LETTER_JI, LETTER_SMALLE);
					break;
				case 'o':
					pLetterData->bSpecial = TRUE;
					swprintf (pLetterData->wszString, sizeof(pLetterData->wszString), L"%lc%lc", LETTER_JI, LETTER_SMALLYO);
					break;
				// Special strings //
				case 'j':
					if (iLen == 2) pLetterData->bWait = TRUE;
					switch (chThirdChar) {
						case 'a':
							pLetterData->bSpecial = TRUE;
							swprintf (pLetterData->wszString, sizeof(pLetterData->wszString), L"%lc%lc%lc", LETTER_SMALLTSU, LETTER_JI, LETTER_SMALLYA);
							break;
						case 'i':
							pLetterData->bSpecial = TRUE;
							swprintf (pLetterData->wszString, sizeof(pLetterData->wszString), L"%lc%lc", LETTER_SMALLTSU, LETTER_JI);
							break;
						case 'e':
							pLetterData->bSpecial = TRUE;
							swprintf (pLetterData->wszString, sizeof(pLetterData->wszString), L"%lc%lc%lc", LETTER_SMALLTSU, LETTER_JI, LETTER_SMALLE);
							break;
						case 'o':
							pLetterData->bSpecial = TRUE;
							swprintf (pLetterData->wszString, sizeof(pLetterData->wszString), L"%lc%lc%lc", LETTER_SMALLTSU, LETTER_JI, LETTER_SMALLYO);
							break;
						case 'y':
							if (iLen == 3) pLetterData->bWait = TRUE;
							switch (chFourthChar) {
								case 'a':
									pLetterData->bSpecial = TRUE;
									swprintf (pLetterData->wszString, sizeof(pLetterData->wszString), L"%lc%lc%lc", LETTER_SMALLTSU, LETTER_JI, LETTER_SMALLYA);
									break;
								case 'i':
									pLetterData->bSpecial = TRUE;
									swprintf (pLetterData->wszString, sizeof(pLetterData->wszString), L"%lc%lc", LETTER_SMALLTSU, LETTER_JI);
									break;
								case 'e':
									pLetterData->bSpecial = TRUE;
									swprintf (pLetterData->wszString, sizeof(pLetterData->wszString), L"%lc%lc%lc", LETTER_SMALLTSU, LETTER_JI, LETTER_SMALLE);
									break;
								case 'o':
									pLetterData->bSpecial = TRUE;
									swprintf (pLetterData->wszString, sizeof(pLetterData->wszString), L"%lc%lc%lc", LETTER_SMALLTSU, LETTER_JI, LETTER_SMALLYO);
									break;
							}
					}
					break;
				case 'y':
					if (iLen == 2) pLetterData->bWait = TRUE;
					switch (chThirdChar) {
						case 'a':
							pLetterData->bSpecial = TRUE;
							swprintf (pLetterData->wszString, sizeof(pLetterData->wszString), L"%lc%lc", LETTER_JI, LETTER_SMALLYA);
							break;
						case 'i':
							pLetterData->wchLetter = LETTER_JI;
							break;
						case 'u':
							pLetterData->bSpecial = TRUE;
							swprintf (pLetterData->wszString, sizeof(pLetterData->wszString), L"%lc%lc", LETTER_JI, LETTER_SMALLYU);
							break;
						case 'e':
							pLetterData->bSpecial = TRUE;
							swprintf (pLetterData->wszString, sizeof(pLetterData->wszString), L"%lc%lc", LETTER_JI, LETTER_SMALLE);
							break;
						case 'o':
							pLetterData->bSpecial = TRUE;
							swprintf (pLetterData->wszString, sizeof(pLetterData->wszString), L"%lc%lc", LETTER_JI, LETTER_SMALLYO);
							break;
					}
				break;
			}
			break;
		case '.':
			if (iMode == MODE_KATAKANA)
				pLetterData->wchLetter = LETTER_DOT;
			else
				pLetterData->wchLetter = LETTER_MARU;
			break;
		case ',':
			pLetterData->wchLetter = LETTER_COMMA;
			break;
		case '-':
			pLetterData->wchLetter = LETTER_LINE;
			break;
		case '\'':
			pLetterData->wchLetter = (bNowQuote) ? LETTER_RIGHTQUOTE : LETTER_LEFTQUOTE;
			bNowQuote = !bNowQuote;
			break;
		break;
	}
	
	if ((pLetterData->wchLetter) || (pLetterData->bSpecial) ||
		(pLetterData->bWait) || (pLetterData->bException))
		return TRUE;
	return FALSE;
}

void SetHotkeys (HWND hWin, BOOL bEnabled) {
	const unsigned char iVkSpecialKeys[] = {
		VK_SPACE,
		VK_DOT,
		//VK_COMMA, Comma us bugged on MSN
		VK_HIFEN,
		VK_APOSTROPHE,
		VK_BACK,
		VK_DELETE
	};
	unsigned char i;

	// Togle hotkeys //
	RegisterHotKey (hWin, VK_ROMAJI, 0, VK_ROMAJI);
	RegisterHotKey (hWin, VK_HIRAGANA, 0, VK_HIRAGANA);
	RegisterHotKey (hWin, VK_KATAKANA, 0, VK_KATAKANA);

	// Special hotkeys //
	for (i=0; i<=sizeof(iVkSpecialKeys); i++) {
		if (bEnabled)
			RegisterHotKey (hWin, iVkSpecialKeys[i], 0, iVkSpecialKeys[i]);
		else
			UnregisterHotKey (hWin, iVkSpecialKeys[i]);
	}

	// Regular hotkeys //
	for (i=0x41; i<=0x5A; i++) {
		if (bEnabled)
			RegisterHotKey (hWin, i, 0, i);
		else
			UnregisterHotKey (hWin, i);
	}

	return;
}

void SendKey (int iVkKey) {
	keybd_event (iVkKey, MapVirtualKey(iVkKey, 0), 0, 0);
	keybd_event (iVkKey, MapVirtualKey(iVkKey, 0), KEYEVENTF_KEYUP, 0);

	return;
}
void SendUnicode (wchar_t iUnicode) {
	// Add 60h to the unicode if it's in katakana mode //
	if (iMode == MODE_KATAKANA)
		if ((iUnicode <= LETTER_N) && (iUnicode >= LETTER_SMALLA))
			iUnicode += 0x60;

	// Send the character //
	if (bNT)
		_SendUnicodeNT (iUnicode);
	else
		_SendUnicode95 (iUnicode);

	return;
}
void _SendUnicode95 (wchar_t iUnicode) {
	char szUnicode[8];
	int i;
	int iLen;
	
	// Make a 0XXXX string //
	sprintf (szUnicode, "0%d", iUnicode);
	iLen = strlen (szUnicode);

	// Send the ALT+0XXX combination //
	keybd_event (VK_MENU, 0, 0, 0);
	for (i=0; i<iLen; i++)
		SendKey (VkKeyScan (szUnicode[i]) + 0x30);
	keybd_event (VK_MENU, 0, KEYEVENTF_KEYUP, 0);
	
	return;
}
void _SendUnicodeNT (wchar_t iUnicode) {
	INPUT stInput = {0};
	stInput.type = INPUT_KEYBOARD;
	stInput.ki.wScan = iUnicode;
	stInput.ki.dwFlags = KEYEVENTF_UNICODE;

	// Here we use SendInput to send the character //
	SendInput (1, &stInput, sizeof(INPUT));

	return;
}

void SendString (char * szString) {
	int iLen;
	int i;

	iLen = strlen (szString);
	if (! iLen) return;

	for (i=0; i<iLen; i++)
		SendKey (VkKeyScan (szString[i]));

	return;
}
void SendUnicodeString (wchar_t * wszString) {
	int iLen;
	int i;

	iLen = wcslen (wszString);
	if (! iLen) return;

	for (i=0; i<iLen; i++)
		SendUnicode (wszString[i]);

	return;
}
