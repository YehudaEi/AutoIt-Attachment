// MJK main header

#define _WIN32_WINNT 0x0500
#include <stdio.h>
#include <windows.h>
#include <shellapi.h>
#include "resource.h"

#define PROGRAM_VERSION 		"Vers�o 0.4"
#define PROGRAM_VERSION_RESSZ	"0.4.0.0"
#define PROGRAM_VERSION_RESINT 	 0,4,0,0
