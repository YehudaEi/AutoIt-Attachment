# MySQL-Front 3.2  (Build 6.11)

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES 'latin1' */;

# Host: 69.51.102.12    Database: Copy_of_timesheet
# ------------------------------------------------------
# Server version 4.1.21-standard

#
# Table structure for table Employees
#

DROP TABLE IF EXISTS `Employees`;
CREATE TABLE `Employees` (
  `Id` int(11) NOT NULL auto_increment,
  `Employee` varchar(20) default NULL COMMENT 'Employee Names',
  `Default Site` decimal(4,0) default '0000' COMMENT 'Default Site Code for Employee',
  `Username` varchar(15) default NULL,
  `Password` varchar(15) default NULL,
  `Email` varchar(20) default NULL,
  PRIMARY KEY  (`Id`)
) ENGINE=MyISAM AUTO_INCREMENT=10 DEFAULT CHARSET=latin1;

#
# Dumping data for table Employees
#

INSERT INTO `Employees` (`Id`,`Employee`,`Default Site`,`Username`,`Password`,`Email`) VALUES (1,'Employee 1',0,'e1','12345',NULL);
INSERT INTO `Employees` (`Id`,`Employee`,`Default Site`,`Username`,`Password`,`Email`) VALUES (2,'Employee 2',2090,'e2','12345',NULL);
INSERT INTO `Employees` (`Id`,`Employee`,`Default Site`,`Username`,`Password`,`Email`) VALUES (3,'Employee 3',0,'e3','12345',NULL);
INSERT INTO `Employees` (`Id`,`Employee`,`Default Site`,`Username`,`Password`,`Email`) VALUES (4,'Employee 4',1020,'e4','12345',NULL);
INSERT INTO `Employees` (`Id`,`Employee`,`Default Site`,`Username`,`Password`,`Email`) VALUES (5,'Employee 5',0,'e5','12345',NULL);
INSERT INTO `Employees` (`Id`,`Employee`,`Default Site`,`Username`,`Password`,`Email`) VALUES (6,'Employee 6',1030,'e6','12345',NULL);
INSERT INTO `Employees` (`Id`,`Employee`,`Default Site`,`Username`,`Password`,`Email`) VALUES (7,'Employee 7',0,'e7','12345',NULL);
INSERT INTO `Employees` (`Id`,`Employee`,`Default Site`,`Username`,`Password`,`Email`) VALUES (8,'Employee 8',0,'e8','12345',NULL);
INSERT INTO `Employees` (`Id`,`Employee`,`Default Site`,`Username`,`Password`,`Email`) VALUES (9,'Employee 9',1020,'e9','12345',NULL);

#
# Table structure for table Jobs
#

DROP TABLE IF EXISTS `Jobs`;
CREATE TABLE `Jobs` (
  `Id` int(11) NOT NULL auto_increment,
  `Name` varchar(20) default NULL,
  `Date` varchar(10) default '11/27/06',
  `Site` varchar(30) default NULL,
  `Hours` decimal(10,2) default '0.00',
  `Comment` varchar(100) default NULL,
  PRIMARY KEY  (`Id`)
) ENGINE=MyISAM AUTO_INCREMENT=72 DEFAULT CHARSET=latin1 COMMENT='Date | SiteCode | HoursWorked | Description';

#
# Dumping data for table Jobs
#


#
# Table structure for table Sites
#

DROP TABLE IF EXISTS `Sites`;
CREATE TABLE `Sites` (
  `Id` int(11) NOT NULL auto_increment,
  `Name` varchar(30) default NULL COMMENT 'Site Names',
  `Code` decimal(4,0) default '0000' COMMENT 'Site Codes/ 0 = "0000"',
  PRIMARY KEY  (`Id`)
) ENGINE=MyISAM AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;

#
# Dumping data for table Sites
#

INSERT INTO `Sites` (`Id`,`Name`,`Code`) VALUES (1,'Jobsite 1',1000);
INSERT INTO `Sites` (`Id`,`Name`,`Code`) VALUES (2,'Jobsite 2',2000);
INSERT INTO `Sites` (`Id`,`Name`,`Code`) VALUES (3,'Jobsite 3',3000);
INSERT INTO `Sites` (`Id`,`Name`,`Code`) VALUES (4,'Jobsite 4',4000);
INSERT INTO `Sites` (`Id`,`Name`,`Code`) VALUES (5,'Jobsite 5',5000);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
