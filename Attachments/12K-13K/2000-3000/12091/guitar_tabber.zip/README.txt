This is not done.

the guitar sounds were recorded from: http://www.chordbook.com/guitarchords.php

please let me know what you think, Comments and questions are welcome

jsammarco@gmail.com