// MJK main module header

#include "mainheader.h"

#define VK_ROMAJI VK_F9
#define VK_HIRAGANA VK_F10
#define VK_KATAKANA VK_F11

#define VK_DOT VkKeyScan('.')
#define VK_COMMA VkKeyScan(',')
#define VK_HIFEN VkKeyScan('-')
#define VK_APOSTROPHE VkKeyScan('\'')
#define MODE_ROMAJI 0
#define MODE_HIRAGANA 1
#define MODE_KATAKANA 2

// Transform data structure //
typedef struct _LETTER_DATA {
	BOOL bWait;
	BOOL bSpecial;
	BOOL bException;
	char iExceptionDelete;
	wchar_t wchLetter;
	wchar_t wszString[10];
} LETTER_DATA, * PLETTER_DATA;

void Activate (HWND hWin);
void Deactivate (HWND hWin);

BOOL HandleHotkey (HWND hDialog, WPARAM wParam);
BOOL StringToLetterData (PLETTER_DATA pLetterData, char * szString);

void SetHotkeys (HWND hWin, BOOL bEnabled);
void SendKey (int iVkKey);
void SendUnicode (wchar_t iUnicode);
void SendString (char * szString);
void SendUnicodeString (wchar_t * wszString);


///////////////////
// Letters table //
///////////////////

// Vows //
#define LETTER_SMALLA 0x3041
#define LETTER_A 0x3042
#define LETTER_SMALLI 0x3043
#define LETTER_I 0x3044
#define LETTER_SMALLU 0x3045
#define LETTER_U 0x3046
#define LETTER_SMALLE 0x3047
#define LETTER_E 0x3048
#define LETTER_SMALLO 0x3049
#define LETTER_O 0x304A

// Ka family //
#define LETTER_KA 0x304B
#define LETTER_KI 0x304D
#define LETTER_KU 0x304F
#define LETTER_KE 0x3051
#define LETTER_KO 0x3053

// Ga family //
#define LETTER_GA 0x304C
#define LETTER_GI 0x304E
#define LETTER_GU 0x3050
#define LETTER_GE 0x3052
#define LETTER_GO 0x3054

// Sa family //
#define LETTER_SA 0x3055
#define LETTER_SHI 0x3057
#define LETTER_SI LETTER_SHI
#define LETTER_SU 0x3059
#define LETTER_SE 0x305B
#define LETTER_SO 0x305D

// Za family //
#define LETTER_ZA 0x3056
#define LETTER_ZI 0x3058
#define LETTER_ZU 0x305A
#define LETTER_ZE 0x305C
#define LETTER_ZO 0x305E

// Ta family //
#define LETTER_TA 0x305F
#define LETTER_CHI 0x3061
#define LETTER_TI LETTER_CHI
#define LETTER_SMALLTSU 0x3063
#define LETTER_TSU 0x3064
#define LETTER_TU LETTER_TSU
#define LETTER_TE 0x3066
#define LETTER_TO 0x3068

// Da family //
#define LETTER_DA 0x3060
#define LETTER_JI 0x3062
#define LETTER_DI LETTER_JI
#define LETTER_DZU 0x3065
#define LETTER_DU LETTER_DZU
#define LETTER_DE 0x3067
#define LETTER_DO 0x3069

// Na family //
#define LETTER_NA 0x306A
#define LETTER_NI 0x306B
#define LETTER_NU 0x306C
#define LETTER_NE 0x306D
#define LETTER_NO 0x306E

// Ha family //
#define LETTER_HA 0x306F
#define LETTER_HI 0x3072
#define LETTER_FU 0x3075
#define LETTER_HU LETTER_FU
#define LETTER_HE 0x3078
#define LETTER_HO 0x307B

// Ba family //
#define LETTER_BA 0x3070
#define LETTER_BI 0x3073
#define LETTER_BU 0x3076
#define LETTER_BE 0x3079
#define LETTER_BO 0x307C

// Pa family //
#define LETTER_PA 0x3071
#define LETTER_PI 0x3074
#define LETTER_PU 0x3077
#define LETTER_PE 0x307A
#define LETTER_PO 0x307D

// Ma family //
#define LETTER_MA 0x307E
#define LETTER_MI 0x307F
#define LETTER_MU 0x3080
#define LETTER_ME 0x3081
#define LETTER_MO 0x3082

// Ya family //
#define LETTER_SMALLYA 0x3083
#define LETTER_YA 0x3084
#define LETTER_SMALLYU 0x3085
#define LETTER_YU 0x3086
#define LETTER_SMALLYO 0x3087
#define LETTER_YO 0x3088

// Ra family //
#define LETTER_RA 0x3089
#define LETTER_RI 0x308A
#define LETTER_RU 0x308B
#define LETTER_RE 0x308C
#define LETTER_RO 0x308D

// Wa family //
#define LETTER_SMALLWA 0x308E
#define LETTER_WA 0x308F
#define LETTER_WI 0x3090
#define LETTER_WE 0x3091
#define LETTER_WO 0x3092

// Others //
#define LETTER_N 0x3093
#define LETTER_COMMA 0x3001
#define LETTER_MARU 0x3002
#define LETTER_LEFTQUOTE 0x300C
#define LETTER_RIGHTQUOTE 0x300D
#define LETTER_DOT 0x30FB
#define LETTER_LINE 0x30FC
