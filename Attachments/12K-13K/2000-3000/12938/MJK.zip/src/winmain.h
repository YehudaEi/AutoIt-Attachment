// MJK interface header

#include "mainheader.h"

#define WM_TRAYICON WM_USER+1

BOOL APIENTRY WinMain (HINSTANCE hInstance, HINSTANCE hPrevInst, char * szCmdLine, int iShow);
BOOL CALLBACK Main_DlgProc (HWND hDialog, UINT iMessage, WPARAM wParam, LPARAM lParam);
BOOL CALLBACK Generic_DlgProc (HWND hDialog, UINT iMessage, WPARAM wParam, LPARAM lParam);
BOOL OnTrayIconClick (HWND hWin, LPARAM lParam);

void CreateTrayIcon (HWND hParent);
void DeleteTrayIcon (HWND hParent);
void SetTrayIcon (HWND hParent, int iMode);
