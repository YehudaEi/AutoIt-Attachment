// MJK main header

#include <stdio.h>
#include <windows.h>
#include <shellapi.h>
#include "resource.h"

#define PROGRAM_VERSION 		"Vers�o 0.3"
#define PROGRAM_VERSION_RESSZ	"0.3.0.0"
#define PROGRAM_VERSION_RESINT 	 0,3,0,0
