// MJK interface module

#include "winmain.h"
#include "magicjap.h"

static HICON hMainIcon;
static HICON hHirIcon;
static HICON hKatIcon;
static HICON hRoIcon;
static HINSTANCE hGlobalInstance;

BOOL APIENTRY WinMain (HINSTANCE hInstance, HINSTANCE hPrevInst, char * szCmdLine, int iShow) {
	// Load the tray icons //
	hMainIcon = LoadIcon (hInstance, MAKEINTRESOURCE(IDR_ICON));
	hHirIcon = LoadIcon (hInstance, MAKEINTRESOURCE(IDR_HIRAGANA));
	hKatIcon = LoadIcon (hInstance, MAKEINTRESOURCE(IDR_KATAKANA));
	hRoIcon = LoadIcon (hInstance, MAKEINTRESOURCE(IDR_ROMAJI));

	hGlobalInstance  = hInstance;

	// Start the main window //
	DialogBoxParam (hInstance, MAKEINTRESOURCE(IDD_MAIN), NULL, Main_DlgProc, 0);
	return FALSE;
}

BOOL CALLBACK Main_DlgProc (HWND hDialog, UINT iMessage, WPARAM wParam, LPARAM lParam) {
	switch (iMessage) {
		case WM_INITDIALOG:
			// Set window icon //
			SendMessage (hDialog, WM_SETICON, ICON_BIG, (LPARAM) hMainIcon);
			SendMessage (hDialog, WM_SETICON, ICON_SMALL, (LPARAM) hMainIcon);
			
			CreateTrayIcon (hDialog);
			Activate (hDialog);
			ShowWindow (hDialog, SW_SHOWMINNOACTIVE);
			return TRUE;
		case WM_PAINT:
			ShowWindow (hDialog, SW_HIDE);
			return FALSE;
		case WM_CLOSE:
			DestroyWindow (hDialog);
			return TRUE;
		case WM_DESTROY:
			Deactivate (hDialog);
			DeleteTrayIcon (hDialog);
			PostQuitMessage (0);
			return TRUE;
		case WM_TRAYICON:
			return OnTrayIconClick (hDialog, lParam);
		case WM_HOTKEY:
			return HandleHotkey (hDialog, wParam);
	}
	
	return FALSE;
}

BOOL CALLBACK Generic_DlgProc (HWND hDialog, UINT iMessage, WPARAM wParam, LPARAM lParam) {
	switch (iMessage) {
		case WM_INITDIALOG:
			// Set window icon //
			SendMessage (hDialog, WM_SETICON, ICON_BIG, (LPARAM) hMainIcon);
			SendMessage (hDialog, WM_SETICON, ICON_SMALL, (LPARAM) hMainIcon);
			return TRUE;
		case WM_CLOSE:
			DestroyWindow (hDialog);
			return TRUE;
		case WM_DESTROY:
			EndDialog (hDialog, 0);
			return TRUE;
		case WM_COMMAND:
			switch (wParam) {
				case IDR_OK:
					DestroyWindow (hDialog);
					return TRUE;
			}
	}

	return FALSE;
}

BOOL OnTrayIconClick (HWND hWin, LPARAM lParam) {
	POINT stPoint;
	HMENU hTrayMenu;
	int iRet;

	switch (lParam) {
		case WM_RBUTTONUP:
			// Load the menu //
			hTrayMenu = GetSubMenu (LoadMenu (hGlobalInstance, MAKEINTRESOURCE(IDR_TRAYMENU)), 0);
			
			// Pop the menu //
			SetForegroundWindow (hWin);
			GetCursorPos (&stPoint);
			iRet = TrackPopupMenu (hTrayMenu, TPM_RETURNCMD|TPM_LEFTBUTTON|TPM_RIGHTALIGN, stPoint.x, stPoint.y, 0, hWin, NULL);
			
			// Destroy the menu //
			DestroyMenu (hTrayMenu);
			PostMessage (hWin, WM_NULL, 0, 0); // TrackPopupMenu bug fix

			// Handle the menu return //
			switch (iRet) {
				case IDR_TRAYROMAJI:
					HandleHotkey (hWin, VK_ROMAJI); // Simulate a VK_ROMAJI keystroke
					break;
				case IDR_TRAYHIRAGANA:
					HandleHotkey (hWin, VK_HIRAGANA); // Simulate a VK_HIRAGANA keystroke
					break;
				case IDR_TRAYKATAKANA:
					HandleHotkey (hWin, VK_KATAKANA); // Simulate a VK_KATAKANA keystroke
					break;
				case IDR_TRAYHELP:
					DialogBoxParam (hGlobalInstance, MAKEINTRESOURCE(IDD_HELP), NULL, Generic_DlgProc, 0);
					break;
				case IDR_TRAYABOUT:
					DialogBoxParam (hGlobalInstance, MAKEINTRESOURCE(IDD_ABOUT), NULL, Generic_DlgProc, 0);
					break;
				case IDR_TRAYEXIT:
					PostMessage (hWin, WM_DESTROY, 0, 0);
					break;
			}

			return TRUE;
	}
	
	return FALSE;
}

void CreateTrayIcon (HWND hParent) {
	NOTIFYICONDATA stIconData = {0};

	// Fill the NOTIFYICONDATA structure //	
	stIconData.cbSize = sizeof (NOTIFYICONDATA);
	stIconData.hWnd = hParent;
	strcpy (stIconData.szTip, "Magic Japanese Keyboard");
	stIconData.uFlags = NIF_MESSAGE | NIF_TIP | NIF_ICON;
	stIconData.uCallbackMessage = WM_TRAYICON;
	stIconData.hIcon = hRoIcon;

	// Notify the system to create the icon //
	Shell_NotifyIcon (NIM_ADD, &stIconData);
	return;
}
void DeleteTrayIcon (HWND hParent) {
	NOTIFYICONDATA stIconData = {0};
	
	// Fill the NOTIFYICONDATA structure //	
	stIconData.cbSize = sizeof (NOTIFYICONDATA);
	stIconData.hWnd = hParent;
	
	// Notify the system to remove the icon //
	Shell_NotifyIcon (NIM_DELETE, &stIconData);
	return;
}
void SetTrayIcon (HWND hParent, int iMode) {
	NOTIFYICONDATA stIconData = {0};
	
	// Fill the NOTIFYICONDATA structure //
	stIconData.cbSize = sizeof (NOTIFYICONDATA);
	stIconData.hWnd = hParent;
	stIconData.uFlags = NIF_ICON;

	// Select the apropriate icon depending on the current mode //
	switch (iMode) {
		case MODE_ROMAJI:
			stIconData.hIcon = hRoIcon;
			break;
		case MODE_HIRAGANA:
			stIconData.hIcon = hHirIcon;
			break;
		case MODE_KATAKANA:
			stIconData.hIcon = hKatIcon;
			break;
	}

	// Notify the system to update the icon //
	Shell_NotifyIcon (NIM_MODIFY, &stIconData);
	return;
}
