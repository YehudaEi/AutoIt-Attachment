; >
; >
; >
; >
; >
Hello and thank you for trying troyzilla.
you are free you modify it and post it in my topic
 but please if you want to use some of my code feel 
free but dont tottaly rip me off by just changing the name of 
the browser and posting it as your own. this is a work in progress so 
expect an updated version soon. thanks and enjoy!! 
; <
; <
; <
; < 
; <
; <
; <