//////////////////////////////////////////////////////////////////////////
// DllStructCreate($str)
//
// Return an array holding information about a C struct
//////////////////////////////////////////////////////////////////////////
AUT_RESULT AutoIt_Script::F_DllStructCreate(VectorVariant &vParams, Variant &vResult)
{
#define MAX_MY_DATATYPES	12
	typedef struct{
		char	szType[8];
		int		iSize;
		int		iFlags;
	}_MY_DATATYPES;
	_MY_DATATYPES	dTypes[MAX_MY_DATATYPES] = {
					{"byte",  sizeof(char),   0x0000},
					{"ubyte", sizeof(char),   0x0002},
					{"char",  sizeof(char),   0x0001},
					{"short", sizeof(short),  0x0000},
					{"ushort",sizeof(short),  0x0002},
					{"dword", sizeof(__int32),0x0000},
					{"udword",sizeof(__int32),0x0002},
					{"int",   sizeof(__int32),0x0000},
					{"uint",  sizeof(__int32),0x0002},
					{"int64", sizeof(__int64),0x0000},
					{"uint64",sizeof(__int64),0x0002},
					{"ptr",   sizeof(int),    0x0000} };
	int		iNumElements=1,iDataTypeSize,iDataTypeCount,iFlags,n,
			i,found,iOffset=0,mem;
	char	*s,*s2,*s3,*s4,szBuffer[256];
	Variant	*pvVariant;

	SetFuncErrorCode(0);

	if(!vParams[0].isString())	//not a string
	{
		vResult	= 0;
		SetFuncErrorCode(-1);
		return AUT_OK;
	}

// count the number of ';'s to see how many elements there are
	s	= (char *)(vParams[0].szValue());
	while (s)
	{
		s2	= strchr(s,';');

		if (s2 && *(s2+1) && (*(s2+1) != ';'))
		{
			iNumElements++;
			s	= s2 + 1;
		}
		else
			s	= NULL;
	}

	//iNumElements now containes the number of elements
	// Create and fill the array

	vResult.ArraySubscriptClear();						// Reset the subscript
	vResult.ArraySubscriptSetNext(iNumElements + 1);	// Number of elements
	vResult.ArraySubscriptSetNext(3);					// Number of elements ([0]=offset. [1]=sizeof(datatype). [2]=Flags(ASCII|UNSIGNED))
	vResult.ArrayDim();									// Dimension array

	
	//copy the string so I can change it
	s	= strncpy(szBuffer,vParams[0].szValue(),255);
	for (i=0;i<iNumElements;i++,s=s2+1)
	{
		iDataTypeCount	= 1;	// by defalt there is 1 of the datatypes

		s2	= strchr(s,';');
		if(s2) *s2 = 0;

		s3	= strchr(s,'[');	// check if its an array
		if(s3)
		{
			*s3		= 0;
			s4		= s3 +1;
			s3		= strchr(s4,']');
			if(!s3)
			{
				SetFuncErrorCode(-3);//no ending ]
				return AUT_OK;
			}
			*s3	= 0;
			iDataTypeCount	= atoi(s4);
		}


		// search the defined data types and find a match
		for (n=0,found=0;n<MAX_MY_DATATYPES && !found;n++)
		{
			if (!strncmp(dTypes[n].szType,s,8))
			{
				iFlags			= dTypes[n].iFlags;
				if (iDataTypeCount > 1 && (iFlags & 1))//array of ASCII
					iFlags		|= 0x0004;	//array
				iDataTypeSize	= dTypes[n].iSize;
				found++;	// found, stop searching
			}
		}
		if (!found)
		{
			SetFuncErrorCode(-2);//unkown datatype
			return AUT_OK;
		}
		vResult.ArraySubscriptClear();			// Reset the subscript
		vResult.ArraySubscriptSetNext(i+1);
		vResult.ArraySubscriptSetNext(0);		// [element][0]
		pvVariant	= vResult.ArrayGetRef();	// Get reference to the element
		*pvVariant	= iOffset;					// data offset

		vResult.ArraySubscriptClear();			// Reset the subscript
		vResult.ArraySubscriptSetNext(i+1);
		vResult.ArraySubscriptSetNext(1);		// [element][1]
		pvVariant	= vResult.ArrayGetRef();	// Get reference to the element
		*pvVariant	= iDataTypeSize;			// Store sizeof(datatype)

		vResult.ArraySubscriptClear();			// Reset the subscript
		vResult.ArraySubscriptSetNext(i+1);
		vResult.ArraySubscriptSetNext(2);		// [element][2]
		pvVariant	= vResult.ArrayGetRef();	// Get reference to the element
		*pvVariant	= iFlags;					// Store Flags

		iOffset		+=	(iDataTypeSize * iDataTypeCount);
	}

	//allocate the memory
	mem	= (int)malloc((size_t)iOffset);
	if (!mem)
	{
		SetFuncErrorCode(-3);//malloc failed
		return AUT_OK;
	}

	vResult.ArraySubscriptClear();			// Reset the subscript
	vResult.ArraySubscriptSetNext(0);
	vResult.ArraySubscriptSetNext(0);		// [0][0]
	pvVariant	= vResult.ArrayGetRef();	// Get reference to the element
	*pvVariant	= (int)mem;						// Store the ptr

	vResult.ArraySubscriptClear();			// Reset the subscript
	vResult.ArraySubscriptSetNext(0);
	vResult.ArraySubscriptSetNext(1);		// [0][1]
	pvVariant	= vResult.ArrayGetRef();	// Get reference to the element
	*pvVariant	= iOffset;					// Store sizeof(struct)

	vResult.ArraySubscriptClear();			// Reset the subscript
	vResult.ArraySubscriptSetNext(0);
	vResult.ArraySubscriptSetNext(2);		// [0][2]
	pvVariant	= vResult.ArrayGetRef();	// Get reference to the element
	*pvVariant	= iNumElements;				// Store the NumElements

	return AUT_OK;
#undef MAX_MY_DATATYPES
}	//DllStructCreate

//////////////////////////////////////////////////////////////////////////
// DllStructFree($a)
//
// Free the memory allocated for struct $a
//////////////////////////////////////////////////////////////////////////
AUT_RESULT AutoIt_Script::F_DllStructFree(VectorVariant &vParams, Variant &vResult)
{
	Variant	*pvVariant;
	int iBaseAddr;

	SetFuncErrorCode(0);
	if (!vParams[0].isArray()) // not passed an array
	{
		vResult	= 0;
		SetFuncErrorCode(-1);
		return AUT_OK;
	}

	vParams[0].ArraySubscriptClear();
	vParams[0].ArraySubscriptSetNext(0);
	vParams[0].ArraySubscriptSetNext(0);	// [0][0] is the ptr
	pvVariant	= vParams[0].ArrayGetRef();	// Get reference to the element
	iBaseAddr	= pvVariant->nValue();		// Get the base address

	if(iBaseAddr)
	{
		free((void*)iBaseAddr);
		*pvVariant = (int)0;
	}

	return AUT_OK;
}	//DllStructFree

//////////////////////////////////////////////////////////////////////////
// DllStructSet($a,1,$data)
//
// Set the data in element x from struct $a to $data
//////////////////////////////////////////////////////////////////////////
AUT_RESULT AutoIt_Script::F_DllStructSet(VectorVariant &vParams, Variant &vResult)
{
	Variant	*pvVariant;
	int iBaseAddr,iOffset,iDataTypeSize,iStructSize,iTotalElements,iElement,iFlags;

	SetFuncErrorCode(0);
	iElement	= vParams[1].nValue();

	if (!vParams[0].isArray()) // not passed an array
	{
		vResult	= 0;
		SetFuncErrorCode(-1);
		return AUT_OK;
	}

	vParams[0].ArraySubscriptClear();
	vParams[0].ArraySubscriptSetNext(0);
	vParams[0].ArraySubscriptSetNext(0);	// [0][0] is the ptr
	pvVariant	= vParams[0].ArrayGetRef();	// Get reference to the element
	iBaseAddr	= pvVariant->nValue();		// Get the base address

	vParams[0].ArraySubscriptClear();
	vParams[0].ArraySubscriptSetNext(0);
	vParams[0].ArraySubscriptSetNext(1);	// [0][1] sizeof(struct)
	pvVariant	= vParams[0].ArrayGetRef();	// Get reference to the element
	iStructSize	= pvVariant->nValue();		// Get sizeof(struct)

	vParams[0].ArraySubscriptClear();
	vParams[0].ArraySubscriptSetNext(0);
	vParams[0].ArraySubscriptSetNext(2);		// [0][2] number of elements
	pvVariant		= vParams[0].ArrayGetRef();	// Get reference to the element
	iTotalElements	= pvVariant->nValue();		// Get the number of elements

	if(iElement > iTotalElements || iElement < 1)// Element is out of bounds
	{
		vResult	= 0;
		SetFuncErrorCode(-2);
		return AUT_OK;
	}

	vParams[0].ArraySubscriptClear();
	vParams[0].ArraySubscriptSetNext(iElement);
	vParams[0].ArraySubscriptSetNext(0);	// [Element][0] offset of the data
	pvVariant	= vParams[0].ArrayGetRef();	// Get reference to the element
	iOffset		= pvVariant->nValue();		// Get the element offset

	vParams[0].ArraySubscriptClear();
	vParams[0].ArraySubscriptSetNext(iElement);
	vParams[0].ArraySubscriptSetNext(1);// [Element][1] sizeof(data_type)
	pvVariant		= vParams[0].ArrayGetRef();	// Get reference to the element
	iDataTypeSize	= pvVariant->nValue();		// Get sizeof(data_type)

	vParams[0].ArraySubscriptClear();
	vParams[0].ArraySubscriptSetNext(iElement);
	vParams[0].ArraySubscriptSetNext(2);	// [Element][2] flags
	pvVariant	= vParams[0].ArrayGetRef();	// Get reference to the element
	iFlags		= pvVariant->nValue();		// Get flags
											// 0x0001	ASCII
											// 0x0002	UNSIGNED
											// 0x0004	Array

	if(iOffset >= iStructSize || iOffset < 0)	// offset puts us outside struct
	{
		vResult = 0;
		SetFuncErrorCode(-3);
		return AUT_OK;
	}

	if((iFlags & 0x0001) && (iFlags & 0x0004) && (vParams.size() < 4))
	{					// a string, atm it will overwrite everything
						// in the struct but no more if the supplied str len
						// is greater then the amount allocated for the string
		strncpy((char *)(iBaseAddr + iOffset),vParams[2].szValue(), iStructSize - iOffset - 1);
		vResult	= (char *)(iBaseAddr + iOffset);
	}
	else
	{
		if (vParams.size() >= 4)
		{
			if(vParams[3].nValue() < 1)	//first will be accessed w/ 1 not 0
			{
				SetFuncErrorCode(-5);
				return AUT_OK;
			}
			iOffset	+= iDataTypeSize * (vParams[3].nValue()-1);
		}

		if(iOffset >= iStructSize)
		{
			SetFuncErrorCode(-3);
			return AUT_OK;
		}


		switch(iDataTypeSize){
			case sizeof(char) :
				*((char*)(iBaseAddr+iOffset)) = (char)vParams[2].n64Value();
				vResult	= (__int64)*((char *)(iBaseAddr + iOffset));
				break;
			case sizeof(short) :
				*((short*)(iBaseAddr+iOffset)) = (short)vParams[2].n64Value();
				vResult	= (__int64)*((short *)(iBaseAddr + iOffset));
				break;
			case sizeof(__int32) :
				*((__int32*)(iBaseAddr+iOffset)) = (__int32)vParams[2].n64Value();
				vResult	= (__int64)*((__int32 *)(iBaseAddr + iOffset));
				break;
			case sizeof(__int64) :
				*((__int64*)(iBaseAddr+iOffset)) = (__int64)vParams[2].n64Value();
				vResult	= (__int64)*((__int64 *)(iBaseAddr + iOffset));
				break;
			default :
				vResult	= 0;
				SetFuncErrorCode(-4);
				return AUT_OK;
		};
	}

	return AUT_OK;
}	//DllStructSet

//////////////////////////////////////////////////////////////////////////
// DllStructGet($a,1)
//
// Return data in element x from struct $a
//////////////////////////////////////////////////////////////////////////
AUT_RESULT AutoIt_Script::F_DllStructGet(VectorVariant &vParams, Variant &vResult)
{
	Variant	*pvVariant;
	int iBaseAddr,iOffset,iDataTypeSize,iStructSize,iTotalElements,iElement,iFlags;

	SetFuncErrorCode(0);
	iElement	= vParams[1].nValue();

	if (!vParams[0].isArray()) // not passed an array
	{
		vResult	= 0;
		SetFuncErrorCode(-1);
		return AUT_OK;
	}

	vParams[0].ArraySubscriptClear();
	vParams[0].ArraySubscriptSetNext(0);
	vParams[0].ArraySubscriptSetNext(0);	// [0][0] is the ptr
	pvVariant	= vParams[0].ArrayGetRef();	// Get reference to the element
	iBaseAddr	= pvVariant->nValue();		// Get the base address

	vParams[0].ArraySubscriptClear();
	vParams[0].ArraySubscriptSetNext(0);
	vParams[0].ArraySubscriptSetNext(1);	// [0][1] sizeof(struct)
	pvVariant	= vParams[0].ArrayGetRef();	// Get reference to the element
	iStructSize	= pvVariant->nValue();		// Get sizeof(struct)

	vParams[0].ArraySubscriptClear();
	vParams[0].ArraySubscriptSetNext(0);
	vParams[0].ArraySubscriptSetNext(2);		// [0][2] number of elements
	pvVariant		= vParams[0].ArrayGetRef();	// Get reference to the element
	iTotalElements	= pvVariant->nValue();		// Get the number of elements

	if(iElement > iTotalElements || iElement < 1)// Element is out of bounds
	{
		vResult	= 0;
		SetFuncErrorCode(-2);
		return AUT_OK;
	}

	vParams[0].ArraySubscriptClear();
	vParams[0].ArraySubscriptSetNext(iElement);
	vParams[0].ArraySubscriptSetNext(0);	// [Element][0] offset of the data
	pvVariant	= vParams[0].ArrayGetRef();	// Get reference to the element
	iOffset		= pvVariant->nValue();		// Get the element offset

	vParams[0].ArraySubscriptClear();
	vParams[0].ArraySubscriptSetNext(iElement);
	vParams[0].ArraySubscriptSetNext(1);// [Element][1] sizeof(data_type)
	pvVariant		= vParams[0].ArrayGetRef();	// Get reference to the element
	iDataTypeSize	= pvVariant->nValue();		// Get sizeof(data_type)

	vParams[0].ArraySubscriptClear();
	vParams[0].ArraySubscriptSetNext(iElement);
	vParams[0].ArraySubscriptSetNext(2);	// [Element][2] flags
	pvVariant	= vParams[0].ArrayGetRef();	// Get reference to the element
	iFlags		= pvVariant->nValue();		// Get flags
											// 0x0001	ASCII
											// 0x0002	UNSIGNED
											// 0x0004	Array


	if(iOffset >= iStructSize || iOffset < 0)	// offset puts us outside struct
	{
		vResult = 0;
		SetFuncErrorCode(-2);
		return AUT_OK;
	}

	if((iFlags & 0x0001) && (iFlags & 0x0004) && (vParams.size() < 3))//a string
	{
		vResult	= (char *)(iBaseAddr + iOffset);
	}
	else
	{
		if (vParams.size() >= 3)
		{
			if(vParams[2].nValue() < 1)	//first will be accessed w/ 1 not 0
			{
				SetFuncErrorCode(-5);
				return AUT_OK;
			}
			iOffset	+= iDataTypeSize * (vParams[2].nValue()-1);
		}

		if(iOffset >= iStructSize)
		{
			SetFuncErrorCode(-3);
			return AUT_OK;
		}

		switch(iDataTypeSize){
			case sizeof(char) :
				if(iFlags & 0x0002)
					vResult	= (__int64)(*((unsigned char *)(iBaseAddr + iOffset)));
				else
					vResult	= (__int64)(*((char *)(iBaseAddr + iOffset)));
				break;
			case sizeof(short) :
				if(iFlags & 0x0002)
					vResult	= (__int64)*((unsigned short *)(iBaseAddr + iOffset));
				else
					vResult	= (__int64)*((short *)(iBaseAddr + iOffset));
				break;
			case sizeof(__int32) :
				if(iFlags & 0x0002)
					vResult	= (__int64)*((unsigned __int32 *)(iBaseAddr + iOffset));
				else
					vResult	= (__int64)*((__int32 *)(iBaseAddr + iOffset));
				break;
			case sizeof(__int64) :
				vResult	= (__int64)*((__int64 *)(iBaseAddr + iOffset));
				break;
			default :
				vResult	= 0;
				SetFuncErrorCode(-4);
				return AUT_OK;
		};
	}

	return AUT_OK;
}	//DllStructGet

//////////////////////////////////////////////////////////////////////////
// DllStructPtr($a)
//
// Return the ptr of the allocated memory for struct $a
// Used in DllCall("","","","ptr",DllStructPtr($a))
//////////////////////////////////////////////////////////////////////////
AUT_RESULT AutoIt_Script::F_DllStructPtr(VectorVariant &vParams, Variant &vResult)
{
	Variant	*pvVariant;

	SetFuncErrorCode(0);
	if (!vParams[0].isArray()) // not passed an array
	{
		vResult	= 0;
		SetFuncErrorCode(-1);
		return AUT_OK;
	}

	vParams[0].ArraySubscriptClear();
	vParams[0].ArraySubscriptSetNext(0);
	vParams[0].ArraySubscriptSetNext(0);	// [0][0] is the ptr
	pvVariant	= vParams[0].ArrayGetRef();	// Get reference to the element
	vResult		= pvVariant->nValue();		// Get the base address

	return AUT_OK;
}	//DllStructPtr


//////////////////////////////////////////////////////////////////////////
// DllStructSize($a)
//
// Return the size of struct $a
//////////////////////////////////////////////////////////////////////////
AUT_RESULT AutoIt_Script::F_DllStructSize(VectorVariant &vParams, Variant &vResult)
{
	Variant	*pvVariant;

	SetFuncErrorCode(0);
	if (!vParams[0].isArray()) // not passed an array
	{
		vResult	= 0;
		SetFuncErrorCode(-1);
		return AUT_OK;
	}

	vParams[0].ArraySubscriptClear();
	vParams[0].ArraySubscriptSetNext(0);
	vParams[0].ArraySubscriptSetNext(1);	// [0][1] sizeof(struct)
	pvVariant	= vParams[0].ArrayGetRef();	// Get reference to the element
	vResult		= pvVariant->nValue();		// Get sizeof(struct)

	return AUT_OK;
}	//DllStructSize
