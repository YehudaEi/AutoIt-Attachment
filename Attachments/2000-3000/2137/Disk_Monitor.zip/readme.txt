you can monitor multiple drives by entering them w/ commas:
C:,D:,F:,N:

To configure and exit right click in the upper left area