Scriptname: Filename.au3

Author:	Dark$oul71

Contact: darksoul71@gmx.de

Purpose:	
Filename.au3 is a small set of UDF�s (=User defined functions) which
I developed for my own little scripts. Freel free to use the source
code as you like. I just would like to encourage everyone to release
his sources under GPL whenever you distribute a script as binary.


Functions included and what the do:

*Func _FileExtractPath ($FileName)
This function extracts the file path with trailing "\" for a 
filename with path. 

Example: _FileExtractPath("C:\MyPath\MyFile.TXT") returns "C:\MyPath\"


* Func _FileExtractFilename ($FileName)
This function extracts the file name for a filename with path. 

Example: _FileExtractFilename("C:\MyPath\MyFile.TXT") returns "MyFile.TXT"


* Func _FileGetExt ($FileName)
This function returns the extension for a filename with path with "."

Example: _FileGetExt ("C:\MyPath\MyFile.TXT") returns ".TXT"


* Func _FileChangeExt ($FileName, $Extension)
This function changes the extension for a filename with path.

Example: _FileChangeExt ("C:\MyPath\MyFile.TXT", "doc") returns "C:\MyPath\MyFile.doc"

* Func _FileStripExt ($FileName)
This function strips the extension for a filename with path.

Example: _FileStripExt ("C:\MyPath\MyFile.TXT") returns "C:\MyPath\MyFile"


* Func _FileIncrementFileName ($FileName)
This function generates a unique filename for a filename with path if the file exists.

Example: _FileIncrementFileName ("C:\MyPath\MyFile.TXT") returns
	"C:\MyPath\MyFile.TXT"     when "C:\MyPath\MyFile.TXT"     does not exist
	"C:\MyPath\MyFile (1).TXT" when "C:\MyPath\MyFile.TXT"     does exist
	"C:\MyPath\MyFile (2).TXT" when "C:\MyPath\MyFile (1).TXT" does exist
	"C:\MyPath\MyFile (3).TXT" when "C:\MyPath\MyFile (2).TXT" does exist
	and so on.

I�ve provided a little sample script called "MoveFileUnique.au3" as example for what you
can use this function.


* Func _DrivePercentFree ($FullPath)
This function return the available diskspace on a drive in %

Example: _DrivePercentFree ("C:\") would return 50 if your HD has a size of 8 GB and 4 GB are still free.

* Func _IsSearchedType ($FullPath, $Types)
This function return "1" it the filename in $FullPath matches one of the extension defined by $Types
and returns "0" if it doesn�t match any of the defined extensions. $Types can be a single extension without 
any separator (e.g. $Types = "txt") or multiple extensions using one of the following separators "|,;:",
e.g. $Types = "avi,mpg,mpeg" is similar to $Types = "avi|mpg|mpeg" or $Types = "avi:mpg:mpeg" 
The dot for the extension is optional and will be added if missing, e.g. both $Types = ".avi,.mpg" and
$Types = "avi,mpg" are valid. Extensions are NOT casesensitive and will be converted to uppercase prior 
comparison.

Example _IsSearchedType ("C:\This is a file.txt", "txt,doc,rtf") would return 1 as one of the specified
extensions is txt.  

Final words:
Feel free to contact me if you have any questions or ideas on this script. Mind you that
I release those scripts without any warranty, e.g. if you use those function within your
backup script and loose your original data because of a bug within _FileIncrementFileName
I�m not responsible for this.

No animals or developers were hurt during the generation of this code <ggg>

Later,
D$
