1) Download Sdate from http://www.mcafeesecurity.com/us/downloads/updates/superdat.asp .
2) Place the SDat*.exe file in the same directory as McAfee Gui.exe .
3) Run McAfee Gui.exe. Files will AutoExtract from SDat*.exe in Files directory, then program will run.