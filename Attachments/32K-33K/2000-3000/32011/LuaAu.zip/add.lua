function add (x, y)
	print("hello world")
	io.flush()
    return (x + y)
end
