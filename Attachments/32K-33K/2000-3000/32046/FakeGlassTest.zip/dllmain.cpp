#include "dll.h"
#include <windows.h>
//#include <string>
//using namespace std;
//string dbg=".";




/*
const char* ia(unsigned int i)
{
    char* buffer=new char[10];
    itoa(i,buffer,10);
    return buffer;
}
*/



unsigned int pixblur(int* image_l, int lc,int x, int y,int w, int h)
{
    int i,j,l=0;
    unsigned long int sum[4]={0,0,0,0};
    int num=0;
    //dbg+="\npixblur ";
    //dbg+=" L=";
    //dbg+=ia(lc);
    //dbg+=" X=";
    //dbg+=ia(x);
    //dbg+=" Y=";
    //dbg+=ia(y);
    //dbg+="\n";
    
    for(i=x-1;i<(x+2);i++)
    {
        if(i>-1 && i<w)
        {
            for(j=y-1;j<(y+2);j++)
            {
                if(j>-1 && j<h)
                {
                    l=i+j*w;
                    if(l!=lc){
                        //dbg+="   c ";
                        //dbg+=ia(image_l[l]);
                        //dbg+=" L=";
                        //dbg+=ia(l);
                        //dbg+=" X=";
                        //dbg+=ia(i);
                        //dbg+=" Y=";
                        //dbg+=ia(j);
                        //dbg+="\n";
                        
                        unsigned int c=image_l[l];
                        sum[0]+=(c&0xFF000000)>>24;
                        sum[1]+=(c&0x00FF0000)>>16;
                        sum[2]+=(c&0x0000FF00)>>8;
                        sum[3]+=(c&0x000000FF);
                        num++;
                    }
                }
            }
        }
    }
    for(i=0;i<4;i++) sum[i]/=num;
    //dbg+="   ... ";
    //dbg+=ia((sum[0]/num));
    //dbg+="\n";
    return (unsigned int)((sum[0]<<24) + (sum[1]<<16) + (sum[2]<<8) + sum[3]);
}

extern "C"{
    /*
    DLLIMPORT int* DIBtoRGB(char* pvBits,int bytelen)//apparently this is not needed!
    {
        if((bytelen%4)>0) return NULL;//non-RGBQUAD length; ByteLen = 4 Bytes(R,G,B,Reserved) * NumPixels
        int quads=bytelen/4;
        int* image_l=new int[quads];
        //dbg+="D2R \n";
        for(int i=0;i<quads;i++)
        {
            unsigned int rgb[3]={(unsigned char) *(pvBits),(unsigned char) *(pvBits+1), (unsigned char) *(pvBits+2)};
            //dbg+=ia(i);
            //dbg+=" ";
            //dbg+="RGB ";
            //dbg+=ia(rgb[0]);
            //dbg+=" ";
            //dbg+=ia(rgb[1]);
            //dbg+=" ";
            //dbg+=ia(rgb[2]);
            //dbg+="\n";
            
            image_l[i]=rgb[0]<<16 + rgb[1]<<8 + rgb[2];
            pvBits+=4;
        }
        return image_l;
    }
    */
    DLLIMPORT void imgfree(int* image_l, int w, int h)
    {
        delete[] image_l;
        //int ln=w*h;
        //for(int l=0;l<ln;l++) delete ((int*)(image_l+l));
    }
    DLLIMPORT int* boxblur(int* image_l, int w, int h,int passes,bool recursion)
    {
        int l=0,x=0,y=0,ln=w*h;
        int* image2_l=new int[ln];
        for(;l<ln;l++)
        {
            x=l%w;
            y=l/w;
            image2_l[l]=pixblur(image_l, l,x,y,w,h);
        }
        if(recursion)imgfree(image_l, w, h);
        if(passes>1) return boxblur(image2_l, w, h,passes-1,true);
        return image2_l;
    }
    /*
    DLLIMPORT void test()
    {
        int image_l[9]={0xFFFFFF,0xFFFFFF,0xFFFFFF,
                        0xFFFFFF,0x000000,0xFFFFFF,
                        0xFFFFFF,0xFFFFFF,0xFFFFFF};
        int* pimage_l=(int*) &image_l;
        pimage_l=boxblur(pimage_l,3,3);
        delete[] pimage_l;
    }
    DLLIMPORT const char* dbgp()
    {
        return dbg.c_str();
    }
    */
}
/*
DllClass::DllClass()
{

}
DllClass::~DllClass ()
{

}
*/
BOOL APIENTRY DllMain (HINSTANCE hInst     /* Library instance handle. */ ,
                       DWORD reason        /* Reason this function is being called. */ ,
                       LPVOID reserved     /* Not used. */ )
{
    switch (reason)
    {
      case DLL_PROCESS_ATTACH:
        break;
      case DLL_PROCESS_DETACH:
        break;

      case DLL_THREAD_ATTACH:
        break;

      case DLL_THREAD_DETACH:
        break;
    }

    /* Returns TRUE on success, FALSE on failure */
    return TRUE;
}


