Merge or replace the user properties files as you wish.

"au3.user.calltips.api" goes into "C:\Program Files\AutoIt3\SciTE\api" or where you've intalled AutoIt.

"au3.userudfs.properties" goes into "C:\Program Files\AutoIt3\SciTE\Properties"

(\/ )
(oO )
(!_!)