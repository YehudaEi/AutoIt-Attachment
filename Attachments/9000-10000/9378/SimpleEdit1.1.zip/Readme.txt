*************************************************************
SimpleEdit 1.0
*************************************************************
Created by Nick KoontZ (Known as Codemyster on autoit forums)
*************************************************************
This is a beta version of my program SimpleEdit 1.0 and i am
still working on it. You may request a feature but just know
this is NOT the final version and i am working on updates as
i type this readme. JUST something to keep in your small mind
*************************************************************



*************************************************************
SimpleEdit 1.0
*************************************************************
Created by Nick KoontZ (Known as Codemyster on autoit forums)
*************************************************************
This is a beta version of my program SimpleEdit 1.1 and i am
still working on it. You may request a feature but just know
this is NOT the final version and i am working on updates as
i type this readme. JUST something to keep in your small mind
*************************************************************
Some people who have helped me with this are thatsgreat2345,
Skrunge, Autoitking (he suported me and gave me a few ideas)




*************************************************************
SimpleEdit 1.0
*************************************************************
Created by Nick KoontZ (Known as Codemyster on autoit forums)
*************************************************************
This is a beta version of my program SimpleEdit 1.1 and i am
still working on it. You may request a feature but just know
this is NOT the final version and i am working on updates as
i type this readme. JUST something to keep in your small mind
*************************************************************
Some people who have helped me with this are thatsgreat2345,
Skrunge, Autoitking (he suported me and gave me a few ideas)
Smoke_n (for his overall autoit knowldge) and if i forgot you, oh 
well! Read below for copyright and legal stuff you just don't care
about.
*************************************************************
This program is owned by me, Nick koontZ (codemyster) and 
Autoitking of the autoit forums (ben) is the ONLY person who has
rights to host this (other than autoit forums where it is first 
posted. Anyone claiming this code, or an alteration of it as
their own, i can and will take it up in court... now enough 
with this legal stuff
*************************************************************
Here are some updates from version 1.0:

Added "open" feature
Added "save" dialog
Removed input box saver
increased type area by about 30 px each way
changed "clear" to "new"
**************************************************************
A thing to remember:
Always press the "new" button before opening another file
**************************************************************
PS: this readme file was typed in SimpleEdit 1.1! 





