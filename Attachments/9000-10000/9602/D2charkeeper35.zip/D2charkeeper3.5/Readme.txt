####################################################################################
####################                                            ####################
####################          D2Charkeeper 3.5 by Gyz           #################### 
####################                 tnx MM                     #################### 
####################                                            ####################
####################################################################################


D2charkeeper is a simple Diablo2 LOD tool that refreshes the 90 day 
"character-expiration" counter of your play characters and mules on battle.net


This tool does not create games, it simply goes into the chat room.
It will place all the characters (one by one) for a random duration between
30 and 35 seconds into the default chat room.
This should be enough to refresh the expiration counter and to avoid Realm Downs.

Default it supports 100 Accounts.

It will run diablo2 in windowed mode

It detects expired Characters and empty Character slots.

It also detects login errors caused by wrong accountnames and/or passwords.

You are able to 'Skip' accounts. (by unchecking the checkboxes) 

It logs all the actions and errors detected, in the Event_log.txt.

It shows (after a run) the last refresh time and the number of days ago that each account was run.

It Will warn on startup if an account refresh was more than 83 days ago.

It also shows a "slot image" per account (8 slots) after a run :

"A" = Active slot
"E" = Empty slot
"X" = Expired slot 

It can be started with command-line options (for use with windows scheduler)

D2charkeeper does not need/use any kind of MOD.

All keypresses and mouse operations have a randomized delay.

You should only start D2Charkeeper when Battle.net is stable.(no lag)

Other popup windows (MS update,e-mail popups etc...) must not cover the D2 window.


1. INSTALL :
------------
Unzip the D2charkeeper.zip
You should have these files :

D2charkeeper\Config\system\pv.exe
D2charkeeper\Config\system\pv.txt
D2charkeeper\Config\system\up.ico
D2charkeeper\Config\system\down.ico
D2charkeeper\Config\D2charkeeper.ini
D2charkeeper\Logs\Events_log.txt
D2charkeeper\D2charkeeper.exe
D2charkeeper\Readme.txt


2. EXECUTE D2Charkeeper.exe :
------------------------------

Put in your Diablo2 LOD cd.
Launch the D2charkeeper.exe.
Add your D2 acounts to the list (push the "Add Account(s)to list" button)
Hit the "Start" button.

You can stop it at any time by pressing <END> Key
You also have the possiblity to <PAUSE> it.
You have an Event_log.txt in \Logs... If you have problems, look in this file.
(via the menu)



#######################################################################################



Graphical User Interface guide :


- Add account button or <INS>
-----------------------------
This should be the first thing to do when starting D2charkeeper for the first time.
When you push this button : a popup window appears where you can fill in your
D2 accountname and the corresponding password.
after hitting "OK", the accountname will be displayed in the List.
Both the accountname and the password are automatically stored in the D2charkeeper.ini
file.
The password is stored encrypted.
The Add button is the "default" button : hitting <enter> will bring up the popup again
and again.
100 accounts can be added this way.


- Remove account button or <DEL>
--------------------------------
This button will remove the selected account from the list.
The corresponding password is also removed.
The D2charkeeper.ini file is updated automatically.
You can select more than one account for deletion.
A confirmation window will popup.


- Change password button
-------------------------
If you have changed you D2 passwords, you can change the passwords in D2charkeeper
accordingly.
You will have to enter the old password first before you are able to enter
a new password.


- Add/Edit Note button
-----------------------
Add or Edit a small note to the account.


- Check/Uncheck buttons
-----------------------
Will check or uncheck all the accounts at once.


- UP/DOWN buttons
------------------
Move an account up or down in the list.
This will change the order in wich the accounts are processed by D2charkeeper.


- Auto shutdown checkbox
------------------------
When checked, your pc will be shutdown automatically when D2charkeeper has finished.
One minute before the actual shutdown, a couple beep sounds will be played and 
a countdown will popup. Pressing <END> will stop this countdown and avoid the
shutdown.


- Start button
---------------
Before pushing the start button, your D2 LOD cd should be inserted.
D2charkeeper will start D2 in a windowed mode and all the chars of the
checked accounts will be placed into the D2 chat room one by one.
This will take about 5 mins per account.
When all the accounts are "refreshed", two beeps will sound and the
program will exit.


Command-line options guide :


- 2 Valid command-line parameters settings
------------------------------------------
'start'
'start shutdown'
these parameters must be in lowercase.

example dos prompt :

"C:\D2charkeeper3.5\D2charkeeper start" : will start D2charkeeper without the GUI (Graphical User Interface)
and do all the 'selected accounts'.
"C:\D2charkeeper3.5\D2charkeeper start shutdown" : will start D2charkeeper without GUI
and shutdown the pc when all the 'selected accounts' are done.
'selected accounts' : the accounts that were 'checked' when the GUI was exited the last time.

example windows 'Scheduled Tasks' :

Configuration - Scheduled Tasks - Add a task - Wizzard Scheduled Tasks
startup line (in Advanced properties) :
C:\D2charkeeper3.5\D2charkeeper.exe start shutdown

When using windows Scheduler to start D2charkeeper, inspect your Events_Log.txt regularly
to check if all was done succesfull.  



#######################################################################################

History
-------
- D2charkeeper 3.5 changes :
Added command-line option functionality (tnx chh)
Valid commandline parameters settings : 
'start' : will start D2charkeeper without GUI.
'start shutdown' : will start D2charkeeper without GUI and shutdown the pc
when all selected accounts are done.
Use this with windows 'Scheduled Tasks' to schedule D2charkeeper.
Added an extra 'iniwrite' when exiting D2charkeeper :
You can now start D2charkeeper, check/uncheck accounts and exit.
The new 'account selection' is now written to the d2charkeeper.ini file.
No changes were done to the .ini file.

- D2charkeeper 3.4 changes :
Minor changes to the GUI-code to ensure more stability and speed.
When moving up/down a record outside the view, the scrollbar will ensure the
moving record stays visible.(tnx Mjolnir)
Iniwrite to .ini now only saves the # of used accounts in the GUI instead of
all 99. This increases the GUI speed. 
The .ini file has been adapted : don't use the previous .ini file !

- D2charkeeper 3.3 changes :
Added File menu + GUI look changes.
Added new columns for the "slot image" + Note
Added new button : Add/Edit Note.
The .ini file has been adapted : don't use the previous .ini file !

- D2charkeeper 3.2 changes :
Added 2 new info columns to the GUI : Last refresh time and days ago.(tnx Dr FrOsig)
Added check on startup : warning if days ago > 83 (tnx Dr FrOsig)
The .ini file has been adapted : don't use the previous .ini file !
added check_all and uncheck_all buttons to the GUI.
 
- D2charkeeper 3.1 changes :
Go to the next account when the first empty slot is found.(tnx Uzhgi)
Do a fast exit when the D2 window is not found or <ALT> + <F4> is pressed.(tnx Uzhgi)
Check more regularly if the D2 window is still active and maximized.
Inside the chatroom : countdown to 1 (instead of 0) and "SplashOff()". 

- D2charkeeper 3.0 changes :
Use of a simple GUI (Graphical User Interface).
No need to make manual changes to the D2charkeeper.ini file anymore.
Passwords are now encrypted in the D2charkeeper.ini file.

- D2charkeeper 2.0 changes :
Now, works in 32 bits and 16 bits video mode.
You can choose to auto-shutdown you pc after execution.


Safety warning
--------------
Regularly make a backup copy of your D2charkeeper.ini file.
This code is based on a BETA autoit release.

----------------------------------------------------------------------------------------
REQUIREMENTS:

Operating system must be Win2000 or superior. Win98/Millenium does not work.
1++ Ghz CPU is recommended.
I will not support computers < 1Ghz due the fact they are more harder to setup.
This tool was created from a windows Xp 2.6 Ghz computer, 1024*768 32bit.
Classic Windows theme was used, but you can use "Normal XP".
-----------------------------------------------------------------------------------------
The D2charkeeper code is originating from the released mm.bot code by Manus Magnus. 
It has been compiled with autoit v3 and does not make any changes to
your original Diablo2 files.

