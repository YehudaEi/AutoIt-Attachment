#include <windows.h>

#pragma data_seg(".shared")  // ".shared" is defined in exports.def to allow
//  all instances of the dll to share these variables
    HWND        m_hHwndKey = 0;
    HHOOK        m_hHookKey = 0;           
    HWND        m_hHwndMouse = 0;
    HHOOK        m_hHookMouse = 0;
    HWND        m_hHwndCBT = 0;
    HHOOK        m_hHookCBT = 0;
#pragma data_seg()


#define WM_MOUSEWHEEL 0x020A
#define WM_XBUTTONDOWN  0x020B
#define WM_XBUTTONUP 0x020C
#define WM_XBUTTONDBLCLK 0x020D
#define XBUTTON1  0x0001
#define XBUTTON2  0x0002

#define AU3_HCBT_SETFOCUS (WM_USER + 0x2A30)
#define AU3_HCBT_ACTIVATE (WM_USER + 0x2A31)
#define AU3_HCBT_CREATEWND (WM_USER + 0x2A32)
#define AU3_HCBT_DESTROYWND (WM_USER + 0x2A33)
#define AU3_HCBT_MINMAX (WM_USER + 0x2A34)
#define AU3_HCBT_MOVESIZE (WM_USER + 0x2A35)

#define AU3_WM_LBUTTONDOWN (WM_USER + 0x1A30)
#define AU3_WM_RBUTTONDOWN (WM_USER + 0x1A31)
#define AU3_WM_MBUTTONDOWN (WM_USER + 0x1A32)
#define AU3_WM_XBUTTONDOWN1 (WM_USER + 0x1A33)
#define AU3_WM_XBUTTONDOWN2 (WM_USER + 0x1A34)
#define AU3_WM_LBUTTONUP (WM_USER + 0x1B30)
#define AU3_WM_RBUTTONUP (WM_USER + 0x1B31)
#define AU3_WM_MBUTTONUP (WM_USER + 0x1B32)
#define AU3_WM_XBUTTONUP1 (WM_USER + 0x1B33)
#define AU3_WM_XBUTTONUP2 (WM_USER + 0x1B34)
#define AU3_WM_LBUTTONDBLCLK (WM_USER + 0x1C30)
#define AU3_WM_RBUTTONDBLCLK (WM_USER + 0x1C31)
#define AU3_WM_MBUTTONDBLCLK (WM_USER + 0x1C32)
#define AU3_WM_XBUTTONDBLCLK1 (WM_USER + 0x1C33)
#define AU3_WM_XBUTTONDBLCLK2 (WM_USER + 0x1C34)
#define AU3_WM_MOUSEWHEELUP (WM_USER + 0x1D30)
#define AU3_WM_MOUSEWHEELDOWN (WM_USER + 0x1D31)
#define AU3_WM_MOUSEMOVE (WM_USER + 0x1F30)

#define AU3_WM_KEYDOWN (WM_USER + 0x0A30)
#define AU3_WM_KEYUP (WM_USER + 0x0A31)

// OS Version data
OSVERSIONINFO    OSvi;

//typedef struct {
//    MOUSEHOOKSTRUCT MOUSEHOOKSTRUCT;
//    DWORD mouseData;
//} MOUSEHOOKSTRUCTEX, *PMOUSEHOOKSTRUCTEX;

// Set the values for the window and hook for the Keyboard hook
void WINAPI SetValuesKey(HWND hWnd, HHOOK hk)
{
    m_hHwndKey = hWnd;
    m_hHookKey = hk;
}

// Set the values for the window and hook for the mouse hook
void WINAPI SetValuesMouse(HWND hWnd, HHOOK hk)
{
    m_hHwndMouse = hWnd;
    m_hHookMouse = hk;
}

// Set the values for the window and hook for the CBT hook
void WINAPI SetValuesCBT(HWND hWnd, HHOOK hk)
{
    m_hHwndCBT = hWnd;
    m_hHookCBT = hk;
}

// This is the CBT hook itself
LRESULT CALLBACK CBTProc(int nCode, WPARAM wParam, LPARAM lParam) 
{
    if (nCode < 0)
        return CallNextHookEx(m_hHookCBT, nCode, wParam, lParam);

    switch (nCode) 
    { 
        case HCBT_SETFOCUS:
            PostMessage(m_hHwndCBT,AU3_HCBT_SETFOCUS, wParam,lParam);
            break; 
        case HCBT_ACTIVATE:
            PostMessage(m_hHwndCBT,AU3_HCBT_ACTIVATE, wParam,lParam);
            break; 
        case HCBT_CREATEWND:
            PostMessage(m_hHwndCBT,AU3_HCBT_CREATEWND, wParam,lParam);
            break; 
        case HCBT_DESTROYWND:
            PostMessage(m_hHwndCBT,AU3_HCBT_DESTROYWND, wParam,lParam);
            break; 
        case HCBT_MINMAX:
            PostMessage(m_hHwndCBT,AU3_HCBT_MINMAX, wParam,lParam);
            break; 
        case HCBT_MOVESIZE:
            PostMessage(m_hHwndCBT,AU3_HCBT_MOVESIZE, wParam,lParam);
            break; 

        default:
            break; 
    } 
    return CallNextHookEx(m_hHookCBT, nCode, wParam, lParam);
} 

// This is the mouse hook itself
LRESULT CALLBACK MouseProc( int nCode, WPARAM wParam, LPARAM lParam )
{
    if (nCode < 0)
        return CallNextHookEx(m_hHookMouse, nCode, wParam, lParam);

    if (nCode == HC_ACTION)
    {
        UINT wParm;

        // If the message is a WM_NC*, convert it to a WM_*
        if ((wParam >= 0xA0) & (wParam <= 0xAD))
            wParam = wParam + 352;

        switch (wParam) 
        { 
            case WM_LBUTTONDOWN:
                    wParm = AU3_WM_LBUTTONDOWN;
                    break;
            case WM_RBUTTONDOWN:
                    wParm = AU3_WM_RBUTTONDOWN;
                    break;
            case WM_MBUTTONDOWN:
                    wParm = AU3_WM_MBUTTONDOWN;
                    break;
            case WM_XBUTTONDOWN:
                    if ( (short)HIWORD(((MOUSEHOOKSTRUCTEX*)lParam)->mouseData) == XBUTTON1 )
                        wParm = AU3_WM_XBUTTONDOWN1;
                    else
                        wParm = AU3_WM_XBUTTONDOWN2;
                    break;
            case WM_LBUTTONUP:
                    wParm = AU3_WM_LBUTTONUP;
                    break;
            case WM_RBUTTONUP:
                    wParm = AU3_WM_RBUTTONUP;
                    break;
            case WM_MBUTTONUP:
                    wParm = AU3_WM_MBUTTONUP;
                    break;
            case WM_XBUTTONUP:
                    if ( (short)HIWORD(((MOUSEHOOKSTRUCTEX*)lParam)->mouseData) == XBUTTON1 )
                        wParm = AU3_WM_XBUTTONUP1;
                    else
                        wParm = AU3_WM_XBUTTONUP2;
                    break;
            case WM_LBUTTONDBLCLK:
                    wParm = AU3_WM_LBUTTONDBLCLK;
                    break;
            case WM_RBUTTONDBLCLK:
                    wParm = AU3_WM_RBUTTONDBLCLK;
                    break;
            case WM_MBUTTONDBLCLK:
                    wParm = AU3_WM_MBUTTONDBLCLK;
                    break;
            case WM_XBUTTONDBLCLK:
                    if ( (short)HIWORD(((MOUSEHOOKSTRUCTEX*)lParam)->mouseData) == XBUTTON1 )
                        wParm = AU3_WM_XBUTTONDBLCLK1;
                    else
                        wParm = AU3_WM_XBUTTONDBLCLK2;
                    break;
            case WM_MOUSEWHEEL:
                    if ((OSvi.dwPlatformId == VER_PLATFORM_WIN32_NT)&&(OSvi.dwMajorVersion>=5))
                    {
                        if ( (short)HIWORD(((MOUSEHOOKSTRUCTEX*)lParam)->mouseData) > 0 )
                            wParm = AU3_WM_MOUSEWHEELUP;
                        else
                            wParm = AU3_WM_MOUSEWHEELDOWN;
                    }
                    else
                           wParm =  AU3_WM_MOUSEWHEELUP;
                    break;
            case WM_MOUSEMOVE:
                    wParm = AU3_WM_MOUSEMOVE;
                    break;
            default:
                return CallNextHookEx(m_hHookMouse, nCode, wParam, lParam);
        }

        // Let the listening window know about the message

        PostMessage(m_hHwndMouse, wParm,(WPARAM)( (MOUSEHOOKSTRUCT*) lParam )->hwnd, MAKELPARAM(
            ( (MOUSEHOOKSTRUCT*) lParam )->pt.x,
            ( (MOUSEHOOKSTRUCT*) lParam )->pt.y));
    }
    return CallNextHookEx(m_hHookMouse, nCode, wParam, lParam);
}

// Keyboard hook
LRESULT CALLBACK KeyProc( int nCode, WPARAM wParam, LPARAM lParam )
{
    UINT    iState=0;
    if (nCode < 0)
        return CallNextHookEx(m_hHookKey, nCode, wParam, lParam);

    if (nCode == HC_ACTION)
    {
        if (GetKeyState(VK_LSHIFT) & 0x8000) iState |= 1;
        if (GetKeyState(VK_RSHIFT) & 0x8000) iState |= 2;
        if (GetKeyState(VK_LCONTROL) & 0x8000) iState |= 4;
        if (GetKeyState(VK_RCONTROL) & 0x8000) iState |= 8;
        if (GetKeyState(VK_LMENU) & 0x8000) iState |= 16;
        if (GetKeyState(VK_RMENU) & 0x8000) iState |= 32;
        if (GetKeyState(VK_LWIN) & 0x8000) iState |= 64;
        if (GetKeyState(VK_RWIN) & 0x8000) iState |= 128;
        if (lParam & 0x80000000)
            PostMessage(m_hHwndKey, AU3_WM_KEYUP, wParam, iState);
        else
        {
            PostMessage(m_hHwndKey, AU3_WM_KEYDOWN, wParam, iState);
        }
    }
    return CallNextHookEx(m_hHookKey, nCode, wParam, lParam);
}

BOOL WINAPI DllMain(HINSTANCE hinstDLL, DWORD fdwReason, LPVOID lpvReserved)
{
    if (fdwReason == DLL_PROCESS_ATTACH)
        DisableThreadLibraryCalls(hinstDLL);


    // Get details of the OS we are running on
    OSvi.dwOSVersionInfoSize = sizeof(OSVERSIONINFO);
    GetVersionEx(&OSvi);

    return TRUE;
}

// This is to prevent the CRT from loading, thus making this a smaller
//  and faster dll.
extern BOOL __stdcall _DllMainCRTStartup( HINSTANCE hinstDLL, DWORD fdwReason, LPVOID lpvReserved)
{
    return DllMain( hinstDLL, fdwReason, lpvReserved );
}


