button
F1
play
C:\WINDOWS\system32\oobe\images\title.wma
