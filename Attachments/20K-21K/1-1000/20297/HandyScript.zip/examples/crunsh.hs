button
F1
play
C:\WINDOWS\Media\recycle.wav
