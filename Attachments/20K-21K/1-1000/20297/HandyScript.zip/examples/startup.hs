button
F1
play
C:\WINDOWS\Media\Windows XP Opstarten.wav
