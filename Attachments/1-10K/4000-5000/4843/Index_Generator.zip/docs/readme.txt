JAK GenIndex Readme
======================
Content
1.Readme
2.Changes
3.Todo

1.Readme
=========
This Program  Generates a file listing for your website
Just select the start folder and it will do it.
Please note: The file generated is called index.html.If a file called index.html already exists it will be renamed to index.html.old.
JAK-Software.DE has not started developing this script.It is based on a script created by CyberSlug.
AutoIT Forum Topic: http://www.autoitscript.com/forum/index.php?showtopic=9773

1.1 Usage
-----------
1.Click GenIndex.exe and select folder
2.Upload all files in "icons" to www.yourdomain.com/icons
3.Upload all index.html files






2.Changes
=======
120=>121
*Released
*Displays "oben.txt" on the top of the page and "unten.txt" on the end of the page.
*Cleaned Code
*Added Logging
*Added Version Information


The following Informations are not correct in fact of the version.This was one work process.100=>120
110=>120
----------------
*Icons in /icons
*more icons for more filetypes
+Show Readme at top of page
*

100=>110
------------------------
+Recursive Mode
+Icons for Filetypes
+Added Icons in /
+"Last Modified" category
+Added MB and GB for size information
+Name: GenIndex


-----------------------
* Changed
- Removed
+ Added


3. Todo
===========
130
---
+Add Recursive Mode Selection
