NOTE: I am not supporting this, only releasing a 9-10 estimated kill version to allow others to see my progress in it's development. 



Requirements: 
Windows XP with the Default Windows XP Theme 



Installation/Setup: 
While in WoW, go into your Video Options, then click the "Default" button. Restart WoW if needed. Then back in your Video Options select Window Mode, with 800x600 resolution. 

Move your character to an area with a decent amount of enemies/creatures of a level that can be handled fairly easily that will still gain you decent experiance. 

Run the program, and just let it run. You can-not use your computer as it runs. For emergency exit, press CTRL+ALT+X 



Notes: 
Will NOT work with melee classes. Will only work for casters. Currently developed and tested on Mage class with Frostbolt (Key 2) and Fireball (Key 3). You MUST have casts binded to Keys 2 and 3. It is reccomended that Key 2 be your weaker of the 2 casts (A slow down cast such as Frostbolt), and your stronger of the 2 casts set to key 3 (eg. Fireball) 

Feel free to make any comments/suggestions in this thread, but do not ask for support. If it doesn't work for you for whatever reasons, then you're out of luck until it's final release. 



Fixes/Changes/Additions/Removals: 

v0.67 
- Changed: Made all specific color matching into wide ranges. This should work for all those that had issues before. Please let me know how it works. 

v0.65 
- Changed: Life/Mana/Rage reading proceedures. Now looks for a range of colors per bar spot, not just a single exact color. 

v0.64 
- Added: Enemy/Creature Life Monitor 

- Fix: Loot attempt discontinues and attacks if a new enemy/creature starts to attack while attempting loot. 



Known Bugs/Problems: 
- None 



Additional Features To Come: 
- Advanced wander algorythm to ensure random movement without wandering too far from the general area.
