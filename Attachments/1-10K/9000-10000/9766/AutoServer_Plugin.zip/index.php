<link rel="shortcut icon" href="favicon.ico">

<? phpinfo(); ?>