<?php echo ('<?xml version="1.0" encoding="utf-8"?>'); ?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01//EN" "http://www.w3.org/TR/html4/strict.dtd">
	<head>
	<title>TestGet</title>
	</head>
	<body>
		<DIV id="left">
		</DIV>
			<div id="right">
			</div>
			<div id ="BreadCrumb"> &nbsp;</div>
			<div id="center">
				<h3>Welcome,</h3> PHP GET Test.<br />
				<?php
					if (!isset($_GET[submit])) {
				?>
					<form action="" method ="get">
						<div>
							Multiply 2 numbers:<br />
							Enter a number: <input type="text" name="num1"/><br />
							Enter a number: <input type="text" name="num2"/><br />
							<input type="submit" name="submit" value="Submit"/> <input type="reset" name="reset" value="Clear" />
						</div>
					</form>
				<?php
				}
					else {
					$answer =$_GET[num1] * $_GET[num2];
				?>
				<h1>Answer</h1>
				<p><?=$_GET[num1]?> * <?=$_GET[num2]?> = <?=$answer?></p>
				<?php
				}
				?>
					
			</div>
	</body>
</html>
