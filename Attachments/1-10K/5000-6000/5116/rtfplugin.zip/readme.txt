Here the early (let it be alpha) version of RTF plugin. This exports 5 functions:

GUICtrlCreateRTFEdit(GUI_hWnd, left, top [, width[, height[, style[, exstyle]]]])
Return handle of created RichEdit control

GUICtrlRTFSet(RTF_control_handle, RTF_string[, type])
RTF_string - should be valid RTF text stream
type - 0 replace content of control, 1 add at cursor position

GUICtrlRTFLoad(RTF_control_handle, filename)

GUICtrlRTFSave(RTF_control_handle, filename)

GUICtrlRTFGet(RTF_control_handle)
Return RTF text stream