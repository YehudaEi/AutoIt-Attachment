BufferAllocate(nBytes) - Allocates memory and returns the address.
BufferFree(Address, nBytes) - Frees allocated memory.

BufferSetCharAsc(Address, Asc) - Sets the asci of a byte at an address.
BufferGetCharAsc(Address) - Gets the asci of a byte at an address.

BufferReadInt(Address) - Reads an integer from an address.
BufferWriteInt(Address, Integer) - Writes an integer to an address.

BufferReadDouble(Address) - Duh!
BufferWriteDouble(Address, Double) - Duh!

BufferReadString(Address) - Reads a string at an address up to the null character.

StoreString(String) - Stores a string in memory and returns its address.
FreeString(Address) - Frees a string in memory.

A3BGPID() - Returns current process ID.

ProcessMemoryRead(ProcessID, SourceAddress, DestinationAddress,nBytes)
Reads memory from the specified process into a destination buffer.
Non-Zero return = Success.

ProcessMemoryWrite(ProcessID, SourceAddress, DestinationAddress, nBytes)
Writes memory from a source buffer into the destination address of the specified
process. Non-Zero return = success.

ConsoleLoad(Title) - Loads a console window.
ConsoleFree() - Frees the console.

ConsoleInput(nBytes) - Prompts the user in the conse window, and then returns the string.

ConsolePrint(String) - Prints a string to the console window.