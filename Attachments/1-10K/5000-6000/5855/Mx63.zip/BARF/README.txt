**** VB to C++   ****

Description: Tutorial on switching from vb to c++
Copyright: � 2003 Jaime Muscatelli


**** Author Information ****

Author: Jaime Muscatelli
Email: webmaster@jaimemuscatelli.zzn.com
Company: J Productions
Screen Name: Jaime141974
Website: www.jprogs.cjb.net


Readme file made in Readme File Generator (By Jaime Muscatelli, www.jprogs.cjb.net)



Book References:

"C++ for VB programmers", Morrison, Apress press.