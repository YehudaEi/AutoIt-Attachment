How to

Copy-paste the lines from the samples. 
I hope it won't be too difficult to find out where you can instert these lines into your script.

ProgressBarFast.vbs or ProgressBar.vbs , as well as ProgressBar.log must be included in the same directory as your script.

---------------

Files

ProgressBarFast.vbs is to use for fast process that last between 5 seconds to 5 minutes.

ProgressBar.vbs is to use for very slow process that can last several hours.

ProgressBar.log contains the datas needed by the progressbar script. your script must write a header (see sample) then "+1" for each item procesed at the end of this file.

_________________

Advantage:

1/ It's a purely textbox based progressbar. It doesn't require any dll installation and doesn't invoke heavy duty class, IE or something.
It's fast and purely no-nonsens VBS.

2/ Modify and adapt the script as you please

3/ "ok" will make the taskbar disapear for a while then will come back after an intelligent period of time.

-----------------

Downsides and limitations:

1/ This progressbar is not minimizable. It can be irritating to have it poping up all the time. In this case clic "cancel" or "ok".
But in some case it can be useful to prevent user from using their computer during the process! :)

2/ "Cancel" won't stop the script that generated the taskbar. So your script should have a way to ne stopped or you will have to kill the script task with Ctr+Alt+Del
Maybe in the future, I will imagine a similar way, though semaphore files, to stop both scripts at once.

3/ Design limited to the basic MsgBox. but we do VBS aren't we? ;)

------------------

contact

fredledingo@yahoo.com

