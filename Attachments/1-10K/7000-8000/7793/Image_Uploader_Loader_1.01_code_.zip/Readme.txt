Hello, This is ment to take screenshots and upload to websites  with push of a key.

Press pring screen to take shots
Press end to stop the program.
really basic stuff.

Screenshots be uploaded to http://iul.g-v.us/ your username

