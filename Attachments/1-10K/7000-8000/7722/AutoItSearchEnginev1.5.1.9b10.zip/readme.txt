[Installation Instructions]

Extract these files to a location like:
C:\Program Files\Search Engine\

You will need to extract the .exe to its own directory since it builds index files in the same directory as its location.

[Readme]

Before searching, you must index your drives.  The first time you start up press the Rebuild Index button.

The rest of the program is fairly easy to use, but just press F1 or click the Help menu for additional help.