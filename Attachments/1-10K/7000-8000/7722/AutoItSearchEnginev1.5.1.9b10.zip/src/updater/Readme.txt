Note:
SEUpdate.exe is downloaded into the same folder as Search Engine.exe when you close the program.