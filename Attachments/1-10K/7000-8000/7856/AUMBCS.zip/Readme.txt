MBCS support for AutoIt v3

[INSTALLATION]
Put Include/MBCString.au3 to your AutoIt's INCLUDE Path
Ensure that your script can find AUMBCS.dll(in the script's folder, or the global PATH entironment variable)

[FUNCTIONS]
_StringInStr:  equ to the function "StringInStr"
_StringMid: equ to the function "StringMid"
_StringLen: equ to the function "StringLen"
_StringLeft: equ to the function 	"StringLeft"
_StringRight: equ to the function "StringRight"
_Send: equ to the function "_Send"
_Chr: equ to the function "Chr"
_Asc: equ to the function "Asc"
_StringReverseW: equ to the function "_StringReverse"
_StringReplace: equ to the function "StringReplace"
_StringTrimLeft: equ to the function "StringTrimLeft"
_StringTrimRight: equ to the function "StringTrimRight"

_StringInsert($string, $substring, $pos):
Inserts $substring into $string beginning at a specified point $pos.

_StringDelete($string, $start, $count)
Removes a substring from a string.

[HISTROY]
0.1 - First Release.