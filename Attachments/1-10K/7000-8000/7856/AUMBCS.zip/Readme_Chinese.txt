﻿MBCS support for AutoIt v3

Updated:	Apr 6th, 2006

目录结构:
	|- AUMBCS.dll
	|- TestAUMBCS.au3
	|- Readme.txt
	|- <Include>
		|- MBCString.au3

在 Windows XP SP2 下测试通过, 应该同样支持 Win98/Win2000/WinXP/Win2003

安装/升级:
	拷贝 Include\MBCString.au3 到你的AutoIt安装目录\Include下, 若需要覆盖, 请选择"是", 若有MBCS.au3, 可以删除了
	[可选项] 拷贝AUMBCS.dll到 C:\Windows\. 也可以放到需要执行的脚本在同一个目录下, 但是不能放到Include里(现在可以在脚本中指定DLL路径, 参见示例)

使用:
	#include<MBCString.au3>, 参见TestAUMBCS.au3

目前完成的功能:
	_StringInStr	同	"StringInStr"
	_StringMid		同	"StringMid"
	_StringLen		同	"StringLen"
	_StringLeft		同	"StringLeft"
	_StringRight	同	"StringRight"
	_Send			同	"_Send"
	_Chr			同	"Chr"
	_Asc			同	"Asc"
	_StringReverseW		同	"_StringReverse"
	_StringReplace		同	"StringReplace"
	_StringTrimLeft		同	"StringTrimLeft"
	_StringTrimRight	同	"StringTrimRight"

	_StringInsert($string, $substring, $pos):
	在$string中, $pos处插入一个子串
	例如: _StringInsert("测试串", "插入ABC", 3)
	返回 "测试插入ABC串"

	_StringDelete($string, $start, $count)
	删除$string从$start开始, $count数目的字符
	例如: _StringDelete("删除ABC测试", 3, 3)
	返回 "删除测试"

参见：
	TestAUMBCS.au3 这个测试例子