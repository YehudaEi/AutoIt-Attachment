Readme

V1
To Come: Playlists.
-------------------

Directions: Keep the .jpg image inside of the same folder as AutoAmp.
To run music files just hit Play, and type in music file name with .mp3, .wma, or .wav
Keep it ez by just bringing all files into autoamp folder so u just have to type filename.