For this to work, you must download the driver EXE from the site (above in my post there is a link) Then move it to c:\, and rename it "driversetup.exe".
Then compile, I couldn't post the compiled version because with FileInstall it's 2.49 MB
~cdkid