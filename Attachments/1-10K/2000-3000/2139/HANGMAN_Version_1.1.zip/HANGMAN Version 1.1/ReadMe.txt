Instructions how to make a word list using ROT13.EXE:

1. Wordlist format must be one word per line with no special characters, only letters. File must be a text file.
2. Open the file you want to make into the word list from the file menu.
3. Click on the OK button.
The bigger the file the longer it will take.
4. Backup the old wordlist.txt and rename newwordlist.txt as wordlist.txt

DISCLAIMER:

These two programs(hangman V1.1.EXE and ROT13.EXE) are made with no intent to harm your computer in any way. If harm does happen because  of these two programs, I take no blame for the harm.
Share and copy all you want as long as the two programs are not changed and I get the credit.
