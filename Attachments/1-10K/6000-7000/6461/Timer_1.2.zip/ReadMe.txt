=======================
timer ver 1.2 1/26/2006
=======================

Calculates the elapsed time since a given command started

Usage: timer [options] command/filename
Options:
  -f filename   text file with commands

Text file format:
- one command per row
- blank lines will be ignored
- comments (rows prefixed with ";") will be ignored

Examples: timer copy *.au3 c:\Backup
          timer -f c:\Tmp\CmdList.txt

The output is appended to the file Timer.log

  
ChangeLog: 
1.0 - 1/18/2006
- Initial release

1.1 - 1/20/2006
- Removed: Output Message box
- Added: Resource Info (version, description,...) in the exe file
- Added: The command name and the results are written in a log file
- Added: The command option "-f" to monitor commands from a file

1.2 - 1/26/2006
- Changed: in command files management (-f option) runwait => run. In this way many commands can be run simultaneously


------------------------------------------------------------------------------------------------------------------

Author: Giuseppe Criaco <gcriaco@quipo.it>
