Aaron's Encrypting Tool Help/ReadMe 

Aaron's Encrypting tool is a small and moderatly powerful encrypting tool. While it still isn't as powerful as commercial ones, this on is free.
Aarons Encrypting Tool is very easy to learn and use. 

To use Aarons Encrypting Tool to cypher, put your text in the box that says Text to encrypte, hold the CTRL key and hit the encrypt button.  
There are many more functions included that could be of use, like "Text from File", "Copy to Clipboard", etc.
Aarons Encrypting Tool has the ability to decrypt any encrypted text with this program.

I hope you like my Program

-Aaron
