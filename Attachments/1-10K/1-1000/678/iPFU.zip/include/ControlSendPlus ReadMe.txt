ControlSendPlus UDF created by "pekster"
Version: 2.03 (created 06/13/2004 mm/dd/yyyy)

SHORT DESCRIPTION: This function is designed to replace the built-in ControlSend
  function. It will correctly handle the shift state (using the global state to
  send the required keys) as well as the control and alt key modifiers.

USAGE: ShiftControlSend("title", "text", "classnameNN", "string", flag)
  The first 4 text parameters are identical to the ControlSend function.
  The 'flag' parameter is a bit different. Consult the table below. Note that in
    all of these modes the global shift state is used to properly send
    characters.
    0 - Default behavior. Special characters like {ENTER} and {UP} are sent to
      the control. The '!', '^', and '+' are alt, control, and shift
      accordingly. All modifier keys are sent LOCALLY.
    1 - Raw mode. Keys are sent as they appear in the "string" parameter.
    2 - Global mode. Identical to mode 0, but the control and alt keystrokes are
      sent globally. See NOTE 1 below.
    3 - Global Ctrl mode.  Identical to mode 0, but control keystrokes are sent
      globally (alt keystrokes are local.) See NOTE 1 below.
    4 - Global Alt mode.  Identical to mode 0, but alt keystrokes are sent
      globally (control keystrokes are local.) See NOTE 1 below.

RETURN: As of version 2.0.3, this function has the same return as ControlSend.
  Success returns 1, and a failure to find the window or control returns 0. A
  failure is any failure to send any characters, so it is possible for some of
  the characters to get sent, and then the rest fail if the window closes
  during the send process.

KEYBOARD LAYOUTS: This function was designed to be used with the standard QWERTY
  US keyboard layout. If you have a different layout, you may need to change the
  function to properly detect characters that require a shift modifier. To do
  this, you will need to edit the string on line 7 between the single quotes.
  Place each character that requires a shift right after one-another. No further
  changes are required. Don't for get capital letters as well as your symbols!

BRACES ISSUE: This is not a bug, since I designed my function to imitate the
  ControlSend function as much as I could. The issue appears when you enter
  a string such as "{I ACTUALLY WANT BRACES}" with a flag other than 1. The
  proper methods of doing this are to use raw mode, or use the "{{}" and "{}}"
  special characters. However, it may appear as if sections of your string were
  ignored by my function. If this occurs, check your use of braces.
  You can also get strange outputs when you don't match braces, the exception
  being the "{{}" and "{}}" uses. If you need to do this, use flag 1.

NOTE 1: Some applications will not properly use the local alt and/ or control
  keystroke. This is why the additional 3 flags were added. To discover the
  proper flag to use for you particular application, you will have to try out
  the different flags. Sometimes both local and global mode work, and other
  times only one will.

LIMITATIONS: The current version observes the following limitations:
  * You cannot send Chr(5) since this character is use internally by the function
    to denote replaced characters. Attempts to do so could result in an error,
    or unexpected results.
  * The windows key "#" is not supported. In my testing, I was not able to use
    this key properly with my function or the ControlSend function, so I removed
    support for it. If you can give me an example where ControlSend can handle
    it, please email me so that I can release a new version with proper windows
    key support

CONTACT: If you have a suggestion, bug report, or otherwise have a need to
  contact me, You may use the information below. If you find a bug, please
  tell me what text you used as the string parameter, what flag you used, and
  the incorrect output that was returned. It also helps if you list your version
  of the function.
    E-mail: pekster@mail-page.com (preferred method)
    user "pekster" on the HiddenSoft forums at www.hiddensoft.com

ACKNOWLEDGEMENTS: Thanks to all the users on the HiddenSoft forums who supplied
  me with assistance. And a big thanks to Jon, the author of AutoIt version 3.
  www.autoitscript.com/autoit3/

LEGAL: This function is provided without any warranty. This code cannot do any
  damage to your computer by itself. If you use it in such a way to cause harm
  or damage of any kind, it is your own fault.
  You may edit, modify, or distribute this function as you see fit. I would ask
  that if you find a bug, or a feature that could be added or improved, please
  send me a detailed email so that I can release a new version. The only thing
  you may not do is claim that you wrote this code (although feel free to change
  it for use in your projects.) Always remember to give proper credit if you use
  a major portion of someone else's code.

VERSION HISTORY:
  2.0.3 (06/13/2004)
    * Added: return value to match ControlSend (see RETURN above)
  2.0.2 (06/13/2004)
    * Bug fixed: dimension range error when using raw mode (flag 1)
    * I didn't fully get rid of all the code I should have in the 2.0.1 release
  2.0.1 (06/12/2004)
    * Removed a useless If...Else statement that wasn't needed
  2.0 (06/12/2004)
    * Updated to work with special chars like {UP}, {DOWN}, and {ASC ####}
    * Updated to work with key modifiers such as !, ^, and +
    * 3 flag modes added to take care of global vs local issue (see NOTE 1)
    * Name changed to ControlSendPlus to reflect the ability to use the !, ^,
      and + key modifiers (old name was ShiftControlSend)
  1.0 (06/09/2004)
    First release. No readme, and did not work with any special characters or
    modifier keys.