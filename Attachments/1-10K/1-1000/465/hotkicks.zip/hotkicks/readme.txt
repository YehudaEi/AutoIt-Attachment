########################
# HotKicks version 1.0 #
########################

Description

This little program (less than 100kb) lets you take complete (or almost complete) control of your Windows operating system. You can now access important areas and functions of Windows at the press of easy-to-remember hotkey combinations. For example you can

- launch notepad, paint, on-screen keyboard, address book etc easily by holding down the Alt key and pressing the first letter of the accessory program e.g. Alt+n for notepad, Alt+m for Windows Media Player,
- launch the windows Run box by pressing F4,
- shutdown/restart Windows now or at a scheduled time: F8 or Ctrl+F8,
- launch your default browser or email client: Alt+b and Ctrl+Alt+b, 
- check the memory status of your computer: Ctrl+Alt+b, 
- check the free space and disk usage of your hard disk and floppy disk: Ctrl+Alt+h and Ctrl+Alt+f,
- check the Identity of your computer: Computer name, IP addresses etc.: Ctrl+Alt+U,
- Open/Close the default CDROM drive: Win + Alt + d
- display the system properties: Ctrl+Alt+s,
- access the control panel: Ctrl+Alt+p,
- close all windows: Ctrl+F4,
- launch your default screensaver: Win+Alt+s,
- access the display properties: Ctrl+Alt+t,
- add/remove programs: Win+Alt+r,
- launch any of the Microsoft Office programs (if installed): Alt+w for Word, Alt+x for Excel etc,
- defragment your hard disk(s) and shutdown the system: Ctrl+Alt+D,
- explore the root of important folders like Desktop, Program Files etc.: Ctrl+Shift+d, Ctrl+Shift+p etc,
- start windows explorer: F6,
- time events using the built-in timer/reminder Alt+R.
- launch your own personal programs (see "How to use")
- modify any or all of the default hotkey combinations to your    preference (see "How to use"). 
##################################################################################

PRESS F11 (WHEN HOTKICKS IS RUNNING) TO SEE ALL THE AVAILABLE HOTKEY COMBINATIONS.

###################################################################################

How to use

Just place the executable "hotkicks.exe" and the ini file "hotkicks.ini" anywhere you like on your computer. Both files must be in the same folder. Doubleclick on the executable and it will place an icon in the system tray and the hotkeys will become active. You can press F11 at any time for the list of available key combinations. If you find the program useful you can put a shortcut to it in your start-up folder so that it starts with windows. Note that the same key F8 is used to shutdown or reboot the computer. The default function of F8 is shutdown. If what you really want is to reboot the machine then press ESC or click CANCEL after pressing F8 and the computer will reboot. If you change your mind just press ESC again. There is no need to press ENTER or click OK to confirm reboot or shutdown. Pressing ENTER merely accelerates the process and prevents you from being able to change your mind with ESC.

All the hotkey combinations are stored in the file "hotkicks.ini" and can therefore be changed at will by the user. The file hotkicks.ini must be kept in the same folder as the executable "hotkicks.exe". The user can also add custom hotkey combinations to launch his/her personal programs. Programs can also be launched in batch. User defined personal programs/hotkeys are stored in the hotkicks.ini file under section [userprog] and batch programs/hotkeys under [userbat]. If the user messes up the ini file, he/she can generate the default ini file by deleting the messed up ini file and pressing "Win + Alt + h". This way, the executable is completely self contained.

#################################################################

Known issues

Some of the hotkey combinations will work only in Windows Me, Windows 2000, Windows XP or higher. The program is biased towards English language OS but most of the hotkeys will work on Windows machines in other languages. DefragtoShutdown is currently not supported on the NT family of Windows.

###################################################################

License

HotKicks is freeware. What you do with it is entirely up to you. Give copies to your friends and enemies and use for personal or commercial purposes! HotKicks is actually a compiled AutoIt script. Many thanks to Jonathan Bennett and his team (http://www.autoitscript.com/) for creating such an excellent, easy to use scripting language. If you have suggestions or comments you can contact the author at <hotkicks@rushpost.com>.

###################################################################

Disclaimer

The author of HotKicks will not and can not be held responsible for any damage done to you or to your computer or computers as a result of using the program HotKicks. The author does not even guarantee that the program will work as described. You use the program entirely at your own risk. Windows and Microsoft Office are trademarks of the Microsoft Corporation. 