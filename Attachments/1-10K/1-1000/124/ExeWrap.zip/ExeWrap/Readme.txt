To get ExeWrap.exe run Compile ExeWrap.bat.

To get sample.exe run sample.ini through ExeWrap.exe.

Thanks Guys,

*** Matt @ MPCS