MultiClip Help/ReadMe 

MultiClip is a small but quite powerful accessory to the windows clipboard that allows one to have immediate text pasting from up to 10 different saved clipboards.

MultiClip is very easy to use once you learn a few simple key combinations. 

To use MultiClip to paste, put your cursor in any box where you would normally type something, hold the CTRL key and hit the number key on the number pad that already has the text you want stored.  
To store some text into a MultiClip key, you first high lite the text you want, then hold both the CTRL and ALT keys, then hit the number key on the number pad where you would like it stored. If enabled, you will hear the Tada sound telling you that it stored correctly.
MultiClip will store the text for the keys in a file called MultiClip.ini that is located in the same folder as the MultiClip program. The stored text for every key will stay in that ini file until you replace it with some new text.

Some other keys you should know about are: 
Win + h will open this help file.
Win + i will open the MultiClip.ini file in Notepad showing all the saved MultiClip keys and all the text for each one. 	
Win + s will turn the saved sound on or off.
And the ESC key will exit MultiClip.
