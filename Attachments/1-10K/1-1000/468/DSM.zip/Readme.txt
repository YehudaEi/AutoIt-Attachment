DSM (Directory Smart Menu)
V1.1

Welkom to DSM!

This tool you can use to build a simple menu from Folders and Files.
It's small and simple and easy to use. 

DSM is!!.
- Small
- Easy to Use
- Up to 2 levels deep (folder,folder, file)
- Run al populair windows files (txt,exe, e.t.)


Installation:
- Create a folder of your choise
- In the folder that you have created,  create new folders that contains the names (items) of your menu.
- Place the files in the folders.
- Run once DSM.exe
- Run DSM.Hta


It's open on the left corner a new window menu.


Still to Improve:
- Create Bullets instead of folder pictures.
- Space in filenames are still not possible.
- Shortcuts also not work.
- Bmp Files aren't open?


