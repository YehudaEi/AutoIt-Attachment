Network System Info eXplorer

This script scan one or more adress and display a lot of information about system.

System minimum : w2k

You must to have administrator right on all computer you scan, else just name and Mac adress is returned, if possible.
WMI must be active.

use beta v3.1.1.119 or +

