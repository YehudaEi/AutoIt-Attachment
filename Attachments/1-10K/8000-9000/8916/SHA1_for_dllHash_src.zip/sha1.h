/* sha1.h

Copyright (c) 2005 Michael D. Leonhard

http://tamale.net/

AutoIt integration by mu <mr@underperson_hotmail.com> [May-06] 

This file is licensed under the terms described in the
accompanying LICENSE file.
*/



#ifndef SHA1_HEADER
typedef unsigned int Uint32;
typedef unsigned short int uInt2;
typedef unsigned      char uChar;

char * ReturnSHA1Encrypt(uChar DigestMD5[20]);
char * StringSHA1Encrypt(char * sString);
char * FileSHA1Encrypt(char * sFilename);

class SHA1
{
	public:
		SHA1();
		~SHA1();
		void addBytes( const char* data, int num );
 		void getDigest();
		uChar* sDigest() { return digest; }
		
		// utility methods
		static Uint32 SHA1::lrot( Uint32 x, int bits );
		static void SHA1::storeBigEndianUint32( unsigned char* byte, Uint32 num );
		
	private:
		// fields
		Uint32 H0, H1, H2, H3, H4;
		unsigned char bytes[64];
		int unprocessedBytes;
		Uint32 size;
		void process();
    	uChar digest[20];
};


#define SHA1_HEADER
#endif




