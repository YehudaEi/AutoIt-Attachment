         MPC Trainer Template by Faldo

This trainer template is the beginning of a project where
the goal will be to let the creator make a powerfull and 
custumizable trainer without knowing any programming
knowlege at all. All you need is a memory searcher that
uses breakpoints (T-search, cheatengine etc.).


------------------------------------------------------------
Current version (0.2):

- Added possibility to define hotkeys to functions
  Definable HotKeys:
   a-z (case sensitive), 0-9, {HOME}, {END}, {DEL}, {INSERT},
   {PGUP}, {PGDN},{PRINTSCREEN}, {PAUSE}, {NUMPAD0}-{NUMPAD9},
   {NUMPADADD},{NUMPADSUB}, {NUMPADDIV}, {NUMPADDOT}, {LALT},
   {RALT}, {RCTRL}, {LSHIFT}, {RSHIFT}, {F1}-{F12}
  Keys you can't define are: #, !, +, ^, {, }
  Definable "presskeys": ^=Ctrl !=Alt +=Shift #=Win
  Example for Ctrl+DEL:
   Press=^
   HotKey={DEL}
- Static Address Engine
- Fixed a bug resulting in you having to start the trainer
  after the you started the game, or it wouldn't attach.


Version 0.1:
- Customized trainer window
- Textbox
- 3rd level BasePointer engine

------------------------------------------------------------
To do list:
- Tutorial on how to gather 3rd level BasePointers
- Amount of functions defined by the creator
- Amount of BasePointer levels defined by creator



If you find a bug or have ideas about the trainer template,
feel free to contact me at faldoroc@hotmail.com or give me
a PM on www.mpcforum.com.