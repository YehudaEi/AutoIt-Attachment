// main_test.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"

#include <Windows.h>
#include "autoit3.h"

int main(int argc, char* argv[])
{
	// Run the calculator
	AU3_Run("calc.exe", "", 1);

	// Wait for the calulator become active - it is titled "Calculator" on English systems
	AU3_WinWaitActive("Calculator", "", 30);


	// Now that the calc window is active type 2 x 4 x 8 x 16
	// Use AutoItSetOption to slow down the typing speed so we can see it :)
	AU3_AutoItSetOption("SendKeyDelay", 400);
	AU3_Send("2*4*8*16=", 0);
	AU3_Sleep(2000);


	// Now quit by sending a "close" request to the calc
	AU3_WinClose("Calculator", "");

	// Now wait for calc to close before continuing
	AU3_WinWaitClose("Calculator", "", 30);

	// Finished!
	return 0;
}
