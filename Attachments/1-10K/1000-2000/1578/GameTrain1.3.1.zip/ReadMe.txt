GameTrain v1.3
RealTime game macro trainer
Ejoc - sapporarn@yahoo.com

You can use and modify this code as long as you credit me, and dont 
distribute the code in a medium that requires people to pay for it.
It's free!


Overview
This is a macro generator that you can run while playing your game and 
configure it while in the game.

Real Time vs Macro #
Whenever you use a hotkey to set a command it will always added it to the
Real Time Macro.  This is intended to be the macro you program while 
playing the game.  When you use the Commands Menu the command you
select will be placed in the Tab you currently have open.


Script Commands

Left Click
Script Syntax: MouseClick|Mouse Button|X Coordinate|Y Coordinate
Mouse Button: left, right, middle
HotKey: CTRL-ALT-L
Example: MouseClick|left|0|0
Left click the mouse at (0,0)
*As of v1.3 Mouse Button can equal any of the valid mouse buttons, but there 
is only a hot key and menu entry for Left Click

Call Macro
Script Syntax: Execute|Macro #
HotKey: CTRL-ALT-C
Example: Execute|1
Call Macro 1

If PixelIS
Script Syntax: If|PixelIs|Color|X Coordinate|Y Coordinate|Script Command
HotKey: CTRL-ALT-I
Example: If|PixelIs|0xFFFFFF|0|0|Execute|1
If Pixel(0,0) is White then Call Macro 1

If PixelISNot
Script Syntax: If|PixelIsNot|Color|X Coordinate|Y Coordinate|Script Command
HotKey: CTRL-ALT-N
Example: If|PixelIsNot|0xFFFFFF|0|0|Execute|1
If Pixel(0,0) is not White then Call Macro 1

Loop Count
Script Syntax: Repeat|Count|Times to Loop
HotKey: CTRL-ALT-O
Example: Repeat|Count|10
Will loop the macro 10 times
*A macro should only have 1 loop condition, the loop condition can be placed 
anywhere in the macro

Loop Infinate
Script Syntax: Repeat|Infinate
HotKey: CTRL-ALT-O
Example: Repeat|Infinate
Loop the macro infinatly

Loop PixelIs
Script Syntax: Repeat|PixelIs|Color|X Coordinate|Y Coordinate
HotKey: CTRL-ALT-O
Example: Repeat|PixelIs|0x000000|0|0
Repeat the macro while Pixel(0,0) is Black

Loop PixelIsNot
Script Syntax: Repeat|PixelIsNot|Color|X Coordinate|Y Coordinate
HotKey: CTRL-ALT-O
Example: Repeat|PixelIsNot|0x000000|0|0
Repeat the macro while Pixel(0,0) is not Black

Send
Script Syntax: Send|String
HotKey: CTRL-ALT-ENTER
Example: Send|{ENTER}
Press the Enter Key
Example: Send|/help
Send the string /help

Sleep
Script Syntax: Sleep|delay in milliseconds
HotKey: CTRL-ALT-S
Example: Sleep|1000
pause the script for 1 second


HotKeys
Execute a Script:
CTRL-ALT-E Execute Real Time Macro
CTRL-ALT-0 Execute Real Time Macro
CTRL-ALT-[1..9] Execute Macro #

Program Real Time Macro:
CTRL-ALT-R Erase the Real Time Macro
CTRL-ALT-L Left Click
CTRL-ALT-ENTER Send
CTRL-ALT-C Call Macro
CTRL-ALT-O Loop Set
CTRL-ALT-I If PixelIs
CTRL-ALT-N If PixelIsNot
CTRL-ALT-H Halt a running script

Quit:
CTRL-ALT-X Quit
