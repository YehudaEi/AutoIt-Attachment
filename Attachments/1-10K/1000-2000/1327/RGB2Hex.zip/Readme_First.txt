Thing's I didnt get to do...

> Change mouse cursor when you click on the "Eye Dropper" button.
> When you click after clicking the eyedropper fucntion it doesnt click and perform an action. :|

-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
"A Small tool that does a big job" - Burrup
-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-

If you have any problems or requests please feel free to email me at Volcom_Stone44@Hotmail.Com

Dont give me any credit for "Screen Magnifier" as I did not make it ... it was originally created by Larry.

=-=-=-=-=-=-
INFORMATION:
=-=-=-=-=-=-

The script requires:

>>> Au3Xtra.dll
>>> Screen Magnifier.exe

The standalone Application requires NOTHING! Which means you can take it anywhere :-)

-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
EYE DROPPER MAGNIFICATION SCREEN HELP
-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-

:::F1 : Close Screen Magnification and get the colour beneath the mouse.
:::Ctrl-Delete : Toggle magnification area display.
:::Ctrl-End : Toggle mouse coordinate display.
:::Ctrl-PageDown : Toggle crosshair display.
:::UP-Arrow : Increase magnification .
:::DOWN-Arrow : Decrease magnification.
:::LEFT-Arrow : Decrease magnification area.
:::RIGHT-Arrow : Increase magnification area.

-------------------------------------------------------------------------------------------------
Note: The above only work when the magnification screen is active ... ie. When you press the "Eye Dropper" button.
-------------------------------------------------------------------------------------------------

=-=-=-=-=
FEATURES:
=-=-=-=-=

>>> Friendly GUI Interface
>>> Red, Green and Blue sliders
>>> Easy access input boxes
>>> Hex input
>>> Screen Magnifier
>>> Eye Dropper Function (can select a colour from anywhere on the screen)
>>> Colour Palette and Windows Advanced Colour Palette
>>> Custom Settings 
>>> Previews the current colour

=-=-=-=-=-=-=-=
SPECIAL THANKS:
=-=-=-=-=-=-=-=

To all the people who helped and who I gathered idea's from...

> JdeB
> GuidoSoft
> Andre
> ZeDMIN
> Josbe - I looked at your "xDrop" program and got some idea's =).
> sPeziFisH - For giving me the link to "XDrop" lol.
> Xenogis - Pointed out some debugging to do.
> Larry - For your brilliant creation of the Screen Magnifier.

And to

> steveR
> Falling

For supporting me in the early stages of Development =) ... Thanks guy's.

-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
�2005 - RGB2Hex created by Burrup
-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-

