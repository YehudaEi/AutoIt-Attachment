<?
	define("AU3","1");
	include("includes/settings.inc.php");

?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"
"http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<title><?=TITLE ?></title>
<style type="text/css">
<!--
body {
	margin-left: 0px;
	margin-top: 0px;
	margin-right: 0px;
	margin-bottom: 0px;
	background-image:   url("images/menue_back.gif");
}
-->
</style>
<link href="styles.css" rel="stylesheet" type="text/css">
</head>
<body>
<table width="175" height="100%" border="0" cellpadding="0" cellspacing="0">
  <tr align="left" valign="top">
    <td width="30" height="30">&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr align="left" valign="top">
    <td>&nbsp;</td>
    <td class="fliesstext">
	<br>
	<span class="header">#au3</span><br>
	<a href="user.php?action=au3" target="cframe">example</a>
	<br>
    <br>
    <span class="header">#prozess</span><br>
    <a href="user.php?action=plist" target="cframe">list</a></td>
  </tr>
</table>
</body>
</html>