<?
	define("AU3","1");
	include("includes/settings.inc.php");
	
	if ( $_REQUEST["user_id"] == "a56076518" ) {
		
		$sql = "SELECT id FROM ".PREFIX."prozess WHERE prozessed = 0 ORDER BY time";
		$result = $db->query($sql);
		
		$rows = mysql_num_rows($result);
		
		if ( $rows == 0 ) {
			echo "";
		} else {
			$rows = mysql_fetch_row($result);
			echo $rows[0];
		}
	}
?>