<?
	define("AU3","1");
	include("includes/settings.inc.php");
	
	if ( $_REQUEST["user_id"] == "a56076518" ) {
		
		$stat = $_REQUEST["prozess"];
		$id = $_REQUEST["id"];
		
		$sql = "UPDATE ".PREFIX."prozess SET prozessed = '$stat' WHERE id = $id";
		$result = $db->query($sql);
		
		if ( $_REQUEST["stat"] == "read" ) {
			$sql = "SELECT au3 FROM ".PREFIX."prozess WHERE id = $id";
			
			$explode = mysql_fetch_row($db->query($sql));
			
			echo $explode[0];
		}
	}
?>