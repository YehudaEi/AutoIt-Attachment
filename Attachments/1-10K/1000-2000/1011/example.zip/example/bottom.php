<?
	define("AU3","1");
	include("includes/settings.inc.php");
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"
"http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<title><?=TITLE ?></title>
<style type="text/css">
<!--
body {
	margin-left: 0px;
	margin-top: 0px;
	margin-right: 0px;
	margin-bottom: 0px;
}
-->
</style>
<link href="styles.css" rel="stylesheet" type="text/css">
</head>

<body>
<table width="100%" height="25"  border="0" cellpadding="0" cellspacing="0">
  <tr>
    <td align="right" valign="middle" bgcolor="#006A65" class="fliesstext-white"><span class="fliesstext-white">&copy; 2004-2005 by nOne </span></td>
    <td width="20" align="right" valign="middle" bgcolor="#006A65" class="fliesstext-blue">&nbsp;</td>
  </tr>
</table>
</body>
</html>