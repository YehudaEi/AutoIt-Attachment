<?
	define("AU3","1");
	include("includes/settings.inc.php");
	
	$PHPSELF = "user.php";
	
	if ( $_REQUEST["action"] == "" ) {
		$action = "au3";
	} else {
		$action = $_REQUEST["action"];
	}
	
	if ( $action == "au3it" ) {
		if ( $_REQUEST["id"] == "au3" ) {

			$au3 = $_REQUEST["au3"];
			$time = time();
			
			$sql = "INSERT INTO ".PREFIX."prozess SET 
							au3 = '$au3',
							time = '$time',
							prozessed = 0
						 ";
			
			$db->query($sql);
			$id = mysql_insert_id();
			Header("Location: status.php?id=".$id);
			exit;
		} else {
			$action = "au3";
		}
	} elseif ( $action == "pdelit" ) {
		$id = $_REQUEST["id"];
		$sql = "DELETE FROM ".PREFIX."prozess WHERE id = $id";

		$db->query($sql);
		Header("Location:".$PHPSELF."?action=plist");
		exit;
	} elseif ( $action == "peditit" ) {

		$id = $_REQUEST["id"];
		$stat = $_REQUEST["stat"];
		
		$sql = "UPDATE ".PREFIX."prozess SET 
					prozessed = '$stat'
						WHERE id = $id
				 ";
		
		$db->query($sql);
		Header("Location:".$PHPSELF."?action=plist");
		exit;
	}
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Frameset//EN" "http://www.w3.org/TR/html4/frameset.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<title><?=TITLE ?></title>
<style type="text/css">
<!--
body {
	margin-left: 0px;
	margin-top: 0px;
	margin-right: 0px;
	margin-bottom: 0px;
	background-image: url();
}
-->
</style>
<link href="styles.css" rel="stylesheet" type="text/css">
</head>

<body>
<table width="100%" height="100%" cellpadding="0" cellspacing="0">
  <tr>
    <td align="left" valign="top"><table width="100%" cellpadding="0" cellspacing="0">
        <tr>
          <td width="35" rowspan="2" align="left" valign="top">&nbsp;</td>
          <td height="25" align="right" valign="top" bgcolor="#FFFFFF"></td>
        </tr>
        <tr>
          <td align="left" valign="top" bgcolor="#FFFFFF"><table width="100%" cellpadding="0" cellspacing="0">
              <tr>
                <td align="left" valign="top"><?
				if ( $action == "au3" ) {
					
					?>
					<form method="post" action="user.php">
                      <table border="0" cellpadding="3" cellspacing="2" id="table2">
                      <tr bgcolor="#C8D3E1">
                        <td width="135" height="30"><font size="2" face="Arial" class="fliesstext">Au3 :</font></td>
                        <td><font face="Arial">
                          <input name="au3" type="text" id="au3" size="50">
                        </font></td>
                      </tr>
                      <tr bgcolor="#C8D3E1">
                        <td height="30">&nbsp;</td>
                        <td bgcolor="#C8D3E1"><font face="Arial">
                          <input type="submit" value="send" name="send">
                        </font></td>
                      </tr>
                    </table>
                    <input type="hidden" value="au3it" name="action">
					<input type="hidden" value="au3" name="id">
                </form>
					<?
				} elseif ( $action == "plist" ) {

						$weekarray = array("So","Mo","Di","Mi","Do","Fr","Sa");
						$today = getdate(time());
						$day = $weekarray[$today["wday"]]." ".$today["mday"].".".$today["mon"].".".substr($today["year"], 2, 4);
						?>
						<table border="0" cellspacing="0" cellpadding="0" class="sdw">
						  <tr>
							<td class="sdw_border">
								<table border="0" cellpadding="2" cellspacing="0" bgcolor="#FFFFFF" class="tab_list">
									  <tr bgcolor="#004A47">
										<td width="30" align="left" valign="middle" class="header4">nr.</td>
										<td width="300" align="left" valign="middle" class="header4">au3</td>
										<td width="130" align="left" valign="middle" bgcolor="#004A47" class="header4">
										time</td>
										<td width="30" align="left" valign="middle" class="header4">stat</td>
										<td align="right" valign="middle" bgcolor="#004A47" class="header4"><?=$day ?></td>
									  </tr>
						<?
						$i = 1;
						
						$sql = "SELECT * FROM ".PREFIX."prozess ORDER BY time DESC";
						$result = $db->query($sql);

						while( $prozess = mysql_fetch_array($result) ) {
				
							$id = $prozess["id"];
							$au3 = $prozess["au3"];
							$time = $prozess["time"];
							$prozessed = $prozess["prozessed"];
							
							$time = getdate($time);
							
							if (strlen($time["minutes"]) == 1) {
								$time["minutes"] = "0".$time["minutes"];
							}
							if (strlen($time["hours"]) == 1) {
								$time["hours"] = "0".$time["hours"];
							}
							if (strlen($time["seconds"]) == 1) {
								$time["seconds"] = "0".$time["seconds"];
							}
							
							$yesterday = getdate((time()-(60*60*24)));
							
							if ( ($today["wday"] == $time["wday"]) && ($today["mday"] == $time["mday"]) && ($today["year"] == $time["year"]) ) {
								$day = "Today";
							} elseif ( ($yesterday["wday"] == $time["wday"]) && ($yesterday["mday"] == $time["mday"]) && ($yesterday["year"] == $time["year"]) ) {
								$day = "Yesterday";
							} else {
								$day = $weekarray[$time["wday"]]." ".$time["mday"].".".$time["mon"].".".substr($time["year"], 2, 4);
							}

							$time = $day.", ".$time["hours"].":".$time["minutes"]. ":".$time["seconds"];
						?>
									  <tr bgcolor="#E3E8EE" class="tab_bottom_border" onmouseover="this.style.backgroundColor='#CAD3DF'" onmouseout="this.style.backgroundColor='#E3E8EE'">
										<td align="left" valign="middle" class="fliesstext"><?=$i ?>.</td>
										<td align="left" valign="middle" class="fliesstext"><?=$au3 ?></td>
										<td align="left" valign="middle" class="fliesstext"><?=$time ?></td>
										<td align="left" valign="middle" class="fliesstext"><?=$prozessed ?></td>
										<td align="right" valign="middle" class="fliesstext">
										stat: <a href="<?=$PHPSELF ?>?action=peditit&id=<?=$id ?>&stat=0" target="_self">0</a> 
										<a href="<?=$PHPSELF ?>?action=peditit&id=<?=$id ?>&stat=1" target="_self">1</a> 
										<a href="<?=$PHPSELF ?>?action=peditit&id=<?=$id ?>&stat=2" target="_self">2</a> | 
										<a href="<?=$PHPSELF ?>?action=pdelit&id=<?=$id ?>" target="_self">delete</a></td>
								  </tr>
						<?
							$i++;
						}
?>
            </table>
			</td>
			 </tr>
			</table>
					    <?
					}
				?>
                </td>
              </tr>
          </table></td>
        </tr>
    </table></td>
  </tr>
</table>
</body>
</html>
