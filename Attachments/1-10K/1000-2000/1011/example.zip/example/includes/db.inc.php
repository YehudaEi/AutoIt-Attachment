<?
if (!defined("AU3")) die("Hackversuch");

class Mysql {

	var $conn_id;
	var $query_result;
	var $query_count = 0;
	var $query_strings = array();

	function connect($db_host, $db_user, $db_pass, $db_name = "") {
		
		$this->db_host = $db_host;
		$this->db_user = $db_user;
		$this->db_pass = $db_pass;
		$this->db_name = $db_name;
		
		
		$this->conn_id = @mysql_connect($this->db_host, $this->db_user, $this->db_pass);
		
		if (!empty($this->conn_id)) {
			
			if (!empty($db_name)) {
			
				$db_select = @mysql_select_db($this->db_name, $this->conn_id);
				
				if (empty($db_select)) {
				
					@mysql_close($this->conn_id);
					$this->conn_id = $db_select;
				}
				
				return $this->conn_id;
			}
		
		} else {
		
			return FALSE;
		}
	}
	
	function close() {
	
		$result = mysql_close($this->conn_id);
		return $result;
	}
	
	function query($query) {
	
		unset($this->query_result);
		
		if (!empty($query)) {
			
			$this->query_count++;
			$this->query_strings[] = $query;
			$this->query_result = @mysql_query($query, $this->conn_id);
		}
		
		if (!empty($this->query_result)) {
	
			return $this->query_result;
		} else {
		
			echo '<pre>';
			print_r($this->error($this->query_result));
			echo '</pre>';
			print($query);
			
			
			echo "Datenbankfehler";
			//return FALSE;
			exit;
		}
	}
	
	function fetch_array($query_id = 0) {
		
		if (empty($query_id)) {
			
			$query_id = $this->query_result;
		}
		
		if (!empty($query_id)) {
			
			$this->row = @mysql_fetch_array($query_id);
			return $this->row;
		} else {
			
			return FALSE;
		}
	}
	
	function num_rows($query_id = 0) {
			
		if (empty($query_id)) {
			
			$query_id = $this->query_result;
		}
		
		if (!empty($query_id)) {
			
			$result = @mysql_num_rows($query_id);
			return $result;
		} else {
		
			return FALSE;
		}
	}
	
	function insert_id($query_id = 0) {
		
		if (empty($query_id)) {
			
			$query_id = $this->query_result;
		}
		
		if (!empty($query_id)) {
			
			$result = @mysql_insert_id($query_id);
			return $result;
		} else {
		
			return FALSE;
		}
	}
	
	function error() {
	
		$result["message"] = @mysql_error($this->conn_id);
		$result["number"] = @mysql_errno($this->conn_id);

		return $result;
	}
	
	function stats() {
	
		$buffer = "";
		
		$buffer .= "Anzahl Queries: ".$this->query_count."<br>\n<br>\n";
		
		$e = 1;
		for ($i = 0; $i < sizeof($this->query_strings); $i++) {
		
			$buffer .= "Query # ".$e.": ".$this->query_strings[$i]."<br>\n";
			$e++;
		}
		
		echo $buffer;
	
	}
}
?>