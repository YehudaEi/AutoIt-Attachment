<?
if (!defined("AU3")) die ("Hackversuch");

// defines
define("PREFIX","example_");
define("TITLE", "AutoIt with Php Mysql Example");

// includes
include("db.inc.php");

// Datenbank Verbindung aufbauen

$db = new Mysql();

$server = "localhost";
$user = "user";
$password = "pass";
$database = "db";

$db->connect($server, $user, $password, $database);
?>