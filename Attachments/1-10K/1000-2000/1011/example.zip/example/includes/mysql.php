<?
define("AU3", "1");

include("settings.inc.php");

$sql = "CREATE TABLE ".PREFIX."prozess (
					id INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
					au3 TEXT,
					time INT(11),
					prozessed INT(2)
					);";

$db->query($sql);
?>