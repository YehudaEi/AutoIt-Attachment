<?
	define("AU3","1");
	include("includes/settings.inc.php");
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"
"http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<title><?=TITLE ?></title>
<style type="text/css">
<!--
body {
	margin-left: 0px;
	margin-top: 0px;
	margin-right: 0px;
	margin-bottom: 0px;
}
-->
</style>
<link href="styles.css" rel="stylesheet" type="text/css">
<style type="text/css">
<!--
.Stil1 {color: #666666}
-->
</style>
</head>

<body>
<table width="100%" height="50"  border="0" cellpadding="0" cellspacing="0">
  <tr bgcolor="#666666">
    <td width="175" align="center" valign="middle" bgcolor="#2D3F53" class="fliesstext Stil1">&nbsp;</td>
    <td align="left" valign="middle" bgcolor="#2D3F53" class="fliesstext-white"><?=TITLE ?></td>
  </tr>
</table>
</body>
</html>