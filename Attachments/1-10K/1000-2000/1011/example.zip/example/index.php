<?
	define("AU3","1");
	include("includes/settings.inc.php");
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Frameset//EN" "http://www.w3.org/TR/html4/frameset.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<title><?=TITLE ?></title>
</head>

<frameset rows="50,*,25" cols="*" framespacing="0" frameborder="no" border="0">
    <frame src="top.php" name="" frameborder="no" scrolling="no" noresize marginwidth="0" marginheight="0" id="">
      <frameset cols="175,*" framespacing="0" border="0">
	  <frame src="menue.php" name="mframe" frameborder="no" scrolling="no" noresize marginwidth="0" marginheight="0" id="mframe">
	  <frame src="user.php" name="cframe" frameborder="no" scrolling="yes" noresize marginwidth="0" marginheight="0" id="cframe">
	</frameset>
    <frame src="bottom.php" name="" frameborder="no" scrolling="no" noresize marginwidth="0" marginheight="0" id="">
</frameset>
<noframes><body>
</body></noframes>
</html>
