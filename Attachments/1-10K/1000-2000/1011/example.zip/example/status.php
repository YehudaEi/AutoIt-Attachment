<?
	define("AU3","1");
	include("includes/settings.inc.php");
	
	$id = $_REQUEST["id"];
	
	$sql = "SELECT prozessed FROM ".PREFIX."prozess WHERE id = $id";
	$result = $db->query($sql);
	
	$explode = mysql_fetch_row($result);
	
	if ( $explode[0] == 0 ) {
		$meta_refresh = '<meta http-equiv="Refresh" content="2;url=status.php?id='.$_REQUEST["id"].'">';
		$error = "Example AU3 Script currently busy, please wait!";
		$color = "red";
	} elseif ( $explode[0] == 1 ) {
		$meta_refresh = '<meta http-equiv="Refresh" content="2;url=status.php?id='.$_REQUEST["id"].'">';
		$error = "Example AU3 Script has started your request!";
		$color = "orange";
	} elseif ( $explode[0] == 2 ) {
		$meta_refresh = "";
		$error = "Example AU3 Script has finished your request!";
		$color = "green";
	}
	
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Frameset//EN" "http://www.w3.org/TR/html4/frameset.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<? echo $meta_refresh ?>
<title><?=TITLE ?></title>
<style type="text/css">
<!--
body {
	margin-left: 0px;
	margin-top: 0px;
	margin-right: 0px;
	margin-bottom: 0px;
	background-image: url();
}
-->
</style>
<link href="styles.css" rel="stylesheet" type="text/css">
<style type="text/css">
<!--
.Stil1 {
	color: #660066;
	font-weight: bold;
}
.Stil2 {
	color: #FFFF00;
	font-weight: bold;
}
-->
</style>
</head>

<body>
<table width="100%" height="100%" cellpadding="0" cellspacing="0">
  <tr>
    <td align="left" valign="top"><table width="100%" cellpadding="0" cellspacing="0">
        <tr>
          <td width="35" rowspan="2" align="left" valign="top">&nbsp;</td>
          <td height="25" align="right" valign="top" bgcolor="#FFFFFF"></td>
        </tr>
        <tr>
          <td align="left" valign="top" bgcolor="#FFFFFF"><table width="100%" cellpadding="0" cellspacing="0">
              <tr>
                <td align="left" valign="top"><table width="500" border="0" cellspacing="0" cellpadding="0">
                  <tr>
                    <td width="30" height="20" align="left" valign="middle">&nbsp;</td>
                    <td align="left" valign="middle" class="fliesstext-<?=$color ?>"><strong><?=$error ?></strong></td>
                  </tr>
                </table>
                </td>
              </tr>
          </table></td>
        </tr>
    </table></td>
  </tr>
</table>
</body>
</html>
