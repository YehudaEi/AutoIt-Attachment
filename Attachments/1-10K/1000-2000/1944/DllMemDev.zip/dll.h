#ifdef BUILD_DLL
/* DLL export */
#define EXPORT __declspec(dllexport)
#else
/* EXE import */
#define EXPORT __declspec(dllimport)
#endif

EXPORT int SetInt(int,int,int);
EXPORT int SetByte(int,int,int);
EXPORT int ReadInt(int,int);
EXPORT int ReadByte(int,int);
EXPORT int CreateMem(int);
EXPORT void FreeMem(int);
EXPORT int CopyMem(int,int);


