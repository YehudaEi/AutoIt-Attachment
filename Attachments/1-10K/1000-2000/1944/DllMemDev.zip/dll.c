#include <stdlib.h>
#include <string.h>
#include "dll.h"

EXPORT int ReadInt(int lpStruct, int iIndex)
{
	int *i;

	if (!lpStruct || iIndex < 0) return 0;
	i	= (int *)(lpStruct + iIndex);
	
	return *i;
}

EXPORT int SetInt(int lpStruct, int iIndex, int iData)
{
	int *i;

	if (!lpStruct || iIndex < 0) return 0;
	i	= (int *)(lpStruct + iIndex);
	
	*i	= iData;
	return *i;
}

EXPORT int ReadByte(int lpStruct, int iIndex)
{
	char *s;

	if (!lpStruct || iIndex < 0 ) return 0;

	s = (char *)lpStruct;
	return (int)s[iIndex];
}

EXPORT int SetByte(int lpStruct, int iIndex, int iData)
{
	char *s;

	if (!lpStruct || iIndex < 0 ) return 0;

	s = (char *)lpStruct;
	s[iIndex] = (char)iData;
	return (int)s[iIndex];
}

EXPORT int CreateMem(int iSize)
{
	char *mem;

	mem	= (char *)malloc((size_t)iSize);
	if ( ! mem) return 0;
	memset(mem,0,iSize);
	return (int)mem;
}

EXPORT void FreeMem(int mem)
{
	free((void*)mem);
}

EXPORT int CopyMem(int mem, int iSize)
{
	char *s;

	s	= (char *)malloc((size_t)iSize);
	if ( ! s ) return 0;
	memcpy(s,(char*)mem,iSize);
	return (int)s;
}

