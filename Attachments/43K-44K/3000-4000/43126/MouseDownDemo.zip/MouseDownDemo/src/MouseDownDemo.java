import java.io.File;

import com.sun.jna.Library;
import com.sun.jna.Native;
import com.sun.jna.WString;

public class MouseDownDemo {
	public static void main(String[] args) {
		System.load(new File("AutoItX3.dll").getAbsolutePath());
		AutoItX autoItX = (AutoItX) Native.loadLibrary("AutoItX3",
				AutoItX.class);

		System.out.println("Default value for MouseClickDownDelay is: "
				+ autoItX.AU3_Opt(new WString("MouseClickDownDelay"), 10));

		long start = System.currentTimeMillis();
		autoItX.AU3_MouseDown(new WString("left"));
		long end = System.currentTimeMillis();
		autoItX.AU3_MouseUp(new WString("left"));
		System.out.println("end - start = " + (end - start));
		System.out.println();

		// Change MouseClickDownDelay to 1 second
		System.out.println("Previous value for MouseClickDownDelay is: "
				+ autoItX.AU3_Opt(new WString("MouseClickDownDelay"), 1000));

		start = System.currentTimeMillis();
		autoItX.AU3_MouseDown(new WString("left"));
		end = System.currentTimeMillis();
		autoItX.AU3_MouseUp(new WString("left"));
		System.out.println("end - start = " + (end - start));
		System.out.println();

		// Change MouseClickDownDelay to 2 seconds
		System.out.println("Previous value for MouseClickDownDelay is: "
				+ autoItX.AU3_Opt(new WString("MouseClickDownDelay"), 2000));

		start = System.currentTimeMillis();
		autoItX.AU3_MouseDown(new WString("left"));
		end = System.currentTimeMillis();
		autoItX.AU3_MouseUp(new WString("left"));
		System.out.println("end - start = " + (end - start));
		System.out.println();
	}

	protected static interface AutoItX extends Library {
		public void AU3_MouseDown(WString button);

		public void AU3_MouseUp(WString button);

		public int AU3_Opt(WString option, int value);
	}
}
