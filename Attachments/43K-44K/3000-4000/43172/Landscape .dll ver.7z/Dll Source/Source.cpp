using namespace std;
#include "Header.h"

double nPi = 3.14159265358979323846;

extern "C"
{
	DLLEXP int GetRGB(int iR, int iG, int iB)
	{
		return (((iR <= 0) ? (0) : (iR)) * 65536) + (((iG <= 0) ? (0) : (iG)) * 256) + ((iB <= 0) ? (0) : (iB));
	}

	DLLEXP int DrawFrame(pixelMap &newMap, int iTotalFrames, int iCurFrame)
	{
		double SunX = (double)-14 + (((double)39 / ((double)iTotalFrames - (double)1)) * ((double)iCurFrame - (double)1));
		double SunY = -((double)27 / (double)380) * (double)pow(SunX, 2) + ((double)297 / (double)380) * (double)SunX + ((double)945 / (double)38);

		double AmbientLight = SunY / 27;
		int SunRedSaturation = int(0.111 * pow(iCurFrame, 2) - 6.667 * iCurFrame + 100);
		double y; double x; int DirectionalLight; int iRGB;

		for (int iy = 0; iy <= 400; iy++)
		{
			y = -15 + iy * 0.125;
			for (int ix = 0; ix <= 400; ix++)
			{
				x = -20 + ix * 0.125;

				DirectionalLight = int((abs(SunX - (x + 6)) / 39) * 60);

				iRGB = GetRGB(2 * SunRedSaturation, 200 - SunRedSaturation, 200 - SunRedSaturation);
				if (y > sin(x) && y > cos(x) && y < tan(x) && y < sin(nPi * x) + 7 && x < 9)
				{
					iRGB = GetRGB(2 * SunRedSaturation, 0, 0);
				}
				else if ((pow((fmod(abs(x) - nPi / 2, 2 * nPi) - nPi), 2) + pow(y - 8.5 + pow(x, 2) / 250, 2)) < 5 && x < 8)
				{
					iRGB = GetRGB(2 * SunRedSaturation, 87 + int(87 * AmbientLight) - DirectionalLight, 0);
				}
				else if ((pow(fmod(abs(x) + nPi / 2, 2 * nPi) - nPi, 2) + pow(y - 7.5 + pow(x, 2) / 280, 2)) < 5 && x < 11)
				{
					iRGB = GetRGB(2 * SunRedSaturation, 41 + int((double)41 * (double)AmbientLight) - DirectionalLight, 0);
				}
				else if (y <= atan(10 - x))
				{
					iRGB = GetRGB(2 * SunRedSaturation, 87 + int(87 * (AmbientLight)) - DirectionalLight, 0);
				}
				else if (y < ((double)iCurFrame / (double)75) * pow(sin(x * (double)2), 2) + (double)0.5 && y < x - (double)9)
				{
					iRGB = GetRGB(2 * SunRedSaturation, 0, 87 + int(87 * AmbientLight) - DirectionalLight);
				}
				else if (abs(30 - pow(x - SunX, 2) - pow(y - SunY, 2)) == 30 - pow(x - SunX, 2) - pow(y - SunY, 2))
				{
					iRGB = GetRGB(0xFF, 0xFF - 2 * SunRedSaturation, 0);
				}

				newMap.iPixels[iy * 400 + ix + 1] = iRGB;
			}
		}
		return 1;
	}
}
