#ifndef _DLL_AU3_EXPORT
#define _DLL_AU3_EXPORT
#include <iostream>
#include <math.h>
//#include <Windows.h>

#define DLLEXP __declspec(dllexport)

struct pixelMap
{
	unsigned int iPixels[160000];
};

extern "C"
{
	DLLEXP int GetRGB(int iR, int iG, int iB);
	DLLEXP int DrawFrame(pixelMap &newMap, int iTotalFrames, int iCurFrame);
}

#endif // closing #ifndef _DLL_AU3_EXPORT