import java.io.File;

import com.sun.jna.Library;
import com.sun.jna.Native;
import com.sun.jna.WString;

public class WinWaitActiveTest {
	public static void main(String[] args) {
		int SW_SHOWNORMAL = 1;
		System.load(new File("AutoItX3.dll").getAbsolutePath());

		AutoItX autoItX = (AutoItX) Native.loadLibrary("AutoItX3",
				AutoItX.class);

		/* Display and hide tooltip in one thread */
		autoItX.AU3_ToolTip(new WString("Hello 2014."), 400, 200);
		try {
			Thread.sleep(2000);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		autoItX.AU3_ToolTip(null, 400, 200);

		/* Call WinWaitActive in another thread */
		Thread t = new Thread(new Runnable() {
			@Override
			public void run() {
				AutoItX autoItX = (AutoItX) Native.loadLibrary("AutoItX3",
						AutoItX.class);

				System.out.println("#1");
				autoItX.AU3_WinWaitActive(new WString("[CLASS:Notepad]"),
						new WString(""));
				System.out.println("#2");
				autoItX.AU3_WinWaitActive(new WString("�ޱ��� - ���±�"),
						new WString(""));
				System.out.println("#3");
			}
		});
		t.start();

		try {
			Thread.sleep(2000);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		autoItX.AU3_Run(new WString("notepad.exe"), null, SW_SHOWNORMAL);

	}

	protected static interface AutoItX extends Library {
		public int AU3_Run(final WString fileName, final WString workingDir,
				final Integer showFlag);

		public void AU3_ToolTip(final WString text, final Integer x,
				final Integer y);

		public int AU3_WinWaitActive(final WString title, final WString text);
	}
}
