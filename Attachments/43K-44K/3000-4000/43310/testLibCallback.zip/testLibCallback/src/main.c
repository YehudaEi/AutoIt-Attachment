/*
 * main.c
 *
 *  Created on: 05.02.2014
 *      Author: Max Reble
 */


#include <windows.h>
#include <stdio.h>


//Same structure as in autoit
struct TestStruct
{
	int Wert1;
	int Wert2;
};


typedef struct TestStruct* (_stdcall * au3_func)(struct TestStruct *);


void _cdecl OnAutoItFunc(struct TestStruct * func, int iSleep){
	struct TestStruct ret;
	//initalize ret as TestStruct
	ret.Wert1 = 1;
	ret.Wert2 = 1;

	if (func){
		//cast the au3_func
		au3_func MyAu3Func = (au3_func) func;
		//while Wert1 > 0 run the program
		while (ret.Wert1 > 0)
		{
			//Here we start the Test() function in AutoIt
			//As return value we will get a pointer, therefore we need the star
			ret = *MyAu3Func(&ret);
			//and at least we're going to count the data one up/down
			ret.Wert1++;
			ret.Wert2--;
			Sleep(iSleep);
		}
	}
}
