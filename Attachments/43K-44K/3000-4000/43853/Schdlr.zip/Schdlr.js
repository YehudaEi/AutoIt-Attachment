window.onload = function() {
    document.getElementById('set').onclick = function() {
        alert('Set Clicked');

        var sun_start = document.getElementById("sunday-start");
        
        if (sun_start.value == "TBA") {
            sun_start.value = "To Be Announced";
            sun_start.style.background = "yellow";
            
            var sun_end = document.getElementById("sunday-end");
            sun_end.value = "To Be Announced";        
            sun_end.style.background = "yellow";
        }
    }
}