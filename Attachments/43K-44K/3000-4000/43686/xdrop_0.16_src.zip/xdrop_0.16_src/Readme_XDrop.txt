:: ======================================
:: XDrop v0.16
:: ======================================
XDrop it's a color manager/administrator which it allows easily capture it, store or use the info about a color.

Some features:
- "Drag and Drop" functionality.
- Copy to clipboard: RGB, HEX, DEC and CMY formats.
- Easy capture from the screen.
- Get a color from the standard color dialog.
- "Store" a color for future usage.
- Set a color from Clipboard.
- Preview for web colors.

REQUIREMENTS (source file only): 
- AutoIt v3.1+ (http://autoit3.com)
- "Au3xtra.dll" (Normally included - Used for palette tool only) (http://autoitscript.com/forum)
(The executable file don't requires any file/AutoIt or extra file.)


:: ========================================
:: QUICK USAGE GUIDE
:: ========================================
COPY A COLOR INFO TO CLIPBOARD:
Click over color info rectangle (for every available format).
This output selected is copied to clipboard.
Color formats for clipboard output: RGB, HEX, DEC and CMY.

"DRAG AND DROP" FUNCTIONALITY:
Simply dragging, you can:
- Copy from current color to a stack.
- Duplicate a color's stack dragging to another stack.
- Set a color from a stack to the current color.
- Capture a color from the screen.

CAPTURE FROM THE SCREEN:
Drag over and explore the screen and then release it to find a color.
You can use two ways:
- Drag the cursor over the green rectangle.
- Use "Free picker" for capture a color without the main window.
NOTE: For restore the main window and capture the color, use SHIFT+PAUSE keys.

INTERACTIVE MODE:
The color it's displayed at the same time when the sliders are moved.

SETTING A COLOR MANUALLY:
Adding a color manually only accepts from the followings formats: DEC, RGB and HEX.
Write the text and then apply it.

LOCK SLIDERS:
When you lock the sliders, every slider is moved proportionally.
This option don't blocks the movement for any slider.

WEB COLOR PREVIEW:
Small preview for web colors (known like safe colors).
You can click over the icon or color for set to current.

PALETTE:
Displays the Window's standard palette to select a color.

:: ========================================
:: ACKNOWLEDGEMENT
:: ========================================
- Jon and AutoIt Team for AutoIt3 (http://www.autoit3.com)
- Some tips/ideas: Larry(DLL Tips, Au3xtra), JPM and CyberSlug.

:: ========================================
:: HISTORY
:: ========================================
0.16 - (14/03/2005)
- Fixed: Bug with Interactive mode.

0.15 - (09/03/2005)
- Added: X, Y info and Zoom(+,-) for magnifier.
- Added: Crosshair for magnifier.
- Added: Free picker. (pick any color without the main window)
- Added: Option for set a color from an input.
- Added: Option for lock sliders.
- Added: Preview for web colors. (like PS)
- Fixed: Small bug in Hex preffix.
- Some small changes code/cosmetic.

v0.1 (27/12/2004)
* First public release.

:: ========================================
:: NOTES/TODO
:: ========================================
- XDrop, tested under Windows 2000 and XP only.
TODO:
- To implement algorithms for color models: HSL, HSB/HSV and CMYK. :p
  (NOTE: If you have some algorithm/function(tested) from RGB or HEX to these mentioned above, please send it to me email.) ;)


:: ========================================
:: COMMENTS / BUGS / SUGGESTIONS
:: ========================================
� 2004-2005 - J. Sierra "JoSBE" :: (jzcript AT yahoo DOT com)