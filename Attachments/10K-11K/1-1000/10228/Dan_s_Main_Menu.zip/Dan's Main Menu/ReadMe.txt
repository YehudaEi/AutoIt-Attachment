Dan's Main Menu
Coded by: Dan
August 2, 2006
AutoIt V3

Special Thanks: 

Gafrost for the close bug.
codemyster for the clickable link.
Paulie for the Login System

