// AutoItTreeViewExtension.cpp : Defines the initialization routines for the DLL.
//

#include "stdafx.h"
#include <afxdllx.h>
/*
#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif
*/

static AFX_EXTENSION_MODULE AutoItTreeViewExtensionDLL = { NULL, NULL };

extern "C" int APIENTRY
DllMain(HINSTANCE hInstance, DWORD dwReason, LPVOID lpReserved)
{
	UNREFERENCED_PARAMETER(lpReserved);

	if (dwReason == DLL_PROCESS_ATTACH)
	{
		TRACE0("AUTOITTREEVIEWEXTENSION.DLL Initializing!\n");
		
		if (!AfxInitExtensionModule(AutoItTreeViewExtensionDLL, hInstance))
			return 0;

		new CDynLinkLibrary(AutoItTreeViewExtensionDLL);
	}
	else if (dwReason == DLL_PROCESS_DETACH)
	{
		TRACE0("AUTOITTREEVIEWEXTENSION.DLL Terminating!\n");
		AfxTermExtensionModule(AutoItTreeViewExtensionDLL);
	}
	return 1;
}


//
//
// http://www.autoitscript.com/forum/index.php?s=&showtopic=9988&view=findpost&p=72153
// 
//


#include "stdafx.h"
#include "stristr.h"
#include <assert.h>
#include <map>
#include <string>


using namespace std;

// given the hwnd for a listbox, put the contents into a pipe delimited string. however, if there are multiple versions of the same string, append a $$X occurance to the end of each one
const char EXPORT *ExtractListContents(HWND hwnd)
{
    static char results[4096];

    *results = '\0';

    long count = SendMessage(hwnd, LB_GETCOUNT, 0, 0);
    map<string, int> SeenList;

    for (long i = 0; i < count; ++i)
    {
        char item[256] = "";
        SendMessage(hwnd, LB_GETTEXT, i, (long) item);

        int cnt = 0;
        map<string, int>::iterator itr = SeenList.find(string(item));
        if (itr == SeenList.end())
        {
            SeenList.insert(make_pair(string(item), 1));
        } else {
            cnt = ++(*itr).second;
        }
        if (i != 0)
            strcat(results, "|");
        strcat(results, item);
        if (cnt >= 2)
        {
            char tmp[32];
            sprintf(tmp, "$$%d", cnt);
            strcat(results, tmp);
        }
    }
    return results;
}



HTREEITEM BasicExtractTreeNode(HANDLE hProcess, HWND hwndTV, HTREEITEM hItem, TV_ITEM *plvi, int indent, LPTSTR pClipData)
{
    while (hItem)
    {
        TVITEMEX item;
        item.hItem = hItem;
        item.mask = TVIF_TEXT | TVIF_CHILDREN;
        item.pszText = (LPTSTR) (plvi + 1);
        item.cchTextMax = 100;


          // Write the local LV_ITEM structure to the remote memory block
          WriteProcessMemory(hProcess, plvi, &item, sizeof(item), NULL);
        
        if (!TreeView_GetItem(hwndTV, plvi))
            fprintf(stderr, "Error calling SendMessage()\n");

          if (*pClipData) lstrcat(pClipData, __TEXT("\n"));
            char tabs[16] = "\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t";
            if (indent < sizeof(tabs) - 1) tabs[indent] = '\0';
            if (indent) lstrcat(pClipData, tabs);
          // Read the remote text string into the end of our clipboard buffer
          ReadProcessMemory(hProcess, plvi + 1, &pClipData[lstrlen(pClipData)], 1024, NULL);

        // Check whether we have child items.
        if (1) //plvi->cChildren > 0)
        {
            // Recursively traverse child items.

            HTREEITEM hItemChild = TreeView_GetNextItem(hwndTV, hItem, TVGN_CHILD);
            //fprintf(stderr, "Found a parent node, first child is %p\n", (long) hItemChild);
            if (hItemChild) BasicExtractTreeNode(hProcess, hwndTV, hItemChild, plvi, indent + 1, pClipData);

        }

        // Go to next sibling item.
        hItem = TreeView_GetNextItem(hwndTV, hItem, TVGN_NEXT);
        //fprintf(stderr, "Moving onto next sibling which is %p\n", (long) hItem);
    }

    return 0;
}



int EXPORT CopyTreeViewToClipboard(HWND hwnd, HWND hwndTV)
{
    //fprintf(stderr, "CopyTreeViewToClipboard(%p, %pd) called\n", hwnd, hwndTV);
   if (hwndTV == NULL) return 0;


   // Open a handle to the remote process's kernel object
   DWORD dwProcessId;
   GetWindowThreadProcessId(hwndTV, &dwProcessId);
   HANDLE hProcess = OpenProcess(PROCESS_VM_OPERATION | PROCESS_VM_READ | PROCESS_VM_WRITE, FALSE, dwProcessId);

   if (hProcess == NULL) {
      MessageBox(hwnd, __TEXT("Could not communicate with process"), "CopyTreeViewToClipboard", MB_OK | MB_ICONWARNING);
      return 0;
   }

   // Prepare a buffer to hold the TreeView's data.
   // Note: Hardcoded maximum of 10240 chars for clipboard data.
   // Note: Clipboard only accepts data that is in a block allocated with
   //       GlobalAlloc using the GMEM_MOVEABLE and GMEM_DDESHARE flags.
   HGLOBAL hClipData = GlobalAlloc(GMEM_MOVEABLE | GMEM_DDESHARE, sizeof(TCHAR) * 10240);
   LPTSTR pClipData = (LPTSTR) GlobalLock(hClipData);
   pClipData[0] = 0;

   // Allocate memory in the remote process's address space
   TV_ITEM* ptvi = (TV_ITEM*) VirtualAllocEx(hProcess, NULL, 4096, MEM_RESERVE | MEM_COMMIT, PAGE_READWRITE);

    HTREEITEM hItem = (HTREEITEM) SendMessage(hwndTV, TVM_GETNEXTITEM, TVGN_ROOT, 0);
    //fprintf(stderr, "For hwndTV=%p I just found root at %p\n", (long) hwndTV, (long) hItem);

    BasicExtractTreeNode(hProcess, hwndTV, hItem, ptvi, 0, pClipData);

   // Free the memory in the remote process's address space
   VirtualFreeEx(hProcess, ptvi, 0, MEM_RELEASE);

   // Cleanup and put our results on the clipboard
   CloseHandle(hProcess);
   OpenClipboard(hwnd);
   EmptyClipboard();
#ifdef UNICODE
   BOOL fOk = (SetClipboardData(CF_UNICODETEXT, hClipData) == hClipData);
#else
   BOOL fOk = (SetClipboardData(CF_TEXT, hClipData) == hClipData);
#endif
   CloseClipboard();
   if (!fOk) {
      GlobalFree(hClipData);
      MessageBox(hwnd, __TEXT("Error putting text on the clipboard"), "CopyTreeViewToClipboard", MB_OK | MB_ICONINFORMATION);
   }
   return (fOk) ? 1 : 0;
}



int EXPORT CopyListViewToClipboard(HWND hwnd, HWND hwndLV)
{
    //fprintf(stderr, "CopyListViewToClipboard(%p, %pd) called\n", hwnd, hwndLV);
   if (hwndLV == NULL) return 0;


   // Get the count of items in the ListView control
   int nCount = ListView_GetItemCount(hwndLV);

   // Open a handle to the remote process's kernel object
   DWORD dwProcessId;
   GetWindowThreadProcessId(hwndLV, &dwProcessId);
   HANDLE hProcess = OpenProcess(PROCESS_VM_OPERATION | PROCESS_VM_READ | PROCESS_VM_WRITE, FALSE, dwProcessId);

   if (hProcess == NULL) {
      MessageBox(hwnd, __TEXT("Could not communicate with process"), "CopyListViewToClipboard", MB_OK | MB_ICONWARNING);
      return 0;
   }

   // Prepare a buffer to hold the ListView's data.
   // Note: Hardcoded maximum of 10240 chars for clipboard data.
   // Note: Clipboard only accepts data that is in a block allocated with
   //       GlobalAlloc using the GMEM_MOVEABLE and GMEM_DDESHARE flags.
   HGLOBAL hClipData = GlobalAlloc(GMEM_MOVEABLE | GMEM_DDESHARE, sizeof(TCHAR) * 10240);
   LPTSTR pClipData = (LPTSTR) GlobalLock(hClipData);
   pClipData[0] = 0;

   // Allocate memory in the remote process's address space
   LV_ITEM* plvi = (LV_ITEM*) VirtualAllocEx(hProcess, NULL, 4096, MEM_RESERVE | MEM_COMMIT, PAGE_READWRITE);

   // Get each ListView item's text data
   for (int nIndex = 0; nIndex < nCount; nIndex++) {

      // Initialize a local LV_ITEM structure
      LV_ITEM lvi;
      lvi.mask = LVIF_TEXT;
      lvi.iItem = nIndex;
      lvi.iSubItem = 0;
      // NOTE: The text data immediately follows the LV_ITEM structure
      //       in the memory block allocated in the remote process.
      lvi.pszText = (LPTSTR) (plvi + 1);
      lvi.cchTextMax = 100;

      // Write the local LV_ITEM structure to the remote memory block
      WriteProcessMemory(hProcess, plvi, &lvi, sizeof(lvi), NULL);

      // Tell the ListView control to fill the remote LV_ITEM structure
      ListView_GetItem(hwndLV, plvi);

      // If this is not the first item, add a carriage-return/linefeed
      if (nIndex > 0) lstrcat(pClipData, __TEXT("\r\n"));

      // Read the remote text string into the end of our clipboard buffer
      ReadProcessMemory(hProcess, plvi + 1, &pClipData[lstrlen(pClipData)], 1024, NULL);
   }

   // Free the memory in the remote process's address space
   VirtualFreeEx(hProcess, plvi, 0, MEM_RELEASE);

   // Cleanup and put our results on the clipboard
   CloseHandle(hProcess);
   OpenClipboard(hwnd);
   EmptyClipboard();
#ifdef UNICODE
   BOOL fOk = (SetClipboardData(CF_UNICODETEXT, hClipData) == hClipData);
#else
   BOOL fOk = (SetClipboardData(CF_TEXT, hClipData) == hClipData);
#endif
   CloseClipboard();
   if (!fOk) {
      GlobalFree(hClipData);
      MessageBox(hwnd, __TEXT("Error putting text on the clipboard"), "CopyListViewToClipboard", MB_OK | MB_ICONINFORMATION);
   }
   return (fOk) ? 1 : 0;
}

int SneakyGetTreeItemName(HWND hWnd, HTREEITEM hItem, HANDLE hProcess, char *buffer, int buffer_size)
{
   // Allocate memory in the remote process's address space
   TVITEMEX* plvi = (TVITEMEX*) VirtualAllocEx(hProcess, NULL, 4096, MEM_RESERVE | MEM_COMMIT, PAGE_READWRITE);
    long children = 0;

        TVITEMEX item;
        item.hItem = hItem;
        item.mask = TVIF_TEXT | TVIF_CHILDREN;
        item.pszText = (LPTSTR) (plvi + 1);
        item.cchTextMax = buffer_size;

          // Write the local LV_ITEM structure to the remote memory block
          WriteProcessMemory(hProcess, plvi, &item, sizeof(item), NULL);

        if (!TreeView_GetItem(hWnd, plvi))
        {
            fprintf(stderr, "Error calling SendMessage(TVIF_TEXT)\n");
        }

      // Read the remote text string into the end of our clipboard buffer
      ReadProcessMemory(hProcess, plvi + 1, buffer, buffer_size, NULL);
      ReadProcessMemory(hProcess, &plvi->cChildren, &children, sizeof(plvi->cChildren), NULL);     

   // Free the memory in the remote process's address space
   VirtualFreeEx(hProcess, plvi, 0, MEM_RELEASE);
   return children;
}


HTREEITEM EXPORT GetTreeViewItemByName(HWND hWnd, HTREEITEM hItem, const char *szItemName)
{
    //DWORD foo = GetCurrentProcessId();
   // Open a handle to the remote process's kernel object
   DWORD dwProcessId;
   GetWindowThreadProcessId(hWnd, &dwProcessId);
   HANDLE hProcess = OpenProcess(PROCESS_VM_OPERATION | PROCESS_VM_READ | PROCESS_VM_WRITE, FALSE, dwProcessId);

    // If hItem is NULL, start search from root item.
    if (hItem == 0)
    {
        hItem = (HTREEITEM) SendMessage(hWnd, TVM_GETNEXTITEM, TVGN_ROOT, 0);
        //fprintf(stderr, "Incoming hItem for hWnd=%p was null, I just found root at %p\n", (long) hWnd, (long) hItem);
    }
    while (hItem)
    {

        char pClipData[100] = "";

        int children = SneakyGetTreeItemName(hWnd, hItem, hProcess, pClipData, 100);
            //fprintf(stderr, "The current item text is %s\n", pClipData);

        // Did we find it?
        if (stristr(pClipData, szItemName))
        {
            //fprintf(stderr, "I found the requested string, its hItem was %p\n", hItem);
             return hItem;
        }


        // Check whether we have child items.
        if (children > 0)
        {
            // Recursively traverse child items.

            HTREEITEM hItemChild = TreeView_GetNextItem(hWnd, hItem, TVGN_CHILD);
            //fprintf(stderr, "Found a parent node, first child is %p\n", (long) hItemChild);
            HTREEITEM hItemFound = GetTreeViewItemByName(hWnd, hItemChild, szItemName);

            // Did we find it?
            if (hItemFound)
            {
                return  hItemFound;
            }
        }

        // Go to next sibling item.
        hItem = TreeView_GetNextItem(hWnd, hItem, TVGN_NEXT);
        //if (hItem) fprintf(stderr, "Moving onto next sibling which is %p\n", (long) hItem);
    }

    // Not found.
    return 0;
}

int EXPORT SelectTreeViewItem(HWND hWnd, HTREEITEM hItem)
{
    return TreeView_SelectItem(hWnd, hItem);
}

int EXPORT EnsureVisibleTreeViewItem(HWND hWnd, HTREEITEM hItem)
{
    return TreeView_EnsureVisible(hWnd, hItem);
}

int EXPORT ExpandTreeViewItem(HWND hWnd, HTREEITEM hItem)
{
    return TreeView_Expand(hWnd, hItem, TVE_EXPAND);
}

int EXPORT CollapseTreeViewItem(HWND hWnd, HTREEITEM hItem)
{
    return TreeView_Expand(hWnd, hItem, TVE_COLLAPSE);
}

HTREEITEM EXPORT GetSelectedTreeViewItem(HWND hWnd)
{
    return TreeView_GetSelection(hWnd);
}

//
//
// http://www.autoitscript.com/forum/index.php?s=&showtopic=9988&view=findpost&p=74102
// 
// 

HTREEITEM EXPORT GetTreeViewNameByItem(HWND hWnd, HTREEITEM hItem, char *szItemName)
{
    if (!hItem)
    {
        *szItemName = '\0';
        return 0;
    }

    // Open a handle to the remote process's kernel object
    DWORD dwProcessId;
    GetWindowThreadProcessId(hWnd, &dwProcessId);
    HANDLE hProcess = OpenProcess(PROCESS_VM_OPERATION | PROCESS_VM_READ | PROCESS_VM_WRITE, FALSE, dwProcessId);
    SneakyGetTreeItemName(hWnd, hItem, hProcess, szItemName, 100);

    return hItem;
}

HTREEITEM EXPORT TreeViewGetRoot(HWND hWnd)
{
    return (HTREEITEM) SendMessage(hWnd, TVM_GETNEXTITEM, TVGN_ROOT, 0);
}

HTREEITEM EXPORT TreeViewNextChild(HWND hWnd, HTREEITEM hItem)
{
    return TreeView_GetNextItem(hWnd, hItem, TVGN_CHILD);
}

HTREEITEM EXPORT TreeViewNextSibling(HWND hWnd, HTREEITEM hItem)
{
    return TreeView_GetNextItem(hWnd, hItem, TVGN_NEXT);
}