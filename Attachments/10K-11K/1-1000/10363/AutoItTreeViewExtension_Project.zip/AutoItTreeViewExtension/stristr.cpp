// stristr /////////////////////////////////////////////////////////
//
// performs a case-insensitive lookup of a string within another
// (see C run-time strstr)
//
// str1 : buffer
// str2 : string to search for in the buffer
//
// example char* s = stristr("Make my day","DAY");
//
// S.Rodriguez, Jan 11, 2004
//
#include <stdafx.h>
#include "stristr.h"

#pragma warning(disable : 4035)

const char* stristr(const char* str1, const char* str2)
{
  __asm
  {
    mov ah, 'A'
    mov dh, 'Z'

    mov esi, str1
    mov ecx, str2
    mov dl, [ecx]
    test dl,dl; NULL?
    jz short str2empty_label

outerloop_label:
    mov ebx, esi; save esi
    inc ebx
innerloop_label:
    mov al, [esi]
    inc esi
    test al,al
    je short str2notfound_label; not found!

    cmp dl,ah          ; 'A'
    jb short skip1
    cmp dl,dh          ; 'Z'
    ja short skip1
    add dl,'a' - 'A'   ; make lowercase the current character in str2
skip1:        

    cmp al,ah          ; 'A'
    jb short skip2
    cmp al,dh          ; 'Z'
    ja short skip2
    add al,'a' - 'A'   ; make lowercase the current character in str1
skip2:        

    cmp al,dl
    je short onecharfound_label
    mov esi, ebx; restore esi value, +1
    mov ecx, str2; restore ecx value as well
    mov dl, [ecx]
    jmp short outerloop_label; search from start of str2 again
onecharfound_label:
    inc ecx
    mov dl,[ecx]
    test dl,dl
    jnz short innerloop_label
    jmp short str2found_label; found!
str2empty_label:
    mov eax, esi // empty str2 ==> return str1
    jmp short ret_label
str2found_label:
    dec ebx
    mov eax, ebx // str2 found ==> return occurence within str1
    jmp short ret_label
str2notfound_label:
    xor eax, eax // str2 nt found ==> return NULL
    jmp short ret_label
ret_label:
  }
}

#pragma warning(default : 4035)

