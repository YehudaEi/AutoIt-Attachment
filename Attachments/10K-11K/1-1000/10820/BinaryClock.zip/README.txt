Draggable binary clock.

Settings include:

	12/24 hour time formats
	RED, BLUE, GREEN, and AMBER LED's
	Always on top attribue.