Modem-on-hold version 1.72 for SV92P SoftModem

See the Readme for this file at:
http://modemsite.com/56k/moh172.asp

