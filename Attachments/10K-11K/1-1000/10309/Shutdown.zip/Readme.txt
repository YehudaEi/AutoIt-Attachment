Download Beyondexec from http://www.beyondlogic.org
to initiate the shutdown procedure then place it in c:\ as bexec.exe
and compile the script.

