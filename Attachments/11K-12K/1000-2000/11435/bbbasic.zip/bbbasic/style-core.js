if (document.cookie.match(/aufstyle=luna/i)) {
	document.write ('<link rel="stylesheet" href="templates/bbbasic/style/dttvb-luna/css.css" />');
}
function choose_luna() {
	document.cookie = 'aufstyle=luna;expires=' + new Date(new Date().getTime() + 31536000000).toGMTString();
	location.reload ();
}
function choose_aqua() {
	document.cookie = 'aufstyle=aqua;expires=' + new Date(new Date().getTime() + 31536000000).toGMTString();
	location.reload ();
}