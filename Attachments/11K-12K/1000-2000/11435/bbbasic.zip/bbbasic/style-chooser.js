document.write ('<div style="margin-bottom: 0.5em;">');
document.write ('Select a style: [<a href="#" onclick="choose_aqua();return false">Aqua</a>] [<a href="#" onclick="choose_luna();return false">Luna</a>]');
document.write ('</div>');