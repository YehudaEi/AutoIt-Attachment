Gnercules' FishBot Readme
===========================

NOTE: If you hare having toruble reading this helpfile or if the formatting
doesn't look right, open this file in Notepad.

I. Version History
------------------
  =1.0= First release of my fishbot, nothing 
  spectacular but I'm sure many people can
  put it to good use.

  Currently Implemented: 
	* Basic Fishing
	* Pixel Searching Bobber Finder
	* Basic GUI
	* Easily Editable values/variables
	* Bait Support (how many to use/which to use)
	* Number of casts
  
  ==Future Releases==
	* fish counting, tracking, sorting, selecting
	* Enhanced GUI
        * Memory Reading Bobber Finder (Contact me please Outshynd)
	* (send me suggestions)
	* Major Code Cleanup (original version done quickly)
        * Translation (depending on the public ;) )

**Please email me at: ame1011(at)gmail(dot)com with any and all suggestions
for this bot.. as well as any bug reports - (please make sure it is in fact
a bug beofre emailing me about it and I would be more than happy to fix it,)
Any emails about how to get the fishbot to work will be
deleted immediately. Also, for my future releases and in order
to add enhanced functionality, I'm in great need of someone who
can create addons for use in game. The Addon itself would actually be 
rather simple to make (or so I believe). All I require the addon to 
do is read the chat box for certain text, and depending on the text the addon
would display a different colored square on the screen. It is through these
means that I would communicate with the game and through color reading, of 
course, I could add many, if not all of the functions described in the
'==Future Releases==' section. Anybody willing to take my challenge would
recieve technical support for the fishbot as well as personal releases with 
enhanced functionality. (You would basically be using the exact same version
I use). This of course means pre release versions along with other things. 

***If you wish to translate the helpfile and/or the comments in the actual bot
please contact me and I will officially release it and give you proper credit


II. Getting Started
-------------------

-Initial Stuff
==============

*If you haven't already done so, extract all the files to the same
directory.

*You will notice several files in the zipped file. WoWFish.exe, 
WoWFish.au3, WoWFish.ini, Banner.jpg and this readme file. The 
exe file is the compiled version of the script found in the .au3
file. The Banner picture is the image used in the gui and the ini
files contains the variables used by the script (see section IV.)

*If you have Autoit, you may choose to run the au3 file, if you do
not have autoit and you trust me (who knows why anyone would do that :P ),
you can run the corresponding .exe file.

*It is best to run WoW in windowed mode when running this bot and
make sure that window maximized. I have not tested it on full screen
mode so I cannot guarantee it will work on fullscreen.

*Make sure that the 'fishing' skill is put in a spellslot with 
keybinding '0' and the bait (if you choose to use it) is put in 
a spellslot with keybinding '9'.

*Start WoW and find a nice fishing spot. Equipt your fishing pole
and zoom your screen all the way into 1st person view. Change
your view so that the horizon (where the water ends and the sky
begins) is roughly a little more than halfway down your screen so
that there is a little more sky than there is water.
Also, make sure that you are facing away from the moonlight/sunlight
as it makes reflections in the water that may be picked up as splashes
by the bot.

 
- Bot Setup
===========

*When first running the bot, please choose 'Test Mode' to set
up all your variables. After clicking this button, you will 
notice that the GUI will dissapear and focus will be given to
the game window. You now have several buttons you can press:

Press:   
	[1] - GetUnderMouse - This is for advanced users, it shows
	       information of the pixel currently under the mouse
	       including Coordinates and Color so that the user may
	       change values of the ini file manually.   
	 
	[2] - Set X1 and Y1 - Will automatically set the top left
	       most values of your bobber search box, depending on 
	       where your mouse is located at the time.

	[3] - Set X2 and Y2 - Will automatically set the bottom right
	       most values of your bobber search box, depending on 
 	       where your mouse is located at the time.
	
	[4] - View search box - Allows you to visually see the box in
	       which the bot will search for the bobber. I highly 
	       reccomend using this function at the beginning of each
	       session to help you position your view properly. (to do
	       this you would view the search box then position the water
	       inside this box perfectly)

	[5] - Set Pole Coords - You will have to open up your character
	       screen for this. Once it's open, move your mouse over the
	       equipted fishing pole and press '5'. This will set these
	       coords as the pole coords. 

	[PAUSE] - Pressing this button will end the bot regardless of
		   what its doing. You will need to press this button
		   after configuring your bot through test mode or anytime
		   you wish to exit fishbot.

*For most users, all you will need to do here is set the x1, y1, x2
and y2 values of your bobber search box.Each option has a message pop up
when one action was completed successfully, if you do not see this message
it means that you did not set up your coords properly. (in order to use these
options you must first click on the WoW window. 


III. Running The Bot
====================

*You are now ready to get started running the bot.

*Run the bot again, but this time select 'Start Bot'

*I highly reccomend running the bot with verbose mode until it works
perfectly for you. This way, if any errors occur, it is much easier to 
determine where the error is occuring.

*You will be prompted with a message that tells you to cast your line
manually, move your cursor (make sure the tip of the cursor is 
pointed on the red feather precisely) and to press 'z'.Then you
will be asked to quickly move your mouse away from the bobber as the bot
reads the pixel color. 

*When this is complete, the bobber will fade and a new bobber is cast,
signaling the start of the bot.

IV. Troubleshooting
===================

*I've said it many times and I will say it again, I have made this Readme
Idiot proof in hopes of reducing the number of help requests about my bot.
Having said that, if you do need help, DO NOT CONTACT ME! Find a forum and
ask more patient and friendly people.

*Before doing anything, check, doublecheck and triplecheck that all the
customization you did to this bot is correct (coords etc.)

---------------------------------------------------------------------------
|          PROBLEM              |            POSSIBLE SOL'N               |
|-------------------------------|-----------------------------------------|
|				|					  |
| * Bobber not being found      |  *make sure you clicked on the red      |
|                               |    feather properly at bot start.       |
|                               |  *try decreasing feather variance in    |
|                               |    ini file                             |
|                               |  *make sure screen is positioned        |
|                               |    properly                             |
|-------------------------------|-----------------------------------------|
|                               |                                         |
| *Bot clicking random places   |  *see point 1 above                     |
|  on the screen rather than    |  *decrease feather variance             |
|  the bobber.                  |  *decrease splash variance              | 
|                               |                                         |
|-------------------------------|-----------------------------------------|
|                               |                                         |
| *Bot not detecting splash     | *decrease splash variance               |
|		                | *make sure you are facing away from     |
|                               |    light                                |
|				|			  		  |
|-------------------------------|-----------------------------------------|
|				|					  |
| *Instead of finding the       | *because of how the set Feather function|
|   bobber, the bot chooses a   |   works, it records the pixel 3 seconds |
|   pixel (usually top left of  |   after pressing the 'z' button. This   |
|   screen) as bobber coord.    |   means that if the bobber moved out of |
|                               |   the way in those 3 seconds, you may   |
|				|   have recorded the water as the feather| 
|				|   color. Simply restart the script and  |
|				|   click on the feather carefully. NOTE: |
|				|   if the feather spawns too far away to |
|				|   set the Color properly, just recast   |
|				|   until the bobber is close then retry. |
|			        |					  |
|-------------------------------|-----------------------------------------|
|				|					  |
| *Instead of waiting for splash| *turn off the mousemove option in the   |
|   the bot clicks on bobber    |   ini file. This happenes because the   |                           
|   prematurely                 |   bobber gets highlighted when moused   |
|                               |   over and the metallic part of the hook|
|                               |   comes very close to looking like the  |
|                               |   splash.                               |
|                               |                                         |
|-------------------------------|-----------------------------------------|

*And that's it kids.. Enjoy the bot and please feel free to give feedback,
suggestions for future releases and anything else (EXCEPT HELP REQUESTS).
My Email again is ame1011(at)gmail(dot)com. Please email me Mod Makers!!

IV. The InI File
===================

|--------------------|----------------------------------------------------|---------------|
|	             |							  |		  |			
|       Value        |    		      Description                 |	Section   |
|		     |							  |		  |			
|--------------------|----------------------------------------------------|---------------|
|                    |                                                    |		  |	
|     x1,y1,x2,y2    | *These are the coordinates of the box in which to  |    COORDS     |
|	             |   search for the bobber                            |		  |	
|--------------------|----------------------------------------------------|---------------|
|		     |                                                    |		  |	
|    PoleX, PoleY    | *The coordinates of your fishing pole while viewing|    COORDS     |
|		     |   the character screen.				  |		  |	
|		     |							  |		  |			
|--------------------|----------------------------------------------------|---------------|
|		     |                                                    |		  |	
|    msgX, msgY      | *The coordinates of the message tooltip            |    COORDS     |
|		     |  						  |		  |				
|--------------------|----------------------------------------------------|---------------|
|		     |							  |		  | 			
|      Feather       | *The color of the red feather on the bobber, used  |		  |
|		     |   for the bobber search method. This is changed    |    COLOR      |
|                    |   session on bot start                             |	          |
|                    |                                                    |		  |
|--------------------|----------------------------------------------------|---------------|
|		     |						          |		  |			
| Splash_d/Splash_n  | *The color of the splash for both day and night,   |    COLOR      |
|		     |   (depending on time of day, splash varies)        |		  |
|                    |                                                    |		  |
|--------------------|----------------------------------------------------|---------------|
|	             |                                                    |		  |
| Cast/Bait/Character| *Keys used to cast line, use bait, open the        |     Keys	  |
|       Key          |    character screen                                |		  |
|		     |					                  |		  |
|--------------------|----------------------------------------------------|---------------|
|		     |						          |		  |
|     first_run      | *tag used by the bot, __do not edit__              |     Run	  |
|		     |						          |		  |
|--------------------|----------------------------------------------------|---------------|
|		     |							  |		  |			
|     max_run        | *number of runs to complete before bots turns off  |     Run       |
|		     |   this is edited by GUI each session start         |               |
|		     |							  |	          |			
|--------------------|----------------------------------------------------|---------------|
|		     |						          |               |
|       Time         | *Value = day/night, determnes if it's day or night |  Time_of_Day  |
|		     |   value entered each session by bot GUI            |               |
|                    |                                                    |               |
|--------------------|----------------------------------------------------|---------------|
|		     |							  |		  |
|    Test Mode       | *Bot determines if test mode is on, dont touch this|     Mode      |
|                    |                                                    |               |
|--------------------|----------------------------------------------------|---------------|
|		     |							  |		  |
|   Verbose Mode     | *Verbose mode displays messages at key intervals   |     Mode      |
|                    |   throughout runtime to let user know what it's    |               |
|                    |   currently doing. I reccomend using verbose mode  |		  |
|                    |   until the bot works perfectly for you, bacause   |               |
|                    |   if errors do occcur, it's easier to determine    |               |
|                    |   what went wrong.                                 |               |
|                    |                                                    |               |
|--------------------|----------------------------------------------------|---------------|  
|		     |							  |		  |
|    Feather         | *The allowed number of shades of variation of the  |               |
| 		     |   red, green, and blue components of the colour of |   Variance    |
|		     |   feather.                                         |               |
|                    |                                                    |               |
|--------------------|----------------------------------------------------|---------------|
|		     |							  |		  |
|    Splash_day      | *The allowed number of shades of variation of the  |               |
|    Splash_night    |   red, green, and blue components of the colour of |   Variance    |
|		     |   the splashes.                                    |               |
|                    |                                                    |               |
|--------------------|----------------------------------------------------|---------------|
|		     |					  		  |		  |
|  useBait / numBait | *useBait determines if bait support is enabled,    |     Misc      |
|      baitType      |   if so, baitType determines bait entered by user, |               |
|                    |   and numBait determines how much bait you have    |               |
|                    |   of the baitType in your inventory.               |               |
|                    |                                                    |               |
|--------------------|----------------------------------------------------|---------------|
|		     |							  |		  |
|   moveMouse        | *determines if bot should move mouse to bobber when|      Misc     |
|                    |   found. This may be useful at first to determine  |               |
|                    |   if the bot is actually finding the bobber        |               |
|                    |   correctly, but it may cause small problems down  |               |
|                    |   the road as the bobber gets highlighted when     |               |
|                    |   moused over as do the colors.                    |               |
|                    |                                                    |               |
|--------------------|----------------------------------------------------|---------------|
|		     |							  |		  |
|    winTitle        | *title of the WoW Window... [some versions have    |               |
|                    |   different titles (like the german)]              |               |
|                    |                                                    |               |
|--------------------|----------------------------------------------------|---------------|
                   
                  	  
                      

__________________________________________________________________________
                =======================================

In closing, all I have to say is LEEEEERROOOOOOOOYYYYY NNJEEEENNNKKKINNSSS