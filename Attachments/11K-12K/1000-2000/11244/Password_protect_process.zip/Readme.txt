WARNING!!! U HAVE TO COMPILE THE SCRIPTS BEFORE U USE THEM(if u don't use the already compiled ones)

Just change the procces in autostart and the password in tray