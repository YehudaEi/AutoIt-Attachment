=====CUT HERE=====
Arr! I suppose t'ere is no such thin' as somebod' rea's the Rea' me but I will - shiver me timbers - write it 'cause I loke writin'! No, I ain't turned int' Aunt Articts!
(Excuse me for that kind of acting but I've always wanted to be Rockhopper in Club Penguin. Arr!)
=====CUT HERE=====

Media Log: While you read the post, it is reccomended that you listen American Idiot by Green Day.

So, welcome to Alpha Clock. This fellow imitates Vista under XP (ok, not totally...) by using predefined skin I create. Arr, you may use your skin but - shiver me timbers - it has to be really small and made in PNG format. Read more about it in "Create your own skin" section

USING
=========
If you are old granny which is its first time to meet mr. PC you won't know how to use it. I think you've already figured out BUT for those noobs out there I will repeat.
So, when the pal runs, you will see a window which you can grab anywhere and drop anywhere. So, no title bar, but you may click anywhere on its backgrouding skin to move it. Got that? You better.
Then, the small "A in a round" in taskbar makes sure that is that Alpha Clock by i542 running and not some shitty copy.
'hen u click on it, you will see About and Close. Before you close Alpha Clock, read the About so you can meet the developing team.
That is it.

REQUIREMENTS
=========
Looking @ lo3dn's readme for the skin kernel, it is obvious you will need to run Windows XP (but not by me - Windows XP is by Microsoft) but I tested it with my latest application (to date) and it is running smooth on 2000. Erm, at least on 2000 on my very old PC. Whatever.
Also, you will need at least 128 MB to run XP + 1 Mb to run my app. For your system and my program to run smooth, you will also need a 500 MHz processor (I prefer Intel) and any graphic card. You read that correctly - any - cause I don't prefer nor nVidia nor ATI. And, if you want to transfer this app to a friend, burn it to ANY type of media, cause I don't prefer nor HD DVD (ok, I am for it a little) nor Bluray.

CREATE YOUR OWN SKIN
=========
To create your own skin, you will need to have Photoshop installed, and I reccomend CS opened.
Play with all those options but REMEMBER TO SET LAYER OPACITY TO AT LEAST 90. MAY BE SMALLER BUT AT LEAST 90!
Make sure it is modern style and seperate layers for each stage, for example "Border" and "Fill". On  my second thought, you will need only Border and Fill layers.
MAKE SURE YOU DELETE BACKGROUDING LAYER! ("Ooh, you can do that?"). So, or set backgrouding contents to transparent in New window, or delete it when you are done. I reccomend the second way cause you will see what you are doing.
For more info download tutorial (COMING SOON) from www.i542.net/skintut.rtf

ABOUT
=========
Just click on that option in the menu to read, I am too tired to explain it here.

CONCLUSION
=========
If you think that my program sucks, look at yours.

- The i542 Developing Man
*Posted by i542 at 19:42 (GMT +1) on September 14, 2007.*
*Edited by i542 at 19:51 (GMT +1) on September 14, 2007.*
*Edited by MediaLog at 19:52 (GMT +1) on September 14, 2007.*