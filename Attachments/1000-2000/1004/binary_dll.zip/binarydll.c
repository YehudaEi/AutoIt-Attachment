// Autor: YDY (Lazycat)
// Version 1.01 (25.01.05)
// Couple pieces of hex encoding/decoding code taken from Autoit project.

#include <windows.h>
#include <stdio.h>
#include <string.h>

char Hex2dec(char Hex)
{
	if (Hex > 0x40) return (Hex - 'A') + 10;
	else return Hex - '0';
}

BOOL APIENTRY DllMain(HINSTANCE hDLLInst, DWORD fdwReason, LPVOID lpvReserved)
{
    switch (fdwReason)
    {
        case DLL_PROCESS_ATTACH:
            break;
        case DLL_PROCESS_DETACH:
            break;
        case DLL_THREAD_ATTACH:
            break;
        case DLL_THREAD_DETACH:
            break;
    }
    return TRUE;
}

__declspec(dllexport) int FileReadBinary(char *FileName, long offset, long bytes, char *szResult)
{
	FILE* fptr;
	char szHexData[17] = "0123456789ABCDEF";
	char *szHexStr;
	unsigned char curchar;
	int retcode;
	long i, fsize;
	if(fptr=fopen(FileName,"rb"))
		{
			fseek(fptr, 0, SEEK_END);
			fsize = ftell(fptr);
			if (offset > fsize) // can't read beyond file end
	   			{
				fclose(fptr);
				return 0;
				}
			retcode = 1;
			if (bytes == -1) bytes = fsize - offset; // read till file end
			if (offset + bytes > fsize)
				{
					bytes = fsize - offset;
					retcode = 2;
				}
			if (bytes > 32768) return 0; // DllCall limitation
			fseek(fptr, offset, SEEK_SET);
			szHexStr = (char*)malloc(bytes*2+1);
			for (i=0; i < bytes; i++)
				{
					curchar = fgetc(fptr);
					szHexStr[i*2]   = szHexData[curchar >> 4];
					szHexStr[i*2+1] = szHexData[curchar % 16];
				}
			szHexStr[i*2+2] = '\0';
			strcpy(szResult, szHexStr);
			free(szHexStr);
			fclose(fptr);
			return retcode;
		}
	    else return 0;
}

__declspec(dllexport) int FileWriteBinary(char *FileName, char *HexString, long offset)
{
	FILE* fptr, *tptr;
	long i, pos;

	if( !(fptr=fopen(FileName,"r+b")) ) // if not possible open file for read (not exists)
		{
			if(fptr=fopen(FileName,"w+b")) //try to create
				{
					fclose(fptr);
				}
				else return 0;
		}

	if(fptr=fopen(FileName,"r+bw+b"))
		{
			fseek(fptr, 0, SEEK_END);
			pos = ftell(fptr);

			if (offset < pos)
				{
					fseek(fptr, offset, SEEK_SET);
				}
				else
				{
					fseek(fptr, pos, SEEK_SET);
				}

			for (i=0;i < strlen(HexString);i+=2)
				{
					fputc((char)(Hex2dec(HexString[i])*16 + Hex2dec(HexString[i+1])), fptr);
				}
			fflush(fptr);
			fclose(fptr);
			return 1;
		}
	    else return 0;
}
