Sample Name 	: Auto-Complete Combo Box
Author		: Eswar Santhosh
Current Version : 1.0.2

Update History :-
==============

Version 1.0.2, 2004-08-12
-------------------------
When no match was found, the Cursor was always at the zero position instead of at the last character typed.

Version 1.0.1, 2002-11-28
-------------------------
When a character is inserted in the middle of the text and no match was found, the focus always shifted to the end of the TextBox. Reported by : NOFX Junkee (nofxjunkee@hotmail.com)

Version 1.0.0, 2000-07-10
-------------------------
Initial Public Release

					