RunAs - Application Launcher
============================

-EXPLANATION-
   This is an application that allows you to launch 
multiple files and applications as another user 
without having to type your username and password 
multiple times.
   This was initially written for personal use. Our 
family has WinXP at home, and each of our 6 family 
members have different user profiles. I'm essentially 
the administrator of the computer and as such often 
need to access inaccessible files while other people 
are on the computer. So instead of logging that user 
off, or switching users, and logging into another 
account, I can just run this appliation, log into it, 
and access whatever files I need to. It's much like 
the Start > Run dialog built into Windows.

-LOGIN WINDOW-
   The initial window that appears when you run the
program. Use this to choose the user you wish to run
applications as.

-MAIN WINDOW-
   After you log in you're presented with the main 
window. On this window there are several controls. 
There's a textbox where you type what file/program you 
want to run, or you can use the Browse button to 
search for the file you'd like. The OK button will 
attempt to run your file and the Cancel button will 
close the program. There is also a menu bar with two 
items, 'Options' and 'Help'.
- Under the 'Help' menu there is an 'About' item that 
  reviews this help file.
- Under the 'Options' menu there are 5 items:
 - Switch Users
     Opens the login dialog so you can switch users.
 - Clear History
     Clear the history of commands you've run before.
 - Always On Top
     Force the window to always be on top of other
     windows so that you can easily find it.
 - Settings
     Opens a window with more advanced options.
       
-SETTINGS WINDOW-
   If you choose 'Settings' from the 'Options' menu 
you will be presented with a window with the following 
options:
- Save window position
    Ensures that next time you open the program the 
    window will be in the same position as when you 
    last used it.
- Save run history
    Saves the commands you type in the registry so
    that you can easily re-use common commands.
    After changing this setting, the program must be
    restarted.
- Start in tray
    The main window will initially not be visible.
    Instead, an icon will be placed in the system tray
    (the area near the clock in your taskbar). Double
    click this icon to restore the main window.
- Minimize to tray
    When you minimize the application, instead of
    going to the taskbar, an icon will appear in the
    system tray.
- Abduct Windows Run Dialog
    When you open the Windows Run Dialog (Start > Run)
    it will automatically be closed, and RunAs will
    move to it's position near the taskbar. This
    feature is a bit buggy, as it currently only
    supports taskbars on the bottom of the screen,
    and when the option is enabled, the program is
    rather CPU intensive.
- After Run
    After a command is successfully run, the chosen
    action will be performed (Nothing, program exit
    or window minimize).
- Escape Key
    Similar to the above option, when the Escape key
    is pressed on the keyboard the chosen action will
    be performed.
- Confirm before exiting
    Prompts before exiting the program, just in case
    you hit the exit button or Escape key by accident.
- Take over "Run as..." context menu item
    Replace the default Windows "Run as..." context 
    menu item with a duplicate that links to this RunAs 
    program.
    By default, Windows has a built in "Run as..." 
    dialog. You can see it if you right click on a 
    program or a shortcut to a program, such as Notepad.
*** Note: This option will change the setting for all 
    users of the computer. To undo this change, choose 
    this same option, and select No at the following 
    prompt.

============================
Contact: Rob Saunders <rksaunders@gmail.com>