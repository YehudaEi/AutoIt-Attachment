IconSaver 1.2
=============

IconSaver is a small freeware utility that saves and restores icons on the
Desktop window. You can use it and distribute it freely as long as this
Readme.txt file is included with the executables. Feel free to e-mail me about
any bug reports or suggestions.
As from version 1.2, IconSaver includes two extra executables: SaveIcons.exe
and RestoreIcons.exe. You can use those instead of IconSaver if you don't want
IconSaver to be in the memory at all. Every time you want to save icons, just
start SaveIcons.exe and that's it. Program will start, save icons and exit. The
same goes for restoring icons. There will be no messages informing you that
icons are saved/restored.


Help
----

Save Icons - Saves icons' positions for the current resolution. When you
change the screen resolution, icons are automatically restored to saved
positions for that resolution.

Restore Icons - Use it to manually restore icons' positions.

About - Displays "About IconSaver" window.

Hide IconSaver - Removes IconSaver's icon from the tray. After that, whenever
you start the IconSaver, it's icon will not be in the tray, but IconSaver
itself will be in the background. If you want this icon back, just run
IconSaver again (only one application instance will stay in the memory).

Close - Closes the application.



If you want the IconSaver to start at Windows startup, create IconSaver's
shortcut and put it into Startup folder.



History:
--------

IconSaver 1.2
    - Added SaveIcons.exe and RestoreIcons.exe

IconSaver 1.1
    - After displaying a popup menu, clicking anywhere outside the menu didn't
      remove the menu

IconSaver 1.0
    - First release



Mario Knok
E-mail: mknok@ztk.tel.hr
Homepage: members.tripod.com/~nole
