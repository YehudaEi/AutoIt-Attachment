HOW TO USE:

Just extract the Winamp Hotcorner.au3 and captdll.dll to the same place and run the .au3 file. 
Make sure you have a classic skin for winamp, and move the winamp window to the top left corner of the screen... as soon as you move the mouse off the window, it should start to dissapear, simply move the mouse to the top left corner again and pause briefly to bring it back.  
To stop the winamp window dissapearing, just move the mouse to that corner to make the window appear, and move it away from the corner.. as sooon as you put it back, it will disapear again.  Or to quit, press ALT + Q.  If you quit by right clicking the icon in the corner, the winamp window will not reappear.