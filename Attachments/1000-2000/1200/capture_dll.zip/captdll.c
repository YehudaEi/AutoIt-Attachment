#include <windows.h>

BOOL APIENTRY DllMain(HINSTANCE hInstDLL, DWORD fdwReason, LPVOID lpvReserved)
{
    switch (fdwReason)
    {
        case DLL_PROCESS_ATTACH:
            break;
        case DLL_THREAD_ATTACH:
            break;
        case DLL_THREAD_DETACH:
            break;
        case DLL_PROCESS_DETACH:
            break;
    }
    return TRUE;
}

__declspec(dllexport) int WINAPI CaptureRegion(char *filename, int nLeft, int nTop, int nWidth, int nHeight)
{
	HWND hDesktopWnd = GetDesktopWindow(); // Desktop handle
	HDC hDesktopDC = GetDC(hDesktopWnd); // Desktop DC
	
	BITMAPINFO bi;
	void *pBits = NULL;
	ZeroMemory(&bi, sizeof(bi));
	bi.bmiHeader.biSize = sizeof(bi.bmiHeader);
	bi.bmiHeader.biHeight = nHeight;
	bi.bmiHeader.biWidth = nWidth;
	bi.bmiHeader.biPlanes = 1;
	bi.bmiHeader.biBitCount = 24;
	bi.bmiHeader.biCompression = BI_RGB;
	// bitmap width should be aligned by DWORD under NT
	bi.bmiHeader.biSizeImage = ((nWidth * bi.bmiHeader.biBitCount +31)& ~31) /8 * nHeight; 
	
	HDC	hBmpFileDC=CreateCompatibleDC(hDesktopDC);
	HBITMAP	hBmpFileBitmap=CreateDIBSection(hDesktopDC,&bi,DIB_RGB_COLORS,&pBits,NULL,0);
	SelectObject(hBmpFileDC, hBmpFileBitmap);
	BitBlt(hBmpFileDC, 0, 0, nWidth, nHeight, hDesktopDC, nLeft,nTop, SRCCOPY);
    	HANDLE	hFile=CreateFile(filename,GENERIC_WRITE,FILE_SHARE_WRITE,NULL,CREATE_ALWAYS,FILE_ATTRIBUTE_NORMAL,NULL);
	if(hFile!=INVALID_HANDLE_VALUE)
	{
		DWORD	dwRet = 0;
		BITMAPFILEHEADER bfh;

		ZeroMemory(&bfh, sizeof(bfh));
		bfh.bfType = 0x4D42;
		bfh.bfOffBits = sizeof(BITMAPFILEHEADER) + sizeof(BITMAPINFOHEADER);
		bfh.bfSize = bi.bmiHeader.biSizeImage + bfh.bfOffBits;

 		WriteFile(hFile, &bfh, sizeof(bfh), &dwRet, NULL);
		WriteFile(hFile, &bi.bmiHeader, sizeof(bi.bmiHeader), &dwRet, NULL);
		WriteFile(hFile, pBits, bi.bmiHeader.biSizeImage, &dwRet, NULL);
		CloseHandle(hFile);
	} else return 0;
	DeleteDC(hBmpFileDC);
	DeleteObject(hBmpFileBitmap);
   	ReleaseDC(hDesktopWnd,hDesktopDC);
    	return 1;
}

__declspec(dllexport) int WINAPI CaptureScreen(char *filename)
{
	int nWidth = GetSystemMetrics(SM_CXSCREEN);
	int nHeight = GetSystemMetrics(SM_CYSCREEN);
	if (CaptureRegion(filename, 0, 0, nWidth, nHeight)) return 1;
	return 0;
}
