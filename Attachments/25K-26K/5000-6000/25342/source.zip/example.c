
/*
 *
 * AutoIt v3 Plugin SDK - Example
 *
 * Copyright (C)1999-2006 Jonathan Bennett <jon at autoitscript com>
 *
 * example.c
 *
 */

#include <stdio.h>
#include <windows.h>

#include "AU3_Plugin_SDK\au3plugin.h"


/****************************************************************************
 * Function List
 *
 * This is where you define the functions available to AutoIt.  Including
 * the function name (Must be the same case as your exported DLL name), the
 * minimum and maximum number of parameters that the function takes.
 *
 ****************************************************************************/

/* "FunctionName", min_params, max_params */
AU3_PLUGIN_FUNC g_AU3_Funcs[] = 
{
	{"SetConsoleColor", 1, 1}
};


/****************************************************************************
 * AU3_GetPluginDetails()
 *
 * This function is called by AutoIt when the plugin dll is first loaded to
 * query the plugin about what functions it supports.  DO NOT MODIFY.
 *
 ****************************************************************************/

AU3_PLUGINAPI int AU3_GetPluginDetails(int *n_AU3_NumFuncs, AU3_PLUGIN_FUNC **p_AU3_Func)
{
	/* Pass back the number of functions that this DLL supports */
	*n_AU3_NumFuncs	= sizeof(g_AU3_Funcs)/sizeof(AU3_PLUGIN_FUNC);

	/* Pack back the address of the global function table */
	*p_AU3_Func = g_AU3_Funcs;

	return AU3_PLUGIN_OK;
}


/****************************************************************************
 * DllMain()
 *
 * This function is called when the DLL is loaded and unloaded.  Do not 
 * modify it unless you understand what it does...
 *
 ****************************************************************************/

BOOL WINAPI DllMain(HANDLE hInst, ULONG ul_reason_for_call, LPVOID lpReserved)
{
    switch (ul_reason_for_call)
	{
		case DLL_PROCESS_ATTACH:
		case DLL_THREAD_ATTACH:
		case DLL_THREAD_DETACH:
		case DLL_PROCESS_DETACH:
			break;
    }
    return TRUE;
}

AU3_PLUGIN_DEFINE(SetConsoleColor)
{ 
	AU3_PLUGIN_VAR	*pMyResult;
	int				nNum1, nResult;
	HANDLE hConsole;
	hConsole = GetStdHandle(STD_OUTPUT_HANDLE);

	/* Allocate the return variable */
	pMyResult = AU3_AllocVar();

	/* Check the base type of the parameters, if they are not both int32
	   then return 1 */
	if ( AU3_GetType(&p_AU3_Params[0]) != AU3_PLUGIN_INT32 || AU3_GetType(&p_AU3_Params[0]) != AU3_PLUGIN_INT32 )
	{
		AU3_SetInt32(pMyResult, 0);
		*p_AU3_Result		= pMyResult;
		*n_AU3_ErrorCode	= 1;		
		*n_AU3_ExtCode		= 0;
		
		return AU3_PLUGIN_OK;
	}

	/* Two parameters were numbers, get the values */
	nNum1	= AU3_GetInt32(&p_AU3_Params[0]);
    SetConsoleTextAttribute(hConsole, nNum1);
	nResult	= 1;
	AU3_SetInt32(pMyResult, nResult);
	
	/* Pass back the result, error code and extended code.
	 * Note: AutoIt is responsible for freeing the memory used in p_AU3_Result
	 */
	*p_AU3_Result		= pMyResult;
	*n_AU3_ErrorCode	= 0;
	*n_AU3_ExtCode		= 0;

	return AU3_PLUGIN_OK;
}

