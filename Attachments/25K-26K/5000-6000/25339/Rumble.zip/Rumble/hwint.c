/*	
    Copyright 2004 Helder Acevedo

    This file is part of XBCD.

    XBCD is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    XBCD is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with Foobar; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

#include "effdrv.h"
#include <math.h>

void WriteReport(int index, BYTE lVal, BYTE rVal)
{
	//Send a report to the device.

	DWORD	BytesWritten = 0;
	INT		Index =0;
	CHAR	OutputReport[4];
	ULONG	Result;
	HANDLE DeviceHandle;
	TCHAR tsz[32];

	//The first byte is the report number.
	OutputReport[0]=0;
	OutputReport[1]=0;
	OutputReport[2]=lVal;
	OutputReport[3]=rVal;

	DebugPrint("WriteReport 1");
	//wsprintf(tsz, TEXT("%d - %d"), lVal, rVal);
	//DebugPrint(tsz);

	DeviceHandle = CreateFile((LPCTSTR)DevPaths->array[index],
					GENERIC_READ | GENERIC_WRITE,
					FILE_SHARE_READ | FILE_SHARE_WRITE,
					(LPSECURITY_ATTRIBUTES)NULL,
					OPEN_EXISTING,
					0,
					NULL);

	//DebugPrint((LPCTSTR)DevPaths->array[index]);

	//wsprintf(tsz, TEXT("DeviceHandle = %d"), DeviceHandle);
	//DebugPrint(tsz);

	Result = WriteFile 
		(DeviceHandle, 
		OutputReport, 
		sizeof(OutputReport), 
		&BytesWritten, 
		NULL);

	DebugPrint("WriteReport 2");

	if (Result == 0)
	{
		DebugPrint("WriteReport 3");
		CloseHandle(DeviceHandle);
	}

	CloseHandle(DeviceHandle);
}

int ftoi(float f)
{
   int result;

	_asm {
		fld f
		fistp result
		}
	return result;
}

double sine(double x)
{
	double result;

	_asm {
		fld x
		fsin
		fstp result
		}

	return result;
}

DWORD WINAPI TimeProc(LPVOID lpParam)
{
	//Timer Function
	//Runs as long as there is an effect that needs to be played

	bTimerOn = TRUE;
	do
	{
		int iDevCount;
		int iEffectCount;
		BOOLEAN bKillTimer = TRUE;
		TCHAR tsz[32];

		DebugPrint("TimeProc 1");
		DebugPrint("TimeProc 2");
		for(iDevCount = 0; iDevCount < Effects->elements; iDevCount++)
		{
			BYTE LVal = 0;
			BYTE RVal = 0;
			BOOLEAN bHasEffect = FALSE;
			BOOLEAN bStopDevice = TRUE;

			Array tmpEffects = (Array)Effects->array[iDevCount];
			DebugPrint("TimeProc 3");
			for(iEffectCount = 0; iEffectCount < tmpEffects->elements; iEffectCount++)
			{
				PHWEFFECT tmpEffect = (PHWEFFECT)tmpEffects->array[iEffectCount];
				DebugPrint("TimeProc 4");
				bHasEffect = TRUE;
				if(tmpEffect->bPlay)
				{
					DWORD dwCurrentTime;
					DebugPrint("TimeProc 5");
					bStopDevice = FALSE;
					dwCurrentTime = timeGetTime();
					if(((tmpEffect->dwStartTime + (tmpEffect->effect.dwDuration/1000)) > dwCurrentTime) || (tmpEffect->effect.dwDuration == INFINITE))
					{
						DebugPrint("TimeProc 6");
						switch(tmpEffect->dwType)
						{
						case EFFECT_CONSTANT:
							{
								DebugPrint("TimeProc 7");
								if(abs(tmpEffect->fconstant.lMagnitude) > LVal)
									LVal = abs(tmpEffect->fconstant.lMagnitude);

								if(abs(tmpEffect->fconstant.lMagnitude) > RVal)
									RVal = abs(tmpEffect->fconstant.lMagnitude);

								break;
							}
						case EFFECT_SINE:
							{
								double bVal2;
								DebugPrint("TimeProc 7");

								bVal2 = timeGetTime() - tmpEffect->dwStartTime;
								DebugPrint("TimeProc 7.01");
								bVal2 = bVal2/tmpEffect->fperiodic.dwPeriod;
								DebugPrint("TimeProc 7.02");
								bVal2 = 360000 * bVal2;
								DebugPrint("TimeProc 7.03");
								bVal2 = bVal2 * M_PI/180;
								DebugPrint("TimeProc 7.04");
								bVal2 = sine(bVal2);
								DebugPrint("TimeProc 7.05");
								bVal2 = tmpEffect->fperiodic.dwMagnitude * bVal2;

								DebugPrint("TimeProc 7.1");

								if(bVal2 > 0)
								{
									bVal2 = absd(bVal2);
									if(bVal2 > RVal)
									{
										RVal = ftoi(bVal2);
									}
								}
								else
								{
									bVal2 = absd(bVal2);
									if(bVal2 > LVal)
									{
										LVal = ftoi(bVal2);
									}
								}

								break;
							}
						case EFFECT_RAMP:
							{
								LONG diffForce;
								LONG diffTime;
								double bVal2;
								DebugPrint("TimeProc 7");

								diffTime = tmpEffect->effect.dwDuration/1000;

								if(tmpEffect->framp.lEnd > tmpEffect->framp.lStart)
								{
									if(tmpEffect->framp.lStart < 0)
									{
										diffForce = abs(tmpEffect->framp.lEnd) + abs(tmpEffect->framp.lStart);
										bVal2 = diffForce * (timeGetTime() - tmpEffect->dwStartTime)/diffTime;
										if(bVal2 < abs(tmpEffect->framp.lStart))
										{
											bVal2 = abs(tmpEffect->framp.lStart) - bVal2;
											if(bVal2 > LVal)
												LVal = ftoi(bVal2);
										}
										else
										{
											bVal2 = bVal2 - abs(tmpEffect->framp.lStart);
											if(bVal2 > RVal)
												RVal = ftoi(bVal2);
										}
									}
									else
									{
										diffForce = abs(tmpEffect->framp.lEnd) - abs(tmpEffect->framp.lStart);
										bVal2 = diffForce * (timeGetTime() - tmpEffect->dwStartTime)/diffTime;

										bVal2 = bVal2 + abs(tmpEffect->framp.lStart);
										if(bVal2 > RVal)
											RVal = ftoi(bVal2);
									}
								}
								else
								{
									if(tmpEffect->framp.lEnd < tmpEffect->framp.lStart)
									{
										if(tmpEffect->framp.lStart < 0)
										{
											diffForce = abs(tmpEffect->framp.lStart) - abs(tmpEffect->framp.lEnd);
											bVal2 = diffForce * (timeGetTime() - tmpEffect->dwStartTime)/diffTime;

											bVal2 = abs(tmpEffect->framp.lStart) + bVal2;
											if(bVal2 > LVal)
													LVal = ftoi(bVal2);
										}
										else
										{
											diffForce = abs(tmpEffect->framp.lEnd) + abs(tmpEffect->framp.lStart);
											bVal2 = diffForce * (timeGetTime() - tmpEffect->dwStartTime)/diffTime;
											if(bVal2 < abs(tmpEffect->framp.lStart))
											{
												bVal2 = abs(tmpEffect->framp.lStart) - bVal2;
												if(bVal2 > RVal)
													RVal = ftoi(bVal2);
											}
											else
											{
												bVal2 = bVal2 - abs(tmpEffect->framp.lStart);
												if(bVal2 > LVal)
													LVal = ftoi(bVal2);
											}
										}
									}
									else
									{
										if(tmpEffect->framp.lStart < 0)
										{
											if(abs(tmpEffect->framp.lStart) > LVal)
												LVal = abs(tmpEffect->framp.lStart);
										}
										else
										{
											if(abs(tmpEffect->framp.lStart) > RVal)
												RVal = abs(tmpEffect->framp.lStart);
										}
									}
								}
								break;
							}
						case EFFECT_SQUARE:
							{
								double bVal2;
								DebugPrint("TimeProc 7");

								bVal2 = timeGetTime() - tmpEffect->dwStartTime;
								DebugPrint("TimeProc 7.01");
								bVal2 = 1000 * bVal2/tmpEffect->fperiodic.dwPeriod;
								DebugPrint("TimeProc 7.02");
								bVal2 = bVal2 - floor(bVal2);
								DebugPrint("TimeProc 7.03");
								if(bVal2 < 0.5)
								{
									if(tmpEffect->fperiodic.dwMagnitude > RVal)
										RVal = tmpEffect->fperiodic.dwMagnitude;
								}
								else
								{
									if(tmpEffect->fperiodic.dwMagnitude > LVal)
										LVal = tmpEffect->fperiodic.dwMagnitude;
								}
								break;
							}
						case EFFECT_TRIANGLE:
							{
								double bVal2;
								DebugPrint("TimeProc 7");

								bVal2 = timeGetTime() - tmpEffect->dwStartTime;
								DebugPrint("TimeProc 7.01");
								bVal2 = 1000 * bVal2/tmpEffect->fperiodic.dwPeriod;
								DebugPrint("TimeProc 7.02");
								bVal2 = bVal2 - floor(bVal2);
								DebugPrint("TimeProc 7.03");
								if(bVal2 < 0.5)
								{
									if(tmpEffect->fperiodic.dwMagnitude > RVal)
										RVal = tmpEffect->fperiodic.dwMagnitude;
								}
								else
								{
									if(tmpEffect->fperiodic.dwMagnitude > LVal)
										LVal = tmpEffect->fperiodic.dwMagnitude;
								}
								break;
							}
						case EFFECT_SAWTOOTHUP:
							{
								double bVal2;
								DebugPrint("TimeProc 7");

								bVal2 = timeGetTime() - tmpEffect->dwStartTime;
								DebugPrint("TimeProc 7.01");
								bVal2 = 1000 * bVal2/tmpEffect->fperiodic.dwPeriod;
								DebugPrint("TimeProc 7.02");
								bVal2 = bVal2 - floor(bVal2);
								DebugPrint("TimeProc 7.03");
								if(bVal2 < 0.5)
								{
									if(tmpEffect->fperiodic.dwMagnitude > RVal)
										RVal = tmpEffect->fperiodic.dwMagnitude;
								}
								else
								{
									if(tmpEffect->fperiodic.dwMagnitude > LVal)
										LVal = tmpEffect->fperiodic.dwMagnitude;
								}
								break;
							}
						case EFFECT_SAWTOOTHDOWN:
							{
								double bVal2;
								DebugPrint("TimeProc 7");

								bVal2 = timeGetTime() - tmpEffect->dwStartTime;
								DebugPrint("TimeProc 7.01");
								bVal2 = 1000 * bVal2/tmpEffect->fperiodic.dwPeriod;
								DebugPrint("TimeProc 7.02");
								bVal2 = bVal2 - floor(bVal2);
								DebugPrint("TimeProc 7.03");
								if(bVal2 < 0.5)
								{
									if(tmpEffect->fperiodic.dwMagnitude > RVal)
										RVal = tmpEffect->fperiodic.dwMagnitude;
								}
								else
								{
									if(tmpEffect->fperiodic.dwMagnitude > LVal)
										LVal = tmpEffect->fperiodic.dwMagnitude;
								}
								break;
							}
						case CONDITION_SPRING:
							{
								break;
							}

						case CONDITION_FRICTION:
							{
								break;
							}

						case CONDITION_DAMPER:
							{
								break;
							}

						case CONDITION_INERTIA:
							{
								break;
							}
						}
					}
					else
						tmpEffect->bPlay = FALSE;
				}
			}

			if(bHasEffect)
			{
				DebugPrint("TimeProc 8");
				if(bStopDevice || bStopAllDevices)
				{
					LastLVal->array[iDevCount] = 0;
					LastRVal->array[iDevCount] = 0;
					WriteReport(iDevCount, 0, 0);
				}
				else
				{
					bKillTimer = FALSE;
					if((LVal != (BYTE)LastLVal->array[iDevCount]) || (RVal != (BYTE)LastRVal->array[iDevCount]))
					{
						DebugPrint("TimeProc 9");
						LastLVal->array[iDevCount] = LVal;
						LastRVal->array[iDevCount] = RVal;
						//sprintf(tsz, "LVal = %d, RVal = %d", (BYTE)LastLVal->array[iDevCount], (BYTE)LastRVal->array[iDevCount]);
						//DebugPrint(tsz);
						DebugPrint("Sending");
						WriteReport(iDevCount, LVal, RVal);
					}
				}
			}
		}

		DebugPrint("TimeProc 10");

		if(bKillTimer)
		{
			DebugPrint("Finished");
			bTimerOn = FALSE;
		}

		//Allow 10 milliseconds between executions of the loop
		//Let the system do some other work
		Sleep(10);
	}
	while(bTimerOn);

	return 0;
}

double absd(double x)
{
	if(x < 0)
		x = x * -1;
	return x;
}