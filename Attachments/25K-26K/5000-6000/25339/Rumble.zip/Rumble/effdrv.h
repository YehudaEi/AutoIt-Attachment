/*	
    Copyright 2004 Helder Acevedo

    This file is part of XBCD.

    XBCD is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    XBCD is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with Foobar; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

/*****************************************************************************
 *
 *  EffDrv.h
 *
 *  Abstract:
 *
 *      Common header file for the template effect driver.
 *
 *****************************************************************************/
#define DIRECTINPUT_VERSION         0x0700
#define STRICT
#include <windows.h>
#include <objbase.h>
#include <dinput.h>
#include <dinputd.h>
#include "array.h"
#include <math.h>

/*
 /  Effects and conditions supported by the device.
 /  These are random numbers that are passed back to
 /  us when an application wants to create an effect.
 /  Numbers must match the ones in our device's
 /  OEMForceFeedback registry key.
*/

#define EFFECT_CONSTANT     371
#define EFFECT_SINE         723

#define EFFECT_RAMP         125
#define EFFECT_SQUARE       285
#define EFFECT_TRIANGLE     459
#define EFFECT_SAWTOOTHUP   542
#define EFFECT_SAWTOOTHDOWN 863

#define CONDITION_SPRING	916
#define CONDITION_FRICTION	215
#define CONDITION_DAMPER	624
#define CONDITION_INERTIA	591

// The following line is used to enable the DebugPrint statements.
// Comment the line to disable DebugPrint.
//#define DBG 1

#ifdef DBG
#define DebugPrint  OutputDebugString
#else
#define DebugPrint
#endif

#ifndef M_PI
#define M_PI       3.14159265358979323846
#endif

/*****************************************************************************
 *
 *      Declare our structures as packed so the compiler won't pad them.
 *
 *****************************************************************************/

#include <pshpack1.h>

/*****************************************************************************
 *
 *      Our imaginary hardware uses this structure for the RESET command.
 *
 *****************************************************************************/

/*****************************************************************************
 *
 *      We report information about our imaginary hardware's memory usage
 *      with the following private structure.
 *
 *****************************************************************************/

typedef struct HARDWAREINFO {
    WORD   wTotalMemory;
    WORD   wMemoryInUse;
} HARDWAREINFO;

/*****************************************************************************
 *
 *      Finished with our structures.  Restore original packing.
 *
 *****************************************************************************/

#include <poppack.h>

/*****************************************************************************
 *
 *      Internal helper functions that talk to our hardware.
 *
 *****************************************************************************/

typedef struct HWEFFECT {
    DWORD dwType;
	BOOLEAN bBusy;
	DWORD dwStartTime;
	//DWORD dwEndTime;
	BOOLEAN bPlay;
    DIEFFECT effect;
	DICONSTANTFORCE fconstant;
	DIPERIODIC fperiodic;
	DIRAMPFORCE framp;
	DICONDITION fcondition;
} HWEFFECT, *PHWEFFECT;

HANDLE hTimer;
BOOLEAN bTimerOn;
BOOLEAN bStopAllDevices;

Array Devices;
Array DevPaths;
Array Effects;
Array LastLVal;
Array LastRVal;

void WriteReport(int index, BYTE lVal, BYTE rVal);
DWORD WINAPI TimeProc(LPVOID lpParam);
double absd(double x);

HRESULT HWResetDevice(DWORD dwUnit);
HRESULT HWStopAllEffects(DWORD dwUnit);
HRESULT HWGetHardwareInfo(DWORD dwUnit, HARDWAREINFO *pinfo);
HRESULT HWDestroyEffect(DWORD dwUnit, DWORD dwEffect);
HRESULT HWStartEffect(DWORD dwUnit, DWORD dwEffect, DWORD dwMode,
                      DWORD dwCount);
HRESULT HWStopEffect(DWORD dwUnit, DWORD dwEffect);
HRESULT HWGetEffectStatus(DWORD dwUnit, DWORD dwEffect, LPDWORD pdwStatus);

#define MAX_EFFECTS		16
#define MAX_UNITS		16

/*****************************************************************************
 *
 *      Helper functions that help us manager our hardware.
 *
 *****************************************************************************/

HRESULT HWAllocateEffectId(DWORD dwUnit, LPDWORD pdwEffect);
HRESULT HWFreeEffectId(DWORD dwUnit, DWORD dwEffect);

/*****************************************************************************
 *
 *      Static globals:  Initialized at PROCESS_ATTACH and never modified.
 *
 *****************************************************************************/

HINSTANCE g_hinst;       /* This DLL's instance handle */

/*****************************************************************************
 *
 *      Dll global functions
 *
 *****************************************************************************/

STDAPI_(ULONG) DllAddRef(void);
STDAPI_(ULONG) DllRelease(void);

/*****************************************************************************
 *
 *      Class factory
 *
 *****************************************************************************/

STDAPI CClassFactory_New(REFIID riid, LPVOID *ppvObj);

/*****************************************************************************
 *
 *      Effect driver
 *
 *****************************************************************************/

STDAPI CEffDrv_New(REFIID riid, LPVOID *ppvObj);
