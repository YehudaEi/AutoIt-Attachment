/* 
   Array.c -- dynamic array data structure for C

   Copyright (C) 1999  Jonathan H. Badger

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 */

#include <windows.h>
#include <stdlib.h>
#include <stdio.h>
#include <malloc.h>
#include "Array.h"

Array newArray (int maxSize)
{
	Array array = (Array) LocalAlloc(LMEM_ZEROINIT, sizeof(ArrayStruct));

  if (array == NULL) {
    //fprintf (stderr, "not enough memory to allocate Array\n");
    //exit (1);
  }
  else {
    array->maxSize = maxSize;
    array->elements = 0;
    array->dirty = 0;
	array->array = (void **) LocalAlloc(LMEM_ZEROINIT, maxSize * sizeof(void *));
    if (array->array == NULL) {
      //fprintf (stderr, "not enough memory to allocate Array\n");
      //exit (1);
    }
  }
  return array;
}

BOOL addToArray (Array array, void *element)
{
	if (array->elements >= array->maxSize)
	{
		return FALSE;
	}
	else
	{
		array->array[array->elements] = element;
		array->elements += 1;
		array->dirty = 1;
		return TRUE;
	}
}

void freeArray (Array array, void (*freefunc) (void *))
{
  int i;

  for (i = 0; i < array->elements; i++) {
	  LocalFree(array->array[i]);
  }
  LocalFree(array->array);
  LocalFree(array);
}