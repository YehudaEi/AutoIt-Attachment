/*	
    Copyright 2004 Helder Acevedo

    This file is part of XBCD.

    XBCD is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    XBCD is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with Foobar; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

/*****************************************************************************
 *
 *  Main.c
 *
 *  Abstract:
 *
 *      Template effect driver that doesn't actually do anything.
 *
 *****************************************************************************/

#include "effdrv.h"

/*****************************************************************************
 *
 *      Constant globals:  Never change.  Ever.
 *
 *****************************************************************************/

/*
 * !!IHV!! You must run GUIDGEN or UUIDGEN to generate your own GUID/CLSID
 */

CLSID CLSID_MyServer =
{ 0x5a31ddde, 0x75c8, 0x4678, 0x8d, 0xfb, 0x87, 0xd, 0xe5, 0x4e, 0xdd, 0xad };

/*****************************************************************************
 *
 *      Dynamic Globals.  There should be as few of these as possible.
 *
 *****************************************************************************/

ULONG g_cRef;                   /* Global reference count */

/*****************************************************************************
 *
 *      DllAddRef / DllRelease
 *
 *      Adjust the DLL reference count.
 *
 *****************************************************************************/

STDAPI_(ULONG)
DllAddRef(void)
{
    return (ULONG)InterlockedIncrement((LPLONG)&g_cRef);
}

STDAPI_(ULONG)
DllRelease(void)
{
    return (ULONG)InterlockedDecrement((LPLONG)&g_cRef);
}

/*****************************************************************************
 *
 *      DllGetClassObject
 *
 *      OLE entry point.  Produces an IClassFactory for the indicated GUID.
 *
 *****************************************************************************/

STDAPI
DllGetClassObject(REFCLSID rclsid, REFIID riid, LPVOID *ppvObj)
{
    HRESULT hres;

	DebugPrint("DllGetClassObject Entry");

    if (IsEqualGUID(rclsid, &CLSID_MyServer)) {
        hres = CClassFactory_New(riid, ppvObj);
    } else {
        *ppvObj = 0;
        hres = CLASS_E_CLASSNOTAVAILABLE;
    }

	DebugPrint("DllGetClassObject Exit");

    return hres;
}

/*****************************************************************************
 *
 *      DllCanUnloadNow
 *
 *      OLE entry point.  Fail if there are outstanding refs.
 *
 *****************************************************************************/

STDAPI
DllCanUnloadNow(void)
{
	DebugPrint("DllCanUnloadNow");

    return g_cRef ? S_FALSE : S_OK;
}

/*****************************************************************************
 *
 *      DllOnProcessAttach
 *
 *      Initialize the DLL.
 *
 *****************************************************************************/

STDAPI_(BOOL)
DllOnProcessAttach(HINSTANCE hinst)
{
    TCHAR tszName[256];
	LPDIRECTINPUT idii;
	HRESULT hres;
	TCHAR tsz[260];
	g_hinst = hinst;

	DebugPrint("DllOnProcessAttach Entry");

    /*
     *  Performance tweak: We do not need thread notifications.
     */
    DisableThreadLibraryCalls(hinst);

    /*
     *  !!IHV!! Initialize your DLL here.
     */

	Devices = newArray(MAX_UNITS);
	DevPaths = newArray(MAX_UNITS);
	Effects = newArray(MAX_UNITS);
	LastLVal = newArray(MAX_UNITS);
	LastRVal = newArray(MAX_UNITS);

	hres = DirectInputCreate(GetModuleHandle(NULL), DIRECTINPUT_VERSION, (VOID**)&idii, NULL);

	if(hres == DI_OK)
	{
		IDirectInputJoyConfig* pDIJC;
		DIJOYCONFIG diJoyConfig;
		LPDIRECTINPUTDEVICE pDID;
		
		DebugPrint("DInputCreate Success");

		hres = idii->lpVtbl->QueryInterface(idii, &IID_IDirectInputJoyConfig, (LPVOID*)&pDIJC);
		if(hres == S_OK)
		{
			int iDevCount = 0;
			BOOLEAN LastDevice = FALSE;

			diJoyConfig.dwSize = sizeof(DIJOYCONFIG);

			do{
				hres = pDIJC->lpVtbl->GetConfig(pDIJC, iDevCount, &diJoyConfig, DIJC_REGHWCONFIGTYPE | DIJC_GUIDINSTANCE);
				if(hres == DI_OK)
				{
					hres = idii->lpVtbl->CreateDevice(idii, &diJoyConfig.guidInstance, &pDID, NULL);
					if(hres == DI_OK)
					{
						DIPROPGUIDANDPATH dpgp;
						DIPROPSTRING dps;

						memset(&dpgp, 0, sizeof(DIPROPGUIDANDPATH));
						memset(&dps, 0, sizeof(DIPROPSTRING));

						dpgp.diph.dwSize = sizeof(DIPROPGUIDANDPATH);
						dpgp.diph.dwHeaderSize = sizeof(DIPROPHEADER);
						dpgp.diph.dwObj = 0;
						dpgp.diph.dwHow = DIPH_DEVICE;

						dps.diph.dwSize = sizeof(DIPROPSTRING);
						dps.diph.dwHeaderSize = sizeof(DIPROPHEADER);
						dps.diph.dwObj = 0;
						dps.diph.dwHow = DIPH_DEVICE;

						hres = pDID->lpVtbl->GetProperty(pDID, DIPROP_GUIDANDPATH, &dpgp.diph);
						hres = pDID->lpVtbl->GetProperty(pDID, DIPROP_PRODUCTNAME, &dps.diph);
						
						if(hres == DI_OK)
						{
							PTCHAR path = (PTCHAR)LocalAlloc(LMEM_ZEROINIT, 260);
							PINT tempint = (PINT)LocalAlloc(LMEM_ZEROINIT, sizeof(INT));
							PBYTE tempbyte = (PBYTE)LocalAlloc(LMEM_ZEROINIT, sizeof(BYTE));
							Array tmpArray = newArray(MAX_EFFECTS);

							wcstombs(path, dpgp.wszPath, sizeof(dpgp.wszPath));
							DebugPrint(path);

							CopyMemory(tempint, &iDevCount, sizeof(iDevCount));
							addToArray(Devices, *tempint);
							addToArray(DevPaths, path);
							//sprintf(tsz, "%d - %d", DevPaths->elements, iDevCount);
							//DebugPrint(tsz);
							addToArray(Effects, tmpArray);
							addToArray(LastLVal, *tempbyte);
							tempbyte = (PBYTE)LocalAlloc(LMEM_ZEROINIT, sizeof(BYTE));
							addToArray(LastRVal, *tempbyte);
						
							//wcstombs(tsz, dps.wsz, sizeof(dps.wsz));
							//DebugPrint(tsz);
						}
						else
						{
							DebugPrint("Failed 4");
						}

						pDID->lpVtbl->Release(pDID);
					}
					else
					{
						DebugPrint("Failed 3");
					}
				}
				else
				{
					LastDevice = TRUE;
					DebugPrint("Failed 2");
				}
				iDevCount += 1;
			}
			while(!LastDevice);

			pDIJC->lpVtbl->Release(pDIJC);
		}
		else
		{
			DebugPrint("Failed 1");
		}

		idii->lpVtbl->Release(idii);
	}
	else
	{
		DebugPrint("DInputCreate Failed");
	}

	if(!(Devices->elements > 0))
	{
		return FALSE;
	}

	DebugPrint("DllOnProcessAttach Exit");

    return TRUE;

}

/*****************************************************************************
 *
 *      DllOnProcessDetach
 *
 *      De-initialize the DLL.
 *
 *****************************************************************************/

STDAPI_(void)
DllOnProcessDetach(void)
{
    /*
     *  !!IHV!! De-initialize your DLL here.
     */

	//Tell the timer to stop the effects on all devices
	bStopAllDevices = TRUE;
	//Wait up to 5 seconds for the timer to finish
	WaitForSingleObject(hTimer, 5000);
	//Close the handle to the timer thread
	CloseHandle(hTimer);

	DebugPrint("DllOnProcessDetach Entry");

	//Free all the arrays
	freeArray(Devices, NULL);
	freeArray(DevPaths, NULL);
	freeArray(Effects, NULL);
	freeArray(LastLVal, NULL);
	freeArray(LastRVal, NULL);

	DebugPrint("DllOnProcessDetach Exit");
}

/*****************************************************************************
 *
 *      DllEntryPoint
 *
 *      DLL entry point.
 *
 *****************************************************************************/

STDAPI_(BOOL)
DllEntryPoint(HINSTANCE hinst, DWORD dwReason, LPVOID lpReserved)
{
	BOOLEAN hres;
	DebugPrint("DllEntryPoint Entry");

    switch (dwReason) {

    case DLL_PROCESS_ATTACH:
        hres = DllOnProcessAttach(hinst);
		break;
	case DLL_PROCESS_DETACH:
        DllOnProcessDetach();
		hres = TRUE;
        break;
    }

	DebugPrint("DllEntryPoint Exit");

    return hres;
}
