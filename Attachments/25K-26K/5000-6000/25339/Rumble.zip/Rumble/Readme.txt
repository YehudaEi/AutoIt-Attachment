    Copyright 2004 Helder Acevedo

    This file is part of XBCD.

    XBCD is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    XBCD is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with Foobar; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

XBCD - XBox Controller Driver
================================
XBCDR - Rumble DLL version 0.70
================================
Windows 98/2000/XP

To test a force feedback device, get the Fedit utility
from the DirectX SDK.

Project files for both Visual C++ 6 and 7.10 are included.

For more information about Force Feedback drivers,
see the ffdrv sample in the Windows DDK.  This driver
is based on that code.

The implementation for arrays is based on Jonathan H. Badger's
code.



Array.c		- Manages arrays used in the driver
Array.h		- Definitions for Array.c
clsfact.c	- OLE Class Factory
effdrv.c	- Contains the functions that are called by DirectInput
effdrv.h	- Global variables and functions for the driver
effhw.c		- Helper functions for communicating with the hardware
hwint.c		- Contains the functions for sending data to the device
main.c		- Startup and shutdown functions of the dll
Rumble.def	- List of exported functions
Rumble.dsp	- Visual C++ 6.0 Project file
Rumble.dsw	- Visual C++ 6.0 Workspace file
Rumble.rc	- Resource file for version information
Rumble.sln	- Visual Studio 7.10 solution file
Rumble.vcproj	- Visual C++ 7.10 project file



---------------------------
Redcl0ud
http://phaseone.sytes.net