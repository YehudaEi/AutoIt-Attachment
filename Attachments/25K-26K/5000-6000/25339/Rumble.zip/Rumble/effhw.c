/*	
    Copyright 2004 Helder Acevedo

    This file is part of XBCD.

    XBCD is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    XBCD is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with Foobar; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

/*****************************************************************************
 *
 *  EffHw.c
 *
 *  Abstract:
 *
 *      Hardware module.
 *
 *****************************************************************************/

#include "effdrv.h"

/*****************************************************************************
 *
 *      HWAllocateEffectId
 *
 *      Allocate a new effect id on the device if there is a spare one.
 *
 *      Since zero is an invalid effect id, we artificially add 1 to
 *      our internal index, so that we never return 0 by mistake.
 *
 *  dwUnit
 *
 *      Hardware unit number.
 *
 *  pdwEffect
 *
 *      Receives the allocated effect id.
 *
 *  Returns:
 *
 *      S_OK if everything is okay.
 *
 *      DIERR_DEVICEFULL if there is no room left.
 *
 *****************************************************************************/

HRESULT
HWAllocateEffectId(DWORD dwUnit, LPDWORD pdwEffect)
{
    DWORD dwEffect;
	Array tmpArray = (Array)Effects->array[dwUnit];
	TCHAR tsz[32];

    *pdwEffect = 0;

    for (dwEffect = 0; dwEffect < MAX_EFFECTS; dwEffect++)
	{
		DebugPrint("HWAllocateEffectId 1");

		if(dwEffect < tmpArray->elements)
		{
			PHWEFFECT tmpEffect;
			tmpEffect = (PHWEFFECT)tmpArray->array[dwEffect];
			DebugPrint("HWAllocateEffectId 2");
			if(!tmpEffect->bBusy)
			{
				ZeroMemory(tmpEffect, sizeof(HWEFFECT));
				DebugPrint("HWAllocateEffectId 3");
				*pdwEffect = dwEffect + 1;
				break;
			}
		}
		else
		{
			if(tmpArray->elements < tmpArray->maxSize)
			{
				PHWEFFECT tmpEffect = LocalAlloc(LMEM_ZEROINIT, sizeof(HWEFFECT));
				DebugPrint("HWAllocateEffectId 4");
				if(addToArray(tmpArray, tmpEffect))
				{
					DebugPrint("HWAllocateEffectId 4.1");
					*pdwEffect = dwEffect + 1;
					DebugPrint("HWAllocateEffectId 4.2");
				}
				else
					LocalFree(tmpEffect);

				/*wsprintf(tsz, TEXT("tmpArray %d, dwEffect %d"), tmpArray->elements, dwEffect);
				DebugPrint(tsz);*/
			}
			break;
		}

    }
	DebugPrint("HWAllocateEffectId 5");

    return (*pdwEffect == 0) ? DIERR_DEVICEFULL : S_OK;
}

/*****************************************************************************
 *
 *      HWFreeEffectId
 *
 *      Release an effect id, making it available for future allocation.
 *
 *      Since zero is an invalid effect id, we artificially added 1 to
 *      our internal index.  Subtract off that 1 to get the internal
 *      index back.
 *
 *  dwUnit
 *
 *      Hardware unit number.
 *
 *  dwEffect
 *
 *      The effect to be freed.
 *
 *  Returns:
 *
 *      S_OK if everything is okay.
 *
 *      E_HANDLE if the handle is not allocated.
 *
 *****************************************************************************/

HRESULT
HWFreeEffectId(DWORD dwUnit, DWORD dwEffect)
{
    HRESULT hres;
	Array tmpArray = (Array)Effects->array[dwUnit];
	PHWEFFECT tmpEffect;
	TCHAR tsz[32];

	DebugPrint("HWFreeEffectId 1");

	//wsprintf(tsz, TEXT("dwUnit %d, dwEffect %d"), dwUnit, dwEffect);
	//DebugPrint(tsz);
	hres = S_OK;
	if(dwEffect <= tmpArray->elements)
	{
		DebugPrint("HWFreeEffectId 2");
		tmpEffect = (PHWEFFECT)tmpArray->array[dwEffect - 1];
		if(tmpEffect->bBusy)
		{
			tmpEffect->bBusy = FALSE;
			DebugPrint("HWFreeEffectId 3");
		}
		else
		{
			hres = E_HANDLE;
		}
	}
	else
	{
		hres = E_HANDLE;
	}

    return hres;
}

/*****************************************************************************
 *
 *      HWResetDevice
 *
 *      Reset the device.
 *
 *      In addition to telling the device to reset itself, we also
 *      mark all the effect slots in the device as "Free".
 *
 *  dwUnit
 *
 *      Hardware unit number.
 *
 *****************************************************************************/

HRESULT
HWResetDevice(DWORD dwUnit)
{
    int iEffect;
	Array tmpArray = (Array)Effects->array[dwUnit];
	PHWEFFECT tmpEffect;

	DebugPrint("HWResetDevice Entry");

    /*
     *  Mark all effects as no longer busy (hence "free").
     */

	for(iEffect = 0; iEffect < tmpArray->elements; iEffect++)
	{
		tmpEffect = (PHWEFFECT)tmpArray->array[iEffect];
		tmpEffect->bPlay = FALSE;
		tmpEffect->bBusy = FALSE;
	}

    return S_OK;
}

/*****************************************************************************
 *
 *      HWStopAllEffects
 *
 *      Stop all playing effects.
 *
 *  dwUnit
 *
 *      Hardware unit number.
 *
 *****************************************************************************/

HRESULT
HWStopAllEffects(DWORD dwUnit)
{
	Array tmpArray = (Array)Effects->array[dwUnit];
	PHWEFFECT tmpEffect;
	int iCount;

	for(iCount = 0; iCount < tmpArray->elements; iCount++)
	{
		tmpEffect = (PHWEFFECT)tmpArray->array[iCount];
		tmpEffect->bPlay = FALSE;
	}

    return S_OK;
}

/*****************************************************************************
 *
 *      HWGetHardwareInfo
 *
 *      Retrieve information about the hardware usage.
 *
 *  dwUnit
 *
 *      Hardware unit number.
 *
 *  pinfo
 *
 *      Pointer to HARDWAREINFO structure that receives info about
 *      the device's memory information.
 *
 *****************************************************************************/

HRESULT
HWGetHardwareInfo(DWORD dwUnit, HARDWAREINFO *pinfo)
{
    /*
     *  We do device memory management on the host side, so no
     *  actual commands need to be sent.
     *
     *  The wMemoryInUse is the number of effects that are
     *  downloaded, and the wTotalMemory is the total number
     *  of effects we support.
     */
    int iEffect;
	Array tmpArray = (Array)Effects->array[dwUnit];
	PHWEFFECT tmpEffect;

    pinfo->wTotalMemory = MAX_EFFECTS;
    pinfo->wMemoryInUse = 0;

	for(iEffect = 0; iEffect < tmpArray->elements; iEffect++)
	{
		tmpEffect = (PHWEFFECT)tmpArray->array[iEffect];
		if(tmpEffect->bBusy)
		{
			pinfo->wMemoryInUse++;
		}
	}

    return S_OK;
}

/*****************************************************************************
 *
 *      HWDestroyEffect
 *
 *      Internal function that destroys an effect.
 *
 *  dwUnit
 *
 *          Hardware unit number.
 *
 *  dwEffect
 *
 *          The effect being destroyed.
 *
 *****************************************************************************/

HRESULT
HWDestroyEffect(DWORD dwUnit, DWORD dwEffect)
{
    return HWFreeEffectId(dwUnit, dwEffect);
}

/*****************************************************************************
 *
 *      HWStartEffect
 *
 *      Internal function that starts playback of an effect.
 *
 *  dwUnit
 *
 *          Hardware unit number.
 *
 *  dwEffect
 *
 *          The effect to start.
 *
 *  dwMode
 *
 *          Flags specifying how this effect should interact with
 *          other effects.
 *
 *          DIES_SOLO - Stop all other effects when playing this one.
 *
 *          DirectInput handles the DIES_NODOWNLOAD flag internally;
 *          we will never see it.
 *
 *  dwCount
 *
 *          Number of times to play the effect.
 *
 *****************************************************************************/

HRESULT
HWStartEffect(DWORD dwUnit, DWORD dwEffect, DWORD dwMode, DWORD dwCount)
{
	TCHAR tsz[32];
	DebugPrint("HWStartEffect 1");

    /*
     *  We don't support hardware DIES_SOLO, so we fake it by manually
     *  stopping all other effects first.
     */
    if (dwMode & DIES_SOLO)
	{
        HWStopAllEffects(dwUnit);
    }
	DebugPrint("HWStartEffect 2");

    /*
     *  If we are actually being asked to play the effect, then play it.
     */
    if (dwCount)
	{
		Array tmpArray = (Array)Effects->array[dwUnit];
		PHWEFFECT tmpEffect = (PHWEFFECT)tmpArray->array[dwEffect - 1];

		DebugPrint("HWStartEffect 3");

		DebugPrint("HWStartEffect 4");
		tmpEffect->dwStartTime = timeGetTime();
		//tmpEffect->dwEndTime = tmpEffect->dwStartTime + (tmpEffect->effect.dwDuration/1000);
		//wsprintf(tsz, TEXT("dwDuration = %d"), tmpEffect->effect.dwDuration);
		//DebugPrint(tsz);
		DebugPrint("HWStartEffect 5");
		tmpEffect->bPlay = TRUE;
		DebugPrint("HWStartEffect 6");

		DebugPrint("HWStartEffect 7");

		//Start the timer only if it's not on already
		if(!bTimerOn)
		{
			DWORD threadId;
			DebugPrint("HWStartEffect 8");
			//Close the handle to the timer thread
			CloseHandle(hTimer);
			//Create a new thread and set TimeProc as its starting function
			hTimer = CreateThread(NULL, 0, TimeProc, NULL, 0, &threadId);
			//Set the thread's priority to critical.  Might not be needed
			SetThreadPriority(hTimer, THREAD_PRIORITY_TIME_CRITICAL);
		}
    }

	DebugPrint("HWStartEffect 9");

    return S_OK;
}

/*****************************************************************************
 *
 *      HWStopEffect
 *
 *      Internal function that stops playback of an effect.
 *
 *  dwUnit
 *
 *          Hardware unit number.
 *
 *  dwEffect
 *
 *          The effect to stop.
 *
 *****************************************************************************/

HRESULT HWStopEffect(DWORD dwUnit, DWORD dwEffect)
{
	Array tmpArray = (Array)Effects->array[dwUnit];
	PHWEFFECT tmpEffect = (PHWEFFECT)tmpArray->array[dwEffect - 1];
	//Set the bPlay flag to false so that the timer doesn't play
	//the effect
	tmpEffect->bPlay = FALSE;

    return S_OK;
}

/*****************************************************************************
 *
 *      HWGetEffectStatus
 *
 *      Internal function that determines whether an effect is still playing.
 *
 *  dwUnit
 *
 *          Hardware unit number.
 *
 *  dwEffect
 *
 *          The effect to query.
 *
 *  pdwStatus
 *
 *          Receives effect status.
 *
 *          0 - not playing
 *          DIEGES_PLAYING - still playing
 *
 *****************************************************************************/

HRESULT
HWGetEffectStatus(DWORD dwUnit, DWORD dwEffect, LPDWORD pdwStatus)
{
	Array tmpArray = (Array)Effects->array[dwUnit];
	PHWEFFECT tmpEffect = (PHWEFFECT)tmpArray->array[dwEffect - 1];

	//Check the bPlay flag for this effect to see if it's
	//being played
    if (tmpEffect->bPlay) {
        *pdwStatus = DIEGES_PLAYING;
    } else {
        *pdwStatus = 0;
    }
    return S_OK;
}
