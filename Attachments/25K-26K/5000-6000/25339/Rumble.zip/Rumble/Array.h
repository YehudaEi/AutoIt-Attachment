#ifndef __ARRAY_H
#define __ARRAY_H

typedef struct {
  int elements;
  int maxSize;
  int dirty;
  void **array;
} ArrayStruct;

typedef ArrayStruct *Array;

Array newArray(int maxSize);
BOOL addToArray(Array array, void * element);
void freeArray(Array array, void (*freefunc) (void *));

#endif /* __ARRAY_H */