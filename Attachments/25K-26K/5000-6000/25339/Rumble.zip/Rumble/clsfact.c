/*	
    Copyright 2004 Helder Acevedo

    This file is part of XBCD.

    XBCD is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    XBCD is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with Foobar; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

/*****************************************************************************
 *
 *  CFact.c
 *
 *  Abstract:
 *
 *      Class factory.
 *
 *****************************************************************************/

#include "effdrv.h"

/*****************************************************************************
 *
 *      CClassFactory_AddRef
 *
 *      Optimization: Since the class factory is static, reference
 *      counting can be shunted to the DLL itself.
 *
 *****************************************************************************/

STDMETHODIMP_(ULONG)
CClassFactory_AddRef(IClassFactory *pcf)
{
	DebugPrint("CClassFactory_Addref");
    return DllAddRef();
}


/*****************************************************************************
 *
 *      CClassFactory_Release
 *
 *      Optimization: Since the class factory is static, reference
 *      counting can be shunted to the DLL itself.
 *
 *****************************************************************************/

STDMETHODIMP_(ULONG)
CClassFactory_Release(IClassFactory *pcf)
{
	DebugPrint("CClassFactory_Release");
    return DllRelease();
}

/*****************************************************************************
 *
 *      CClassFactory_QueryInterface
 *
 *      Our QI is very simple because we support no interfaces beyond
 *      ourselves.
 *
 *****************************************************************************/

STDMETHODIMP
CClassFactory_QueryInterface(IClassFactory *pcf, REFIID riid, LPVOID *ppvOut)
{
    HRESULT hres;

	DebugPrint("CClassFactory_QueryInterface Entry");

    if (IsEqualIID(riid, &IID_IUnknown) ||
        IsEqualIID(riid, &IID_IClassFactory)) {
        CClassFactory_AddRef(pcf);
        *ppvOut = pcf;
        hres = S_OK;
    } else {
        *ppvOut = 0;
        hres = E_NOINTERFACE;
    }

	DebugPrint("CClassFactory_QueryInterface Exit");
    return hres;
}

/*****************************************************************************
 *
 *      CClassFactory_CreateInstance
 *
 *      Create the effect driver object itself.
 *
 *****************************************************************************/

STDMETHODIMP
CClassFactory_CreateInstance(IClassFactory *pcf, IUnknown *punkOuter,
                             REFIID riid, LPVOID *ppvObj)
{
    HRESULT hres;

	DebugPrint("CClassFactory_CreateInstance Entry");

    if (punkOuter == 0) {
        hres = CEffDrv_New(riid, ppvObj);
    } else {
        /*
         *  We don't support aggregation.
         */
        hres = CLASS_E_NOAGGREGATION;
    }

	DebugPrint("CClassFactory_CreateInstance Exit");

    return hres;
}

/*****************************************************************************
 *
 *      CClassFactory_LockServer
 *
 *****************************************************************************/

STDMETHODIMP
CClassFactory_LockServer(IClassFactory *pcf, BOOL fLock)
{

	DebugPrint("CClassFactory_LockServer Entry");

    if (fLock) {
        DllAddRef();
    } else {
        DllRelease();
    }

	DebugPrint("CClassFactory_LockServer Exit");

    return S_OK;
}

/*****************************************************************************
 *
 *      The VTBL for our Class Factory
 *
 *****************************************************************************/

IClassFactoryVtbl CClassFactory_Vtbl = {
    CClassFactory_QueryInterface,
    CClassFactory_AddRef,
    CClassFactory_Release,
    CClassFactory_CreateInstance,
    CClassFactory_LockServer,
};

/*****************************************************************************
 *
 *      Our static class factory.
 *
 *****************************************************************************/

IClassFactory g_cf = { &CClassFactory_Vtbl };

/*****************************************************************************
 *
 *      CClassFactory_New
 *
 *****************************************************************************/

STDMETHODIMP
CClassFactory_New(REFIID riid, LPVOID *ppvOut)
{
    HRESULT hres;

	DebugPrint("CClassFactory_New Entry");

    /*
     *  Attempt to obtain the desired interface.  QueryInterface
     *  will do an AddRef if it succeeds.
     */
    hres = CClassFactory_QueryInterface(&g_cf, riid, ppvOut);

	DebugPrint("CClassFactory_New Exit");

    return hres;

}
