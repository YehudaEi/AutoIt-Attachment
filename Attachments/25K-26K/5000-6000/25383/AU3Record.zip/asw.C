#include <windows.h>
#include <stdio.h>

#define EDIT_HEADER "Opt(\"WinWaitDelay\",100)\r\nOpt(\"WinTitleMatchMode\",4)\r\nOpt(\"WinDetectHiddenText\",1)\r\nOpt(\"MouseCoordMode\",0)\r\n"
#define APP_CLASS "AU3Record"

// *************************************************
// Global Variables
// *************************************************

HINSTANCE	g_hInstance;

HHOOK		hhKeyboard,hhMouse;
HINSTANCE	DLLinst;
WNDPROC		Hook_WndProc;

BOOL		bALT,bCTRL,bSHIFT,bLWIN,bRWIN,bAPPS,bJustHooked,bStdOut=FALSE;
BOOL		bUseWinText=FALSE,bRecMouse=TRUE,bRecNHide=TRUE,bHookin=FALSE,bTimer=FALSE;
BOOL		bDBLClick=FALSE,bPrevDBLClick=FALSE,bLMouseDwn=FALSE,bRMouseDwn=FALSE;

HWND		Form1,hookCtrl,editCtrl,runCtrl,Browse1,g_FOCme;
HWND		RMbutton,WTbutton,Hbutton,SVbutton,SVASbutton,EXbutton,Desc1,Desc2;
HWND		Record1,Left1,Right1,RecStop1;
HWND		cur_hWnd;

HICON		icoRed,icoBlue;

char		cur_Text[21];
char		next_Text[21];
char		cur_Title[513];
char		next_Title[513];
char		szKeyTxt[256][14];

RECT		winSIZE, winPOS;
POINT		xyMouse;
int		xPrevMouse,yPrevMouse;
UINT		nTimer=1;

HANDLE		*fp1;

char		*pszDisplayStr,*pszMouseBuff,*pszTmpStr,*pszDisplayChg,*pszSaveAs;

// *************************************************
// Function Prototypes
// *************************************************

void	ChangeFONT(HWND, char*,int,int);
void	InitFONT(HWND);
void	Run (char*);

char*   GetFileName(char*,char*,char*,int);
void    FormLoad (void);

LRESULT CALLBACK WndProc (HWND, UINT, WPARAM, LPARAM);
LRESULT CALLBACK Message_Handler (HWND, UINT, WPARAM, LPARAM);
void    SubClassDumbBMP (void);

BOOL	CALLBACK EnumChildWinProc (HWND, LPARAM);
BOOL	getTheText (void);

void    WinAble (BOOL);
void    StartHookin (void);
void    StopHookin (void);
void    LoadszKeyTxt (void);
void	SaveScript(void);
void	RetrieveScript(void);
char	*command(int);

void	_cmbstring(char **, char *);
void	_newstring(char **, char *, size_t);

// *************************************************
// Entry Point
// *************************************************

int WINAPI WinMain(HINSTANCE hInst,HINSTANCE hPrev,LPSTR CmdLine,int CmdShow)
{
	WNDCLASS	Wc;
	MSG		Msg;
	
	if(_stricmp(command(1),"/o")==0) bStdOut=TRUE;
		
	_newstring(&pszDisplayStr,(char*)"",1);
	_newstring(&pszDisplayChg,(char*)"",1);
	_newstring(&pszMouseBuff,(char*)"",1);
	_newstring(&pszTmpStr,(char*)"",1);
	_newstring(&pszSaveAs,(char*)"",1);
	
	g_hInstance    =  hInst;

	Wc.style         =  CS_HREDRAW | CS_VREDRAW | CS_OWNDC;
	Wc.lpfnWndProc   =  WndProc;
	Wc.cbClsExtra    =  0;
	Wc.cbWndExtra    =  0;
	Wc.hInstance     =  hInst;
	Wc.hIcon         =  LoadIcon(hInst,MAKEINTRESOURCE(123));
	Wc.hCursor       =  LoadCursor(NULL,IDC_ARROW);
	Wc.hbrBackground =  (HBRUSH)(COLOR_BTNFACE+1);
	Wc.lpszMenuName  =  NULL;
	Wc.lpszClassName =  APP_CLASS;
	RegisterClass(&Wc);

	FormLoad();

	while(GetMessage(&Msg,NULL,0,0))
	{
		HWND hActiveWindow = GetActiveWindow();
		if( !IsWindow(hActiveWindow) || !IsDialogMessage(hActiveWindow,&Msg) )
		{
			TranslateMessage(&Msg);
			DispatchMessage(&Msg);
		}
	}
	return Msg.wParam;
}

void FormLoad (void)
{
	int s,h;
	if(bStdOut)
	{
		h=124;
		s=WS_CAPTION|WS_SYSMENU|WS_MINIMIZEBOX|WS_GROUP;
	}
	else
	{
		h=500;
		s=WS_MINIMIZEBOX|WS_GROUP|WS_SIZEBOX|WS_CAPTION|WS_MAXIMIZEBOX|WS_SYSMENU;
	}
	Form1 = CreateWindowEx(WS_EX_TOPMOST,APP_CLASS,"AU3Record 3.1 - ( Made for AutoIt v3 )",
			s,CW_USEDEFAULT,CW_USEDEFAULT,510,h,NULL,(HMENU)NULL,g_hInstance,NULL);
	hookCtrl = CreateWindowEx(0,"static","",WS_CHILD,-10,-10,5,5,Form1,(HMENU)NULL,g_hInstance,NULL);
	Hbutton = CreateWindowEx(0,"button","S&hrink Window During Record",WS_CHILD|WS_VISIBLE|BS_AUTOCHECKBOX|WS_TABSTOP,
			95,8,180,16,Form1,(HMENU)101,g_hInstance,NULL);
	InitFONT(Hbutton);
	WTbutton = CreateWindowEx(0,"button","Record Window &Text",WS_CHILD|WS_VISIBLE|BS_AUTOCHECKBOX|WS_TABSTOP,
			95,24,180,16,Form1,(HMENU)102,g_hInstance,NULL);
	InitFONT(WTbutton);
	RMbutton = CreateWindowEx(0,"button","Record &Mouse",WS_CHILD|WS_VISIBLE|BS_AUTOCHECKBOX|WS_TABSTOP,
			95,40,180,16,Form1,(HMENU)103,g_hInstance,NULL);
	InitFONT(RMbutton);
	Desc1 = CreateWindowEx(0,"static","  Run('",SS_CENTERIMAGE|SS_SUNKEN|WS_CHILD|WS_VISIBLE,
			95,60,400,26,Form1,(HMENU)NULL,g_hInstance,NULL);
	InitFONT(Desc1);
	Desc2 = CreateWindowEx(0,"static","\')",SS_CENTERIMAGE|WS_CHILD|WS_VISIBLE,
			398,63,15,20,Form1,(HMENU)NULL,g_hInstance,NULL);
	InitFONT(Desc2);
	Left1 = CreateWindowEx(0,"static","<",SS_CENTERIMAGE|WS_CHILD,
			0,0,20,25,Form1,(HMENU)NULL,g_hInstance,NULL);
	Right1 = CreateWindowEx(0,"static",">",SS_CENTERIMAGE|WS_CHILD,
			74,0,20,25,Form1,(HMENU)NULL,g_hInstance,NULL);
	RecStop1 = CreateWindowEx(0,"static","Click To Record",SS_CENTERIMAGE|WS_CHILD|WS_VISIBLE,
			7,70,85,15,Form1,(HMENU)NULL,g_hInstance,NULL);
	InitFONT(RecStop1);
	ChangeFONT(Left1,"",18,600);
	ChangeFONT(Right1,"",18,600);

	runCtrl = CreateWindowEx(WS_EX_CLIENTEDGE,"edit","",WS_GROUP|WS_CHILD|WS_VISIBLE|WS_TABSTOP|ES_LEFT|ES_AUTOHSCROLL,
			135,63,260,20,Form1,(HMENU)NULL,g_hInstance,NULL);
	InitFONT(runCtrl);
	Browse1 = CreateWindowEx(WS_EX_WINDOWEDGE,"button","&Browse",WS_CHILD|WS_GROUP|WS_VISIBLE|BS_PUSHBUTTON|WS_TABSTOP,
			420,63,68,20,Form1,(HMENU)201,g_hInstance,NULL);
	InitFONT(Browse1);
	if(!bStdOut)
	{
		SVbutton = CreateWindowEx(WS_EX_WINDOWEDGE,"button","&Save",WS_CHILD|WS_GROUP|WS_VISIBLE|BS_PUSHBUTTON|WS_TABSTOP,
			290,8,70,20,Form1,(HMENU)302,g_hInstance,NULL);
		InitFONT(SVbutton);
		SVASbutton = CreateWindowEx(WS_EX_WINDOWEDGE,"button","Save &As",WS_CHILD|WS_GROUP|WS_VISIBLE|BS_PUSHBUTTON|WS_TABSTOP,
			290,36,70,20,Form1,(HMENU)303,g_hInstance,NULL);
		InitFONT(SVASbutton);
	}
	char szButtText[12];
	if(bStdOut)
		strcpy(szButtText,"&Cancel");
	else
		strcpy(szButtText,"E&xit");
		
	EXbutton = CreateWindowEx(WS_EX_WINDOWEDGE,"button",szButtText,WS_CHILD|WS_GROUP|WS_VISIBLE|BS_PUSHBUTTON|WS_TABSTOP,
			370,22,70,20,Form1,(HMENU)304,g_hInstance,NULL);
	InitFONT(EXbutton);
	Record1 = CreateWindowEx(0,"static","RecordButton",WS_CHILD|WS_VISIBLE|SS_ICON|WS_GROUP|SS_NOTIFY,
			10,10,0,0,Form1,(HMENU)401,g_hInstance,NULL);
	icoBlue=LoadImage(GetModuleHandle(0),MAKEINTRESOURCE(123),IMAGE_ICON,0,0,LR_CREATEDIBSECTION);
	icoRed=LoadImage(GetModuleHandle(0),MAKEINTRESOURCE(456),IMAGE_ICON,0,0,LR_CREATEDIBSECTION);
	SendMessage(Record1,(UINT)STM_SETIMAGE,(WPARAM)IMAGE_ICON,(LPARAM)icoBlue);

	MoveWindow(Record1,22,20,48,48,TRUE);	

	SendMessage(RMbutton,(UINT)BM_SETCHECK,(WPARAM)BST_CHECKED,(LPARAM)103);
	SendMessage(Hbutton,(UINT)BM_SETCHECK,(WPARAM)BST_CHECKED,(LPARAM)101);
	if(bStdOut)EnableWindow(Hbutton,FALSE);

	GetClientRect(Form1,&winPOS);
	editCtrl = CreateWindowEx(WS_EX_CLIENTEDGE,"edit","",WS_GROUP|WS_TABSTOP|WS_CHILD|WS_VISIBLE|ES_WANTRETURN|WS_VSCROLL|WS_HSCROLL|ES_MULTILINE|ES_AUTOVSCROLL|ES_AUTOHSCROLL,
			5,95,winPOS.right-winPOS.left-10,winPOS.bottom-winPOS.top-103,Form1,(HMENU)102,g_hInstance,NULL);
	InitFONT(editCtrl);
	if(bStdOut)EnableWindow(editCtrl,FALSE);

	SubClassDumbBMP();
	LoadszKeyTxt();
	if(bStdOut)
		SetFocus(WTbutton);
	else
		SetFocus(Hbutton);
	ShowWindow(Form1,SW_SHOW);
}


LRESULT CALLBACK WndProc (HWND hWnd, UINT Msg, WPARAM wParam, LPARAM lParam)
{
	if(Msg==WM_TIMER)
	{
		if(bTimer)
			SendMessage(Record1,(UINT)STM_SETIMAGE,(WPARAM)IMAGE_ICON,(LPARAM)icoBlue);
		else
			SendMessage(Record1,(UINT)STM_SETIMAGE,(WPARAM)IMAGE_ICON,(LPARAM)icoRed);
		bTimer=!bTimer;
		
	}
	else if(Msg==WM_NEXTDLGCTL && !bStdOut)
	{
		if(editCtrl==GetFocus() && !(GetWindowLong(editCtrl,GWL_STYLE) & ES_READONLY))
			SendMessage(editCtrl,EM_REPLACESEL,TRUE,(LONG)"	");
	}
	else if(Msg==WM_SETFOCUS||Msg==WM_KILLFOCUS||Msg==WM_ACTIVATEAPP)
	{
		HWND	feauxCuss;

		feauxCuss=GetFocus();
		if(feauxCuss==Form1)
			SetFocus(g_FOCme);
		if(GetParent(feauxCuss)==Form1)
			g_FOCme=feauxCuss;
	}
	else if(Msg==WM_MOUSEMOVE)
	{
		if( bHookin&&bRecNHide )
		{
			int f_wid=(int)(short)LOWORD(lParam);
			int f_hgt=(int)(short)HIWORD(lParam);
			if(f_wid>77 && f_wid<91 && f_hgt>2 && f_hgt<23)
			{
				if(GetWindowRect(Form1,&winPOS))
					MoveWindow(Form1,winPOS.left+5,winPOS.top,winPOS.right-winPOS.left,winPOS.bottom-winPOS.top,TRUE);
			}
			else if(f_wid>-1 && f_wid<12 && f_hgt>2 && f_hgt<23)
			{
				if(GetWindowRect(Form1,&winPOS))
					MoveWindow(Form1,winPOS.left-5,winPOS.top,winPOS.right-winPOS.left,winPOS.bottom-winPOS.top,TRUE);
			}
		}
	}
	else if(Msg==WM_SIZE && !bStdOut)
	{
		GetClientRect(Form1,&winPOS);
		MoveWindow(editCtrl,5,95,winPOS.right-winPOS.left-10,winPOS.bottom-winPOS.top-103,TRUE);
	}
	else if(Msg==WM_GETMINMAXINFO&&!bStdOut)
	{
		LPMINMAXINFO minmax;
		minmax = (LPMINMAXINFO)lParam;
		minmax->ptMinTrackSize.x = 514;
		minmax->ptMinTrackSize.y = 250;
		return 0;
	}
	else if(Msg==WM_COMMAND)
	{
		if(LOWORD(wParam)==401)
		{
			if(!bHookin)
				StartHookin();
			else
				StopHookin();
		}
		else if(LOWORD(wParam)==101 && !bStdOut)
			bRecNHide=!bRecNHide;
		else if(LOWORD(wParam)==102)
			bUseWinText=!bUseWinText;
		else if(LOWORD(wParam)==103)
			bRecMouse=!bRecMouse;
		else if(LOWORD(wParam)==201)
			SetWindowText(runCtrl,GetFileName("Select an EXE for AutoIt to Run","","Executable(*.exe)|*.EXE",0));
		else if(LOWORD(wParam)==302)
		{
			RetrieveScript();
			SaveScript();
		}
		else if(LOWORD(wParam)==303)
		{
			RetrieveScript();
			_newstring(&pszSaveAs,(char*)"",1);
			SaveScript();
		}
		else if(LOWORD(wParam)==304)
			PostMessage(Form1,WM_CLOSE,0,0);
	}
	else if(Msg==WM_CLOSE)
	{
		if(bHookin)StopHookin();
		RetrieveScript();
		if(strcmp(pszDisplayStr,pszDisplayChg) && !bStdOut)
		{
			if(MessageBox(Form1,"The text has changed!\n\nSave the script?","AU3Recorder",MB_SYSTEMMODAL|MB_YESNO)==IDYES)
				SaveScript();
		}
		DestroyWindow(Form1);
		return 0;
	}
	else if(Msg==WM_DESTROY)
	{
		if(pszTmpStr)GlobalFree(pszTmpStr);
		if(pszDisplayStr)GlobalFree(pszDisplayStr);
		if(pszMouseBuff)GlobalFree(pszMouseBuff);
		if(bHookin)StopHookin();
		UnregisterClass(APP_CLASS,g_hInstance);
		FlushFileBuffers(GetStdHandle(STD_OUTPUT_HANDLE));
		PostQuitMessage(0);
	}
	return DefWindowProc(hWnd,Msg,wParam,lParam);
}


//  Here we set up a routine to get messages sent to our hidden BMP. 
//  
void SubClassDumbBMP (void)
{
	Hook_WndProc=(WNDPROC) SetWindowLong(hookCtrl,GWL_WNDPROC,(LONG)Message_Handler);
}


LRESULT CALLBACK Message_Handler (HWND hWnd, UINT Msg, WPARAM wParam, LPARAM lParam)
{
	while(1)
	{
		cur_hWnd=GetForegroundWindow();

		if((Form1==cur_hWnd||Form1==GetParent(cur_hWnd))&&!(wParam==16||wParam==17||wParam==18||wParam==91||wParam==92||wParam==93))
			break;

		if(!cur_hWnd||(Form1==cur_hWnd||Form1==GetParent(cur_hWnd))) 
		{
			Sleep(50);
			cur_hWnd=GetForegroundWindow();
			if(!cur_hWnd||(Form1==cur_hWnd||Form1==GetParent(cur_hWnd)))cur_hWnd=FindWindow(NULL,"Program Manager");
		}


		if(bRecMouse && (Msg==WM_LBUTTONDOWN||Msg==WM_NCLBUTTONDOWN||Msg==WM_RBUTTONDOWN||Msg==WM_NCRBUTTONDOWN))
		{
			if(bJustHooked)bJustHooked=FALSE;
			getTheText();
			GetCursorPos(&xyMouse);
			GetWindowRect(cur_hWnd,&winPOS);
			if (strlen(pszDisplayStr))
			{
				if(pszDisplayStr[strlen(pszDisplayStr)-1]!=10)
					_cmbstring(&pszDisplayStr,(char*)"\")\r\n");
			}
			if( !((xPrevMouse==xyMouse.x-winPOS.left)&&(yPrevMouse==xyMouse.y-winPOS.top)))
			{
				xPrevMouse=xyMouse.x-winPOS.left;
				yPrevMouse=xyMouse.y-winPOS.top;
				_newstring(&pszTmpStr,(char*)"",256);
				sprintf(pszTmpStr,"MouseMove(%d,%d)\r\n",xPrevMouse,yPrevMouse);
				_cmbstring(&pszMouseBuff,pszTmpStr);
				*pszTmpStr=0;
			}
			_cmbstring(&pszMouseBuff,(char*)"MouseDown(\"");
			if(Msg==WM_LBUTTONDOWN||Msg==WM_NCLBUTTONDOWN)
			{
				_cmbstring(&pszMouseBuff,(char*)"left\")\r\n");
				bLMouseDwn=TRUE;
			}
			else
			{
				_cmbstring(&pszMouseBuff,(char*)"right\")\r\n");
				bRMouseDwn=TRUE;
			}
			bPrevDBLClick=FALSE;
			break;
		}

		if(Msg==WM_LBUTTONDBLCLK||Msg==WM_NCLBUTTONDBLCLK||Msg==WM_RBUTTONDBLCLK||Msg==WM_NCRBUTTONDBLCLK)
		{
			if(bRecMouse)
			{
				if(!bPrevDBLClick)
				{
					pszDisplayStr[strlen(pszDisplayStr)-strlen(strrchr(pszDisplayStr,13))]='\0';
					pszDisplayStr[strlen(pszDisplayStr)-strlen(strrchr(pszDisplayStr,13))]='\0';
					pszDisplayStr[strlen(pszDisplayStr)-strlen(strrchr(pszDisplayStr,13))]='\0';
				}
				pszDisplayStr[strlen(pszDisplayStr)-strlen(strrchr(pszDisplayStr,10))+1]='\0';

				_newstring(&pszTmpStr,(char*)"",256);
				if(Msg==WM_LBUTTONDBLCLK||Msg==WM_NCLBUTTONDBLCLK)
					sprintf(pszTmpStr,"MouseClick(\"left\",%d,%d,2)\r\n",xPrevMouse,yPrevMouse);
				else
					sprintf(pszTmpStr,"MouseClick(\"right\",%d,%d,2)\r\n",xPrevMouse,yPrevMouse);
				_cmbstring(&pszDisplayStr,pszTmpStr);
				*pszTmpStr=0;

				SetWindowText(editCtrl,pszDisplayStr);
				bDBLClick=TRUE;
				bPrevDBLClick=TRUE;
			}
			break;
		}
		if(bRecMouse && (Msg==WM_LBUTTONUP||Msg==WM_NCLBUTTONUP||Msg==WM_RBUTTONUP||Msg==WM_NCRBUTTONUP))
		{
			if(bJustHooked)
			{
				bJustHooked=FALSE;
				break;
			}
			if(bDBLClick)
				bDBLClick=FALSE;
			else
			{
				_cmbstring(&pszDisplayStr,pszMouseBuff);
				*pszMouseBuff=0;
				SetWindowText(editCtrl,pszDisplayStr);
				GetCursorPos(&xyMouse);
				if( !((xPrevMouse==xyMouse.x-winPOS.left)&&(yPrevMouse==xyMouse.y-winPOS.top)))
				{
					xPrevMouse=xyMouse.x-winPOS.left;
					yPrevMouse=xyMouse.y-winPOS.top;
					_newstring(&pszTmpStr,(char*)"",256);
					sprintf(pszTmpStr,"MouseMove(%d,%d)\r\n",xPrevMouse,yPrevMouse);
					_cmbstring(&pszDisplayStr,pszTmpStr);
					*pszTmpStr=0;
				}
				_cmbstring(&pszDisplayStr,(char*)"MouseUp(\"");
				if(Msg==WM_LBUTTONUP||Msg==WM_NCLBUTTONUP)
				{
					_cmbstring(&pszDisplayStr,(char*)"left\")\r\n");
					bLMouseDwn=0;
				}
				else
				{
					_cmbstring(&pszDisplayStr,(char*)"right\")\r\n");
					bRMouseDwn=0;
				}
//				_cmbstring(&pszDisplayStr,(char*)"Sleep(1000)\r\n");
				SetWindowText(editCtrl,pszDisplayStr);
			}
			break;

		}

		if(Msg==WM_KEYDOWN)
		{
			if((bSHIFT==0)&&(bCTRL==0)&&(bALT==0)&&(bLWIN==0)&&(bRWIN==0))
			{
				if(getTheText())
					_cmbstring(&pszDisplayStr,(char*)"Send(\"");
			}
			if(pszDisplayStr[strlen(pszDisplayStr)-1]==10)
				_cmbstring(&pszDisplayStr,(char*)"Send(\"");
			while(1)
			{
				if(wParam>47&&wParam<91)
				{
					_newstring(&pszTmpStr,(char*)"",2);
					pszTmpStr[0]=(int)wParam;
					pszTmpStr[1]=0;
					_cmbstring(&pszDisplayStr,CharLower(pszTmpStr));
					*pszTmpStr=0;
					break;
				}
				if(wParam==16)
				{
					if(!bSHIFT)
					{
						_cmbstring(&pszDisplayStr,(char*)"{SHIFTDOWN}");
						bSHIFT=1;
					}
					break;
				}
				if(wParam==17)
				{
					if(!bCTRL)
					{
						_cmbstring(&pszDisplayStr,(char*)"{CTRLDOWN}");
						bCTRL=1;
					}
					break;
				}
				if(wParam==18)
				{
					if(!bALT)
					{
						_cmbstring(&pszDisplayStr,(char*)"{ALTDOWN}");
						bALT=1;
					}
					break;
				}
				if(wParam==91)
				{
					if(!bLWIN)
					{
						_cmbstring(&pszDisplayStr,(char*)"{LWINDOWN}");
						bLWIN=1;
					}
					break;
				}
				if(wParam==92)
				{
					if(!bRWIN)
					{
						_cmbstring(&pszDisplayStr,(char*)"{RWINDOWN}");
						bRWIN=1;
					}
					break;
				}
				if(wParam==93)
				{
					if(!bAPPS)
						bAPPS=1;
					break;
				}
				if(strcmp(szKeyTxt[wParam],"Unknown")==0)
				{
					_newstring(&pszTmpStr,(char*)"",256);
					sprintf(pszTmpStr,"%d",wParam);
					_cmbstring(&pszDisplayStr,pszTmpStr);
					*pszTmpStr=0;
				}
				else
					_cmbstring(&pszDisplayStr,szKeyTxt[wParam]);
				break;
			}
			SetWindowText(editCtrl,pszDisplayStr);
			break;
		}
		if(Msg==WM_KEYUP)
		{
			while(1)
			{
				if(wParam==9)
				{
					if(bALT==1)
						_cmbstring(&pszDisplayStr,szKeyTxt[wParam]);
					break;			}
				if(wParam==3||wParam==27)
				{
					if(bCTRL==1)
						_cmbstring(&pszDisplayStr,szKeyTxt[wParam]);
					break;
				}
				if(wParam==44)
				{
					if(getTheText()|| pszDisplayStr[strlen(pszDisplayStr)-1]==10)
						_cmbstring(&pszDisplayStr,(char*)"Send(\"");
					_cmbstring(&pszDisplayStr,szKeyTxt[wParam]);
					SetWindowText(editCtrl,pszDisplayStr);
					break;
				}
				if(wParam==16)
				{
					_cmbstring(&pszDisplayStr,(char*)"{SHIFTUP}");
					bSHIFT=0;
					break;
				}
				if(wParam==17)
				{
					_cmbstring(&pszDisplayStr,(char*)"{CTRLUP}");
					bCTRL=0;
					break;
				}
				if(wParam==18)
				{
					_cmbstring(&pszDisplayStr,(char*)"{ALTUP}");
					bALT=0;
					break;
				}
				if(wParam==66||wParam==68||wParam==69||wParam==70||wParam==76||wParam==77||wParam==82||wParam==85)
				{
					if(bLWIN||bRWIN)
					{
						_newstring(&pszTmpStr,(char*)"",2);
						pszTmpStr[0]=(int)wParam;
						pszTmpStr[1]=0;
						_cmbstring(&pszDisplayStr,CharLower(pszTmpStr));
						*pszTmpStr=0;
					}
					break;
				}
				if(wParam==91)
				{
					_cmbstring(&pszDisplayStr,(char*)"{LWINUP}");
					bLWIN=0;
					break;
				}
				if(wParam==92)
				{
					_cmbstring(&pszDisplayStr,(char*)"{RWINUP}");
					bRWIN=0;
					break;
				}
				if(wParam==93)
				{
					_cmbstring(&pszDisplayStr,(char*)"{APPSKEY}");
					bAPPS=0;
				}
				break;
			}
			SetWindowText(editCtrl,pszDisplayStr);
		}
		break;
	}
	return CallWindowProc(Hook_WndProc,hWnd,Msg,wParam,lParam);
}

// *************************************************
//               Run Time Functions
// *************************************************

BOOL getTheText (void)
{
	char	fmt_Text[42];
	char	fmt_Title[1026];

	*next_Title = 0;

	GetWindowText(cur_hWnd,next_Title,513);
	if(strlen(next_Title)==0)
	{
		char	szClass[513];
		GetClassName(cur_hWnd,szClass,512);
		sprintf(next_Title,"classname=%s",szClass);
	}

	*next_Text=0;

	if(bUseWinText)
		EnumChildWindows(cur_hWnd,EnumChildWinProc,0);

	if((strcmp(cur_Title,next_Title)!=0) || ( strcmp(cur_Text,next_Text)!=0))
	{
		strcpy(cur_Title,next_Title);
		strcpy(cur_Text,next_Text);
		if( strchr(cur_Title,34) )
		{
			int	j=0;
			for (int i=0;i<strlen(cur_Title);i++)
			{
				fmt_Title[j] = cur_Title[i];
				j++;
				if( cur_Title[i] == 34 )
				{
					fmt_Title[j] = 34;
					j++;
				}
			}
			fmt_Title[j] = 0;
		}
		else
			strcpy(fmt_Title,cur_Title);
			
		if( strchr(cur_Text,34) )
		{
			int	j=0;
			for (int i=0;i<strlen(cur_Text);i++)
			{
				fmt_Text[j] = cur_Text[i];
				j++;
				if( cur_Text[i] == 34 )
				{
					fmt_Text[j] = 34;
					j++;
				}
			}
			fmt_Text[j] = 0;
		}
		else
			strcpy(fmt_Text,cur_Text);
					
		if( pszDisplayStr[strlen(pszDisplayStr)-1]!=10 )
			_cmbstring(&pszDisplayStr,(char*)"\")\r\n");

		_cmbstring(&pszDisplayStr,(char*)"WinWait(\"");
		_cmbstring(&pszDisplayStr,fmt_Title);
		_cmbstring(&pszDisplayStr,(char*)"\",\"");
		_cmbstring(&pszDisplayStr,fmt_Text);
		_cmbstring(&pszDisplayStr,(char*)"\")\r\nIf Not WinActive(\"");
		_cmbstring(&pszDisplayStr,fmt_Title);
		_cmbstring(&pszDisplayStr,(char*)"\",\"");
		_cmbstring(&pszDisplayStr,fmt_Text);
		_cmbstring(&pszDisplayStr,(char*)"\") ");

		_cmbstring(&pszDisplayStr,(char*)"Then WinActivate(\"");
		_cmbstring(&pszDisplayStr,fmt_Title);
		_cmbstring(&pszDisplayStr,(char*)"\",\"");
		_cmbstring(&pszDisplayStr,fmt_Text);
		_cmbstring(&pszDisplayStr,(char*)"\")\r\nWinWaitActive(\"");
		_cmbstring(&pszDisplayStr,fmt_Title);
		_cmbstring(&pszDisplayStr,(char*)"\",\"");
		_cmbstring(&pszDisplayStr,fmt_Text);
		_cmbstring(&pszDisplayStr,(char*)"\")\r\n");
		SetWindowText(editCtrl,pszDisplayStr);
		return TRUE;
	}
	else
		return FALSE;
}


BOOL CALLBACK EnumChildWinProc (HWND hWnd, LPARAM lParam)
{
	if(strlen(next_Text)>=20)return TRUE;

	int	b;
	char	Buffer[21];
	if((GetWindowLong(hWnd,GWL_STYLE)&WS_VISIBLE) )
	{
		GetWindowText(hWnd,Buffer,21);
		b=strlen(next_Text);
		if(b<strlen(Buffer))
			strcpy(next_Text,Buffer);
	}
	return TRUE;
}


void WinAble (BOOL bShow)
{
	if(!bStdOut)
	{
		EnableWindow(editCtrl,bShow);
		EnableWindow(SVbutton,bShow);
		EnableWindow(SVASbutton,bShow);
		EnableWindow(Hbutton,bShow);
	}
	EnableWindow(WTbutton,bShow);
	EnableWindow(RMbutton,bShow);
	EnableWindow(EXbutton,bShow);
	EnableWindow(Desc1,bShow);
	EnableWindow(Desc2,bShow);
	EnableWindow(runCtrl,bShow);
	EnableWindow(Browse1,bShow);
	if(bRecNHide)
	{
		if(bShow)
		{
			MoveWindow(Record1,22,20,48,48,TRUE);
			MoveWindow(RecStop1,7,70,85,15,TRUE);
		}
		else
		{
			MoveWindow(Record1,20,0,48,48,TRUE);
			MoveWindow(RecStop1,11,50,80,15,TRUE);
		}
	}
	if(bShow)
		SetWindowText(RecStop1,"Click To Record");
	else
		if(bRecNHide)
			SetWindowText(RecStop1,"Click To Stop");
		else
			SetWindowText(RecStop1,"  Click To Stop");
}


void StartHookin (void)
{
	if( !(DLLinst = LoadLibrary("ASWhook.dll")) )
	{
		MessageBox (Form1,"DLL load Failed","Error",4096);
		PostMessage(Form1,WM_CLOSE,0,0);
	}
	else
	{
		HOOKPROC keyHOOKproc=(HOOKPROC)GetProcAddress(DLLinst,"KeyProc");
		HOOKPROC mouseHOOKproc=(HOOKPROC)GetProcAddress(DLLinst,"MouseProc");
		FARPROC SetKeyhWnd=(FARPROC)GetProcAddress(DLLinst,"SetValuesKey");
		FARPROC SetMousehWnd=(FARPROC)GetProcAddress(DLLinst,"SetValuesMouse");
		if(!keyHOOKproc || !mouseHOOKproc || !SetKeyhWnd || !SetMousehWnd)
		{
			MessageBox(Form1,"DLL load ERROR","Error",4096);
			FreeLibrary(DLLinst);
			PostMessage(Form1,WM_CLOSE,0,0);
		}
		else
		{
			hhKeyboard=SetWindowsHookEx(WH_KEYBOARD,keyHOOKproc,DLLinst,0);
			hhMouse=SetWindowsHookEx(WH_MOUSE,mouseHOOKproc,DLLinst,0);
			SetKeyhWnd(hookCtrl,hhKeyboard);
			SetMousehWnd(hookCtrl,hhMouse);
			bHookin=TRUE;
		}
	}
	SetTimer(Form1,nTimer,1000,NULL);
	if(bRecNHide)
	{
		ShowWindow(Form1,SW_HIDE);
		ShowWindow(Left1,SW_SHOWNOACTIVATE);
		ShowWindow(Right1,SW_SHOWNOACTIVATE);
		GetWindowRect(Form1,&winSIZE);
		SetWindowLong(Form1,GWL_STYLE,WS_POPUP|WS_DLGFRAME);
		SetWindowLong(Form1,GWL_EXSTYLE,WS_EX_TOOLWINDOW);
		ShowWindow(Form1,SW_SHOWNOACTIVATE);
		MoveWindow(Form1,0,0,95,75,TRUE);
	}
	WinAble(FALSE);
	RetrieveScript();
	if(!strlen(pszDisplayStr))
		_newstring(&pszDisplayStr,EDIT_HEADER,0);
	bJustHooked=TRUE;
	cur_hWnd=FindWindow(NULL,"Program Manager");
	strcpy(cur_Title,(char*)"`~``~~``~");
	strcpy(cur_Text,(char*)"`~``~~``~");
	int t = SendMessage(runCtrl,WM_GETTEXTLENGTH,0,0);
	_newstring(&pszTmpStr,(char*)"",t+1);
	SendMessage(runCtrl,WM_GETTEXT,(WPARAM)t+1,(LPARAM)pszTmpStr);
	if( strlen(pszTmpStr) )
	{
		Run(pszTmpStr);
		if(pszDisplayStr[strlen(pszDisplayStr)-1]!=10 )
			_cmbstring(&pszDisplayStr,(char*)"\r\n");
		_cmbstring(&pszDisplayStr,(char*)"Run('");
		_cmbstring(&pszDisplayStr,pszTmpStr);
		_cmbstring(&pszDisplayStr,(char*)"')\r\n");
		SetWindowText(editCtrl,pszDisplayStr);
		SetWindowText(runCtrl,"");
	}
	*pszTmpStr=0;
}


void StopHookin (void)
{
	UnhookWindowsHookEx(hhKeyboard);
	UnhookWindowsHookEx(hhMouse);
	FreeLibrary(DLLinst);
	bHookin=FALSE;
	KillTimer(Form1,nTimer);
	bTimer=FALSE;
	if(strlen(pszDisplayStr))
	{
		if( pszDisplayStr[strlen(pszDisplayStr)-1]!=10 )
		{
			if( pszDisplayStr[strlen(pszDisplayStr)-4]!=34 )
				_cmbstring(&pszDisplayStr,(char*)"\")");
			_cmbstring(&pszDisplayStr,(char*)"\r\n");
		}
	}
	if(bStdOut)
	{
		int	nPos=0;
		char    cTemp;
		
		if(pszDisplayStr[strlen(pszDisplayStr)-1]!=10)
			_cmbstring(&pszDisplayStr,(char*)"\")\r\n");

		printf("\n#region --- ScriptWriter generated code Start --- \n");
		// Dump all but \r characters to STDOUT
		while ( ( (cTemp = pszDisplayStr[nPos]) != '\0'))
		{
			if (!(cTemp == '\r'))
				printf("%c",cTemp);
			nPos++;
		} // End While
		printf("#endregion --- ScriptWriter generated code End --- \n\n");
		PostMessage(Form1,WM_CLOSE,0,0);
	}
	else	
	{
		if(strlen(pszDisplayStr))
			SetWindowText(editCtrl,pszDisplayStr);
		else
			_newstring(&pszDisplayStr,EDIT_HEADER,0);
		SendMessage(Record1,(UINT)STM_SETIMAGE,(WPARAM)IMAGE_ICON,(LPARAM)icoBlue);
		WinAble(TRUE);
		if(bRecNHide)
		{
			ShowWindow(Form1,SW_HIDE);
			ShowWindow(Left1,SW_HIDE);
			ShowWindow(Right1,SW_HIDE);
			SetWindowLong(Form1,GWL_STYLE,WS_GROUP|WS_MINIMIZEBOX|WS_SIZEBOX|WS_CAPTION|WS_POPUP|WS_SYSMENU);
			SetWindowLong(Form1,GWL_EXSTYLE,0);
			MoveWindow(Form1,winSIZE.left,winSIZE.top,winSIZE.right-winSIZE.left,winSIZE.bottom-winSIZE.top,TRUE);
			ShowWindow(Form1,SW_SHOW);
		}
	}
}


void LoadszKeyTxt (void)
{
	int	a;
	strcpy(cur_Text,(char*)"@#$zxc");
	strcpy(cur_Title,(char*)"@#$zxc");
	for( a=1;a<=255;a++)
		szKeyTxt[a][0]=MapVirtualKey(a,2);

	strcpy(szKeyTxt[3],(char*)"{CTRLBREAK}");
	strcpy(szKeyTxt[8],(char*)"{BACKSPACE}");
	strcpy(szKeyTxt[9],(char*)"{TAB}");
	strcpy(szKeyTxt[13],(char*)"{ENTER}");
	strcpy(szKeyTxt[16],(char*)"{SHIFT}");
	strcpy(szKeyTxt[17],(char*)"{CTRL}");
	strcpy(szKeyTxt[18],(char*)"{ALT}");
	strcpy(szKeyTxt[19],(char*)"{PAUSE}");
	strcpy(szKeyTxt[20],(char*)"{CAPSLOCK}");
	strcpy(szKeyTxt[27],(char*)"{ESC}");
	strcpy(szKeyTxt[32],(char*)"{SPACE}");
	strcpy(szKeyTxt[33],(char*)"{PGUP}");
	strcpy(szKeyTxt[34],(char*)"{PGDN}");
	strcpy(szKeyTxt[35],(char*)"{END}");
	strcpy(szKeyTxt[36],(char*)"{HOME}");
	strcpy(szKeyTxt[37],(char*)"{LEFT}");
	strcpy(szKeyTxt[38],(char*)"{UP}");
	strcpy(szKeyTxt[39],(char*)"{RIGHT}");
	strcpy(szKeyTxt[40],(char*)"{DOWN}");
	strcpy(szKeyTxt[44],(char*)"{PRINTSCREEN}");
	strcpy(szKeyTxt[45],(char*)"{INS}");
	strcpy(szKeyTxt[46],(char*)"{DEL}");
	strcpy(szKeyTxt[91],(char*)"{LWIN}");
	strcpy(szKeyTxt[92],(char*)"{RWIN}");
	strcpy(szKeyTxt[93],(char*)"{APPSKEY}");
	strcpy(szKeyTxt[107],(char*)"{+}");
	strcpy(szKeyTxt[112],(char*)"{F1}");
	strcpy(szKeyTxt[113],(char*)"{F2}");
	strcpy(szKeyTxt[114],(char*)"{F3}");
	strcpy(szKeyTxt[115],(char*)"{F4}");
	strcpy(szKeyTxt[116],(char*)"{F5}");
	strcpy(szKeyTxt[117],(char*)"{F6}");
	strcpy(szKeyTxt[118],(char*)"{F7}");
	strcpy(szKeyTxt[119],(char*)"{F8}");
	strcpy(szKeyTxt[120],(char*)"{F9}");
	strcpy(szKeyTxt[121],(char*)"{F10}");
	strcpy(szKeyTxt[122],(char*)"{F11}");
	strcpy(szKeyTxt[123],(char*)"{F12}");
	strcpy(szKeyTxt[144],(char*)"{NUMLOCK}");
	strcpy(szKeyTxt[145],(char*)"{SCROLLLOCK}");
}

void _cmbstring(char** szL, char* szR)
{
	if(!strlen(szR))return;

	*szL=(char*)realloc(*szL,(strlen(*szL)+strlen(szR)+1) * sizeof(char));
	strcat(*szL,szR);
}

void _newstring(char** szL, char* szR, size_t nChar)
{
	if(nChar>0)
		*szL=(char*)calloc(nChar , sizeof(char));
	else
	{
		*szL=(char*)realloc(*szL,(strlen(szR)+1) * sizeof(char));
		strcpy(*szL,szR);
	}
}

void SaveScript(void)
{
	BOOL	bGO=FALSE;
	
	while(strlen(pszSaveAs)==0&&!bGO)
	{
		_newstring(&pszTmpStr,(char*)GetFileName("Save AutoIt Script","","AutoIt Script(*.au3)|*.AU3",1),0);
		if(strlen(pszTmpStr)==0)
		{
			bGO=TRUE;
			break;
		}
		_newstring(&pszSaveAs,pszTmpStr,0);
		*pszTmpStr=0;
		if(!strrchr(pszSaveAs,46) || strrchr(pszSaveAs,46)<strrchr(pszSaveAs,92))
			_cmbstring(&pszSaveAs,(char*)".au3");
		DWORD dwTemp = GetFileAttributes(pszSaveAs);
		if ( dwTemp != 0xFFFFFFFF )
		{
			if(MessageBox(Form1,"File Exists!\n\nOverWrite?","Warning",MB_ICONWARNING|MB_SYSTEMMODAL|MB_YESNO)!=IDYES)
				bGO=TRUE;
		}
	}
	if(strlen(pszSaveAs)&&!bGO)
	{
		fp1=CreateFile(pszSaveAs,GENERIC_WRITE,0,NULL,CREATE_ALWAYS,FILE_ATTRIBUTE_NORMAL,NULL);
		DWORD dwBytesWrit;
		WriteFile(fp1,pszDisplayStr,strlen(pszDisplayStr),&dwBytesWrit,NULL);
		FlushFileBuffers(fp1);
		CloseHandle(fp1);
		_newstring(&pszDisplayChg,pszDisplayStr,0);
		MessageBox(Form1,"Script Saved.","AU3Recorder",MB_SYSTEMMODAL);
	}
}

void RetrieveScript(void)
{
	int t;
	t = SendMessage(editCtrl,WM_GETTEXTLENGTH,0,0);
	_newstring(&pszDisplayStr,(char*)"",t+1);
	SendMessage(editCtrl,WM_GETTEXT,(WPARAM)t+1,(LPARAM)pszDisplayStr);
}

char *GetFileName(char*szTitle,char*szDir,char*szFilter,int nFlag)
{
	OPENFILENAME		ofn;
	char			szFile[2048];
	char			Extension[255];
	char			ch=0;
	int			Counter;

	memset(&Extension,0,sizeof(Extension));

	strcat(Extension,szFilter);
	for(Counter=1;Counter<=strlen(szFilter)-1;Counter++)
	{
		ch=szFilter[Counter];
		if(ch=='|')
			Extension[Counter]=0;
		else
			Extension[Counter]=ch;
	}

	ZeroMemory(&ofn, sizeof(OPENFILENAME));
	ofn.lStructSize		= sizeof(OPENFILENAME);
	ofn.hwndOwner		= Form1;
	szFile[0]		= '\0';
	ofn.lpstrFilter		= Extension;
	ofn.lpstrTitle		= szTitle;
	ofn.nMaxFile		= 2047;
	ofn.lpstrFile		= szFile;
	ofn.lpstrInitialDir	= szDir;	// Set working dir
	if ( nFlag == 0 )
	{
		ofn.Flags=OFN_NODEREFERENCELINKS|OFN_HIDEREADONLY|OFN_EXPLORER|OFN_PATHMUSTEXIST|OFN_FILEMUSTEXIST;
		if(GetOpenFileName(&ofn))
 			_newstring(&pszTmpStr,ofn.lpstrFile,0);
	}
	else
	{
		if(GetSaveFileName(&ofn))
 			_newstring(&pszTmpStr,ofn.lpstrFile,0);
	}

	return pszTmpStr;
}

void Run (char* Cmdline)
{
	STARTUPINFO si;
	PROCESS_INFORMATION pi;
	memset(&si,0,sizeof(si));
	memset(&pi,0,sizeof(pi));
	si.cb=sizeof(si);
	si.dwFlags=STARTF_USESHOWWINDOW;
	si.wShowWindow=1;
	if(CreateProcess(NULL,Cmdline,NULL,NULL,FALSE,
		NORMAL_PRIORITY_CLASS,NULL,NULL,&si,&pi)==TRUE)
	{
		WaitForInputIdle(pi.hProcess,1500);
		CloseHandle(pi.hProcess);
		CloseHandle(pi.hThread);
	}
}

void ChangeFONT(HWND hWnd, char *Font, int Size, int Weight)
{
	HFONT	hFont;
	HDC	hDC=GetDC(HWND_DESKTOP);
	int	CyPixels=GetDeviceCaps(hDC,LOGPIXELSY);
	ReleaseDC(HWND_DESKTOP,hDC);
	hFont = CreateFont(0-(Size*CyPixels)/72,0,0,0,Weight,0,0,0,0,
        	OUT_TT_PRECIS,CLIP_DEFAULT_PRECIS,DEFAULT_QUALITY,FF_DONTCARE,Font);
	SendMessage(hWnd,WM_SETFONT,(WPARAM)hFont,(LPARAM)TRUE);
}

void InitFONT(HWND hWnd){SendMessage(hWnd,(UINT)WM_SETFONT,(WPARAM)GetStockObject(DEFAULT_GUI_FONT),(LPARAM)MAKELPARAM(FALSE,0));}

char *command (int nArg)
{
	register int i = 0;
	char *c, *s = GetCommandLine();

	if(nArg < i) // return entire commandline
	{
		while(*s && *s != 32)
		{
			if(*s == 34)
				while(*++s && *s != 34);
			s++;
		}
		while(isspace((unsigned char)*s))s++;
		_newstring(&pszTmpStr,(char*)"",strlen(s)+1);
		strcpy(pszTmpStr, s);
		if(*(pszTmpStr+strlen(pszTmpStr)-1)==20) *pszTmpStr=0;
			return pszTmpStr;
	}
	while(i <= nArg)
 	{
		while(isspace((unsigned char)*s)) s++; // skip whitespace
		c = s;
		if(*s == 34)                           // argument starts a quote
		{
			while(*++s && *s != 34);          // skip till next quote
			if(*s) s++;                       // skip quote itself
		}
		else
		{
			while(*s && *s != 32)
				s++;
		}
		i++;
	}
	if(*c == 34)
	{
		c++;                                 // skip leading quote
		if(*(s-1) == 34) s--;                // skip any trailing quotes
	}
	_newstring(&pszTmpStr,(char*)"",(s - c) + 1);
	strncpy(pszTmpStr, c, (s - c));
	pszTmpStr[s-c]=0;
	return pszTmpStr;
}
