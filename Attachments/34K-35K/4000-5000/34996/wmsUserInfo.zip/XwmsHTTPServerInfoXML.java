package com.xwms.wms.http;

import java.io.*;
import java.util.*;

import com.wowza.wms.vhost.*;
import com.wowza.wms.logging.WMSLoggerFactory;
import com.wowza.wms.server.*;
import com.wowza.wms.application.*;
import com.wowza.wms.http.*;
import com.wowza.wms.client.*;
import com.wowza.wms.http.*;

public class XwmsHTTPServerInfoXML extends HTTProvider2Base
{	
	private void outputConnectionInfo(StringBuffer ret, ConnectionCounter counter)
	{
		ret.append("<ConnectionsCurrent>"+counter.getCurrent()+"</ConnectionsCurrent>");
		ret.append("<ConnectionsTotal>"+counter.getTotal()+"</ConnectionsTotal>");
		ret.append("<ConnectionsTotalAccepted>"+counter.getTotalAccepted()+"</ConnectionsTotalAccepted>");
		ret.append("<ConnectionsTotalRejected>"+counter.getTotalRejected()+"</ConnectionsTotalRejected>");
	}
	
	public void onHTTPRequest(IVHost inVhost, IHTTPRequest req, IHTTPResponse resp)
	{
		if (!doHTTPAuthentication(inVhost, req, resp))
			return;

		StringBuffer ret = new StringBuffer();
		
		try
		{
			List vhostNames = VHostSingleton.getVHostNames();
			ret.append("<?xml version=\"1.0\"?>\n<WowzaMediaServerPro>");
					
			Iterator<String> iter = vhostNames.iterator();
			while (iter.hasNext())
			{
				String vhostName = iter.next();
				IVHost vhost = (IVHost)VHostSingleton.getInstance(vhostName);
				if (vhost != null)
				{
					ret.append("<VHost>");
					ret.append("<Name>"+vhostName+"</Name>");
					ret.append("<TimeRunning>"+vhost.getTimeRunningSeconds()+"</TimeRunning>");
					ret.append("<ConnectionsLimit>"+vhost.getConnectionLimit()+"</ConnectionsLimit>");
					
					outputConnectionInfo(ret, vhost.getConnectionCounter());
					
					List appNames = vhost.getApplicationNames();
					List<String> appFolders = vhost.getApplicationFolderNames();
					Iterator<String> appNameIterator = appFolders.iterator();
					while (appNameIterator.hasNext())
					{
						String applicationName = appNameIterator.next();
						ret.append("<Application>");
						ret.append("<Name><![CDATA["+applicationName+"]]></Name>");
						boolean appExists = appNames.contains(applicationName);
						ret.append("<Status>"+(appExists?"loaded":"unloaded")+"</Status>");

						if (appExists)
						{
							IApplication application = vhost.getApplication(applicationName);
							if (application == null)
								continue;
							
							ret.append("<TimeRunning>"+application.getTimeRunningSeconds()+"</TimeRunning>");
							outputConnectionInfo(ret, application.getConnectionCounter());
							
							List appInstances = application.getAppInstanceNames();
							Iterator<String> iterAppInstances = appInstances.iterator();
							while (iterAppInstances.hasNext())
							{
								String appInstanceName = iterAppInstances.next();
								IApplicationInstance appInstance = application.getAppInstance(appInstanceName);
								if (appInstance == null)
									continue;
								
								ret.append("<ApplicationInstance>");
								ret.append("<Name><![CDATA["+appInstance.getName()+"]]></Name>");
								ret.append("<TimeRunning>"+appInstance.getTimeRunningSeconds()+"</TimeRunning>");
								
								outputConnectionInfo(ret, appInstance.getConnectionCounter());
								
								List<IClient> clients = appInstance.getClients();
								Iterator<IClient> iterClient = clients.iterator();
								while(iterClient.hasNext())
								{
									IClient client = iterClient.next(); //appInstance.getClient(c);
									if (client == null)
										continue;

									ret.append("<Client>");
									ret.append("<ClientId>"+client.getClientId()+"</ClientId>");
									ret.append("<FlashVersion>"+client.getFlashVer()+"</FlashVersion>");
									ret.append("<IpAddress>"+client.getIp()+"</IpAddress>");
									ret.append("<Referrer><![CDATA["+client.getReferrer()+"]]></Referrer>");
									ret.append("<QueryString><![CDATA["+client.getQueryStr()+"]]></QueryString>");
									ret.append("<TimeRunning>"+client.getTimeRunningSeconds()+"</TimeRunning>");
									//ret.append("<Duration>"+((double)(System.currentTimeMillis()-client.getConnectTime())/1000.0)+"</Duration>");
									ret.append("<DateStarted>"+client.getDateStarted()+"</DateStarted>");
									ret.append("<URI><![CDATA["+client.getUri()+"]]></URI>");
									
									String protocolStr = "unknown";
									switch(client.getProtocol())
									{
									case RtmpSessionInfo.PROTOCOL_RTMP:
										protocolStr = client.isEncrypted()?"RTMPE":"RTMP";
										break;
									case RtmpSessionInfo.PROTOCOL_RTMPT:
										protocolStr = client.isSSL()?"RTMPS":(client.isEncrypted()?"RTMPTE":"RTMPT");
										break;
									}
									
									ret.append("<Protocol>"+protocolStr+"</Protocol>");
									ret.append("<IsSSL>"+client.isSSL()+"</IsSSL>");
									ret.append("<IsEncrypted>"+client.isEncrypted()+"</IsEncrypted>");
									ret.append("<Port>"+client.getServerHostPort().getPort()+"</Port>");
									ret.append("</Client>");
								}
								
								ret.append("</ApplicationInstance>");
							}
						}
						
						ret.append("</Application>");
					}
					
					ret.append("</VHost>");
				}
			}
			
			ret.append("</WowzaMediaServerPro>");
		}
		catch (Exception e)
		{
			WMSLoggerFactory.getLogger(HTTPServerVersion.class).error("HTTPServerInfoXML.onHTTPRequest: "+e.toString());
			e.printStackTrace();
		}
				
		try
		{
			resp.setHeader("Content-Type", "text/xml");
			
			OutputStream out = resp.getOutputStream();
			byte[] outBytes = ret.toString().getBytes();
			out.write(outBytes);
		}
		catch (Exception e)
		{
			WMSLoggerFactory.getLogger(HTTPServerVersion.class).error("HTTPServerInfoXML.onHTTPRequest: "+e.toString());
			e.printStackTrace();
		}
		
	}
}