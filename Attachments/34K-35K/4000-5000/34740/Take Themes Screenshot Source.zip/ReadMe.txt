Chrome Theme Screenshot Taker

I wanted a tool to be able to take screenshots of Chrome themes from the command line so I made this.

Only ever tested on XP.

Run loadChromeWithProfile.bat first if you want to show the bookmarks bar, add bookmarks or what ever to the profile that will be used for screenshots.

The following options are allowed for the command line....

-source - The path to the theme without a trailing \
takeScreenshot -source="C:\path\to\theme"

-destination - By default the screenshot will be placed in the themes parent directory.  You may use this value to point to the directory that youd like the screenshot to be saved into.
takeScreenshot -source="C:\path\to\theme" -destination="C:\some\path"

-filetype - May be png or jpg.  Do not include a . .  If ommitted then it will default to png.
takeScreenshot -source="C:\path\to\theme" -destination="C:\some\path" -filetype="jpg"
 
-jpgquality - If you set filetype to jpg then you can use this value to determine the quality to compress it as.  The value must be between 1-100 and the higher the value the better the quality.  The default value is 90.
takeScreenshot -source="C:\path\to\theme" -destination="C:\some\path" -filetype="jpg" -jpgquality=100

-resolution - The resolution should be written out with the Width and Height values and an x between them (1280x1024).  If no resolution is giving then a dialog will appear asking you to pick one.
takeScreenshot -source="C:\path\to\theme" -destination="C:\some\path" -filetype=jpg -jpgquality=100 -resolution=1024x768

-chromespath - If ommitted it will try to use an installed Chrome.  If included it will load that Chrome instead, good for portable Chromes.
takeScreenshot -source="C:\path\to\theme" -destination="C:\some\path" -filetype=jpg -jpgquality=100 -resolution=1024x768 -chromespath="C:\Chromes\path\chrome.exe"

-opensshot - If this option is in the command line then when it finishs it will open the screenshot with the default program for that file extension.
takeScreenshot -source="C:\path\to\theme" -destination="C:\some\path" -filetype=jpg -jpgquality=100 -resolution=1024x768 -chromespath="C:\Chromes\path\chrome.exe" -opensshot

-loadprofile - If this command is used then all other values will be ignored and it will launch Chrome with the profile used for screenshots.  Use this to setup the profile such as displaying the bookmarks bar or what not.
takeScreenshot -source="C:\path\to\theme" -loadprofile

Its best not to be doing anything when it does its work or you could get unexpected results ;)

PAEz