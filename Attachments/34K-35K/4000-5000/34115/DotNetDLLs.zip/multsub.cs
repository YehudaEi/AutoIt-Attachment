using System;
using System.Collections.Generic;
using System.Runtime.InteropServices;

namespace myCSLibrary
{
  [ClassInterface(ClassInterfaceType.AutoDual)]
  public class MultSubClass
  {
    private int myProperty;
    public MultSubClass()
    {
    }
    public int mult2(int input)
    {
      return 2 * input;
    }
    public int sub1(int input)
    {
      return input - 1;
    }

    public int myDotNetProperty {
      get { return myProperty; }
      set { myProperty = value; }
    }
  }
}