Imports System.Collections.Generic
Imports System.Text
Imports System.Runtime.InteropServices

Namespace myDotNetLibrary
  <ClassInterface(ClassInterfaceType.AutoDual)> _
  Public Class myDotNetClass
    Private myProperty As String

    Public Sub New()
    End Sub

    Public Function myDotNetMethod(input As String) As String
      Return "Hello " & input
    End Function

    Public Property myDotNetProperty() As String
      Get
        Return myProperty
      End Get
      Set(ByVal value As String)
        myProperty = value
      End Set
    End Property

  End Class
End Namespace