Jeeves version 1.2.6

Changelog:

; fixed cvs log prereason var was not cleared after loop.
; added detection of clockskews from switching from random timers to static timers
; fixed bug with rerandom the timers when they hit
; updated config screen to show the timers and current worktime
; need to fix bug with startup that it asks after 5 minutes
; fixed time reg bug caused by new improvements ;(

Jeeves version 1.2.5

Changelog:

;when starting the executable. jeeves wil try to read the last logged time and date from the logfile and using it as idle time, thus detecting the startup as an event and possible ask for an activity reason. (depending on you time away)

Jeeves version 1.2.4

initial release

---------------------------------------------------------------

Dear autoit users,

would like to share my first autoit experience, this application is something i wanted to create a long time ago, and never had gotten the time to.

its a simple application, that will track the time between events. 

you can initiate an event while working, or it will count the time your workstation is locked or unlocked. (also screensaver)

for me, this helps alot in tracking my time, especially during business hours.
while i am working i can quickly log what i was doing, or if i get pulled away to a meeting the script will ask me were i was. 
I work on a lot of items during the day, and i mostly dont know in advance what they are, thus the reason for this tool to allways log things what happend and not what you are going to do.

All this makes my live so easy when putting these events in a time registration system. i love to easely recalculate my work hours even if i "forget" to justify my time for a week. 

If you are allready 100% disciplined in your company's time registration and allways submit your timesheet on a daily basis, then you probably dont need this tool. But if not then give it a try and tell me if its really usefull for you.

so jeeves, your personal assistant is born,it will help track your workhours in a log 

- Install
---------

copy the executable were you want. and run it. 
make sure you can write in that folder. otherwise copy it to the temp folder

- Configuration
---------------

from the system tray you can select to configure and edit the applications settings, if you have changed the jeeves.ini then make sure to click the apply button to activate the changes

default i have disabled it to register it under HKCU/run. 
so to have it startup automaticly edit the jeeves.ini and it will add a entry for you in the registry.

- Usage
-------

jeeves will normally act as its not there. it sit's in your system tray, when you lock or unlock the workstation or if your screensaver kicks in, it will log dates and times to the jeeves.txt.
also it will ask you for a reason if you were inactive for more then 5 minutes, (or longer as you can configure in the jeeves.ini) if no reason is supplied it will just log the time and date.

randomly it will also ask you what you were doing (between 30 minutes and two hours. its also configurable) 

while working you can use the following hotkey's (tap them quickly after each other not holding)

(ALT+`) = to add an activity reason while working, so you can log this time and continue to work on another.
(WIN+`) = to add an activity reason and lock your workstation right after)
(WIN+ESC) = to add an activity reason and lock/hibernate your workstation right after, i use it alot on my netbook
(CTRL+`) = a quick way to open the jeeves.txt

when you exit jeeves and or reboot your workstation, jeeves will read the last activity date from the log.
it will then act as if it was running all this time. (helps in logging the events correctly)

- Code
------

i know this source code may look odd for you experiance programmers, i solved things with very basic knowlegde of autoit.
my real programming experiance besides scripting, dates back to turbo/pascal and c=64 assembly.
any tips in handling things are allways welcome.

- Additional credits
--------------------

I got the inspiration from the post IsWorkStationLocked() & IsScreenSaverRunning() by Zinthose thanks to him for getting the locked status readable as easy as he did. (note: i searched for a long time to do this from another script way, (vb, batch, tools etc) all no good, but this works great, thx Zinthose. :)

- Compile
---------

in the zip file is supplied the source, and the icon used for the systemtray.
it uses the hotkey udf include

- Logfile example
-----------------

2009/08/22 01:53:35 - Administrator@NL036LT0001 working for 1 hour(s) on releasing jeeves
2009/08/22 10:25:55 - Administrator@NL036LT0001 working for 8.5 hour(s) on sleep...

- Cvs example
-------------

2009/08/22 01:53:35,S0,L0,I1,la=0,ha=0,62.6,releasing jeeves
2009/08/22 10:25:55,S0,L0,I1,la=0,ha=0,512.2,sleep...

- Feedback
----------

allways welcome, positive or negative, if you like it, modify it, please let me know

Thanks in advance

SoulShepard

- Files md5sum
--------------

jeeves.au3 : 0dc02a5a9901706f0df68ae0d26e5fda 
jeeves.exe : f238affe830e09f56660e7c4f991932a
 