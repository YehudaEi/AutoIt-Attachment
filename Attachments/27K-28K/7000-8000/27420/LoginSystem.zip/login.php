<?php
$user = $_GET["user"];
$pass = $_GET["pass"];
$fp = fopen("AutoITdata.txt", "r"); //Change this to whatever you want
$string = fgets($fp); 
$array = array(
    'AutoITmaniac'	=> '59AC3DE36BEBDF65',
    'PeterVonSch�cel'	=> 'B9B67DC9EFDB181F',
    'testclient' 	=> '3D6D40013A462CFF');

while ($name = key($array)) {
    if ($name == $user) {
	if ($pass == current($array))
	{
		echo $string;
		break;
	}
	else
	{
		echo "01";//Wrong Password
		break;
	}      
    }
    next($array);
}
echo "02";//Wrong Username
?>