Mcky's CalEntry
---------------
*TIP*: When in doubt,the help file,HELPME.CHM,is always available.

Version : 1.6


License Agreement:
------------------
AUTHOR IS PROVIDING THIS SOFTWARE AND THE ACCOMPANYING
FILES "AS IS". AUTHOR DISCLAIMS ALL WARRANTIES, CONDITIONS
OR REPRESENTATIONS (WHETHER EXPRESSED OR IMPLIED, ORAL
OR WRITTEN) WITH RESPECT TO THE SOFTWARE AND THE
ACCOMPANYING FILES. AUTHOR DOES NOT WARRANT THAT THE
SOFTWARE WILL FUNCTION WITHOUT INTERRUPTION OR BE ERROR
FREE, THAT AUTHOR WILL CORRECT ALL DEFICIENCIES, ERRORS,
DEFECTS OR NONCONFORMITIES OR THAT THE SOFTWARE WILL
MEET YOUR SPECIFIC REQUIREMENTS. I DON'T ACCEPT ANY
RESPONSIBILITY FOR ANY MISUSE OF THIS PROGRAM.


What is it:
-----------
It is a 32-bit freeware program for easily setting reminders and other tasks. It is very small in size and
easily fits on a floppy disk. It was created using the freeware tool AutoIT3,available at the AutoIT website.
Mcky's CalEntry can be used for commercial or non- commercial purposes. Source code can be requested through 
my e-mail address. 


Features:
---------
* Freeware for commercial or non-commercial use
* Source code in AutoIT3 format provided
* Small application size and does not need any bloated DLLs to run
* Easily fits on a floppy disk/thumbdrive for portability and syncronize your tasks with the built-in Backup program.
* Clean and easy-to-use interface,even a child could use it. Advanced users will appreciate its powerful capabilities.
* Does not write to the registry. Keep own settings in SETTINGS.INI
* Nice and comprehensive help file layout
* Create unlimited tasks for days/months/years
* Option to start program with Windows startup
* Option to automatically delete dates older than today
* Use a custom WAV//MP3 alarm sound for alarms
* Choose from 4 different types of tasks to execute
* Backup or restore your calendar data in just one click,on any media
* Export your tasks list to 2 different kinds of formats,HTML and CSV
* Export to HTML webpage document. Sizzle it up with built-in CSS templates or create your own
* Export to CSV document,importable into Excel,Access or other applications that supports of importing CSV data. Manipulate the data however you want it



System requirements:
--------------------
* Microsoft Windows 95,98,98SE,ME,NT,2000,XP or 2003 (Windows 95 does not support HTML Help file support)
* Recommended: Windows XP
* 800x600 screen resolution
* Minimum CPU required by operating system
* Minimum RAM required by operating system
* 550KB Hard disk space (More needed as you create more tasks)
* HTML Help engine installed to view help file
* A floppy disk or any other backup media if you wish to backup tasks using the built-in Backup program.
* Microsoft Office or OpenOffice installed if you wish to import CSV file

Usage:
------
Start CalEntry (Or press ALT+BACKSPACE if it is already running). Select a new date on the date box,then press
the Create a new task button. Specify your task,its timing and press Create.
Please refer to help file,HELPME.CHM for more in-depth details.


Mcky,2006
WEB:http://mcky_boyz.tripod.com
EMAIL:mckyboyz@yahoo.com