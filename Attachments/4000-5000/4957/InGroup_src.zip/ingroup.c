/* Replace "dll.h" with the name of your header */
#include <windows.h>
#include <stdlib.h>
#include <lm.h>
#include "au3plugin.h"

/****************************************************************************
* Function List
*
* This is where you define the functions available to AutoIt.  Including
* the function name (Must be the same case as your exported DLL name), the
* minimum and maximum number of parameters that the function takes.
*
****************************************************************************/

/* "FunctionName", min_params, max_params */
AU3_PLUGIN_FUNC g_AU3_Funcs[] = 
{
    {"InGroup", 1, 2}
};

/*
Multiple Function Example

AU3_PLUGIN_FUNC g_AU3_Funcs[NUMFUNCS] = 
{
    {"PluginFunc1", 2, 2},
    {"PluginFunc2", 1, 1},
    {"PluginFunc3", 1, 5}
};
*/

/****************************************************************************
* AU3_GetPluginDetails()
*
* This function is called by AutoIt when the plugin dll is first loaded to
* query the plugin about what functions it supports.  DO NOT MODIFY.
*
****************************************************************************/

AU3_PLUGINAPI int AU3_GetPluginDetails(int *n_AU3_NumFuncs, AU3_PLUGIN_FUNC **p_AU3_Func)
{
    /* Pass back the number of functions that this DLL supports */
    *n_AU3_NumFuncs	= sizeof(g_AU3_Funcs)/sizeof(AU3_PLUGIN_FUNC);;
    
    /* Pack back the address of the global function table */
    *p_AU3_Func = g_AU3_Funcs;
    
    return AU3_PLUGIN_OK;
}

BOOL APIENTRY DllMain (HINSTANCE hInst     /* Library instance handle. */ ,
                       DWORD reason        /* Reason this function is being called. */ ,
                       LPVOID reserved     /* Not used. */ )
{
    switch (reason)
    {
      case DLL_PROCESS_ATTACH:
        break;
    
      case DLL_PROCESS_DETACH:
        break;
    
      case DLL_THREAD_ATTACH:
        break;
    
      case DLL_THREAD_DETACH:
        break;
    }
    
    /* Returns TRUE on success, FALSE on failure */
    return TRUE;
}

/****************************************************************************
* 
* InGroup("groupname", "username")
*
****************************************************************************/

AU3_PLUGIN_DEFINE(InGroup)
{
    /* The inputs to a plugin function are:
     *		n_AU3_NumParams		- The number of parameters being passed
     *		p_AU3_Params		- An array of variant like variables used by AutoIt
     *
     * The outputs of a plugin function are:
     *		p_AU3_Result		- A pointer to a variant variable for the result
     *		n_AU3_ErrorCode		- The value for @Error
     *		n_AU3_ExtCode		- The value for @Extended
     */
    HMODULE hLib;
    FARPROC fpNetUserGetLocalGroups, fpNetUserGetGroups, fpNetApiBufferFree, fpNetGetDCName;
    LPGROUP_USERS_INFO_0 pTmpGlobalBuf, pGlobalBuf = NULL;
    LPLOCALGROUP_USERS_INFO_0 pTmpLocalBuf, pLocalBuf = NULL;
    DWORD i, dwEntriesRead = 0, dwTotalEntries = 0;
    WCHAR wszGroup[256], wszUser[20];
    WCHAR wszServer[256], wszDomain[256];
    LPWSTR pwszTemp;
    LPBYTE pDCBuf = NULL;
    BOOL bFound = FALSE;
    
    AU3_PLUGIN_VAR *pMyResult;
    char *szUser, *szGroup;
    
    if (n_AU3_NumParams > 0)
    {
        /* Get string representations of the two parameters passed - this works even if we
         * were passed numbers or floats.
         * Note: AU3_GetString() allocates some memory that we must manually free later.
         */
        szGroup	= AU3_GetString(&p_AU3_Params[0]);
        if (n_AU3_NumParams == 1)
        {
            i = sizeof(char)*20;
            szUser = (char *)malloc(i);
            GetUserName(szUser, &i);
        }
        else
            szUser = AU3_GetString(&p_AU3_Params[1]);        

        /* Load NetApi32 library */
        hLib = LoadLibrary("NetApi32.dll");
        if(hLib)
        {
        	/* Get Net function pointers */
        	fpNetUserGetLocalGroups = GetProcAddress(hLib, "NetUserGetLocalGroups");
        	fpNetUserGetGroups = GetProcAddress(hLib, "NetUserGetGroups");
        	fpNetApiBufferFree = GetProcAddress(hLib, "NetApiBufferFree");
        	fpNetGetDCName = GetProcAddress(hLib, "NetGetDCName");
        	
        	if(fpNetUserGetLocalGroups && fpNetUserGetGroups && fpNetApiBufferFree && fpNetGetDCName)
        	{
        		/* Convert parameter strings to UNICODE */
        		MultiByteToWideChar(CP_ACP, 0, szUser, -1, wszUser, sizeof(wszUser));
        		MultiByteToWideChar(CP_ACP, 0, szGroup, -1, wszGroup, sizeof(wszGroup));
        		*wszDomain = L'\0';
        
        		pwszTemp = wcschr(wszGroup, L'\\');
        		if(pwszTemp == NULL)
        		{
        			/* Get local groups */
        			fpNetUserGetLocalGroups(NULL, wszUser, 0, LG_INCLUDE_INDIRECT, (LPBYTE*)&pLocalBuf, 
        									MAX_PREFERRED_LENGTH, &dwEntriesRead, &dwTotalEntries);
        			if(pLocalBuf)
        			{
        				pTmpLocalBuf = pLocalBuf;
        				/* Loop through list of local groups */
        				for(i = 0; i < dwEntriesRead; i++)
        				{
        					if(pTmpLocalBuf && !_wcsicmp(wszGroup, pTmpLocalBuf->lgrui0_name))
        					{
        						bFound = TRUE;
        						break;
        					}
        					pTmpLocalBuf++;
        				}
        				fpNetApiBufferFree(pLocalBuf);
        			}
        		}
        		else
        		{
        			wcsncat(wszDomain, wszGroup, pwszTemp-wszGroup);
        			pwszTemp++;
        			wcscpy(wszGroup, pwszTemp);
        		}
        		
        		if(!bFound)
        		{
        			/* Get domain controler name */			
        			if(fpNetGetDCName(NULL, wszDomain, &pDCBuf) == NERR_Success)
        			{
        				wcscpy(wszServer, (LPWSTR)pDCBuf);
        				fpNetApiBufferFree(pDCBuf);
        				/* Reset local buffer pointer */
        				pLocalBuf = NULL;
        				/* Get domain local groups */
        				fpNetUserGetLocalGroups(wszServer, wszUser, 0, LG_INCLUDE_INDIRECT, (LPBYTE*)&pLocalBuf,
        										MAX_PREFERRED_LENGTH, &dwEntriesRead, &dwTotalEntries);
        				if(pLocalBuf)
        				{
        					pTmpLocalBuf = pLocalBuf;
        					/* Loop through list of domain local groups */
        					for(i = 0; i < dwEntriesRead; i++)
        					{
        						if(pTmpLocalBuf && !_wcsicmp(wszGroup, pTmpLocalBuf->lgrui0_name))
        						{
        							bFound = TRUE;
        							break;
        						}
        						pTmpLocalBuf++;
        					}
        					fpNetApiBufferFree(pLocalBuf);
        				}
        				
        				if(!bFound)
        				{
        					/* Get domain global groups */
        					fpNetUserGetGroups(wszServer, wszUser, 0, (LPBYTE*)&pGlobalBuf,
        									   MAX_PREFERRED_LENGTH, &dwEntriesRead, &dwTotalEntries);
        					if(pGlobalBuf)
        					{
        						pTmpGlobalBuf = pGlobalBuf;
        						/* Loop through list of domain global groups */
        						for(i = 0; i < dwEntriesRead; i++)
        						{
        							if(pTmpGlobalBuf && !_wcsicmp(wszGroup, pTmpGlobalBuf->grui0_name))
        							{
        								bFound = TRUE;
        								break;
        							}
        							pTmpGlobalBuf++;
        						}
        						fpNetApiBufferFree(pGlobalBuf);
        					}
        				}
        			}
        		}
        	}
        	FreeLibrary(hLib);
        }        
        /* Free temporary storage */        
        AU3_FreeString(szGroup);
        if (n_AU3_NumParams == 1)
           free(szUser);
        else
            AU3_FreeString(szUser);
    }
    
    /* Allocate and build the return variable */
    pMyResult = AU3_AllocVar();
    
    /* Set the return variable */
    if (bFound)
       AU3_SetInt32(pMyResult, 1);
    else
       AU3_SetInt32(pMyResult, 0);
    
    /* Pass back the result, error code and extended code.
     * Note: AutoIt is responsible for freeing the memory used in p_AU3_Result
     */
    *p_AU3_Result		= pMyResult;
    *n_AU3_ErrorCode	= 0;
    *n_AU3_ExtCode		= 0;
    
    return AU3_PLUGIN_OK;
}
