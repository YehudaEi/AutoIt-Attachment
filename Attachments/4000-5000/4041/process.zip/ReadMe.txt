Description of "Process Analyzer"

The "Process Analyzer" displays the running processes
in the upper listbox. After clicking on any entry the
top level windows belonging to this process will be shown 
in the lower listbox. If there exists at least one window,
the button "Modules" will be enabled, and when clicking 
it you'll get displayed all of the DLLs, OCXe etc. which 
are used (loaded) by the selected process. On selecting
a list entry, the version of the module will displayed.
With the button "Terminate" you can terminate the selected 
process except of "kernel32.dll" and "explorer.exe".

For using this tool just unzip it into a separate folder
and make sure to have the VB5 Runtime Support installed.

Delphin Software
Mail: delphinsoft@gmx.de