#include <Windows.h>

DWORD WINAPI ThreadProc(LPVOID lpParameter);
void NullMemory(void *pVoid, unsigned int uiSize);
char *const TrimCommandLine();

// Thin wrapper around the PROCESS_INFORMATION structure to ensure the handles are closed
class CProcessInformation : public PROCESS_INFORMATION
{
public:
	CProcessInformation()
	{
		hProcess = NULL;
		hThread = NULL;
	}

	~CProcessInformation()
	{
		CloseHandle(hProcess);
		CloseHandle(hThread);
	}
};

// Class to organize the data necessary for std handle
class CStdHandle
{
public:
	CStdHandle(SECURITY_ATTRIBUTES sa, DWORD dwSize = 0) : m_hRead(NULL), m_hWrite(NULL), m_sa(sa), m_dwSize(dwSize) { }
	~CStdHandle()
	{
		CloseHandle(m_hRead);
		CloseHandle(m_hWrite);
	}
	bool CreatePipe() { return ::CreatePipe(&m_hRead, &m_hWrite, &m_sa, m_dwSize) != 0; }
	HANDLE Read() const { return m_hRead; }
	HANDLE Write() const { return m_hWrite; }
	SECURITY_ATTRIBUTES SecurityAttributes() const { return m_sa; }
private:
	HANDLE m_hRead;
	HANDLE m_hWrite;
	SECURITY_ATTRIBUTES m_sa;
	DWORD m_dwSize;
};

// POD to hold the handles used in the thread callback
struct ThreadParams 
{
	HANDLE hRead;
	HANDLE hWrite;
};

int main(/*Its unsafe to use the arguments to main if not linking against CRT*/)
{
	DWORD dwExitCode(0x7FFFFFFF);

	// Create the child process std handles
	SECURITY_ATTRIBUTES saAttr = { sizeof(SECURITY_ATTRIBUTES), NULL, TRUE };
	CStdHandle cStdOut(saAttr), cStdErr(saAttr), cStdIn(saAttr);
	
	if (!cStdOut.CreatePipe() || !cStdErr.CreatePipe() || !cStdIn.CreatePipe())
	{
		MessageBox(NULL, "Unable to create std handles.", "Error", MB_ICONERROR);
		return dwExitCode;
	}

	SetHandleInformation(cStdOut.Read(), HANDLE_FLAG_INHERIT, 0);
	SetHandleInformation(cStdErr.Read(), HANDLE_FLAG_INHERIT, 0);
	SetHandleInformation(cStdIn.Write(), HANDLE_FLAG_INHERIT, 0);

	// Trim the name of this executable
	char *const p = TrimCommandLine();

	// Create the process information
	CProcessInformation pi;
	STARTUPINFO si;
	NullMemory(&si, sizeof(si));
	si.cb	= sizeof(si);
	si.dwFlags	= STARTF_USESHOWWINDOW | STARTF_USESTDHANDLES;
	si.wShowWindow = SW_SHOWNORMAL;
	si.hStdOutput = cStdOut.Write();
	si.hStdError = cStdErr.Write();
	si.hStdInput = cStdIn.Read();

	// Start the child process
	if (CreateProcess(NULL, p, NULL, NULL, TRUE, NULL, NULL, NULL, &si, &pi))
	{
		// Set up the POD structures
		ThreadParams tpStdOut = { cStdOut.Read(), GetStdHandle(STD_OUTPUT_HANDLE) };
		ThreadParams tpStdErr = { cStdErr.Read(), GetStdHandle(STD_ERROR_HANDLE) };
		ThreadParams tpStdIn = { GetStdHandle(STD_INPUT_HANDLE), cStdIn.Write()  };

		// Create the threads to monitor each std handle
		HANDLE hThreadStdOut = CreateThread(NULL, 0, &ThreadProc, &tpStdOut, 0, NULL);
		HANDLE hThreadStdErr = CreateThread(NULL, 0, &ThreadProc, &tpStdErr, 0, NULL);
		HANDLE hThreadStdIn = CreateThread(NULL, 0, &ThreadProc, &tpStdIn, 0, NULL);

		// Wait for the process to exit and get the exit code
		do
		{
			GetExitCodeProcess(pi.hProcess, &dwExitCode);
			Sleep(10);
		}
		while (dwExitCode == STILL_ACTIVE);

		// Stop all the other threads
		TerminateThread(hThreadStdOut, 0);
		TerminateThread(hThreadStdErr, 0);
		TerminateThread(hThreadStdIn, 0);
	}
	return dwExitCode;
}

// Thread callback function
DWORD WINAPI ThreadProc(LPVOID lpParameter)
{
	ThreadParams *pHandles = reinterpret_cast<ThreadParams*>(lpParameter);
	// This buffer size is small so that the symbol __chkstk will not be required
	// Avoiding this symbol allows us to avoid linking to MSVCRT and
	// so we can have a super-tiny executable (This requires the appropriate
	// compiler/linker settings to achieve).
	const unsigned int uiBufferSize(2048);
	char szBuffer[uiBufferSize];
	DWORD dwRead, dwWritten;
	while(true)
	{
		if (ReadFile(pHandles->hRead, &szBuffer, uiBufferSize, &dwRead, NULL))
			WriteFile(pHandles->hWrite, szBuffer, dwRead, &dwWritten, NULL);
		Sleep(10);
	}
}

// Equivalent to ZeroMemory
void NullMemory(void *pVoid, unsigned int uiSize)
{
	unsigned char *pByte = static_cast<unsigned char*>(pVoid);
	for (unsigned int i = 0; i < uiSize; ++i, ++pByte)
		*pByte = 0;
}

// Trims the name of the executable (us) from the command line
char *const TrimCommandLine()
{
	char *p = GetCommandLine();
	if (*p == '"')
	{
		while (*(++p) != '"');
		p += 2;
	}
	else
	{
		while (*(++p) != ' ');
		p += 1;
	}
	return p;
}