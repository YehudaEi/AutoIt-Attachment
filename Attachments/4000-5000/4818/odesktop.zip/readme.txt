Quick guide for odesktop
========================

Right click on the Quick Launch bar, after the last button in the
taskbar, to have the context menu with 'open folder' and select this
to open "...\Microsoft\Internet Explorer\Quick Launch"

Move the file "Open Desktop.scf" to a save place; I think just one
level higher should be Ok. This way any change to your Quick Launch
bar can be restored whenever necessary.

Unzip odesktop and place the odesktop directory to a useful location, for
example to have it as %programfiles%\odesktop.

Within odesktop, double click create_shortcut.js to create
"click above inner icon to open folder.lnk".

Drag and drop this shortcut directly to a convenient position within
the Quick Launch bar.

Now you should have replaced the original function of the desktop icon
by odesktop and everything is prepared to try:

Click on the icon but not higher than the inner icon
--> ToggleDesktop function as usual

Click on the icon above the inner icon
--> Open Desktop as folder


klaus.s 2005`10`25
