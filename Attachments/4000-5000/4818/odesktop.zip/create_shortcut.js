var WSH= new ActiveXObject( "WScript.Shell")
var FSO= new ActiveXObject( "Scripting.FileSystemObject")

shortcut= WSH.createShortcut( "click above inner icon to open folder.lnk")
shortcut.TargetPath= FSO.GetAbsolutePathName( "odesktop.exe")
shortcut.IconLocation= FSO.GetAbsolutePathName( "odesktop.ico")
shortcut.Save()
