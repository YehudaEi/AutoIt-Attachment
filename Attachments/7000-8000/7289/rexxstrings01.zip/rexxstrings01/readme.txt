REXX01.AU3 for AUTOIT3                                  03-06-06
Autor: Lutz M�ller, FH K�ln - Campus Gummersbach

Please, follow:

1.	The manual is written on in German. It is worth to a FREEPASCSAL Unit
2.	Width information about the text functions REXX under:

http://ftp.gwdg.de/pub/languages/rexx/brexx/html/string.html
http://www.ilook.fsnet.co.uk/index/rexstr.htm
http://nokix.pasjagsm.pl/help/learn_rexx/funcs2.htm

Changes to version 00
03-06-06: Define of all local variables in the string functions