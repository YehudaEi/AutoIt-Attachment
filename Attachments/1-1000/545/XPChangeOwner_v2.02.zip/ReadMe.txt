v2.02
(Dec 5 2004)  (Note - Do not try on XP 64bit Edition.)



What U Do:
==========
1- Run XPChangeOwner.exe from anywhere (it runs everything by itself no other files needed**.)
2- Say yes to the setup and shutdown when machine boots up customer fills it out and reboots.	
-----------Thats it, give to customer and when they turn it on it begins.-------------------

**NoTE - Will now install any OEMLOGO.bmp place within the same dir as XPChangeOwner.exe.
=============================================================================================
=============================================================================================

Aborts, removals:
-----------------
Can cancel before install via Ok/Cancel install button
Can cancel and REMOVE install by running XPChangeOwner.exe from anywhere but "C:\RegOwner"
	and it will offer to remover setup folder and registry setting.
Can ABORT during Data input by entering Acer in either User or Owner boxes and confirming.
==============================================================================================



What They Do (new Owner):
=========================
Once Windows starts, but before any menu access is available the first user/owner will be 
prompted to enter the following Data:
	1-Owners Name	(can be blank) 
	2-Company or Organization	(can be blank)
	3-Main Users Name(or nickname)	(cannot be blank, and spaces are removed)
They will be display data back and asked to confirm, if NO it will restart Question Input.

Once they accept (OK) the diplayed data it begins changing the info.
They will then be dispayed a reboot message and the machine will reboot completing the proceedure.

Done!
==============================================================================================





What Happens:
=============
Service Tech install:
--------------------
1 - Checks to see if it is already installed in registry
		- if not, copies itself to c:\RegOwner and writes startup in RunOnce key
		- if is, offers to be uninstalled if running from outside c:\RegOwner
2 - Checks for OEMLOGO.BMP in it's dir and if so copies to computer c:\RegOwner
3 - Offers to ShutDown and Power OFF computer for Service Tech.

Customer turns computer on:
--------------------------
1 - Confirms OS is Windows XP via registry
	If not Windows XP, will error with message.
2 - Checks to see if it is running from C:\RegOwner if so continues

3 - Detects and stores current User account name in memory

4 - Displays 3 Input Boxes, 1 after another (hope to make all in one, not able yet).
	Each asking user neccisary data to preform changes.

5 - Shows user Data entered and asks for confirmation.

6 - Checks to see if Acer was entered in either USER or OWNER and if not continues

7 - Checks for OEMLOGO.BMP in its working folder and if so copies to System32 folder

8 - Changes registry key to new inputed values. 
	HKEY_LOCAL_MACHINE, Software\Microsoft\Windows NT\CurrentVersion, RegisteredOwner
	HKEY_LOCAL_MACHINE, Software\Microsoft\Windows NT\CurrentVersion, RegisteredOrganization

9 - Creates New User Account and gives Admin rights via NET USER and NET LOCALGROUPS command

10 - Deletes Current logged on User Account via NET USER command

11 - Deletes registry key 
	HKEY_LOCAL_MACHINE, SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\DocFolderPaths, CURRENT-USER-NAME

12 - Creates CleanUp.bat files to remove itself upon reboot

13 - Writes registry key for after reboot to cleanup and remove its own files & folder.
	HKEY_LOCAL_MACHINE, SOFTWARE\Microsoft\Windows\CurrentVersion\RunOnce, Cleanup,C:\regowner\cleanup.bat

14 - Notifies User to Reboot or it will automatically in 3 seconds

15 - Upon reboot/startup cleanup.bat runs and removes:
	"C:\Documents and Settings\CURRENT-USER-NAME" folder
	"C:\regowner\*.*" - itself  

=====================================================================================================


My To Do List:
==============
-Bring focus to 1st entry window (works except when started by runonce at bootup?)
-Create all data input in one window with 3 text input areas 
	(current script program can't though they told me they will work on it)) 
-Currently unable to remove registry entry
	HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\Windows NT\CurrentVersion\ProfileList\
as the actual key generates differing numbers for each install (looking into it though).

Notes:
======
Currently only tested on:
Windows XP Home (no service packs)
Windows XP Professional (no service packs)

P.S. it is scripted to error out if it does not detect "Microsoft Windows XP" version in the registry.



Changes History:
================
v2.02 - Change code (@COMSPEC & " /C" "NET...... to (@COMSPEC & " /C NET......
v2.01 - Added ability to install OEMLOGO.BMP to system32 folder if located in same dir as XPChangeOwner.exe  
	- Added function to detect current loggeg on USER name and remove it (instad of just the "Acer" username).
			-this avoids problems possibly created by an errored setup User account name.
	- Added "Please Click Here" text to first inputbox so user knows to bring into focus (see to do list).
v2.00 - Total rewrite using AutoIt v3.0.102
	- Combined many features to keep it solo, no more supporting files with zip, exe is all you need.
	- FIXED -BUG - User can no longer leave USER input blank (which boots to Administrator login)
	- Added Install so it will install itself & write to RunOnce itself (no need for zip or reg file)
	- Added UnInstall so if run from anywhere other than it's install dir it will offer to uninstall
	- Added several checks to see if it is in the registry before doing specific things.
	- Added a Create it's own Cleanup.bat file for after completion
	- Added Hiding cmd prompt windows
	- Added Shutdown/powerdown after install setup
v1.02 - Added feature to remove spaces in USER if they are entered plus text msg to warn of it.
	- Added Abort feature, if Acer (or acer) is used for either Owner or User.
	- FIXED -BUG - when Customers USER name has a space 2nd word becomes password (now removes any spaces).
v1.01 - Cleaned up code
	- added Tabs to Confirmation Message box to make Users Data easier to read and confirm
	- Change some text in some title bars (New Owner Data Required to Owner Data Required splash Message)
	- Change Splash screen text as per Colins request
	- "found bug" (Space in USER name makes 2nd word password, not suree bout 3rd etc.), added temporary 
		Text message telling user not to but am working on correcting.
v1.00 - Quick release to Colin, still wanting to do some cleaning up.
	- only tested on XP Home without service packs.

=========================================================================================================
Please contact me with wants,wishes, or errors.
A.B.Ames
abames@drytel.net