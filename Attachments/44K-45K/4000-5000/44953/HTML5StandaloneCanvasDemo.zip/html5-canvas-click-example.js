// Simple interactive HTML5 Canvas demo
// Author: Ascend4nt (except MouseEventToCanvasCoords() by Mark Pilgrim)

// Globals
var g_Canvas, g_Ctx;
var g_LastX, g_LastY;
var g_bMouseDown = false;

// Canvas event coordinate transfer
// (from http://diveintohtml5.info/canvas.html)
// Author: Mark Pilgrim
function MouseEventToCanvasCoords(e, Canvas)
{
	var x, y;
	if (e.pageX != undefined && e.pageY != undefined) {
		x = e.pageX;
		y = e.pageY;
    }
    else {
		x = e.clientX + document.body.scrollLeft +
            document.documentElement.scrollLeft;
		y = e.clientY + document.body.scrollTop +
            document.documentElement.scrollTop;
    }
    x -= Canvas.offsetLeft;
    y -= Canvas.offsetTop;
    return [x, y];
}
// "oncontextmenu" handler for Canvas
function OnCanvCtxMenu(evt)
{
    evt = evt || window.event;    
    //console.log("Canvas Context-menu event");

    // Prevent the Default context menu from showing up:
    evt.preventDefault();
    evt.returnValue = false;    
}
// "onmousedown" handler for Canvas
// - Draws small box, records X, Y position -
function MouseDownCanv(evt)
{
	evt = evt || window.event;
	//var elem = evt.target || event.SrcElement;

	// evt.x doesn't work on Firefox:
	//g_LastX = evt.x - g_Canvas.offsetLeft;
    //g_LastY = evt.y - g_Canvas.offsetTop;
    var coords = MouseEventToCanvasCoords(evt, g_Canvas);
    g_LastX = coords[0];
    g_LastY = coords[1];
    
    //console.log("Mouse down recvd, X = " + g_LastX);
    
    g_bMouseDown = true;
    g_Ctx.fillStyle = "blue";
    g_Ctx.fillRect(g_LastX - 2, g_LastY - 2, 3, 3);
}
// "onmouseup" handler for Canvas
// - Draws either a line from last X, Y, or draws a circle if no movement -
function MouseUpCanv(evt)
{
    evt = evt || window.event;
    if (g_bMouseDown)
    {
		var coords = MouseEventToCanvasCoords(evt, g_Canvas);
        var x2 = coords[0], y2 = coords[1];
        
        // Assemble random color string as a '#' followed by 3 hex pairs: "#1A2B3C"
        // Math.floor(Math.random() * 256) generates a value between 0 and 255,
        // and toString(16) converts it to base16 hex (2 digits max, with FF == 255)
        var sColor = "#";
        for (i = 0; i < 3; i++)
            sColor += Math.floor((Math.random() * 256)).toString(16);
        
        //console.log("Color = " + sColor);

        // Draw either a line or circle depending on where the mouse button is released
		if (x2 == g_LastX && y2 == g_LastY)
        {
            // Circle if mouse start = mouse end
			g_Ctx.beginPath();
            g_Ctx.arc(x2, y2, 8, 0, Math.PI * 2);
            g_Ctx.fillStyle = sColor;
            g_Ctx.fill();
        } else {
            // Line if mouse start <> mouse end
            g_Ctx.beginPath();
            g_Ctx.lineWidth = "3";
            g_Ctx.strokeStyle = sColor;
            g_Ctx.moveTo(g_LastX, g_LastY);
            g_Ctx.lineTo(x2, y2);
            g_Ctx.stroke();
        }
		g_bMouseDown = false;
    }    
}
// Main function (runs after page is loaded)
function main()
{
    //console.log("HTML loaded");
    
    // Get Canvas element and Context
    g_Canvas = document.getElementById("myCanvas");
    if (!g_Canvas) return;
    g_Ctx = g_Canvas.getContext("2d");
    if (!g_Ctx) return;   
    
    // Add event handlers (The onevent="func()" attributes work incorrectly
    // in Firefox [event objects aren't passed])
    // Also, older IE versions might need .attachEvent()
    g_Canvas.addEventListener("mousedown", MouseDownCanv, false);
    g_Canvas.addEventListener("mouseup", MouseUpCanv, false);
    g_Canvas.addEventListener("contextmenu", OnCanvCtxMenu, false);
    
    // Example Drawing: Gradient:    
    var Grad = g_Ctx.createLinearGradient(0,0,0,60);
	if (Grad)
    {
		Grad.addColorStop(0, "red");
		Grad.addColorStop(1, "blue");
		g_Ctx.fillStyle = Grad;
    }
	g_Ctx.fillRect(0,0,419,60);
     
    // Example Drawing: Text
	g_Ctx.font = "30px serif";
	g_Ctx.fillStyle = "white";
	g_Ctx.textBaseline = "top";
	g_Ctx.fillText("HTML5 Canvas Drawing!", 50, 10);
    
    // Example Drawing: Circle, Line
	g_Ctx.beginPath();
	g_Ctx.arc(200, 100, 20, 0, Math.PI * 2);
	g_Ctx.fillStyle = "red";
	g_Ctx.fill();

	g_Ctx.beginPath();
	g_Ctx.lineWidth = "3";
	g_Ctx.strokeStyle = "green";
	g_Ctx.moveTo(185, 85);
	g_Ctx.lineTo(215, 115);
	g_Ctx.stroke();
    
    // End main [event handlers will continue to run]
}

window.onload = main;