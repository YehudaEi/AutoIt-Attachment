Tools
	AutoIt 3.3.10.2 / SciTE 3.4.1

How to reproduce : Just compile (F7)

Got Errors :
       test_stripped.au3(146,43) : error: Function165(): undefined function.
       test_stripped.au3(152,35) : error: Function051(): undefined function.

WARNING !!
	Referring to another problem report, if you change to "/mo" switch, the "test_stripped.au3" output
	file will never be updated
	==> Remove this output file before compilation

	
NOTE
	I tried to removed useless functions, but in this case the problem disappears...
	See "global.au3" for some comment on specific lines.