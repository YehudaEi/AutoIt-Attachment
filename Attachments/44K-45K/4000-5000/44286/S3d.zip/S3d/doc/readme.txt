=================================================
 S3d - Simple 3D Graphic Library
 v1.3.1 (09/JUN/2014)
 
 Author: Starg
 
 - Tested on: Windows 7 SP1 (x86)
              AutoIt v3.3.12.0
 - Requires GDIPlus.au3
 
 * Use at your own risk!
 
 - Special Thanks: S.Programs
=================================================


* Functions
=================================================
_S3d_SelectGraphic($hGraphic, $iWidth, $iHeight, $iSmooth = 2)
_S3d_SelectPen($hPen)
_S3d_SelectBrush($hBrush)
_S3d_SelectFont($hFont)
_S3d_SelectFormat($hFormat)
_S3d_SetClipCount($iCount)
_S3d_Dist($nPos1X = 0, $nPos1Y = 0, $nPos1Z = 0, $nPos2X = 0, $nPos2Y = 0, $nPos2Z = 0)
_S3d_DistFromCamera($nPosX = 0, $nPosY = 0, $nPosZ = 0)
_S3d_SetCamera($nCameraX, $nCameraY, $nCameraZ, $nTargetX, $nTargetY, $nTargetZ, $nVAngle = 0, $nFAngle = 0.8, $nFScale = 1000)
_S3d_SetCameraEx($nCameraX, $nCameraY, $nCameraZ, $nXYAngle = 0, $nXZAngle = 0, $nVAngle = 0, $nFAngle = 0.8, $nFScale = 1000)
_S3d_SetLocalMatrix($n00 = 1, $n01 = 0, $n02 = 0, $n03 = 0, $n10 = 0, $n11 = 1, $n12 = 0, $n13 = 0, $n20 = 0, $n21 = 0, $n22 = 1, $n23 = 0, $n30 = 0, $n31 = 0, $n32 = 0, $n33 = 1)
_S3d_MultiplyLocalMatrix($n00 = 1, $n01 = 0, $n02 = 0, $n03 = 0, $n10 = 0, $n11 = 1, $n12 = 0, $n13 = 0, $n20 = 0, $n21 = 0, $n22 = 1, $n23 = 0, $n30 = 0, $n31 = 0, $n32 = 0, $n33 = 1, $fRefresh = True)
_S3d_LocalTranslate($nX, $nY, $nZ, $fRefresh = True)
_S3d_LocalScale($nX, $nY, $nZ, $fRefresh = True)
_S3d_LocalRotateX($nAngle, $fDeg = False, $fRefresh = True)
_S3d_LocalRotateY($nAngle, $fDeg = False, $fRefresh = True)
_S3d_LocalRotateZ($nAngle, $fDeg = False, $fRefresh = True)
_S3d_GetLocalMatrix()
_S3d_SetLocalMatrixEx(ByRef $aMatrix)
_S3d_GetPos($nX, $nY, $nZ)
_S3d_InitCurrentPos()
_S3d_MoveTo($nX, $nY, $nZ = Default)
_S3d_Clear($nColor = 0xFF000000)
_S3d_Line($nX1, $nY1, $nZ1, $nX2, $nY2, $nZ2)
_S3d_LineTo($nX, $nY, $nZ)
_S3d_Box($nX1, $nY1, $nZ1, $nX2, $nY2, $nZ2)
_S3d_Arrow($nX1, $nY1, $nZ1, $nX2, $nY2, $nZ2, $nLen = 30, $nAngle = 0.6)
_S3d_Circle($nX, $nY, $nZ, $nRad, $fFill = False)
_S3d_Polygon($aPoints, $fFill = False)
_S3d_RegPolygon($nX, $nY, $nZ, $nRad, $iNum, $fFill = True)
_S3d_Star($nX, $nY, $nZ, $nRad1, $nRad2, $iNum, $fFill = True)
_S3d_Square($nX1, $nY1, $nZ1, $nX2, $nY2, $nZ2, $nX3, $nY3, $nZ3, $nX4, $nY4, $nZ4, $fFill = True)
_S3d_MoveTo2($nXL, $nYL, $nZL, $nXR, $nYR, $nZR)
_S3d_RibbonTo($nXL, $nYL, $nZL, $nXR, $nYR, $nZR)
_S3d_String($sString, $nX, $nY, $nZ)


* Functions (Internal use only)
=================================================
__S3d_CreateMatrix()
__S3d_SetMatrix(ByRef $aMatrix, $n00 = 1, $n01 = 0, $n02 = 0, $n03 = 0, $n10 = 0, $n11 = 1, $n12 = 0, $n13 = 0, $n20 = 0, $n21 = 0, $n22 = 1, $n23 = 0, $n30 = 0, $n31 = 0, $n32 = 0, $n33 = 1)
__S3d_MultiplyMatrix(ByRef $aOutMatrix, ByRef $aInMatrix1, ByRef $aInMatrix2)
__S3d_SetCamera($nCameraX, $nCameraY, $nCameraZ, $nXYCos, $nXYSin, $nXZCos, $nXZSin, $nVAngle, $nFAngle, $nFScale)
__S3d_ConvertPos(ByRef $nOutX, ByRef $nOutY, $nInX, $nInY, $nInZ)
__S3d_Clip(ByRef $nOutX, ByRef $nOutY, $nOkX, $nOkY, $nOkZ, $nFailX, $nFailY, $nFailZ)
__S3d_Deg2Rad($nDeg)

