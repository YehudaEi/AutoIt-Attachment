using namespace std;
#include "Header.h"

extern "C"
{
	DLLEXPORT int Disturb(int dX, int dY, int width, int height, int ripRad, int depth,
		bool useBuffer1, heightMap &rippleMap1, heightMap &rippleMap2)
	{
		heightMap &dest = (useBuffer1) ? (rippleMap1) : (rippleMap2);
		int bounds = width * height;

		for (int x = dX - ripRad; x < dX + ripRad; x++)
		{
			for (int y = dY - ripRad; y < dY + ripRad; y++) 
			{
				dest.data[BoundsCheck(x + y * width, 0, bounds)] = depth;
			}
		}

		return 0;
	}

	DLLEXPORT int NewFrame(newFrameParams &pr,
		heightMap &rippleMap1, heightMap &rippleMap2,
		pixelMap &ripple, pixelMap &texture)
	{
		heightMap &source = (pr.useBuffer1) ? (rippleMap1) : (rippleMap2);
		heightMap &dest = (pr.useBuffer1) ? (rippleMap2) : (rippleMap1);

		int bounds = pr.width * pr.height;
		int width = pr.width;
		int i = 0;
		int xOff;
		for (i = width; i < bounds - width; i++)
		{
			dest.data[i] = ((source.data[i - 1] + 
							 source.data[i + 1] +
							 source.data[i - width] +
							 source.data[i + width]) >> 1) - dest.data[i];
			dest.data[i] -= (dest.data[i] >> 5);

			if ((texture.data[i] >> 24) && 0xFF) // only modify if the alpha is greater than 0
			{
				if (source.data[i] != dest.data[i])
				{
					xOff = dest.data[i - 1] - dest.data[i + 1];
					ripple.data[i] = texture.data[BoundsCheck(
						i + xOff
						+ (dest.data[i - width] - dest.data[i + width]) * width, 0, bounds
						)];
					Shade(ripple.data[i], xOff);
				}
				else
				{
					ripple.data[i] = texture.data[i];
				}
			}
		}

		// Force edge elements to 0
		for (i = 0; i < width; i++) // Top pixel row
		{
			if (dest.data[i] != 0) dest.data[i] = 0;
		}
		for (i = width * 2; i < bounds - width; i += width) // Left pixel column
		{
			if (dest.data[i] != 0) dest.data[i] = 0;
		}
		for (i = width * 2 - 1; i < bounds - width; i += width) // Right pixel column
		{
			if (dest.data[i] != 0) dest.data[i] = 0;
		}
		for (i = bounds - width; i < bounds; i++) // Bottom pixel row
		{
			if (dest.data[i] != 0) dest.data[i] = 0;
		}

		pr.useBuffer1 = !pr.useBuffer1;

		return 0;
	}

	int BoundsCheck(int number, int lower, int higher)
	{
		if (number >= higher)
		{
			return higher - 1;
		}
		else if (number < lower) return lower;

		return number;
	}

	void Shade(unsigned int &ARGB, int factor)
	{
		if (factor == 0) return;
		factor = BoundsCheck(factor, -12, 12);

		ARGB = ((ARGB >> 16) % 256) * 16777216  + GetRGB(
			((ARGB >> 16) % 256) + factor, 
			((ARGB >> 8) % 256) + factor, 
			(ARGB % 256) + factor
			);
	}
	unsigned int GetRGB(int iR, int iG, int iB)
	{
		return (BoundsCheck(iR, 0, 256) * 65536) + (BoundsCheck(iG, 0, 256) * 256) + (BoundsCheck(iB, 0, 256));
	}
}
