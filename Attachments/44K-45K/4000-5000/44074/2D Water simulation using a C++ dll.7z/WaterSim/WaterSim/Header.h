#ifndef _DLL_AU3_EXPORT
#define _DLL_AU3_EXPORT
#include <iostream>
#include <math.h>

#define DLLEXPORT __declspec(dllexport)

struct newFrameParams
{
	int width;
	int height;
	bool useBuffer1;
};
struct heightMap
{
	short data[];
};
struct pixelMap
{
	unsigned int data[];
};

extern "C"
{
	DLLEXPORT int Disturb(int dX, int dY, int width, int height, int ripRad, int depth,
		bool useBuffer1, heightMap &rippleMap1, heightMap &rippleMap2);
	DLLEXPORT int NewFrame(newFrameParams &pr,
		heightMap &rippleMap1, heightMap &rippleMap2,
		pixelMap &rippleData, pixelMap &textureData);

	int BoundsCheck(int number, int lower, int higher);
	void Shade(unsigned int &ARGB, int factor);
	unsigned int GetRGB(int iR, int iG, int iB);
}

#endif // closing #ifndef _DLL_AU3_EXPORT