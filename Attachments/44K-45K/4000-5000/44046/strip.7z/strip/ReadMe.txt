Tools
	AutoIt 3.3.10.2 (with or without 3.3.11.5-beta)
	SciTE 3.4.1

How to reproduce :
	1) Choose any non-system/non-critical process with your task manager and get its PID
	2) Put this number at line 13
	3) Verify that everything is fine, except this problem : just comment lines 5&6 and compile (F7)
	4) Run the compiled EXE and verify a debug "ArrayDisplay" is shown
	5) Uncomment lines 5&6 and compile (F7)
	6) The produced stripped file contains an error @59. The original source function is in "./Processes_Threads_nDLLs/[Includes]/_ProcessUndocumented.au3", line 160.
	   As you can see, there are in the original source :
	      a) a first code line
	      b) a comment line
	      c) a declarative line with DllStructCreate
	   But in the stripped file, the line "c" has been removed. I got exactly the same problem with another function from the same source file with the same structure-lines
	   a/b/c

