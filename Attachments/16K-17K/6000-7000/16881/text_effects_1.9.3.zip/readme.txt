English:
----------------------------------------------

Hi!

Sometimes I thought about a program I just completed, that there's missing something that makes it a kind of special. So I started coding this text effects. I hope they can help to make your scripts either interesting or better to use.
Another point mentioned very often in the forums can be solved with this UDF too:
You can create a kind of about box out in a label or input component. And the best aspect of this: You can choose out of 18 (!!) different effects to show your credits or data! Just try the function "_txt_eff__about_messages"!

Installation:
Copy the text_effects.au3 either in your your script's dir or in the subfolder "include" of your AutoIt directory!
To use this UDF, you need to compile or run it with  v 3.1.1.66 (Beta) or a later version.

Good luck, peethebee