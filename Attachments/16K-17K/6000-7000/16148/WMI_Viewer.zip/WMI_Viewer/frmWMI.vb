Imports System.Management
Public Class frmWMI
    Inherits System.Windows.Forms.Form

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Friend WithEvents Panel1 As System.Windows.Forms.Panel
    Friend WithEvents LB As System.Windows.Forms.ListBox
    Friend WithEvents PB As System.Windows.Forms.ProgressBar
    Friend WithEvents SB As System.Windows.Forms.StatusBar
    Friend WithEvents Splitter1 As System.Windows.Forms.Splitter
    Friend WithEvents LV As System.Windows.Forms.ListView
    Friend WithEvents ch1 As System.Windows.Forms.ColumnHeader
    Friend WithEvents ch2 As System.Windows.Forms.ColumnHeader
    Friend WithEvents btnStop As System.Windows.Forms.Button
    Friend WithEvents btnUpdate As System.Windows.Forms.Button
    Friend WithEvents CLB As System.Windows.Forms.CheckedListBox
    Friend WithEvents Label1 As System.Windows.Forms.Label
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
Me.Panel1 = New System.Windows.Forms.Panel()
Me.Label1 = New System.Windows.Forms.Label()
Me.CLB = New System.Windows.Forms.CheckedListBox()
Me.btnUpdate = New System.Windows.Forms.Button()
Me.btnStop = New System.Windows.Forms.Button()
Me.LB = New System.Windows.Forms.ListBox()
Me.PB = New System.Windows.Forms.ProgressBar()
Me.SB = New System.Windows.Forms.StatusBar()
Me.Splitter1 = New System.Windows.Forms.Splitter()
Me.LV = New System.Windows.Forms.ListView()
Me.ch1 = New System.Windows.Forms.ColumnHeader()
Me.ch2 = New System.Windows.Forms.ColumnHeader()
Me.Panel1.SuspendLayout()
Me.SuspendLayout()
'
'Panel1
'
Me.Panel1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
Me.Panel1.Controls.AddRange(New System.Windows.Forms.Control() {Me.Label1, Me.CLB, Me.btnUpdate, Me.btnStop})
Me.Panel1.Dock = System.Windows.Forms.DockStyle.Top
Me.Panel1.Name = "Panel1"
Me.Panel1.Size = New System.Drawing.Size(620, 92)
Me.Panel1.TabIndex = 0
'
'Label1
'
Me.Label1.AutoSize = True
Me.Label1.Location = New System.Drawing.Point(6, 3)
Me.Label1.Name = "Label1"
Me.Label1.Size = New System.Drawing.Size(169, 15)
Me.Label1.TabIndex = 5
Me.Label1.Text = "Hide classes with qualifiers:"
'
'CLB
'
Me.CLB.Anchor = ((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right)
Me.CLB.BackColor = System.Drawing.SystemColors.ControlLight
Me.CLB.CheckOnClick = True
Me.CLB.ColumnWidth = 120
Me.CLB.IntegralHeight = False
Me.CLB.Items.AddRange(New Object() {"abstract", "aggregation", "association", "autocook", "classcontext", "costly", "createby", "deleteby", "description", "dynamic", "genericperfctr", "helpindex", "hiperf", "locale", "mappingstring", "perfdefault", "perfdetail", "perfindex", "provider", "registrykey", "singleton", "supportupdate", "uuid"})
Me.CLB.Location = New System.Drawing.Point(6, 24)
Me.CLB.MultiColumn = True
Me.CLB.Name = "CLB"
Me.CLB.Size = New System.Drawing.Size(498, 60)
Me.CLB.TabIndex = 4
'
'btnUpdate
'
Me.btnUpdate.Anchor = (System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right)
Me.btnUpdate.Location = New System.Drawing.Point(511, 23)
Me.btnUpdate.Name = "btnUpdate"
Me.btnUpdate.Size = New System.Drawing.Size(100, 28)
Me.btnUpdate.TabIndex = 3
Me.btnUpdate.Text = "Load Classes"
'
'btnStop
'
Me.btnStop.Anchor = (System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right)
Me.btnStop.Location = New System.Drawing.Point(511, 56)
Me.btnStop.Name = "btnStop"
Me.btnStop.Size = New System.Drawing.Size(100, 28)
Me.btnStop.TabIndex = 0
Me.btnStop.Text = "Stop"
'
'LB
'
Me.LB.Dock = System.Windows.Forms.DockStyle.Left
Me.LB.IntegralHeight = False
Me.LB.ItemHeight = 16
Me.LB.Location = New System.Drawing.Point(0, 92)
Me.LB.Name = "LB"
Me.LB.Size = New System.Drawing.Size(204, 383)
Me.LB.Sorted = True
Me.LB.TabIndex = 1
'
'PB
'
Me.PB.Anchor = ((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right)
Me.PB.Location = New System.Drawing.Point(0, 477)
Me.PB.Maximum = 1000
Me.PB.Name = "PB"
Me.PB.Size = New System.Drawing.Size(620, 23)
Me.PB.TabIndex = 3
'
'SB
'
Me.SB.Location = New System.Drawing.Point(0, 475)
Me.SB.Name = "SB"
Me.SB.Size = New System.Drawing.Size(620, 26)
Me.SB.TabIndex = 4
'
'Splitter1
'
Me.Splitter1.BackColor = System.Drawing.SystemColors.ControlDark
Me.Splitter1.Location = New System.Drawing.Point(204, 92)
Me.Splitter1.Name = "Splitter1"
Me.Splitter1.Size = New System.Drawing.Size(3, 383)
Me.Splitter1.TabIndex = 5
Me.Splitter1.TabStop = False
Me.Splitter1.Visible = False
'
'LV
'
Me.LV.Columns.AddRange(New System.Windows.Forms.ColumnHeader() {Me.ch1, Me.ch2})
Me.LV.Dock = System.Windows.Forms.DockStyle.Fill
Me.LV.FullRowSelect = True
Me.LV.GridLines = True
Me.LV.HideSelection = False
Me.LV.Location = New System.Drawing.Point(207, 92)
Me.LV.MultiSelect = False
Me.LV.Name = "LV"
Me.LV.Size = New System.Drawing.Size(413, 383)
Me.LV.TabIndex = 6
Me.LV.Tag = "0"
Me.LV.View = System.Windows.Forms.View.Details
'
'ch1
'
Me.ch1.Text = "Property"
Me.ch1.Width = 120
'
'ch2
'
Me.ch2.Text = "Value"
Me.ch2.Width = 120
'
'Form1
'
Me.AutoScaleBaseSize = New System.Drawing.Size(6, 15)
Me.ClientSize = New System.Drawing.Size(620, 501)
Me.Controls.AddRange(New System.Windows.Forms.Control() {Me.LV, Me.Splitter1, Me.LB, Me.Panel1, Me.PB, Me.SB})
Me.MinimumSize = New System.Drawing.Size(500, 0)
Me.Name = "frmWMI"
Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
Me.Text = "WMI Viewer lets you inspect Win32_... classes"
Me.Panel1.ResumeLayout(False)
Me.ResumeLayout(False)

    End Sub

#End Region

Dim _Stop As Boolean

Private Sub Form1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
  Dim i%
  LV_Resize(Nothing, Nothing)
  CLB.SetItemChecked(2, True) : Application.DoEvents()
  Me.Show()
  Call LoadClasses()
  Splitter1.Visible = True
End Sub

 Sub LoadClasses()
  Dim mc As ManagementClass = New ManagementClass("\\.\root\cimv2"), opt As New EnumerationOptions(), cname$
  opt.EnumerateDeep = True
  Dim mcc As ManagementObjectCollection = mc.GetSubclasses(opt), mo As ManagementObject, _
      q As QualifierData, IsQ As Boolean, cb As CheckBox, qualTest$ = " ", i%
  Me.Cursor.Current = Cursors.WaitCursor
  For i = 0 To CLB.CheckedItems.Count - 1
     qualTest &= CLB.CheckedItems.Item(i).ToString & " "
  Next
  PB.Visible = True
  PB.Value = 20 : LV.Items.Clear()
  LB.Items.Clear() : LB.Items.Add("Loading ...") : Application.DoEvents()
  LB.BeginUpdate()
      For Each mo In mcc
         PB.Value = (PB.Value + 1) Mod PB.Maximum
         cname = mo.Path.className
         If cname Like "Win32_*" Then
           IsQ = True
           For Each q In mo.Qualifiers
               If InStr(qualTest, q.Name.ToLower) <> 0 Then
                 IsQ = False : Exit For
               End If
           Next
           If IsQ Then LB.Items.Add(cname)
         End If
      Next
   LB.Items.RemoveAt(0)
   LB.EndUpdate()
   LB.SelectedIndex = LB.FindStringExact("Win32_ComputerSystem")
   PB.Visible = False : SB.Text = "Done"
   Me.Cursor.Current = Cursors.Default
 End Sub

Private Sub LV_Resize(ByVal sender As Object, ByVal e As System.EventArgs) Handles LV.Resize
  With LV
  If .Width = CInt(.Tag) Then Exit Sub
  .Columns(0).Width = .Width \ 3
  .Columns(1).Width = .Width - .Columns(0).Width - 30
  .Tag = .Width
  End With
End Sub

Private Sub LB_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles LB.SelectedIndexChanged
 _Stop = False : Call FillLVx()
End Sub

Sub FillLVx()
   Me.Cursor.Current = Cursors.WaitCursor
   PB.Visible = True
   PB.Value = 20 : LV.Items.Clear() : LV.BeginUpdate()
   '--------------------------------------------------------------------------
   On Error Resume Next
   Dim mc As ManagementObjectCollection = _
       (New ManagementObjectSearcher("SELECT * FROM " & LB.SelectedItem.ToString)).Get
   Dim [Property] As PropertyData, mo As ManagementObject, item As ListViewItem
   Dim x As String, z As Object
   For Each mo In mc
     Application.DoEvents() : If _Stop Then GoTo [Exit]
     For Each [Property] In mo.Properties()
        Application.DoEvents() : If _Stop Then GoTo [Exit]
        With [Property]
          x = .Name : z = .Value
          item = LV.Items.Add(x)
          If x = "Caption" Then item.ForeColor = Color.Blue
          If Not .IsArray And Not IsNothing(z) Then item.SubItems.Add(z.ToString)
          PB.Value = (PB.Value + 1) Mod PB.Maximum
        End With
     Next
   Next
    '--------------------------------------------------------------------------
[Exit]:
   LV.EndUpdate()
   PB.Visible = False : SB.Text = IIf(_Stop, "Stoped", "Done")
   Me.Cursor.Current = Cursors.Default
End Sub

Private Sub btnStop_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnStop.Click
  _Stop = True
End Sub

Private Sub btnUpdate_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnUpdate.Click
    Call LoadClasses()
End Sub

Private Sub CLB_Leave(ByVal sender As Object, ByVal e As System.EventArgs) Handles CLB.Leave
    CLB.SelectedIndex = -1
End Sub
End Class
