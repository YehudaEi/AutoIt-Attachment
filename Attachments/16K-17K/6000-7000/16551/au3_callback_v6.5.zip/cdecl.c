/*
    Compile with TinyC
    >tcc -shared cdecl.c
*/


// exported procedure
void __attribute__((dllexport)) cdecl_test (void* pcb) {
	// callback definition
	int (*_cb)(char*) = pcb;
    
	// Breakpoint
	// __asm__("int3");

	// call back three times
	_cb("one");
	_cb("two");
	_cb("three");
}