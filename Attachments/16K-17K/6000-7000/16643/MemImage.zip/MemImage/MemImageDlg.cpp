// MemImageDlg.cpp : implementation file
//

#include "stdafx.h"
#include "MemImage.h"
#include "MemImageDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CMemImageDlg dialog

CMemImageDlg::CMemImageDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CMemImageDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CMemImageDlg)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
	// Note that LoadIcon does not require a subsequent DestroyIcon in Win32
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
}

void CMemImageDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CMemImageDlg)
		// NOTE: the ClassWizard will add DDX and DDV calls here
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CMemImageDlg, CDialog)
	//{{AFX_MSG_MAP(CMemImageDlg)
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	ON_BN_CLICKED(IDC_BUTTON1, OnButton1)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CMemImageDlg message handlers

BOOL CMemImageDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	// Set the icon for this dialog.  The framework does this automatically
	//  when the application's main window is not a dialog
	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon
	
	// TODO: Add extra initialization here
	
	return TRUE;  // return TRUE  unless you set the focus to a control
}

// If you add a minimize button to your dialog, you will need the code below
//  to draw the icon.  For MFC applications using the document/view model,
//  this is automatically done for you by the framework.

void CMemImageDlg::OnPaint() 
{
	if (IsIconic())
	{
		CPaintDC dc(this); // device context for painting

		SendMessage(WM_ICONERASEBKGND, (WPARAM) dc.GetSafeHdc(), 0);

		// Center icon in client rectangle
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// Draw the icon
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialog::OnPaint();
	}
}

// The system calls this to obtain the cursor to display while the user drags
//  the minimized window.
HCURSOR CMemImageDlg::OnQueryDragIcon()
{
	return (HCURSOR) m_hIcon;
}

void CMemImageDlg::OnButton1() 
{
	// load image
	Image image(L"Nice.bmp");

	// Create stream with 0 size
	IStream* pIStream	= NULL;
	if(CreateStreamOnHGlobal(NULL, TRUE, (LPSTREAM*)&pIStream) != S_OK)
	{
		AfxMessageBox(_T("Failed to create stream on global memory!"));
		return;
	}

	// Get encoder class id for jpg compression
	// for other compressions use 
	//     image/bmp 
	//     image/jpeg 
	//     image/gif 
	//     image/tiff 
	//     image/png 

	CLSID pngClsid;
	GetEncoderClsid(L"image/jpeg", &pngClsid);
	
	// Setup encoder parameters
	EncoderParameters encoderParameters;
	encoderParameters.Count = 1;
	encoderParameters.Parameter[0].Guid = EncoderQuality;
	encoderParameters.Parameter[0].Type = EncoderParameterValueTypeLong;
	encoderParameters.Parameter[0].NumberOfValues = 1;

	// setup compression level
	ULONG quality = 50;
	encoderParameters.Parameter[0].Value = &quality;

	//  Save the image to the stream
	Status SaveStatus = image.Save(pIStream, &pngClsid, &encoderParameters);
	if(SaveStatus != Ok)
	{
		// this shoud free global memory used by the stream
		// according to MSDN
		pIStream->Release();
		AfxMessageBox(_T("Failed to save to stream!"));
		return;
	}

	// get the size of the stream
	ULARGE_INTEGER ulnSize;
	LARGE_INTEGER lnOffset;
	lnOffset.QuadPart = 0;
	if(pIStream->Seek(lnOffset, STREAM_SEEK_END, &ulnSize) != S_OK)
	{
		pIStream->Release();
		AfxMessageBox(_T("Failed to get the size of the stream!"));
		return;
	}

	// now move the pointer to the begining of the file
	if(pIStream->Seek(lnOffset, STREAM_SEEK_SET, NULL) != S_OK)
	{
		pIStream->Release();
		AfxMessageBox(_T("Failed to smove the file pointer to the beginning of the stream!"));
		return;
	}
	
	// here you can do what ever you want
	/* 
		1. You can use global memory
			HGLOBAL hg;
			if(GetHGlobalFromStream(pIStream, &hg) = S_OK)
			... use hg for something
	
	    2. Copy it into some other buffer
		char *pBuff = new char[ulnSize.QuadPart];

		// Read the stream directly into the buffer
		ULONG ulBytesRead;
		if(pIStream->Read(pBuff, ulnSize.QuadPart, &ulBytesRead) != S_OK)
		{
			pIStream->Release();
			return;
		}
	*/

	// I am going to save it to the file just so we can load the jpg to a gfx program
	CFile fFile;
	if(fFile.Open(_T("test.jpg"), CFile::modeCreate | CFile::modeWrite))
	{
		char *pBuff = new char[ulnSize.QuadPart];

		// Read the stream directly into the buffer
		ULONG ulBytesRead;
		if(pIStream->Read(pBuff, ulnSize.QuadPart, &ulBytesRead) != S_OK)
		{
			pIStream->Release();
			delete pBuff;
			return;
		}

		fFile.Write(pBuff, ulBytesRead);
		fFile.Close();
		delete pBuff;
	}
	else AfxMessageBox(_T("Failed to save data to the disk!"));

	// Free memory used by the stream
	pIStream->Release();
}

int CMemImageDlg::GetEncoderClsid(const WCHAR* format, CLSID* pClsid)
{
   UINT  num = 0;          // number of image encoders
   UINT  size = 0;         // size of the image encoder array in bytes

   ImageCodecInfo* pImageCodecInfo = NULL;

   GetImageEncodersSize(&num, &size);
   if(size == 0)
      return -1;  // Failure

   pImageCodecInfo = (ImageCodecInfo*)(malloc(size));
   if(pImageCodecInfo == NULL)
      return -1;  // Failure

   GetImageEncoders(num, size, pImageCodecInfo);

   for(UINT j = 0; j < num; ++j)
   {
      if( wcscmp(pImageCodecInfo[j].MimeType, format) == 0 )
      {
         *pClsid = pImageCodecInfo[j].Clsid;
         free(pImageCodecInfo);
         return j;  // Success
      }    
   }

   free(pImageCodecInfo);
   return -1;  // Failure
}