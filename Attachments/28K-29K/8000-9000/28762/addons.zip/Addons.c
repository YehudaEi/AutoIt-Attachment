/*
**  Addons.c        Auxilliary integral 64-bit functions for AutoIt beta 3.3.1.6
**
**                  Temporary workaround until some core functions get fixed.
**
**  compile with:   gcc -O2 -lm -shared addons.c -o addons.dll
**
**  usage:          via Addons.au3
**
**                  jchd
*/

#ifdef __cplusplus
extern "C" {
#endif


#define DLL_EXPORT __declspec(dllexport)
#define DLL_IMPORT __declspec(dllimport)


#if defined(_MSC_VER) || defined(__BORLANDC__)
  typedef __int64 type_int64;
  typedef unsigned __int64 type_uint64;
#else
  typedef long long int type_int64;
  typedef unsigned long long int type_uint64;
#endif

typedef type_int64     i64;         /* 8-byte   signed integer */
typedef type_uint64    u64;         /* 8-byte unsigned integer */
typedef long           i32;         /* 4-byte   signed integer */
typedef unsigned long  u32;         /* 4-byte unsigned integer */
typedef short          i16;         /* 2-byte   signed integer */
typedef unsigned short u16;         /* 2-byte unsigned integer */
typedef char            i8;         /* 1-byte   signed integer */
typedef unsigned char   u8;         /* 1-byte unsigned integer */



DLL_EXPORT i64 Div(i64 a, i64 b) {
    return(a / b);
}


DLL_EXPORT i64 Mod(i64 a, i64 b) {
    return(a % b);
}


DLL_EXPORT u64 BitAnd(u64 a, u64 b) {
    return(a & b);
}


DLL_EXPORT u64 BitOr(u64 a, u64 b) {
    return(a | b);
}


DLL_EXPORT u64 BitXor(u64 a, u64 b) {
    return(a ^ b);
}


DLL_EXPORT u64 BitNot(u64 a) {
    return(~a);
}


// gcc will perform a logical (unsigned) shift on unsigned values
DLL_EXPORT u64 BitShift(u64 a, i32 b) {
    if (b > 0) {
        return(a >> b);
    } else {
        return(a << -b);
    }
}


// gcc will perform an arithmetic (signed) shift on signed values
DLL_EXPORT i64 SignBitShift(i64 a, i32 b) {
    if (b > 0) {
        return(a >> b);
    } else {
        return(a << -b);
    }
}


DLL_EXPORT u64 BitRotate(u64 a, i32 b) {
    if (b > 0) {
        return((a >> b) | (a << (64 - b)));
    } else {
        return((a << -b) | (a >> (64 + b)));
    }
}


#ifdef __cplusplus
}       // extern "C"
#endif
