#include "main.h"

int (WINAPI *pMyMessageBoxW) (HWND, LPCWSTR, LPCWSTR, UINT); // pointer to the bridge

// MessageBoxW hook function
int DLL_EXPORT MyMsgBox(HWND hwnd, LPCWSTR text, LPCWSTR caption, UINT flags)
{
    if (pMyMessageBoxW == NULL)
        return 1;
	
	// modify the original text
    wchar_t buf[1024]= L"We hooked the message box.  Original text:\n\n";
    wcscat_s(buf, 1024, text);
	// call the original MessageBoxW function through the Bridge
    return pMyMessageBoxW(hwnd, buf, L"Hooked MessageBoxW", MB_OK | MB_ICONEXCLAMATION);
}

// obtain the address to the Bridge
int DLL_EXPORT GetMessageBoxW(void *p)
{
	// this function must be called before setting the hook to provide the hooking function with the bridge address
    pMyMessageBoxW = (int (WINAPI *)(HWND, LPCWSTR, LPCWSTR, UINT)) p;
    return 0;
}

BOOL WINAPI DllMain(HINSTANCE hinstDLL, DWORD fdwReason, LPVOID lpvReserved)
{
    switch (fdwReason)
    {
        case DLL_PROCESS_ATTACH:
            pMyMessageBoxW = NULL;
        case DLL_PROCESS_DETACH:
        case DLL_THREAD_ATTACH:
        case DLL_THREAD_DETACH:
            break;
    }
    return TRUE; // succesful
}