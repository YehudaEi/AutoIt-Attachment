NOTE:  Make sure you have installed the Microsoft Visual C++ 2008 SP1 Runtime Redistributable

1. Compile 'testapp.au3' and 'ApiHookExample.au3'
2. Place 'msgdll.dll' in the same directory as the compiled scripts.
3. Run 'ApiHookExample.exe'