//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by resources.rc
//
#define IDD_MAINDLG                     101
#define IDI_MAINICON                    102
#define IDC_EXPLORER1                   1001
#define IDC_DEVLEVEL_EDIT               1001
#define IDC_LOGEDIT                     1006
#define IDC_REACTOS_BUTTON              1007
#define IDC_WINE_BUTTON                 1007
#define IDC_WIN2KSRC_BUTTON             1008
#define IDC_PARENTID_EDIT               1009
#define IDC_UPCASE_CHECK                1010
#define IDC_KERNEL_BUTTON               1011
#define IDC_STATIC                      -1

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NO_MFC                     1
#define _APS_NEXT_RESOURCE_VALUE        103
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1013
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
