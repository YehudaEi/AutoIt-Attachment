INSTALLATION:
Unzip into any directory and run Jsaioie.au3

First run will create an ini config file: Jsaioie.au3.ini
Each run will create a log: Jsaioie.au3.log.txt,
and a Javascript preview file for debugging: Jsaio-loaded.js

Logs and previews are overwritten with each run, config file can be deleted to create first run.

Config:

[sys]
editor=<fullpath to your editor>
includeDir=<path to autoit include directory, with trailing slash>


Config values will be asked for on first run.

REQUIREMENTS:
AutoIt v3.3.8.1  -- may run on earlier, who knows.
Internet Explorer 10 -- results undefined otherwise

Library AutoItObject.au3
Library IE.au3




