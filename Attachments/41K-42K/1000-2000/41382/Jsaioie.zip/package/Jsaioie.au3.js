var __initializations__;
// Import $AutoItForCom frm body attribute, amazing!
function init(){
  var el=document.getElementById("body");
  // set it as a window property to access it by A.<some fn or property>
  window.A=el.getAttribute('AutoIt');
}

var __ini_utils__;
// Write to apps ini
function iniValueSet(s,k,v){
  var inif=A.ScriptFullPath+".ini";
  return A.IniWrite(inif,s,k,v);
}
// Read from apps ini
function iniValue(s,k,d){
  var inif=A.ScriptFullPath+".ini";
  if (!A.FileExists(inif)) {
    return d;
  }
  var r=A.IniRead(inif,s,k,d);
  return r;
}

var __ini_gets__;
// Cache ini sys.includeDir value
var include_dir_
// Get cache, else ini, else ask
function includeDir(){
  //e C:\!mark\_dev\jsaio_vpw\Jsaioie.au3.ini
  var dd='C:\\Program Files (x86)\\AutoIt3\\Include';
  if (typeof includeDir_=='undefined') {
    var d=iniValue('sys','includeDir','');
    if (d=='') {
      //FileSelectFolder ( "dialog text", "root dir" [, flag [, "initial dir" [, hwnd]]] )
      d=A.FileSelectFolder('Select AutoIt3 Include Directory','',2,dd,A.hGui);
      if (!A.FileExists(d)) {
        return '';
      }else{
        d=d+"\\";
        iniValueSet('sys','includeDir',d);
        includeDir_=d;
        return d;
      }
    }
    d=d+"\\";
    includeDir_=d;
    return d;
  }else{
    return includeDir_;
  }
}
// Cache ini sys.editor value
var editor_
// Get cache, else ini, else ask
function editor(){
  var dd='notepad.exe';
  if (typeof editor_=='undefined') {
    var d=iniValue('sys','editor','');
    if (d=='') {
      //FileOpenDialog ( "title", "init dir", "filter" [, options [, "default name" [, hwnd]]] )
      d=A.FileOpenDialog('Select editor to open files, or press CANCEL to use notepad.exe ...','','Executables (*.exe)',1,'',A.hGui);
      if (!A.FileExists(d)) {
        editor_=dd;
        iniValueSet('sys','editor',dd);
        return dd;
      }else{
        iniValueSet('sys','editor',d);
        editor_=d;
        return d;
      }
    }
    editor_=d;
    return d;
  }else{
    return editor_;
  }
}


var __resources__;
// Icon for loaded files
function imgDataOk(){
  return 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAACAAAAAgCAYAAABzenr0AAAABHNCSVQICAgIfAhkiAAAAAlwSFlzAAALEgAACxIB0t1+/AAAABx0RVh0U29mdHdhcmUAQWRvYmUgRmlyZXdvcmtzIENTNXG14zYAAAh0SURBVFiFpZdrjF1VGYafb621L+ecmU47baW0zEyk4U6oIZQCFqLA1BiMhKFY+GFALPwxEBoR5QeiMd6iRg0lmhgkRqwg7RQxhNAWWmwbCeKFElo0RDsDhXam7XQ6M+ecfVufP/aeaatc2riSlexkJ+t9v/v7iapyKqfvps1LyHUFmCvx2RkKIsbtA92BkU1DG/r/eirvyckQ6Fu1dR5psZIiv54iX6Lez8X7EPUgAALGZhhzSKzbhbFPSxw/uffxK0f+LwI9X9gZmbHmV8nTezRL5mieIaolIAYRAUBRUC2/RBDnkCAaxwUPaaPxveHffHzqlAn0DTx/KVn6qCbN8zVLEQSxAWIcGIeIhYoAqqAe9Xl1M1Q9EkRIVHuTIFw9NHjNiydNoG9gy02atNdpa8LhFbEhxkYlgYqEWHcCAVUQBF9kUKT4PMUXCaopUmsgYbx6aGP/Ix9KoPeGzTeTtH+rzXEQi7ExxoaIixAXYVyI2BCxDmNDEANakE7sY2L/qxh8ScKnWFfDdfSBL5BaBxLXbh/a2P/o+xLoHdiyhKT1sk6Nh4JFXA3jIsTFGBdjwhgTRNiwhq1149sjULQookWcsyClPT7Eu6MF4nPSdpOxd/egRYuo6zx80UTqXRDXlg8PXrtzGtNMfyy6bWdAljyhzaMhSGmxDUvwoI6NOnBxJ0Gjm6Czm9aenzDyzAr2/+FaJnas5u2Ro1xw8WUsPD0mcAlRvZPaacuw8TwwFrBoawLSdF3vzdsa07hu+sOOTdyr7eY5eI/YGmLC0mpXw4Z1bNzAxg2i2adxZPtdHHhpLQQGxJL84ykmR18nmVjLGYvmYRrzsanAVBPUY2xcJmfegmSqF2sfAL42E4Kez23tlMmJt3TqSJeYsHJ9DRs2MFEHLurA1hpE3QtI9g4yPHgj6qKyEoCiKDizdx5F91KCpfcTek/eNoivMTV2iCQt8HkTzVtokSCNrhYdnb3Dv/vkQQcgSXqDZu2usqEEiAkwLsIEtTLecY2gsxtJD3Dg+bvxWEwFXhaBMtGCK3qErp4mwYLlJEfGODDS5o02SDGO8Rne5GiRolm7Jkl4C/BQGYIiGyBLy/o2riq3KuvDGjbuIGiEjDz9JZqH9mFrDUBR9ahCEASMjh5kw/qNzNr2Cr2f/ws5s2kfHkHFYYOQwoeIz8A4yFLI8xuAh0zvqhd6KfKLVT0iFjEOYwNMEGLDCBuGhLNnMfXaLzj42gZsXKvAFSdK7IQ8L7DWEtXrNA+9xaFtdxF1BMQddVwYVwld9g9jXNm4fH5B78otHzOkRb8WxXwBxNjy2hDjQkwQ4DrmUhx+g/0vfAWCYKb5tFstlg2s4VNrHsEnbabL2cQ1Du16gubuXxN0zcGEISYIMS4A68qKEEGLfA55cZ2hSK9GiwgxYCxiXdnLXYCJ6jinjGy+k/bkeNl4gLTdYvFZZzPv+m/gL7uFS1bcSLvVAhFEBLWO/S98GZ34N64+GxME5Xu2CrEYUA1QrjSono8iIqay3mGswwSOoHM+43/+Nkfe3I6N64DivScyytm3/oyjLmJ8Ehbf9nPOWLiALElKL7iI1vgoo1vvwkYRJoww0y3cGBCDoODzhUZFSq+K4RgJi613k+7bwsifvotE0UzGZ+02Z31mDcHSqxEgDOHo3HlcdOejONEqFIqNa4zteYbJ1x7GNeYjziDWViEwgICAE5HdiFmCeCnDIBDEkB3h4La7ybIUGzYQgWRqikXnXsKcq+7n7WefxZiyFL2HOGrQc94y9u5+CRfGgKAu4ODOBzl9/jIkWgitCWQ6TGIQ495xYoOtauwARRGXpAw26KD96oNMvLtnxvVpmtHd3cXl92zi9Y1fZ89zawlmGnlplKvPqsCrPm9D2lPjjO28l9mfeKxMwmM/M4TtRi2bxLnRUtko3jWIxzYz9vqvkDCaaTQ2z7j0jnUkB/7FWy8+jIsjTFSbuQQ18izjxKPYqM7RoZ00d69Fgk5AS+9bd0StPOOGn+wf7vvss7vE2B6vhi7eYezlBzg8mRNIDgoZcMWn7yA6fTnbv9XLobYSkZBzEkfKsh995Uec1nEWxGeDmQLndg+vX/H30ifWDuKC61RhYbCHaOFi5vYsQcSgeGpxg1nLf0zyxhMsOHMpPRd2lZa815mWZqqVUFHUe5LmGHHxNw76j4INwNinYHoYrXxulkn9sLanumqNLhpdH8GEdWxUxwYxuJjJZkajHlHrqIEFYwBzTJOqL6/3oLlSZAk+SyjSFkXSJG9N0jp6kNbkGBLXEx/a3uH1K0ZmBEnfwOb7SVrf0SzHBA1MWMcElRBxEdZFiJlWQ8GxhiICeFSLGT3o8xTNE3yeUGQtfNbGp018OoVYA3H8g72D/ffBcXogCZMfRj6+VfLJc8hblVUeLQp8noHNKuBSjs0QYFoVHyOgRYYvShJaJGjWQrMWUEBYezsP9JszKXK8JOtbuWUJafayNifDcihVqsiGJbCpRKk4xNjjYjBNYJpEWhGphGmeoD6FWgcaBsuH1x+TZP8jSvsGtqwiTR7X1gSCPQG8HNdBNTWrJJjJveI4L1Se8Gk5/zUvRWkY37538Jr3F6XHkVhJmqzzrckA7zEmnAFHbLUTHLeYVJmPLyoiOVpUBIxgah1KGK4eGuz/5X9jfcBismUpefZLbbcu1KwNKtUwcdUwMZywFxwXBjRH0Woxqf+T0H1xaMO1O94L54NXs9v/GJqx5D6ydI1mSTd5hnqPIDBzp48vQY0BFyJBOE4Q/lQb0feHH7uq+X4YJ7Wc9q56sVvSrFpOi4vUF/PxRYgiZWs1ijGpGHMY63Zh7e+JovVDj181+mFvnxSBE8jctOlcyVkB5nJ8vhgQrBtG/Q6cPD/0ZP+uU3nvP+MTD7LclHcgAAAAAElFTkSuQmCC';
}
// Icon for loading files
function imgData(){
  return 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAACAAAAAgCAYAAABzenr0AAAABHNCSVQICAgIfAhkiAAAAAlwSFlzAAALEgAACxIB0t1+/AAAABx0RVh0U29mdHdhcmUAQWRvYmUgRmlyZXdvcmtzIENTNXG14zYAAAirSURBVFiFpZd7rFxVFYe/tfbe55yZe9tLW26AYm8BH8WK1PjAEIEo0v4hUeMramKiATQxAcVYWyrB+ASKRqOgliiIweAbwYgxpWKQgpH4AoUSQ4AOgtjb0mnvvTNzHnsv/zjTW1BRiDvZyWQy2eub3157rd8SM+O5rFsvnVlnTjaocnoVeZ6YiXc8ZiY7xWz7+ot6f3gu58mzAbjt8tVHJsfbG+PNjbEuma1IkCUDDETACbXCPq9yrxP7aSH6w9M3PrLn/wLY+elV+bAjm8skF1bRllUpYaKogCqICACWDAPMQCzhRcmcHMiEK7tml5+2ubfwnAF++fnVp5TGt4aNra1SAlUyJ3gnOAXvBBn/1oBk0ESjiUbdGCklcqcUTh7MhfNe/7Hdtz9rgB1XrH7HKNkNc3XyJpB5Jc+U4ITgGEMIOkZI7f9HVamaRB2NsjGqKlFViQmnFI7z1m/qXfM/AW7dOvOukfHdfmV4NfLckQWl8JB5IfeOzINzSh4EFYhJeGy25J4H50kodZOoGugUjpmjHMlg0isd5Zz1m3rfekaAHVtn1g0Td/dry7wXOpmQB6UIUGSOwgtZcHQzZdmkZ7YfGZbCscsjVbGG3U+MaMq/E00YjEp2PdxnUBprj89ZGCaOyISOcNpZm3t3/hvAnZ9eGfYH/+d+bWsQ6OZKngndTOjmjk7h6AZlMnd0vOdLN89z3fYDzC1Ezji5y2XnHs2JLz2D39+zi339WbpFhNTnvodLjl4RGJQRS3BEpr1uYu1rt7SJ6Q+RHMz8xkFjawzoZEIWWgWKcfDJTJnIHEctzblg2wGu+tk/kAhejZt+U/OXh+b56vkjjpxexfSkIt5YGAjJoMiVJhqDylhomHHeLgEuWlTgtstWLZlHHu1XNhVC+687udItlCWFMtnxTATH0Utybryr4m2f65Groa5Nwhgj00cfz6uOj2x5QyBlOZrVdCaFfXMDYlMyGCWGlVHWxlSQ4RJh5nUX9fZ6gFp5y6hKUyJC5sB7IQ9CN1OKzFN4z/Ku54m+cv62J3CSUKeHM8kMmnlkxakMVkzxmhdn9EcjhsM9kB6gP4A6KnVKlI0xalInBH03cGULkOStpbVyete+9ywoWVC6QViSOzIC5399lr8/OaQTFKwtQGCE4JndO8tPbrqRu++a5A9fOY5lkzXlYIRTyLyn9g11IwQ1yih04S3AlXrbpTMzjfHylBLOKc4JwQu5EwqvBOdZ6gPf2LHAj+/cS+EdmIAZph4JBXVscM7RyXMe2zfiQ9v2EciZyAo6maMIbe3wTvDeAdAkXrLjspmXaXSsb8ymRRSnglch80oWHEEdR044dj2e+Og3nyBgi9VvOBrxkXe+mms2bqCK1l4D0HHK9+/Yx/W/HrIsDwR1ZK7dXkDHBzQpLYtiZ2sZOTMly8cNBa/gRAgK3SCYeT5w1R7mBiU+tPc+Kite8IIT+OSGFbz7OONtZ76C4WjUwongMT687TEenjWO6HqCtud5JwQnqAoJCQinK7AWQVRlUYHgBC+O6SWBz/3gIDvv79MJrfSWEuZzrn7fGrLBHKQ+297zfI5aeSxVXQMQgrB/vuKCr8+SO0fuHCG4tn+IjFUQ6iQrtZWu7XAyhnCiLJtw7PhTxWXf20Muh4SHUV1z4dkv5HUrAohg5KyYn+O6D56MqW+vwoTCO275XZ+v3TLP9FKHmKCi+LHSIoCBV5H7FdZFQ5yAGBQeDizABVfvo6pqOoWiwEJZ8coTj2XLG5fxiwf/hhvXAcOY6BacctIqfnvPw+RZQAQCiUuun+XVa45h5QqYG7aBRQTFCE4e98HxKxd5a4QCA3HKRNfxye8MeaA3Ryd3YFDVFUunlrH9s6fyievv46qbd4ELT6kFwtLCk2eHv/NBmVso2XhNn+9smsIfFhIn1Bh3KA3bvcgs40SezCI7/pzz7e37yQ+lrBm1er675RQeenLEV3/+KJnzFF4Xd8dD3TQ8bZnQyRx33neQK386YGlX2htvpe9LtFt0/cW9nlPudSqoJB4/uJRLrttPM9hPWdcMy5LhwgLvf9PLeM3anDM/dhe2sI8qNozKcnEPq6rdZfn0PSohlnzxh3u5/S+JPIC2Tej+DRf3/uTHHenGIJxtGLtmV3LC6px1LzoSVUgRupMFXzx3ih/cXXHKSccw1Z0h/RcraQZm1hoVM5LB/oMlf3y04PhjZgkKTuymxWb0i888b2nKXG/Q2NTUkg7TyyeYyJROrnQyR+6hKRfIiy6drAuxfUak9t1jtNkrrb5JjapuKBtjUEWGZcNcGdl7YEj/4JCuk9LVaWbDxb09i37g1q0zW4ZJLm0wJgqlmwlFcBR5a0ryzJOF1p75sTVTbX1hStBEiNGom7bhVE2irI3hqGFUp7YVlwlFKLDPr9+0e9NY/fH73lt9oZjO3zsfZc2wbr12kkQUR50SFZEQhTwknOoiAGOAlA4b0jpCVbcAZW0Mq3bHCIXnb2mh+dShuE+3ZJevXlcJdy9Ey5wTikzJPASvZEHGnwXnFa+CaJvRmBGTEJPRxERZQd0k6sYoq7FBrY0JB1my087a8h8s2SLEFavfOTK+N1cb3guZb91R8G2f8F5wTlFp7fmhFaMRE9TRiDFRN1DVRtUYTWNMeKHj5JzXb3zkmU3pUyDePjJumK9jMCDL3GJwr+BcW8/lcJnADKK1IE1sQcrakJSYDM5y7Lz1m3vX/musZxxMdlyx+lWVce0o2UmjJiEKfuwXnID+y2BiyWjGuVDHNjFyp3S9/NUnzj1r8+6d/ynOfx3Nfv2JVVk5KZtKk49U0ZbXBsnaKempCgDE1AZVUTKFoHIgF/tyXrP1jIt7g2eK8ayG09u3ziyvVdrhFE5OyaajkSGIGahgCpWKPOmFex12c4786IxNu2f/19nPCuCpa/tnZ04kyAZVTm0SzwfEC71k7JRov1z/8d69z+W8fwJbQT7slWMScQAAAABJRU5ErkJggg==';
}
// Icon for functions
function imgDataFn(){
  return 'data:image/gif;base64,R0lGODlhDAAMALMAAAAAADhWAH3AAMv/a1OAANr/lYBZAMDAwICAgKb/Af95Af9AAf/rAd//Af+yAf///yH5BAEAAAcALAAAAAAMAAwAAAQx8MhJ6wk4WEy6wFQwPEJZTgHxFMNQlNpFCC07fFJKFzZ+lTaX70cTxnIm2BGVsTgnEQA7';
}
// Icon for constants
function imgDataConst(){
  return 'data:image/gif;base64,R0lGODlhDAAMALMAAAAAAKpMAP9zAf+5gf/cv4AwAIAdAMDAwICAgIAdAP8nAf8UAf9NAf9gAf86Af///yH5BAEAAAcALAAAAAAMAAwAAAQp8MhJJxk4YyGH+OAXdEJgmiI5Tt7aUu8RqzRbkoJG3HIYrqWTcFUpRgAAOw==';
}


var __string_utils__;
// Remove path and replace dot with _
function idFromFilePath(f){
  var a=f.split('\\');
  var s=a[a.length-1];
  s=s.replace(/\./g,'_');
  return s;
}
// Get filename from path
function filenameFromFilePath(f){
  var a=f.split('\\');
  var s=a[a.length-1];
  return s;
}

var __commands__;
// Use editor spec to open file
function editFile(f){
  var cmd='"'+editor()+'" "%(f)"';
  var cmd=cmd.replace('%(f)',includeDir()+f);
  A.Run(cmd,'');
}

var __function_readers__;
// Parse header, todo: rewrite to use array
function fileHeaderText(f){
  var fh = A.FileOpen(includeDir()+f, 0);
  //Check if file opened for reading OK
  if (fh==-1) {
    alert('could not open:'+includeDir()+f);
    return;
  }
  var s='';
  var hit=false;
  var hitcs=false;
  while (true) {
    var l=A.FileReadLine(fh);
    if (A.error==-1) {
      break;
    }
    if (!hit) {
      if (l.substr(0,1)===';'||l.substr(0,3)==='#cs') {
        hit=true;
        hitcs=(l.substr(0,3)==='#cs');
        if (l.indexOf('=====')==-1&&l.substr(0,3)!=='#cs') {
          var ll=l;
          if (ll.substr(0,1)==';') {
            ll=ll.substr(1);
          }
          ll=$.trim(ll);
          s+=ll+'<br>';
        }
      }
    }else{
      if (hitcs) {
        if (l.substr(0,3)==='#ce') {
          break;
        }
      }else{
        if (l.substr(0,1)!==';') {
          break;
        }
      }
      if (l.indexOf('=====')==-1) {
        var ll=l;
        if (ll.substr(0,1)==';') {
          ll=ll.substr(1);
        }
        ll=$.trim(ll);
        s+=ll+'<br>';
      }
    }
  }
  A.FileClose(fh);
  return s;
}
var __counters__
// Running total of fn and consts
var ident_tot_ct=0;
// Incrementer
function identTotCt(){
  ident_tot_ct++;
  setTimeout('identTotCtUp()',200);
}
// Updater
function identTotCtUp(){
  $('#totIdentCt').html(''+ident_tot_ct);
}
//////////////////
var fn_tot_ct=0;
// Incrementer
function fnTotCt(){
  fn_tot_ct++;
  setTimeout('fnTotCtUp()',200);
}
// Updater
function fnTotCtUp(){
  $('#totFnCt').html(''+fn_tot_ct);
}

//////////////////
var const_tot_ct=0;
// Incrementer
function constTotCt(){
  const_tot_ct++;
  setTimeout('constTotCtUp()',200);
}
// Updater
function constTotCtUp(){
  $('#totConstCt').html(''+const_tot_ct);
}
//////////////////
var file_tot_ct=0;
// Incrementer
function fileTotCt(){
  file_tot_ct++;
  setTimeout('fileTotCtUp()',200);
}
// Updater
function fileTotCtUp(){
  $('#totFileCt').html(''+file_tot_ct);
}


var __files__
// Make Div for file, then call file items
function addFileDiv(f){
  var fn=idFromFilePath(f);
  var fn2=filenameFromFilePath(f);
  var htm='';
  htm+='<div';
  htm+=' class="hdr"';
  htm+=' id="'+fn+'"';
  htm+=' file="'+f+'"';
  htm+='>';
  htm+='<img';
  htm+=' id="'+fn+'_icon"';
  htm+=' width="16"';
  htm+=' src="';
  htm+=imgData();
  htm+='"';
  htm+=' style="padding-right:4px;"';
  htm+=' title="Click to copy #include"';
  htm+='>';
  htm+='<div class="hdrtxt"';
  htm+=' id="'+fn+'_hdrtxt"';
  htm+='>';
  htm+='<a';
  htm+=' title="Click to open file"';
  htm+='>';
  htm+=fn2;
  htm+='</a>';
  htm+='&nbsp;';
  htm+='</div>';
  htm+='<div';
  htm+=' id="'+fn+'_hdr"';
  htm+='>';
  htm+='<tt';
  htm+=' id="'+fn+'_doch"';
  htm+='>';
  htm+='<a';
  htm+=' title="Click to show doc header"';
  htm+='>';
  htm+='Documentation';
  htm+='</a>';
  htm+='</tt><br>';
  htm+='<tt';
  htm+=' class="hid folder"';
  htm+=' id="'+fn+'_doch_"';
  htm+=' style="display:none;"';
  htm+='>';
  htm+=fileHeaderText(f);
  htm+='</tt>';
  htm+='</div>';
  htm+='<div class="sub hid folder" id="'+fn+'_" style="display:none;">';
  //child items go here
  htm+='</div>';
  htm+='</div>';
  // inject the html
  $('#d1').append(htm);
  // hover effect
  $('#'+fn).hover(function(){
    $(this).css("background","#111122");
  },
  function (){
    $(this).css("background","none");
  });
  //click icon to copy include
  $('#'+fn+'_icon').click(function (event){
    event.stopPropagation();
    A.ClipPut('#include <'+$(this).parent().attr('file')+'>');
    A.status('include put on clip');
  });
  //click text to edit file
  $('#'+fn+'_hdrtxt>a').click(function (event){
    event.stopPropagation();
    var nn=$(this).parent().parent().attr('file');
    editFile(nn);
  });
  //click elsewhere to fold and unfold
  $('#'+fn).click(function (){
    //if ($(this).find(">:first-child")) {
    if(!$('#'+$(this).attr('id')+'_').hasClass("hid")){
      $('#'+$(this).attr('id')+'_').slideUp(400,function(){
        $(this).addClass("hid");
      });
    }else{
      $('#'+$(this).attr('id')+'_').slideDown(400,function(){
        $(this).removeClass("hid");
        $(this).css("display","inline-block");
      });
    }
  });
  //click documentation to fold and unfold
  $('#'+fn+'_doch').click(function (event){
    event.stopPropagation();
    if(!$('#'+$(this).attr('id')+'_').hasClass("hid")){
      $('#'+$(this).attr('id')+'_').slideUp(400,function(){
        $(this).addClass("hid");
      });
    }else{
      $('#'+$(this).attr('id')+'_').slideDown(400,function(){
        $(this).removeClass("hid");
        $(this).css("display","inline-block");
      });
    }
  });
  // trigger processing of my child items
  addFileItems(fn+'_',f);
}



var __file_items__
// Cache for parallel processing with timeouts
//[divid]
//.a array
//.divid
//.f
//.x
//.end
//.s
//.d
//.hit
//.hitcs
//.hitend
var fileItemsStore={};

// Process some items using cache
function addFileItemsDoer(divid){
  var me=fileItemsStore[divid];
  if (me.x<me.end) {// process the line
    var l=me.a[me.x];
    if (l==='') {
      me.hit=false;
      me.hitcs=false;
      me.hitend=false;
      me.d='';
    }
    // gather docs
    if (!me.hit) {
      if (l.substr(0,1)===';'||l.substr(0,3)==='#cs') {
        me.hit=true;
        me.hitcs=(l.substr(0,3)==='#cs');
        if (l.indexOf('=====')==-1&&l.substr(0,3)!=='#cs'&&l.indexOf('Global Const')===-1) {
          var ll=l;
          if (ll.substr(0,1)==';') {
            ll=ll.substr(1);
          }
          ll=$.trim(ll);
          me.d=me.d+ll+'<br>';
        }
      }
    }else{
      if (me.hitcs) {
        if (l.substr(0,3)==='#ce') {
          me.hitend=true;
        }
      }else{
        if (l.substr(0,1)!==';') {
          me.hitend=true;
        }
      }
      if (!me.hitend) {
        if (l.indexOf('=====')==-1&&l.indexOf('Global Const')===-1) {
          var ll=l;
          if (ll.substr(0,1)==';') {
            ll=ll.substr(1);
          }
          ll=$.trim(ll);
          me.d=me.d+ll+'<br>';
        }
      }
    }
    // is a function
    if (l.substr(0,5)=='Func ') {
      me.hit=false;
      me.hitcs=false;
      me.hitend=false;
      var n=l.substring(5,l.indexOf('('));
      addFnItem(divid,n,l,me.d);
      me.d='';
    }
    // is a const
    if (l.substr(0,13)=='Global Const ') {
      me.hit=false;
      me.hitcs=false;
      me.hitend=false;
      var n=l.substring(13,l.indexOf('='));
      n=$.trim(n);
      if (n.substr(0,1)=='$') {
        n=n.substr(1);
      }
      addConstItem(divid,n,l,me.d);
      me.d='';
    }
    me.x=me.x+1;
    // batch process without timeout, 20 at a time
    if (me.x%20==0) {
      //probably doesnt help
      var rr=Math.floor(Math.random()*50);
      // lots to load, give someone else a chance
      var pad=200;
      // calling self with delay
      setTimeout('addFileItemsDoer("'+divid+'")',10+rr+pad);
    }else{
      // calling self directly
      addFileItemsDoer(divid);
    }
  }else{
    //update my icon now loaded
    $('#'+divid+'icon').attr('src',imgDataOk());
    // update loaded count
    fileTotCt();
    //die
  }
}

// Interface for processing
function addFileItems(divid,f){
  A.status(f+' reading...');
  var fs = A.FileRead(includeDir()+f);
  //Check if file opened for reading OK
  if (A.error!==0) {
    alert('could not open:'+includeDir()+f);
    return;
  }
  fs=fs.replace(/\r/g,'');
  var a=fs.split('\n');
  A.status(f);
  //create cache
  fileItemsStore[divid]={
    a:a,
    end:a.length,
    x:0,
    s:'',
    d:'',
    hit:false,
    hitcs:false,
    hitend:false,
    divid:divid
  }
  //call processor
  addFileItemsDoer(divid);
}

var __file_item_types__
// Add a function
function addFnItem(divid,s,l,d){
  // s=name
  // l=line text
  // d=docs
  identTotCt();
  fnTotCt();
  var htm='';
  htm+='<div class="fn"';
  htm+=' id="';
  htm+=divid+'_'+s;
  htm+='"';
  htm+=' fname="';
  htm+=s;
  htm+='"';
  htm+=' fnamel="';
  htm+=s.toLowerCase();
  htm+='"';
  htm+=' tname="';
  htm+=divid;
  htm+='"';
  htm+=' title="';
  htm+=l.replace(/"/g,"'");
  htm+='"';
  htm+='>';
  if (1) {
    htm+='<img';
    htm+=' id="';
    htm+=divid+'_'+s+'_img';
    htm+='"';
    htm+=' title="';
    htm+='Click to copy function call';
    htm+='"';
    htm+=' src="';
    htm+=imgDataFn();
    htm+='"';
    htm+=' width="12"';
    htm+=' height="12"';
    htm+='>';
  }
  htm+=s;
  htm+='</div>';
  //
  htm+='<tt';
  htm+=' class="hid folder"';
  htm+=' id="'+divid+'_'+s+'_"';
  htm+=' style="display:none;"';
  htm+='>';
  htm+='<b>'+l.replace(/"/g,"'")+'</b><br>'+d;
  htm+='</tt>';
  // inject the html
  $('#'+divid).append(htm);
  // hover effect
  $('#'+divid+'_'+s).hover(function(){
    $(this).css("background","#222233");
  },
  function (){
    $(this).css("background","none");
  });
  // click image to copy stuff
  $('#'+divid+'_'+s+'_img').click(function (event){
    event.stopPropagation();
    var tit=$(this).parent().attr('title');
    tit=tit.replace(/Func /,'');
    tit=tit.replace(/ByRef /,'');
    tit=tit.replace(/(\$[a-zA-Z0-9_]+) *= *[^,\)]+(,|\))/g,'$1$2');
    A.ClipPut(';'+tit);
    A.status('Function signature placed on clipboard:'+tit);
  });
  // click elsewhere to unfold and fold
  $('#'+divid+'_'+s).click(function (event){
    event.stopPropagation();
    if(!$('#'+$(this).attr('id')+'_').hasClass("hid")){
      $('#'+$(this).attr('id')+'_').slideUp(400,function(){
        $(this).addClass("hid");
      });
    }else{
      $('#'+$(this).attr('id')+'_').slideDown(400,function(){
        $(this).removeClass("hid");
        $(this).css("display","inline-block");
      });
    }
  });
}

function addConstItem(divid,s,l,d){
  identTotCt();
  constTotCt();
  var htm='';
  htm+='<div class="fn"';
  htm+=' id="';
  htm+=divid+'_'+s;
  htm+='"';
  htm+=' fname="';
  htm+=s;
  htm+='"';
  htm+=' fnamel="';
  htm+=s.toLowerCase();
  htm+='"';
  htm+=' tname="';
  htm+=divid;
  htm+='"';
  htm+=' title="';
  htm+=l.replace(/"/g,"'");
  htm+='"';
  htm+='>';
  if (1) {
    htm+='<img';
    htm+=' id="';
    htm+=divid+'_'+s+'_img';
    htm+='"';
    htm+=' title="';
    htm+='Click to copy Const';
    htm+='"';
    htm+=' src="';
    htm+=imgDataConst();
    htm+='"';
    htm+=' width="12"';
    htm+=' height="12"';
    htm+='>';
  }
  htm+=s;
  htm+='</div>';
  //
  htm+='<tt';
  htm+=' class="hid folder"';
  htm+=' id="'+divid+'_'+s+'_"';
  htm+=' style="display:none;"';
  htm+='>';
  htm+='<b>'+l.replace(/"/g,"'")+'</b><br>'+d;
  htm+='</tt>';
  //inject the html
  $('#'+divid).append(htm);
  // hover effect
  $('#'+divid+'_'+s).hover(function(){
    $(this).css("background","#222233");
  },
  function (){
    $(this).css("background","none");
  });
  // click image to copy stuff
  $('#'+divid+'_'+s+'_img').click(function (event){
    event.stopPropagation();
    var tit=$(this).parent().attr('title');
    tit=tit.replace(/Global Const /,'');
    tit=tit.replace(/ *=.*/,'');
    A.ClipPut(';'+tit);
    A.status('Const placed on clipboard:'+tit);
  });
  // click elsewhere to fold unfold
  $('#'+divid+'_'+s).click(function (event){
    //if ($(this).find(">:first-child")) {
    event.stopPropagation();
    if(!$('#'+$(this).attr('id')+'_').hasClass("hid")){
      $('#'+$(this).attr('id')+'_').slideUp(400,function(){
        $(this).addClass("hid");
      });
    }else{
      $('#'+$(this).attr('id')+'_').slideDown(400,function(){
        $(this).removeClass("hid");
        $(this).css("display","inline-block");
      });
    }
  });
}


var __filtering__
// do this directly since not many files
function input1Keyup(){
  input1_to=0;
  var o=$('.hdr');
  o.each(function(){
    var f=$(this).attr('file');
    f=f.toLowerCase();
    var v=$( "#input1" ).val();
    v=v.toLowerCase();
    if (f.indexOf(v)!=-1) {
      $(this).removeClass('tmphid');
    }else{
      $(this).addClass('tmphid');
    }
  });
}
// do it hard way to retain responsiveness
var input2Keyup_phase_=0
// processor, calls self delayed in stages
function input2Keyup_phase(){
  var ph=input2Keyup_phase_;
  if (ph==0) {
    var o=$('.hdr');
    //alert('got .hdr');
    if (v=$( "#input2" ).val()=='') {
      o.removeClass('tmphid');
      $('.folder').addClass('hid').css('display','none');
      o=$('.fn.tmphid').removeClass('tmphid').css('display','block');
      A.status='DONE';
      return;
    }
    o.addClass('tmphid');
    input2Keyup_phase_++;
    setTimeout('input2Keyup_phase()',100);
  }else if (ph==1) {
    o=$('.fn');
    o.addClass('tmphid');
    o.css('display','none');
    input2Keyup_phase_++;
    setTimeout('input2Keyup_phase()',100);
  }else if (ph==2) {
    var op=$('.fn').parent();
    op.addClass("hid");
    op.css("display",'none');
    input2Keyup_phase_++;
    setTimeout('input2Keyup_phase()',100);
  }else if (ph==3) {
    var v=$( "#input2" ).val();
    v=v.toLowerCase();
    //
    o=$('.fn[fnamel*="'+v+'"]');
    op=o.parent();
    op.removeClass("hid");
    op.css("display","inline-block");
    var opp=op.parent();
    opp.removeClass('tmphid');
    //
    o.removeClass('tmphid');
    o.css('display','block');
    A.status='DONE';
  }
}
// sub-interface for input2
function input2Keyup(){
  input2_to=0;
  input2Keyup_phase_=0;
  A.status='Filtering...';
  input2Keyup_phase();
}
// public interfaces here
var input1_to=0
var input2_to=0
// this prevents queue backup
function input1Refresh(){
  if (input1_to==0) {
    input1_to=setTimeout('input1Keyup()',1500);
  }else{
    clearTimeout(input1_to);
    input1_to=setTimeout('input1Keyup()',1500);
  }
}
function input2Refresh(){
  if (input2_to==0) {
    input2_to=setTimeout('input2Keyup()',1500);
  }else{
    clearTimeout(input2_to);
    input2_to=setTimeout('input2Keyup()',1500);
  }
}

var __utils__;
function isKeyCodePrintable(keycode){
  var valid =
        (keycode > 47 && keycode < 58)   || // number keys
        keycode == 32 || keycode == 13   || // spacebar & return key(s) (if you want to allow carriage returns)
        (keycode > 64 && keycode < 91)   || // letter keys
        (keycode > 95 && keycode < 112)  || // numpad keys
        (keycode > 185 && keycode < 193) || // ;=,-./` (in order)
        (keycode > 218 && keycode < 223);   // [\]' (in order)
  return valid;
}
function scrollIt(up){
  if (up) {
    window.scrollBy(0,-A.controlHeight);
  }else{
    window.scrollBy(0,A.controlHeight);
  }
}

var __Main__;
// initializations
function Main_setups(){
  includeDir();
  //e C:\!mark\_dev\jsaio_vpw\Jsaioie.au3.ini
  editor();
  var htm='';
  htm+='<label';
  htm+='>';
  htm+='&nbsp;&nbsp;Functions:&nbsp;';
  htm+='</label>';
  htm+='<label';
  htm+=' id="';
  htm+='totFnCt';
  htm+='"';
  htm+='>';
  htm+='0';
  htm+='</label>';
  htm+='<img';
  htm+=' src="';
  htm+=imgDataFn();
  htm+='"';
  htm+=' width="';
  htm+='12';
  htm+='"';
  htm+=' height="';
  htm+='12';
  htm+='"';
  htm+=' style="';
  htm+='vertical-align:bottom;margin-left:6px;';
  htm+='"';
  htm+='>';
  htm+='<label';
  htm+='>';
  htm+='&nbsp;&nbsp;Constants:&nbsp;';
  htm+='</label>';
  htm+='<label';
  htm+=' id="';
  htm+='totConstCt';
  htm+='"';
  htm+='>';
  htm+='0';
  htm+='</label>';
  htm+='<img';
  htm+=' src="';
  htm+=imgDataConst();
  htm+='"';
  htm+=' width="';
  htm+='12';
  htm+='"';
  htm+=' height="';
  htm+='12';
  htm+='"';
  htm+=' style="';
  htm+='vertical-align:bottom;margin-left:6px;';
  htm+='"';
  htm+='>';
  //
  htm+='<label';
  htm+='>';
  htm+='&nbsp;&nbsp;Loaded Files:&nbsp;';
  htm+='</label>';
  htm+='<label';
  htm+=' id="';
  htm+='totFileCt';
  htm+='"';
  htm+='>';
  htm+='0';
  htm+='</label>';
  htm+='<img';
  htm+=' src="';
  htm+=imgDataOk();
  htm+='"';
  htm+=' width="';
  htm+='12';
  htm+='"';
  htm+=' height="';
  htm+='12';
  htm+='"';
  htm+=' style="';
  htm+='vertical-align:bottom;margin-left:6px;';
  htm+='"';
  htm+='>';
  //
  htm+='<label>&nbsp;of&nbsp;</label>';
  htm+='<label';
  htm+=' id="';
  htm+='allFileCt';
  htm+='"';
  htm+='>';
  htm+='0';
  htm+='</label>';

  $('#totIdentCt').after(htm);
  // allow document scrolling with updown pageup down
  $( "#input1" ).keydown(function(event) {
    if (isKeyCodePrintable(event.keyCode)) {
      input1Refresh();
    }else{
      if (false) {
      }else if (event.keyCode===40) {//down
         scrollIt();
      }else if (event.keyCode===38) {//up
        scrollIt(true);
      }else if (event.keyCode===34) {//pgdn
        scrollIt();
      }else if (event.keyCode===33) {//pgup
        scrollIt(true);
      }
    }
  });
  $( "#input2" ).keyup(function() {
    if (isKeyCodePrintable(event.keyCode)) {
      input2Refresh();
    }else{
      if (false) {
      }else if (event.keyCode===40) {//down
         scrollIt();
      }else if (event.keyCode===38) {//up
        scrollIt(true);
      }else if (event.keyCode===34) {//pgdn
        scrollIt();
      }else if (event.keyCode===33) {//pgup
        scrollIt(true);
      }
    }
  });
  // clear and refresh
  $( "#input2clear" ).click(function() {
    $( "#input2" ).val('');
    input2Refresh();
  });
  $( "#input1clear" ).click(function() {
    $( "#input1" ).val('');
    input1Refresh();
  });
}
function Main(){
  Main_setups();
  //return;
  var search=A.FileFindFirstFile(includeDir()+'*.au3');
  if (search==-1) {
    alert('not found');
    return
  }
  var s='';
  var ct=0;
  while (true) {
    var f=A.FileFindNextFile(search);
    if (A.error) {
      break;
    }
    // do a single file for debug
    if (false&&f!='SQLite.dll.au3') {
      continue;
    }
    ct+=1;
    //put in queue
    files_+=f+';';
    if (ct>2) {
      // uncomment for testing
      //break;
    }
  }
  $('#allFileCt').html(''+ct);
  // once all in queue, call processor to dispatch
  setTimeout('loadFiles2()',100);
  //alert('testEnumProps:'+s);
}
// queue for parallel processing
var files_=''
// take from queue and call processor
function loadFiles2(){
  var a=files_.split(';');
  var f=a[0];
  if (f==='') {
    A.status('DONE');
    return;
  }
  // shift queue
  a.splice(0,1);
  // updata
  files_=a.join(';');
  A.status('loading:'+f);
  // dispatch this, but do it in right order so- no processor
  addFileDiv(f);
  // take a breath and call self
  setTimeout('loadFiles2()',500);
}

