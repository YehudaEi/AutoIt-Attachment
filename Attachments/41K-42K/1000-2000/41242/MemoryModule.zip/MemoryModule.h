/*
 * Memory DLL loading code
 * Version 0.0.3
 *
 * Copyright (c) 2004-2013 by Joachim Bauch / mail@joachim-bauch.de
 * http://www.joachim-bauch.de
 *
 * The contents of this file are subject to the Mozilla Public License Version
 * 2.0 (the "License"); you may not use this file except in compliance with
 * the License. You may obtain a copy of the License at
 * http://www.mozilla.org/MPL/
 *
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * The Original Code is MemoryModule.h
 *
 * The Initial Developer of the Original Code is Joachim Bauch.
 *
 * Portions created by Joachim Bauch are Copyright (C) 2004-2013
 * Joachim Bauch. All Rights Reserved.
 *
 */

#ifndef __MEMORY_MODULE_HEADER
#define __MEMORY_MODULE_HEADER

#include <windows.h>

typedef void *HMEMORYMODULE;

//typedef void *HMEMORYRSRC;

typedef void *HCUSTOMMODULE;


#ifdef __cplusplus
extern "C" {
#endif

/* typedef HCUSTOMMODULE (*CustomLoadLibraryFunc)(LPCSTR, void *);
 * typedef FARPROC (*CustomGetProcAddressFunc)(HCUSTOMMODULE, LPCSTR, void *);
 * typedef void (*CustomFreeLibraryFunc)(HCUSTOMMODULE, void *);
 */

typedef FARPROC WINAPI (*_GetProcAddress)(HMODULE hModule,LPCSTR lpProcName);
typedef LPVOID WINAPI (*_VirtualAlloc)(LPVOID lpAddress,SIZE_T dwSize,DWORD flAllocationType,DWORD flProtect);
typedef WINBOOL WINAPI (*_VirtualFree)(LPVOID lpAddress,SIZE_T dwSize,DWORD dwFreeType);
typedef WINBOOL WINAPI (*_VirtualProtect)(LPVOID lpAddress,SIZE_T dwSize,DWORD flNewProtect,PDWORD lpflOldProtect);
typedef HMODULE WINAPI (*_LoadLibrary)(LPCSTR lpLibFileName);
typedef WINBOOL WINAPI (*_FreeLibrary)(HMODULE hLibModule);
typedef VOID WINAPI (*_SetLastError)(DWORD dwErrCode);
typedef HANDLE WINAPI (*_GetProcessHeap)(VOID);
typedef LPVOID WINAPI (*_HeapAlloc)(HANDLE hHeap,DWORD dwFlags,SIZE_T dwBytes);
typedef LPVOID WINAPI (*_HeapReAlloc)(HANDLE hHeap,DWORD dwFlags,LPVOID lpMem,SIZE_T dwBytes);
typedef WINBOOL WINAPI (*_HeapFree)(HANDLE hHeap,DWORD dwFlags,LPVOID lpMem);
//typedef HGLOBAL WINAPI (*_GlobalAlloc)(UINT uFlags,SIZE_T dwBytes);
//typedef HGLOBAL WINAPI (*_GlobalReAlloc)(HGLOBAL hMem,SIZE_T dwBytes,UINT uFlags);
//typedef HGLOBAL WINAPI (*_GlobalFree)(HGLOBAL hMem);
typedef WINBOOL WINAPI (*_IsBadReadPtr)(CONST VOID *lp,UINT_PTR ucb);
typedef int WINAPI (*_CompareStringA)(LCID Locale,DWORD dwCmpFlags,LPCSTR lpString1,int cchCount1,LPCSTR lpString2,int cchCount2);

/**
 * Load DLL from memory location.
 *
 * All dependencies are resolved using default LoadLibrary/GetProcAddress
 * calls through the Windows API.
 */
//HMEMORYMODULE WINAPI MemoryLoadLibrary(const void *);

/**
 * Load DLL from memory location using custom dependency resolvers.
 *
 * Dependencies will be resolved using passed callback methods.
 */
HMEMORYMODULE WINAPI MemoryLoadLibraryEx(const void *,
    HMODULE,
    _GetProcAddress);

/**
 * Get address of exported method.
 */
FARPROC WINAPI MemoryGetProcAddress(HMEMORYMODULE, LPCSTR);

/**
 * Free previously loaded DLL.
 */
void WINAPI MemoryFreeLibrary(HMEMORYMODULE);

/**
 * Find the location of a resource with the specified type and name.
 */
//HMEMORYRSRC WINAPI MemoryFindResource(HMEMORYMODULE, LPCTSTR, LPCTSTR);

/**
 * Find the location of a resource with the specified type, name and language.
 */
//HMEMORYRSRC WINAPI MemoryFindResourceEx(HMEMORYMODULE, LPCTSTR, LPCTSTR, WORD);

/**
 * Get the size of the resource in bytes.
 */
//DWORD WINAPI MemorySizeofResource(HMEMORYMODULE, HMEMORYRSRC);

/**
 * Get a pointer to the contents of the resource.
 */
//LPVOID WINAPI MemoryLoadResource(HMEMORYMODULE, HMEMORYRSRC);

/**
 * Load a string resource.
 */
//int WINAPI MemoryLoadString(HMEMORYMODULE, UINT, LPTSTR, int);

/**
 * Load a string resource with a given language.
 */
//int WINAPI MemoryLoadStringEx(HMEMORYMODULE, UINT, LPTSTR, int, WORD);

#ifdef __cplusplus
}
#endif

#endif  // __MEMORY_MODULE_HEADER
