for installing and updating Malwarebytes1.45.0.0 when the installation is being blocked by a virus. 

download malewarebytes (malewarebytes.org) and rename the installer dun dun dun.exe

"Auto Mbam.exe" and "dun dun dun.exe" must be in the same folder to for this to work. you must have an internet connection for the updater to work.

after malewarebytes is installed and you have run a scan, i reccomend you restart in safemode and run another scan to be safe.

good luck. feel free to share. 

