
function AutoItTools:CreateAutoitFunctionHeader(s, p)

	local nl = self:NewLineInUse()
	local header = "; #FUNCTION# " .. string.rep("=", 100) .. nl .. "; Name...........: " .. s .. nl .. "; Description ...: " .. nl --..
	local params = false
	local firstparam = true
	local tabs = ""
	local syntax = "; Syntax.........: " .. s .. "("
	local parameters = "; Parameters ....: "

	for byref, param, optional in p:gmatch("(%w-)%s*($[%w_]+)%s*([=]?[^,%)]*)") do
		if param ~= "" and param ~= nil then
			params = true
			if firstparam == true then
				if byref ~= "" and byref ~= nil then
					syntax = syntax .. "ByRef " .. param
				elseif optional ~= "" and optional ~= nil then --
					syntax = syntax .. "[" .. param .. " = "
				else
					syntax = syntax .. param
				end
			else
				if byref ~= "" and byref ~= nil then
					syntax = syntax .. " , ByRef " .. param
				elseif optional ~= "" and optional ~= nil then --
					syntax = syntax .. " [, " .. param .. " = "
				else
					syntax = syntax .. ", " .. param
				end
			end
			firstparam = false
			parameters = parameters .. tabs .. param .. "\t-" .. nl
			tabs = ";\t\t\t\t   "
		end
	end

	if params == false then
		parameters = parameters .. "None" .. nl
		tabs = ";\t\t\t\t   "
	end

	local author = "Beege"  -- Enter Your Name Here

	header = header .. syntax .. ")" .. nl .. parameters
	header = header .. "; Return values .: Success \t- " .. nl .. tabs .. "Failure \t- " .. nl .. "; Author ........: " .. author .. nl
	header = header .. "; Modified.......: " .. nl
	header = header .. "; Remarks .......: None" .. nl
	header = header .. "; Link ..........: " .. nl
	header = header .. "; Example .......: " .. nl
	return header .. "; " .. string.rep("=", 111) .. nl
end	-- CreateFunctionHeader()


function AutoItTools:InsertAutoitFunctionHeader()
	local line, pos = editor:GetCurLine()
	local pos = editor.CurrentPos - pos
	local lineNum = editor:LineFromPosition(pos)
	local from, to, name = line:find("[Ff][Uu][Nn][Cc][%s]*([%w%s_]*)")
	if to ~= nil then
		local pfrom, pto, pname = line:find("(%(.-[%)_])")
		local i = 0
		if pto ~= nil then
			while pname:find("_%s*$") do	-- Found an underscore, so need to get the next line, too
				i = i + 1
				local tmp = editor:GetLine(lineNum+i)
				local wfrom = pname:find("_%s*$")
				local nfrom = tmp:find("[^%s]")
				pname = pname:sub(1, wfrom-1) .. tmp:sub(nfrom, -1)
				pname = 	pname:gsub("[\n\r]", "")
			end
			editor:Home()
			editor:AddText(self:CreateAutoitFunctionHeader(name,pname))
		else
			print("Argument list not found, unable to insert header.")
		end
	else
		print("Function definition not found, unable to insert header.")
	end
end	-- InsertFunctionHeader()
