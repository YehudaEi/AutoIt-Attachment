FickyFocus v.02 by Samuel Murray

A little program that tries to prevent other windows from stealing the focus of the current window.  While similar programs work by pegging the active window "on top", they often do not prevent new windows or dialogs from stealing the focus.  FickyFocus does just that.

Usage:
Press Ctrl+Space, and FickyFocus will identify the current window as the preferred current window, and will do its best to prevent other windows from becoming the active window.  If you need another window to become the active window, just press Ctrl+Space, go to the other window, and press Ctrl+Space again.

Issues:
FickyFocus may slow down your computer.  FickyFocus will try not to prevent you from working in other windows (e.g. you can click a button in a window even if it is not the current active window, but you may struggle using a selection widget in such a window, unless you're fast).  There is no virus in FickyFocus (if your antivirus says otherwise, install AutoIt and run the script file itself).

Options:

OPTION 1: Would you like FickyFocus to identify the current window as the preferred active window if the previous active window is closed?  If yes, if you close the current active window (or if it closes by itself), FickyFocus will wait half a second and then presume that the window that is now the current window is your preferred active window (no need to press Ctrl+Space once again).  If no, if you close a window, FickyFocus will automatically disable until you press Ctrl+Space again.

OPTION 2: Would you like other programs to know that you had pressed Ctrl+Space?  If yes, the keystrokes Ctrl+Space will be sent on to whatever program is listening for such keystrokes.  If no, programs that wait for the user to press Ctrl+Space will wait forever... :-)

Advanced:FickyFocus is an AutoIt script.  The EXE file is a compiled version of the script file -- it's not merely a launcher.  So if you want to edit the script, edit the AU3 file and then run the AU3 file (not the EXE file).

The file keepfocus_OLD is the old version of FickyFocus. It is temperamental and works in a completely different way.

 