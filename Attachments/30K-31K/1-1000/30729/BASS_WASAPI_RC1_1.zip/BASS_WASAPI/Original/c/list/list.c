#include "basswasapi.h"

#include <stdio.h>

void main()
{
	BASS_WASAPI_DEVICEINFO di;
	int a;
	for (a=0;BASS_WASAPI_GetDeviceInfo(a,&di);a++) {
		printf("dev %d: %s\n\tid: %s\n\tflags:",a,di.name,di.id);
		if (di.flags&BASS_DEVICE_LOOPBACK) printf(" loopback");
		if (di.flags&BASS_DEVICE_INPUT) printf(" input");
		if (di.flags&BASS_DEVICE_ENABLED) printf(" enabled");
		if (di.flags&BASS_DEVICE_DEFAULT) printf(" default");
		printf(" (%d)\n",di.flags);
	}
}
