// Microsoft Visual C++ �Ŏ����������ꂽ IDispatch ���b�v �N���X

// ����: ���̃t�@�C���̓��e��ҏW���Ȃ��ł��������B ���̃N���X���ēx
//  Microsoft Visual C++ �Ő������ꂽ�ꍇ�A�ύX���㏑�����܂��B


#include "stdafx.h"
#include "actaj71qe71udp.h"

/////////////////////////////////////////////////////////////////////////////
// CActAJ71QE71UDP

IMPLEMENT_DYNCREATE(CActAJ71QE71UDP, CWnd)

/////////////////////////////////////////////////////////////////////////////
// CActAJ71QE71UDP �v���p�e�B

/////////////////////////////////////////////////////////////////////////////
// CActAJ71QE71UDP �I�y���[�V����

long CActAJ71QE71UDP::Open()
{
	long result;
	InvokeHelper(0x1, DISPATCH_METHOD, VT_I4, (void*)&result, NULL);
	return result;
}

long CActAJ71QE71UDP::Close()
{
	long result;
	InvokeHelper(0x2, DISPATCH_METHOD, VT_I4, (void*)&result, NULL);
	return result;
}

long CActAJ71QE71UDP::ReadDeviceBlock(LPCTSTR szDevice, long dwSize, long* lpdwData)
{
	long result;
	static BYTE parms[] =
		VTS_BSTR VTS_I4 VTS_PI4;
	InvokeHelper(0x3, DISPATCH_METHOD, VT_I4, (void*)&result, parms,
		szDevice, dwSize, lpdwData);
	return result;
}

long CActAJ71QE71UDP::WriteDeviceBlock(LPCTSTR szDevice, long dwSize, long* lpdwData)
{
	long result;
	static BYTE parms[] =
		VTS_BSTR VTS_I4 VTS_PI4;
	InvokeHelper(0x4, DISPATCH_METHOD, VT_I4, (void*)&result, parms,
		szDevice, dwSize, lpdwData);
	return result;
}

long CActAJ71QE71UDP::ReadDeviceRandom(LPCTSTR szDeviceList, long dwSize, long* lpdwData)
{
	long result;
	static BYTE parms[] =
		VTS_BSTR VTS_I4 VTS_PI4;
	InvokeHelper(0x5, DISPATCH_METHOD, VT_I4, (void*)&result, parms,
		szDeviceList, dwSize, lpdwData);
	return result;
}

long CActAJ71QE71UDP::WriteDeviceRandom(LPCTSTR szDeviceList, long dwSize, long* lpdwData)
{
	long result;
	static BYTE parms[] =
		VTS_BSTR VTS_I4 VTS_PI4;
	InvokeHelper(0x6, DISPATCH_METHOD, VT_I4, (void*)&result, parms,
		szDeviceList, dwSize, lpdwData);
	return result;
}

long CActAJ71QE71UDP::ReadBuffer(long lStartIO, long lAddress, long lReadSize, short* lpwData)
{
	long result;
	static BYTE parms[] =
		VTS_I4 VTS_I4 VTS_I4 VTS_PI2;
	InvokeHelper(0x7, DISPATCH_METHOD, VT_I4, (void*)&result, parms,
		lStartIO, lAddress, lReadSize, lpwData);
	return result;
}

long CActAJ71QE71UDP::WriteBuffer(long lStartIO, long lAddress, long lWriteSize, short* lpwData)
{
	long result;
	static BYTE parms[] =
		VTS_I4 VTS_I4 VTS_I4 VTS_PI2;
	InvokeHelper(0x8, DISPATCH_METHOD, VT_I4, (void*)&result, parms,
		lStartIO, lAddress, lWriteSize, lpwData);
	return result;
}

long CActAJ71QE71UDP::GetClockData(short* lpwYear, short* lpwMonth, short* lpwDay, short* lpwDayOfWeek, short* lpwHour, short* lpwMinute, short* lpwSecond)
{
	long result;
	static BYTE parms[] =
		VTS_PI2 VTS_PI2 VTS_PI2 VTS_PI2 VTS_PI2 VTS_PI2 VTS_PI2;
	InvokeHelper(0x9, DISPATCH_METHOD, VT_I4, (void*)&result, parms,
		lpwYear, lpwMonth, lpwDay, lpwDayOfWeek, lpwHour, lpwMinute, lpwSecond);
	return result;
}

long CActAJ71QE71UDP::SetClockData(short wYear, short wMonth, short wDay, short wDayOfWeek, short wHour, short wMinute, short wSecond)
{
	long result;
	static BYTE parms[] =
		VTS_I2 VTS_I2 VTS_I2 VTS_I2 VTS_I2 VTS_I2 VTS_I2;
	InvokeHelper(0xa, DISPATCH_METHOD, VT_I4, (void*)&result, parms,
		wYear, wMonth, wDay, wDayOfWeek, wHour, wMinute, wSecond);
	return result;
}

long CActAJ71QE71UDP::SetDevice(LPCTSTR szDevice, long dwData)
{
	long result;
	static BYTE parms[] =
		VTS_BSTR VTS_I4;
	InvokeHelper(0xb, DISPATCH_METHOD, VT_I4, (void*)&result, parms,
		szDevice, dwData);
	return result;
}

long CActAJ71QE71UDP::SetCpuStatus(long lOperation)
{
	long result;
	static BYTE parms[] =
		VTS_I4;
	InvokeHelper(0xc, DISPATCH_METHOD, VT_I4, (void*)&result, parms,
		lOperation);
	return result;
}

long CActAJ71QE71UDP::GetCpuType(BSTR* lpszCpuName, long* lplCpuType)
{
	long result;
	static BYTE parms[] =
		VTS_PBSTR VTS_PI4;
	InvokeHelper(0xd, DISPATCH_METHOD, VT_I4, (void*)&result, parms,
		lpszCpuName, lplCpuType);
	return result;
}

long CActAJ71QE71UDP::GetActNetworkNumber()
{
	long result;
	InvokeHelper(0xe, DISPATCH_PROPERTYGET, VT_I4, (void*)&result, NULL);
	return result;
}

void CActAJ71QE71UDP::SetActNetworkNumber(long nNewValue)
{
	static BYTE parms[] =
		VTS_I4;
	InvokeHelper(0xe, DISPATCH_PROPERTYPUT, VT_EMPTY, NULL, parms,
		 nNewValue);
}

long CActAJ71QE71UDP::GetActStationNumber()
{
	long result;
	InvokeHelper(0xf, DISPATCH_PROPERTYGET, VT_I4, (void*)&result, NULL);
	return result;
}

void CActAJ71QE71UDP::SetActStationNumber(long nNewValue)
{
	static BYTE parms[] =
		VTS_I4;
	InvokeHelper(0xf, DISPATCH_PROPERTYPUT, VT_EMPTY, NULL, parms,
		 nNewValue);
}

long CActAJ71QE71UDP::GetActUnitNumber()
{
	long result;
	InvokeHelper(0x10, DISPATCH_PROPERTYGET, VT_I4, (void*)&result, NULL);
	return result;
}

void CActAJ71QE71UDP::SetActUnitNumber(long nNewValue)
{
	static BYTE parms[] =
		VTS_I4;
	InvokeHelper(0x10, DISPATCH_PROPERTYPUT, VT_EMPTY, NULL, parms,
		 nNewValue);
}

long CActAJ71QE71UDP::GetActConnectUnitNumber()
{
	long result;
	InvokeHelper(0x11, DISPATCH_PROPERTYGET, VT_I4, (void*)&result, NULL);
	return result;
}

void CActAJ71QE71UDP::SetActConnectUnitNumber(long nNewValue)
{
	static BYTE parms[] =
		VTS_I4;
	InvokeHelper(0x11, DISPATCH_PROPERTYPUT, VT_EMPTY, NULL, parms,
		 nNewValue);
}

long CActAJ71QE71UDP::GetActIONumber()
{
	long result;
	InvokeHelper(0x12, DISPATCH_PROPERTYGET, VT_I4, (void*)&result, NULL);
	return result;
}

void CActAJ71QE71UDP::SetActIONumber(long nNewValue)
{
	static BYTE parms[] =
		VTS_I4;
	InvokeHelper(0x12, DISPATCH_PROPERTYPUT, VT_EMPTY, NULL, parms,
		 nNewValue);
}

long CActAJ71QE71UDP::GetActCpuType()
{
	long result;
	InvokeHelper(0x13, DISPATCH_PROPERTYGET, VT_I4, (void*)&result, NULL);
	return result;
}

void CActAJ71QE71UDP::SetActCpuType(long nNewValue)
{
	static BYTE parms[] =
		VTS_I4;
	InvokeHelper(0x13, DISPATCH_PROPERTYPUT, VT_EMPTY, NULL, parms,
		 nNewValue);
}

long CActAJ71QE71UDP::GetActPortNumber()
{
	long result;
	InvokeHelper(0x14, DISPATCH_PROPERTYGET, VT_I4, (void*)&result, NULL);
	return result;
}

void CActAJ71QE71UDP::SetActPortNumber(long nNewValue)
{
	static BYTE parms[] =
		VTS_I4;
	InvokeHelper(0x14, DISPATCH_PROPERTYPUT, VT_EMPTY, NULL, parms,
		 nNewValue);
}

CString CActAJ71QE71UDP::GetActHostAddress()
{
	CString result;
	InvokeHelper(0x15, DISPATCH_PROPERTYGET, VT_BSTR, (void*)&result, NULL);
	return result;
}

void CActAJ71QE71UDP::SetActHostAddress(LPCTSTR lpszNewValue)
{
	static BYTE parms[] =
		VTS_BSTR;
	InvokeHelper(0x15, DISPATCH_PROPERTYPUT, VT_EMPTY, NULL, parms,
		 lpszNewValue);
}

long CActAJ71QE71UDP::GetActTimeOut()
{
	long result;
	InvokeHelper(0x16, DISPATCH_PROPERTYGET, VT_I4, (void*)&result, NULL);
	return result;
}

void CActAJ71QE71UDP::SetActTimeOut(long nNewValue)
{
	static BYTE parms[] =
		VTS_I4;
	InvokeHelper(0x16, DISPATCH_PROPERTYPUT, VT_EMPTY, NULL, parms,
		 nNewValue);
}

long CActAJ71QE71UDP::GetActSourceNetworkNumber()
{
	long result;
	InvokeHelper(0x17, DISPATCH_PROPERTYGET, VT_I4, (void*)&result, NULL);
	return result;
}

void CActAJ71QE71UDP::SetActSourceNetworkNumber(long nNewValue)
{
	static BYTE parms[] =
		VTS_I4;
	InvokeHelper(0x17, DISPATCH_PROPERTYPUT, VT_EMPTY, NULL, parms,
		 nNewValue);
}

long CActAJ71QE71UDP::GetActSourceStationNumber()
{
	long result;
	InvokeHelper(0x18, DISPATCH_PROPERTYGET, VT_I4, (void*)&result, NULL);
	return result;
}

void CActAJ71QE71UDP::SetActSourceStationNumber(long nNewValue)
{
	static BYTE parms[] =
		VTS_I4;
	InvokeHelper(0x18, DISPATCH_PROPERTYPUT, VT_EMPTY, NULL, parms,
		 nNewValue);
}

long CActAJ71QE71UDP::GetDevice(LPCTSTR szDevice, long* lpdwData)
{
	long result;
	static BYTE parms[] =
		VTS_BSTR VTS_PI4;
	InvokeHelper(0x19, DISPATCH_METHOD, VT_I4, (void*)&result, parms,
		szDevice, lpdwData);
	return result;
}

long CActAJ71QE71UDP::CheckDeviceString(LPCTSTR szDevice, long lCheckType, long lSize, long* lplDeviceType, BSTR* lpszDeviceName, long* lplDeviceNumber, long* lplDeviceRadix)
{
	long result;
	static BYTE parms[] =
		VTS_BSTR VTS_I4 VTS_I4 VTS_PI4 VTS_PBSTR VTS_PI4 VTS_PI4;
	InvokeHelper(0x1a, DISPATCH_METHOD, VT_I4, (void*)&result, parms,
		szDevice, lCheckType, lSize, lplDeviceType, lpszDeviceName, lplDeviceNumber, lplDeviceRadix);
	return result;
}

long CActAJ71QE71UDP::EntryDeviceStatus(LPCTSTR szDeviceList, long lSize, long lMonitorCycle, long* lplData)
{
	long result;
	static BYTE parms[] =
		VTS_BSTR VTS_I4 VTS_I4 VTS_PI4;
	InvokeHelper(0x1b, DISPATCH_METHOD, VT_I4, (void*)&result, parms,
		szDeviceList, lSize, lMonitorCycle, lplData);
	return result;
}

long CActAJ71QE71UDP::FreeDeviceStatus()
{
	long result;
	InvokeHelper(0x1c, DISPATCH_METHOD, VT_I4, (void*)&result, NULL);
	return result;
}

long CActAJ71QE71UDP::ReadDeviceBlock2(LPCTSTR szDevice, long lSize, short* lpsData)
{
	long result;
	static BYTE parms[] =
		VTS_BSTR VTS_I4 VTS_PI2;
	InvokeHelper(0x1d, DISPATCH_METHOD, VT_I4, (void*)&result, parms,
		szDevice, lSize, lpsData);
	return result;
}

long CActAJ71QE71UDP::WriteDeviceBlock2(LPCTSTR szDevice, long lSize, short* lpsData)
{
	long result;
	static BYTE parms[] =
		VTS_BSTR VTS_I4 VTS_PI2;
	InvokeHelper(0x1e, DISPATCH_METHOD, VT_I4, (void*)&result, parms,
		szDevice, lSize, lpsData);
	return result;
}

long CActAJ71QE71UDP::ReadDeviceRandom2(LPCTSTR szDevice, long lSize, short* lpsData)
{
	long result;
	static BYTE parms[] =
		VTS_BSTR VTS_I4 VTS_PI2;
	InvokeHelper(0x1f, DISPATCH_METHOD, VT_I4, (void*)&result, parms,
		szDevice, lSize, lpsData);
	return result;
}

long CActAJ71QE71UDP::WriteDeviceRandom2(LPCTSTR szDeviceList, long lSize, short* lpsData)
{
	long result;
	static BYTE parms[] =
		VTS_BSTR VTS_I4 VTS_PI2;
	InvokeHelper(0x20, DISPATCH_METHOD, VT_I4, (void*)&result, parms,
		szDeviceList, lSize, lpsData);
	return result;
}

long CActAJ71QE71UDP::GetDevice2(LPCTSTR szDevice, short* lpsData)
{
	long result;
	static BYTE parms[] =
		VTS_BSTR VTS_PI2;
	InvokeHelper(0x21, DISPATCH_METHOD, VT_I4, (void*)&result, parms,
		szDevice, lpsData);
	return result;
}

long CActAJ71QE71UDP::SetDevice2(LPCTSTR szDevice, short sData)
{
	long result;
	static BYTE parms[] =
		VTS_BSTR VTS_I2;
	InvokeHelper(0x22, DISPATCH_METHOD, VT_I4, (void*)&result, parms,
		szDevice, sData);
	return result;
}
