#if !defined(AFX_ACTAJ71QE71UDP_H__00D75850_EFA1_4836_BB34_86F227F7AF39__INCLUDED_)
#define AFX_ACTAJ71QE71UDP_H__00D75850_EFA1_4836_BB34_86F227F7AF39__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
//  Microsoft Visual C++ �ɂ���Ď����������ꂽ IDispatch ���b�v �N���X

// ����: ���̃t�@�C���̓��e��ҏW���Ȃ��ł��������B ���̃N���X���ēx
//  Microsoft Visual C++ �Ő������ꂽ�ꍇ�A�ύX���㏑�����܂��B

/////////////////////////////////////////////////////////////////////////////
// CActAJ71QE71UDP ���b�v �N���X

class CActAJ71QE71UDP : public CWnd
{
protected:
	DECLARE_DYNCREATE(CActAJ71QE71UDP)
public:
	CLSID const& GetClsid()
	{
		static CLSID const clsid
			= { 0xafea551b, 0xae9c, 0x11d3, { 0x83, 0xae, 0x0, 0xa0, 0x24, 0xbd, 0xbf, 0x2b } };
		return clsid;
	}
	virtual BOOL Create(LPCTSTR lpszClassName,
		LPCTSTR lpszWindowName, DWORD dwStyle,
		const RECT& rect,
		CWnd* pParentWnd, UINT nID,
		CCreateContext* pContext = NULL)
	{ return CreateControl(GetClsid(), lpszWindowName, dwStyle, rect, pParentWnd, nID); }

    BOOL Create(LPCTSTR lpszWindowName, DWORD dwStyle,
		const RECT& rect, CWnd* pParentWnd, UINT nID,
		CFile* pPersist = NULL, BOOL bStorage = FALSE,
		BSTR bstrLicKey = NULL)
	{ return CreateControl(GetClsid(), lpszWindowName, dwStyle, rect, pParentWnd, nID,
		pPersist, bStorage, bstrLicKey); }

// �A�g���r���[�g
public:

// �I�y���[�V����
public:
	long Open();
	long Close();
	long ReadDeviceBlock(LPCTSTR szDevice, long dwSize, long* lpdwData);
	long WriteDeviceBlock(LPCTSTR szDevice, long dwSize, long* lpdwData);
	long ReadDeviceRandom(LPCTSTR szDeviceList, long dwSize, long* lpdwData);
	long WriteDeviceRandom(LPCTSTR szDeviceList, long dwSize, long* lpdwData);
	long ReadBuffer(long lStartIO, long lAddress, long lReadSize, short* lpwData);
	long WriteBuffer(long lStartIO, long lAddress, long lWriteSize, short* lpwData);
	long GetClockData(short* lpwYear, short* lpwMonth, short* lpwDay, short* lpwDayOfWeek, short* lpwHour, short* lpwMinute, short* lpwSecond);
	long SetClockData(short wYear, short wMonth, short wDay, short wDayOfWeek, short wHour, short wMinute, short wSecond);
	long SetDevice(LPCTSTR szDevice, long dwData);
	long SetCpuStatus(long lOperation);
	long GetCpuType(BSTR* lpszCpuName, long* lplCpuType);
	long GetActNetworkNumber();
	void SetActNetworkNumber(long nNewValue);
	long GetActStationNumber();
	void SetActStationNumber(long nNewValue);
	long GetActUnitNumber();
	void SetActUnitNumber(long nNewValue);
	long GetActConnectUnitNumber();
	void SetActConnectUnitNumber(long nNewValue);
	long GetActIONumber();
	void SetActIONumber(long nNewValue);
	long GetActCpuType();
	void SetActCpuType(long nNewValue);
	long GetActPortNumber();
	void SetActPortNumber(long nNewValue);
	CString GetActHostAddress();
	void SetActHostAddress(LPCTSTR lpszNewValue);
	long GetActTimeOut();
	void SetActTimeOut(long nNewValue);
	long GetActSourceNetworkNumber();
	void SetActSourceNetworkNumber(long nNewValue);
	long GetActSourceStationNumber();
	void SetActSourceStationNumber(long nNewValue);
	long GetDevice(LPCTSTR szDevice, long* lpdwData);
	long CheckDeviceString(LPCTSTR szDevice, long lCheckType, long lSize, long* lplDeviceType, BSTR* lpszDeviceName, long* lplDeviceNumber, long* lplDeviceRadix);
	long EntryDeviceStatus(LPCTSTR szDeviceList, long lSize, long lMonitorCycle, long* lplData);
	long FreeDeviceStatus();
	long ReadDeviceBlock2(LPCTSTR szDevice, long lSize, short* lpsData);
	long WriteDeviceBlock2(LPCTSTR szDevice, long lSize, short* lpsData);
	long ReadDeviceRandom2(LPCTSTR szDevice, long lSize, short* lpsData);
	long WriteDeviceRandom2(LPCTSTR szDeviceList, long lSize, short* lpsData);
	long GetDevice2(LPCTSTR szDevice, short* lpsData);
	long SetDevice2(LPCTSTR szDevice, short sData);
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ �͑O�s�̒��O�ɒǉ��̐錾��}�����܂��B

#endif // !defined(AFX_ACTAJ71QE71UDP_H__00D75850_EFA1_4836_BB34_86F227F7AF39__INCLUDED_)
