// Sample_SupportDlg.h : header file
//
//{{AFX_INCLUDES()
#include "actsupport3.h"
//}}AFX_INCLUDES

#if !defined(AFX_SAMPLE_SUPPORTDLG_H__CE790F86_DF6C_11D5_9D11_EDE5BD57E368__INCLUDED_)
#define AFX_SAMPLE_SUPPORTDLG_H__CE790F86_DF6C_11D5_9D11_EDE5BD57E368__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

/////////////////////////////////////////////////////////////////////////////
// CSample_SupportDlg dialog

class CSample_SupportDlg : public CDialog
{
// Construction
public:
	CSample_SupportDlg(CWnd* pParent = NULL);	// standard constructor

// Dialog Data
	//{{AFX_DATA(CSample_SupportDlg)
	enum { IDD = IDD_SAMPLE_SUPPORT_DIALOG };
	CString	m_Message;
	CString	m_ErrorCode;
	CActSupport3	m_ActSupport;
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CSample_SupportDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	HICON m_hIcon;

	// Generated message map functions
	//{{AFX_MSG(CSample_SupportDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	afx_msg void OnGetErrorMessage();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_SAMPLE_SUPPORTDLG_H__CE790F86_DF6C_11D5_9D11_EDE5BD57E368__INCLUDED_)
