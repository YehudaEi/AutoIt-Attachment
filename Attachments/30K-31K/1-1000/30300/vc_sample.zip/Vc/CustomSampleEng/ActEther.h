/* this ALWAYS GENERATED file contains the definitions for the interfaces */


/* File created by MIDL compiler version 5.01.0164 */
/* at Thu Feb 17 14:09:37 2000
 */
/* Compiler settings for D:\Act\Control\ActEther\ActEther.idl:
    Oicf (OptLev=i2), W1, Zp8, env=Win32, ms_ext, c_ext
    error checks: allocation ref bounds_check enum stub_data 
*/
//@@MIDL_FILE_HEADING(  )


/* verify that the <rpcndr.h> version is high enough to compile this file*/
#ifndef __REQUIRED_RPCNDR_H_VERSION__
#define __REQUIRED_RPCNDR_H_VERSION__ 440
#endif

#include "rpc.h"
#include "rpcndr.h"

#ifndef __RPCNDR_H_VERSION__
#error this stub requires an updated version of <rpcndr.h>
#endif // __RPCNDR_H_VERSION__

#ifndef COM_NO_WINDOWS_H
#include "windows.h"
#include "ole2.h"
#endif /*COM_NO_WINDOWS_H*/

#ifndef __ActEther_h__
#define __ActEther_h__

#ifdef __cplusplus
extern "C"{
#endif 

/* Forward Declarations */ 

#ifndef __IActQJ71E71TCP_FWD_DEFINED__
#define __IActQJ71E71TCP_FWD_DEFINED__
typedef interface IActQJ71E71TCP IActQJ71E71TCP;
#endif 	/* __IActQJ71E71TCP_FWD_DEFINED__ */


#ifndef ___IActQJ71E71TCPEvents_FWD_DEFINED__
#define ___IActQJ71E71TCPEvents_FWD_DEFINED__
typedef interface _IActQJ71E71TCPEvents _IActQJ71E71TCPEvents;
#endif 	/* ___IActQJ71E71TCPEvents_FWD_DEFINED__ */


#ifndef __IActQJ71E71UDP_FWD_DEFINED__
#define __IActQJ71E71UDP_FWD_DEFINED__
typedef interface IActQJ71E71UDP IActQJ71E71UDP;
#endif 	/* __IActQJ71E71UDP_FWD_DEFINED__ */


#ifndef __ActQJ71E71TCP_FWD_DEFINED__
#define __ActQJ71E71TCP_FWD_DEFINED__

#ifdef __cplusplus
typedef class ActQJ71E71TCP ActQJ71E71TCP;
#else
typedef struct ActQJ71E71TCP ActQJ71E71TCP;
#endif /* __cplusplus */

#endif 	/* __ActQJ71E71TCP_FWD_DEFINED__ */


#ifndef ___IActQJ71E71UDPEvents_FWD_DEFINED__
#define ___IActQJ71E71UDPEvents_FWD_DEFINED__
typedef interface _IActQJ71E71UDPEvents _IActQJ71E71UDPEvents;
#endif 	/* ___IActQJ71E71UDPEvents_FWD_DEFINED__ */


#ifndef __IActAJ71QE71TCP_FWD_DEFINED__
#define __IActAJ71QE71TCP_FWD_DEFINED__
typedef interface IActAJ71QE71TCP IActAJ71QE71TCP;
#endif 	/* __IActAJ71QE71TCP_FWD_DEFINED__ */


#ifndef __ActQJ71E71UDP_FWD_DEFINED__
#define __ActQJ71E71UDP_FWD_DEFINED__

#ifdef __cplusplus
typedef class ActQJ71E71UDP ActQJ71E71UDP;
#else
typedef struct ActQJ71E71UDP ActQJ71E71UDP;
#endif /* __cplusplus */

#endif 	/* __ActQJ71E71UDP_FWD_DEFINED__ */


#ifndef ___IActAJ71QE71TCPEvents_FWD_DEFINED__
#define ___IActAJ71QE71TCPEvents_FWD_DEFINED__
typedef interface _IActAJ71QE71TCPEvents _IActAJ71QE71TCPEvents;
#endif 	/* ___IActAJ71QE71TCPEvents_FWD_DEFINED__ */


#ifndef __IActAJ71QE71UDP_FWD_DEFINED__
#define __IActAJ71QE71UDP_FWD_DEFINED__
typedef interface IActAJ71QE71UDP IActAJ71QE71UDP;
#endif 	/* __IActAJ71QE71UDP_FWD_DEFINED__ */


#ifndef __ActAJ71QE71TCP_FWD_DEFINED__
#define __ActAJ71QE71TCP_FWD_DEFINED__

#ifdef __cplusplus
typedef class ActAJ71QE71TCP ActAJ71QE71TCP;
#else
typedef struct ActAJ71QE71TCP ActAJ71QE71TCP;
#endif /* __cplusplus */

#endif 	/* __ActAJ71QE71TCP_FWD_DEFINED__ */


#ifndef ___IActAJ71QE71UDPEvents_FWD_DEFINED__
#define ___IActAJ71QE71UDPEvents_FWD_DEFINED__
typedef interface _IActAJ71QE71UDPEvents _IActAJ71QE71UDPEvents;
#endif 	/* ___IActAJ71QE71UDPEvents_FWD_DEFINED__ */


#ifndef __IActAJ71E71TCP_FWD_DEFINED__
#define __IActAJ71E71TCP_FWD_DEFINED__
typedef interface IActAJ71E71TCP IActAJ71E71TCP;
#endif 	/* __IActAJ71E71TCP_FWD_DEFINED__ */


#ifndef __ActAJ71QE71UDP_FWD_DEFINED__
#define __ActAJ71QE71UDP_FWD_DEFINED__

#ifdef __cplusplus
typedef class ActAJ71QE71UDP ActAJ71QE71UDP;
#else
typedef struct ActAJ71QE71UDP ActAJ71QE71UDP;
#endif /* __cplusplus */

#endif 	/* __ActAJ71QE71UDP_FWD_DEFINED__ */


#ifndef ___IActAJ71E71TCPEvents_FWD_DEFINED__
#define ___IActAJ71E71TCPEvents_FWD_DEFINED__
typedef interface _IActAJ71E71TCPEvents _IActAJ71E71TCPEvents;
#endif 	/* ___IActAJ71E71TCPEvents_FWD_DEFINED__ */


#ifndef __IActAJ71E71UDP_FWD_DEFINED__
#define __IActAJ71E71UDP_FWD_DEFINED__
typedef interface IActAJ71E71UDP IActAJ71E71UDP;
#endif 	/* __IActAJ71E71UDP_FWD_DEFINED__ */


#ifndef __ActAJ71E71TCP_FWD_DEFINED__
#define __ActAJ71E71TCP_FWD_DEFINED__

#ifdef __cplusplus
typedef class ActAJ71E71TCP ActAJ71E71TCP;
#else
typedef struct ActAJ71E71TCP ActAJ71E71TCP;
#endif /* __cplusplus */

#endif 	/* __ActAJ71E71TCP_FWD_DEFINED__ */


#ifndef ___IActAJ71E71UDPEvents_FWD_DEFINED__
#define ___IActAJ71E71UDPEvents_FWD_DEFINED__
typedef interface _IActAJ71E71UDPEvents _IActAJ71E71UDPEvents;
#endif 	/* ___IActAJ71E71UDPEvents_FWD_DEFINED__ */


#ifndef __ActAJ71E71UDP_FWD_DEFINED__
#define __ActAJ71E71UDP_FWD_DEFINED__

#ifdef __cplusplus
typedef class ActAJ71E71UDP ActAJ71E71UDP;
#else
typedef struct ActAJ71E71UDP ActAJ71E71UDP;
#endif /* __cplusplus */

#endif 	/* __ActAJ71E71UDP_FWD_DEFINED__ */


/* header files for imported files */
#include "oaidl.h"
#include "ocidl.h"

void __RPC_FAR * __RPC_USER MIDL_user_allocate(size_t);
void __RPC_USER MIDL_user_free( void __RPC_FAR * ); 

#ifndef __IActQJ71E71TCP_INTERFACE_DEFINED__
#define __IActQJ71E71TCP_INTERFACE_DEFINED__

/* interface IActQJ71E71TCP */
/* [unique][helpstring][dual][uuid][object] */ 


EXTERN_C const IID IID_IActQJ71E71TCP;

#if defined(__cplusplus) && !defined(CINTERFACE)
    
    MIDL_INTERFACE("AFEA5511-AE9C-11D3-83AE-00A024BDBF2B")
    IActQJ71E71TCP : public IDispatch
    {
    public:
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE Open( 
            /* [retval][out] */ LONG __RPC_FAR *lplReturnCode) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE Close( 
            /* [retval][out] */ LONG __RPC_FAR *lplReturnCode) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE ReadDeviceBlock( 
            /* [string][in] */ BSTR szDevice,
            /* [in] */ LONG dwSize,
            /* [size_is][out] */ LONG __RPC_FAR *lpdwData,
            /* [retval][out] */ LONG __RPC_FAR *lplReturnCode) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE WriteDeviceBlock( 
            /* [string][in] */ BSTR szDevice,
            /* [in] */ LONG dwSize,
            /* [size_is][in] */ LONG __RPC_FAR *lpdwData,
            /* [retval][out] */ LONG __RPC_FAR *lplReturnCode) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE ReadDeviceRandom( 
            /* [string][in] */ BSTR szDeviceList,
            /* [in] */ LONG dwSize,
            /* [size_is][out] */ LONG __RPC_FAR *lpdwData,
            /* [retval][out] */ LONG __RPC_FAR *lplReturnCode) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE WriteDeviceRandom( 
            /* [string][in] */ BSTR szDeviceList,
            /* [in] */ LONG dwSize,
            /* [size_is][in] */ LONG __RPC_FAR *lpdwData,
            /* [retval][out] */ LONG __RPC_FAR *lplReturnCode) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE ReadBuffer( 
            /* [in] */ LONG lStartIO,
            /* [in] */ LONG lAddress,
            /* [in] */ LONG lReadSize,
            /* [out] */ SHORT __RPC_FAR *lpwData,
            /* [retval][out] */ LONG __RPC_FAR *lplReturnCode) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE WriteBuffer( 
            /* [in] */ LONG lStartIO,
            /* [in] */ LONG lAddress,
            /* [in] */ LONG lWriteSize,
            /* [out] */ SHORT __RPC_FAR *lpwData,
            /* [retval][out] */ LONG __RPC_FAR *lplReturnCode) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE GetClockData( 
            /* [out] */ SHORT __RPC_FAR *lpwYear,
            /* [out] */ SHORT __RPC_FAR *lpwMonth,
            /* [out] */ SHORT __RPC_FAR *lpwDay,
            /* [out] */ SHORT __RPC_FAR *lpwDayOfWeek,
            /* [out] */ SHORT __RPC_FAR *lpwHour,
            /* [out] */ SHORT __RPC_FAR *lpwMinute,
            /* [out] */ SHORT __RPC_FAR *lpwSecond,
            /* [retval][out] */ LONG __RPC_FAR *lplReturnCode) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE SetClockData( 
            /* [in] */ SHORT wYear,
            /* [in] */ SHORT wMonth,
            /* [in] */ SHORT wDay,
            /* [in] */ SHORT wDayOfWeek,
            /* [in] */ SHORT wHour,
            /* [in] */ SHORT wMinute,
            /* [in] */ SHORT wSecond,
            /* [retval][out] */ LONG __RPC_FAR *lplReturnCode) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE SetDevice( 
            /* [string][in] */ BSTR szDevice,
            /* [in] */ LONG dwData,
            /* [retval][out] */ LONG __RPC_FAR *lplReturnCode) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE SetCpuStatus( 
            /* [in] */ LONG lOperation,
            /* [retval][out] */ LONG __RPC_FAR *lplReturnCode) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE GetCpuType( 
            /* [string][out] */ BSTR __RPC_FAR *szCpuName,
            LONG __RPC_FAR *lplCpuType,
            /* [retval][out] */ LONG __RPC_FAR *lplReturnCode) = 0;
        
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_ActNetworkNumber( 
            /* [retval][out] */ long __RPC_FAR *pVal) = 0;
        
        virtual /* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE put_ActNetworkNumber( 
            /* [in] */ long newVal) = 0;
        
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_ActStationNumber( 
            /* [retval][out] */ long __RPC_FAR *pVal) = 0;
        
        virtual /* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE put_ActStationNumber( 
            /* [in] */ long newVal) = 0;
        
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_ActUnitNumber( 
            /* [retval][out] */ long __RPC_FAR *pVal) = 0;
        
        virtual /* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE put_ActUnitNumber( 
            /* [in] */ long newVal) = 0;
        
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_ActConnectUnitNumber( 
            /* [retval][out] */ long __RPC_FAR *pVal) = 0;
        
        virtual /* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE put_ActConnectUnitNumber( 
            /* [in] */ long newVal) = 0;
        
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_ActIONumber( 
            /* [retval][out] */ long __RPC_FAR *pVal) = 0;
        
        virtual /* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE put_ActIONumber( 
            /* [in] */ long newVal) = 0;
        
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_ActCpuType( 
            /* [retval][out] */ long __RPC_FAR *pVal) = 0;
        
        virtual /* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE put_ActCpuType( 
            /* [in] */ long newVal) = 0;
        
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_ActHostAddress( 
            /* [retval][string][out] */ BSTR __RPC_FAR *pVal) = 0;
        
        virtual /* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE put_ActHostAddress( 
            /* [string][in] */ BSTR newVal) = 0;
        
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_ActTimeOut( 
            /* [retval][out] */ long __RPC_FAR *pVal) = 0;
        
        virtual /* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE put_ActTimeOut( 
            /* [in] */ long newVal) = 0;
        
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_ActSourceNetworkNumber( 
            /* [retval][out] */ long __RPC_FAR *pVal) = 0;
        
        virtual /* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE put_ActSourceNetworkNumber( 
            /* [in] */ long newVal) = 0;
        
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_ActSourceStationNumber( 
            /* [retval][out] */ long __RPC_FAR *pVal) = 0;
        
        virtual /* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE put_ActSourceStationNumber( 
            /* [in] */ long newVal) = 0;
        
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_ActDestinationIONumber( 
            /* [retval][out] */ long __RPC_FAR *pVal) = 0;
        
        virtual /* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE put_ActDestinationIONumber( 
            /* [in] */ long newVal) = 0;
        
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_ActMultiDropChannelNumber( 
            /* [retval][out] */ long __RPC_FAR *pVal) = 0;
        
        virtual /* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE put_ActMultiDropChannelNumber( 
            /* [in] */ long newVal) = 0;
        
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_ActThroughNetworkType( 
            /* [retval][out] */ long __RPC_FAR *pVal) = 0;
        
        virtual /* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE put_ActThroughNetworkType( 
            /* [in] */ long newVal) = 0;
        
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_ActDidPropertyBit( 
            /* [retval][out] */ long __RPC_FAR *pVal) = 0;
        
        virtual /* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE put_ActDidPropertyBit( 
            /* [in] */ long newVal) = 0;
        
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_ActDsidPropertyBit( 
            /* [retval][out] */ long __RPC_FAR *pVal) = 0;
        
        virtual /* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE put_ActDsidPropertyBit( 
            /* [in] */ long newVal) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE GetDevice( 
            /* [string][in] */ BSTR szDevice,
            /* [out] */ LONG __RPC_FAR *lpdwData,
            /* [retval][out] */ LONG __RPC_FAR *lplReturnCode) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE CheckDeviceString( 
            /* [in] */ BSTR szDevice,
            /* [in] */ LONG lCheckType,
            /* [in] */ LONG lSize,
            /* [out] */ LONG __RPC_FAR *lplDeviceType,
            /* [string][out] */ BSTR __RPC_FAR *lpszDeviceName,
            /* [out] */ LONG __RPC_FAR *lplDeviceNumber,
            /* [out] */ LONG __RPC_FAR *lplDeviceRadix,
            /* [retval][out] */ LONG __RPC_FAR *lplReturnCode) = 0;
        
    };
    
#else 	/* C style interface */

    typedef struct IActQJ71E71TCPVtbl
    {
        BEGIN_INTERFACE
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *QueryInterface )( 
            IActQJ71E71TCP __RPC_FAR * This,
            /* [in] */ REFIID riid,
            /* [iid_is][out] */ void __RPC_FAR *__RPC_FAR *ppvObject);
        
        ULONG ( STDMETHODCALLTYPE __RPC_FAR *AddRef )( 
            IActQJ71E71TCP __RPC_FAR * This);
        
        ULONG ( STDMETHODCALLTYPE __RPC_FAR *Release )( 
            IActQJ71E71TCP __RPC_FAR * This);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetTypeInfoCount )( 
            IActQJ71E71TCP __RPC_FAR * This,
            /* [out] */ UINT __RPC_FAR *pctinfo);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetTypeInfo )( 
            IActQJ71E71TCP __RPC_FAR * This,
            /* [in] */ UINT iTInfo,
            /* [in] */ LCID lcid,
            /* [out] */ ITypeInfo __RPC_FAR *__RPC_FAR *ppTInfo);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetIDsOfNames )( 
            IActQJ71E71TCP __RPC_FAR * This,
            /* [in] */ REFIID riid,
            /* [size_is][in] */ LPOLESTR __RPC_FAR *rgszNames,
            /* [in] */ UINT cNames,
            /* [in] */ LCID lcid,
            /* [size_is][out] */ DISPID __RPC_FAR *rgDispId);
        
        /* [local] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *Invoke )( 
            IActQJ71E71TCP __RPC_FAR * This,
            /* [in] */ DISPID dispIdMember,
            /* [in] */ REFIID riid,
            /* [in] */ LCID lcid,
            /* [in] */ WORD wFlags,
            /* [out][in] */ DISPPARAMS __RPC_FAR *pDispParams,
            /* [out] */ VARIANT __RPC_FAR *pVarResult,
            /* [out] */ EXCEPINFO __RPC_FAR *pExcepInfo,
            /* [out] */ UINT __RPC_FAR *puArgErr);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *Open )( 
            IActQJ71E71TCP __RPC_FAR * This,
            /* [retval][out] */ LONG __RPC_FAR *lplReturnCode);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *Close )( 
            IActQJ71E71TCP __RPC_FAR * This,
            /* [retval][out] */ LONG __RPC_FAR *lplReturnCode);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *ReadDeviceBlock )( 
            IActQJ71E71TCP __RPC_FAR * This,
            /* [string][in] */ BSTR szDevice,
            /* [in] */ LONG dwSize,
            /* [size_is][out] */ LONG __RPC_FAR *lpdwData,
            /* [retval][out] */ LONG __RPC_FAR *lplReturnCode);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *WriteDeviceBlock )( 
            IActQJ71E71TCP __RPC_FAR * This,
            /* [string][in] */ BSTR szDevice,
            /* [in] */ LONG dwSize,
            /* [size_is][in] */ LONG __RPC_FAR *lpdwData,
            /* [retval][out] */ LONG __RPC_FAR *lplReturnCode);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *ReadDeviceRandom )( 
            IActQJ71E71TCP __RPC_FAR * This,
            /* [string][in] */ BSTR szDeviceList,
            /* [in] */ LONG dwSize,
            /* [size_is][out] */ LONG __RPC_FAR *lpdwData,
            /* [retval][out] */ LONG __RPC_FAR *lplReturnCode);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *WriteDeviceRandom )( 
            IActQJ71E71TCP __RPC_FAR * This,
            /* [string][in] */ BSTR szDeviceList,
            /* [in] */ LONG dwSize,
            /* [size_is][in] */ LONG __RPC_FAR *lpdwData,
            /* [retval][out] */ LONG __RPC_FAR *lplReturnCode);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *ReadBuffer )( 
            IActQJ71E71TCP __RPC_FAR * This,
            /* [in] */ LONG lStartIO,
            /* [in] */ LONG lAddress,
            /* [in] */ LONG lReadSize,
            /* [out] */ SHORT __RPC_FAR *lpwData,
            /* [retval][out] */ LONG __RPC_FAR *lplReturnCode);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *WriteBuffer )( 
            IActQJ71E71TCP __RPC_FAR * This,
            /* [in] */ LONG lStartIO,
            /* [in] */ LONG lAddress,
            /* [in] */ LONG lWriteSize,
            /* [out] */ SHORT __RPC_FAR *lpwData,
            /* [retval][out] */ LONG __RPC_FAR *lplReturnCode);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetClockData )( 
            IActQJ71E71TCP __RPC_FAR * This,
            /* [out] */ SHORT __RPC_FAR *lpwYear,
            /* [out] */ SHORT __RPC_FAR *lpwMonth,
            /* [out] */ SHORT __RPC_FAR *lpwDay,
            /* [out] */ SHORT __RPC_FAR *lpwDayOfWeek,
            /* [out] */ SHORT __RPC_FAR *lpwHour,
            /* [out] */ SHORT __RPC_FAR *lpwMinute,
            /* [out] */ SHORT __RPC_FAR *lpwSecond,
            /* [retval][out] */ LONG __RPC_FAR *lplReturnCode);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *SetClockData )( 
            IActQJ71E71TCP __RPC_FAR * This,
            /* [in] */ SHORT wYear,
            /* [in] */ SHORT wMonth,
            /* [in] */ SHORT wDay,
            /* [in] */ SHORT wDayOfWeek,
            /* [in] */ SHORT wHour,
            /* [in] */ SHORT wMinute,
            /* [in] */ SHORT wSecond,
            /* [retval][out] */ LONG __RPC_FAR *lplReturnCode);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *SetDevice )( 
            IActQJ71E71TCP __RPC_FAR * This,
            /* [string][in] */ BSTR szDevice,
            /* [in] */ LONG dwData,
            /* [retval][out] */ LONG __RPC_FAR *lplReturnCode);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *SetCpuStatus )( 
            IActQJ71E71TCP __RPC_FAR * This,
            /* [in] */ LONG lOperation,
            /* [retval][out] */ LONG __RPC_FAR *lplReturnCode);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetCpuType )( 
            IActQJ71E71TCP __RPC_FAR * This,
            /* [string][out] */ BSTR __RPC_FAR *szCpuName,
            LONG __RPC_FAR *lplCpuType,
            /* [retval][out] */ LONG __RPC_FAR *lplReturnCode);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_ActNetworkNumber )( 
            IActQJ71E71TCP __RPC_FAR * This,
            /* [retval][out] */ long __RPC_FAR *pVal);
        
        /* [helpstring][id][propput] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *put_ActNetworkNumber )( 
            IActQJ71E71TCP __RPC_FAR * This,
            /* [in] */ long newVal);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_ActStationNumber )( 
            IActQJ71E71TCP __RPC_FAR * This,
            /* [retval][out] */ long __RPC_FAR *pVal);
        
        /* [helpstring][id][propput] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *put_ActStationNumber )( 
            IActQJ71E71TCP __RPC_FAR * This,
            /* [in] */ long newVal);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_ActUnitNumber )( 
            IActQJ71E71TCP __RPC_FAR * This,
            /* [retval][out] */ long __RPC_FAR *pVal);
        
        /* [helpstring][id][propput] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *put_ActUnitNumber )( 
            IActQJ71E71TCP __RPC_FAR * This,
            /* [in] */ long newVal);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_ActConnectUnitNumber )( 
            IActQJ71E71TCP __RPC_FAR * This,
            /* [retval][out] */ long __RPC_FAR *pVal);
        
        /* [helpstring][id][propput] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *put_ActConnectUnitNumber )( 
            IActQJ71E71TCP __RPC_FAR * This,
            /* [in] */ long newVal);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_ActIONumber )( 
            IActQJ71E71TCP __RPC_FAR * This,
            /* [retval][out] */ long __RPC_FAR *pVal);
        
        /* [helpstring][id][propput] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *put_ActIONumber )( 
            IActQJ71E71TCP __RPC_FAR * This,
            /* [in] */ long newVal);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_ActCpuType )( 
            IActQJ71E71TCP __RPC_FAR * This,
            /* [retval][out] */ long __RPC_FAR *pVal);
        
        /* [helpstring][id][propput] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *put_ActCpuType )( 
            IActQJ71E71TCP __RPC_FAR * This,
            /* [in] */ long newVal);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_ActHostAddress )( 
            IActQJ71E71TCP __RPC_FAR * This,
            /* [retval][string][out] */ BSTR __RPC_FAR *pVal);
        
        /* [helpstring][id][propput] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *put_ActHostAddress )( 
            IActQJ71E71TCP __RPC_FAR * This,
            /* [string][in] */ BSTR newVal);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_ActTimeOut )( 
            IActQJ71E71TCP __RPC_FAR * This,
            /* [retval][out] */ long __RPC_FAR *pVal);
        
        /* [helpstring][id][propput] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *put_ActTimeOut )( 
            IActQJ71E71TCP __RPC_FAR * This,
            /* [in] */ long newVal);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_ActSourceNetworkNumber )( 
            IActQJ71E71TCP __RPC_FAR * This,
            /* [retval][out] */ long __RPC_FAR *pVal);
        
        /* [helpstring][id][propput] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *put_ActSourceNetworkNumber )( 
            IActQJ71E71TCP __RPC_FAR * This,
            /* [in] */ long newVal);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_ActSourceStationNumber )( 
            IActQJ71E71TCP __RPC_FAR * This,
            /* [retval][out] */ long __RPC_FAR *pVal);
        
        /* [helpstring][id][propput] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *put_ActSourceStationNumber )( 
            IActQJ71E71TCP __RPC_FAR * This,
            /* [in] */ long newVal);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_ActDestinationIONumber )( 
            IActQJ71E71TCP __RPC_FAR * This,
            /* [retval][out] */ long __RPC_FAR *pVal);
        
        /* [helpstring][id][propput] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *put_ActDestinationIONumber )( 
            IActQJ71E71TCP __RPC_FAR * This,
            /* [in] */ long newVal);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_ActMultiDropChannelNumber )( 
            IActQJ71E71TCP __RPC_FAR * This,
            /* [retval][out] */ long __RPC_FAR *pVal);
        
        /* [helpstring][id][propput] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *put_ActMultiDropChannelNumber )( 
            IActQJ71E71TCP __RPC_FAR * This,
            /* [in] */ long newVal);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_ActThroughNetworkType )( 
            IActQJ71E71TCP __RPC_FAR * This,
            /* [retval][out] */ long __RPC_FAR *pVal);
        
        /* [helpstring][id][propput] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *put_ActThroughNetworkType )( 
            IActQJ71E71TCP __RPC_FAR * This,
            /* [in] */ long newVal);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_ActDidPropertyBit )( 
            IActQJ71E71TCP __RPC_FAR * This,
            /* [retval][out] */ long __RPC_FAR *pVal);
        
        /* [helpstring][id][propput] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *put_ActDidPropertyBit )( 
            IActQJ71E71TCP __RPC_FAR * This,
            /* [in] */ long newVal);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_ActDsidPropertyBit )( 
            IActQJ71E71TCP __RPC_FAR * This,
            /* [retval][out] */ long __RPC_FAR *pVal);
        
        /* [helpstring][id][propput] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *put_ActDsidPropertyBit )( 
            IActQJ71E71TCP __RPC_FAR * This,
            /* [in] */ long newVal);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetDevice )( 
            IActQJ71E71TCP __RPC_FAR * This,
            /* [string][in] */ BSTR szDevice,
            /* [out] */ LONG __RPC_FAR *lpdwData,
            /* [retval][out] */ LONG __RPC_FAR *lplReturnCode);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *CheckDeviceString )( 
            IActQJ71E71TCP __RPC_FAR * This,
            /* [in] */ BSTR szDevice,
            /* [in] */ LONG lCheckType,
            /* [in] */ LONG lSize,
            /* [out] */ LONG __RPC_FAR *lplDeviceType,
            /* [string][out] */ BSTR __RPC_FAR *lpszDeviceName,
            /* [out] */ LONG __RPC_FAR *lplDeviceNumber,
            /* [out] */ LONG __RPC_FAR *lplDeviceRadix,
            /* [retval][out] */ LONG __RPC_FAR *lplReturnCode);
        
        END_INTERFACE
    } IActQJ71E71TCPVtbl;

    interface IActQJ71E71TCP
    {
        CONST_VTBL struct IActQJ71E71TCPVtbl __RPC_FAR *lpVtbl;
    };

    

#ifdef COBJMACROS


#define IActQJ71E71TCP_QueryInterface(This,riid,ppvObject)	\
    (This)->lpVtbl -> QueryInterface(This,riid,ppvObject)

#define IActQJ71E71TCP_AddRef(This)	\
    (This)->lpVtbl -> AddRef(This)

#define IActQJ71E71TCP_Release(This)	\
    (This)->lpVtbl -> Release(This)


#define IActQJ71E71TCP_GetTypeInfoCount(This,pctinfo)	\
    (This)->lpVtbl -> GetTypeInfoCount(This,pctinfo)

#define IActQJ71E71TCP_GetTypeInfo(This,iTInfo,lcid,ppTInfo)	\
    (This)->lpVtbl -> GetTypeInfo(This,iTInfo,lcid,ppTInfo)

#define IActQJ71E71TCP_GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)	\
    (This)->lpVtbl -> GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)

#define IActQJ71E71TCP_Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)	\
    (This)->lpVtbl -> Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)


#define IActQJ71E71TCP_Open(This,lplReturnCode)	\
    (This)->lpVtbl -> Open(This,lplReturnCode)

#define IActQJ71E71TCP_Close(This,lplReturnCode)	\
    (This)->lpVtbl -> Close(This,lplReturnCode)

#define IActQJ71E71TCP_ReadDeviceBlock(This,szDevice,dwSize,lpdwData,lplReturnCode)	\
    (This)->lpVtbl -> ReadDeviceBlock(This,szDevice,dwSize,lpdwData,lplReturnCode)

#define IActQJ71E71TCP_WriteDeviceBlock(This,szDevice,dwSize,lpdwData,lplReturnCode)	\
    (This)->lpVtbl -> WriteDeviceBlock(This,szDevice,dwSize,lpdwData,lplReturnCode)

#define IActQJ71E71TCP_ReadDeviceRandom(This,szDeviceList,dwSize,lpdwData,lplReturnCode)	\
    (This)->lpVtbl -> ReadDeviceRandom(This,szDeviceList,dwSize,lpdwData,lplReturnCode)

#define IActQJ71E71TCP_WriteDeviceRandom(This,szDeviceList,dwSize,lpdwData,lplReturnCode)	\
    (This)->lpVtbl -> WriteDeviceRandom(This,szDeviceList,dwSize,lpdwData,lplReturnCode)

#define IActQJ71E71TCP_ReadBuffer(This,lStartIO,lAddress,lReadSize,lpwData,lplReturnCode)	\
    (This)->lpVtbl -> ReadBuffer(This,lStartIO,lAddress,lReadSize,lpwData,lplReturnCode)

#define IActQJ71E71TCP_WriteBuffer(This,lStartIO,lAddress,lWriteSize,lpwData,lplReturnCode)	\
    (This)->lpVtbl -> WriteBuffer(This,lStartIO,lAddress,lWriteSize,lpwData,lplReturnCode)

#define IActQJ71E71TCP_GetClockData(This,lpwYear,lpwMonth,lpwDay,lpwDayOfWeek,lpwHour,lpwMinute,lpwSecond,lplReturnCode)	\
    (This)->lpVtbl -> GetClockData(This,lpwYear,lpwMonth,lpwDay,lpwDayOfWeek,lpwHour,lpwMinute,lpwSecond,lplReturnCode)

#define IActQJ71E71TCP_SetClockData(This,wYear,wMonth,wDay,wDayOfWeek,wHour,wMinute,wSecond,lplReturnCode)	\
    (This)->lpVtbl -> SetClockData(This,wYear,wMonth,wDay,wDayOfWeek,wHour,wMinute,wSecond,lplReturnCode)

#define IActQJ71E71TCP_SetDevice(This,szDevice,dwData,lplReturnCode)	\
    (This)->lpVtbl -> SetDevice(This,szDevice,dwData,lplReturnCode)

#define IActQJ71E71TCP_SetCpuStatus(This,lOperation,lplReturnCode)	\
    (This)->lpVtbl -> SetCpuStatus(This,lOperation,lplReturnCode)

#define IActQJ71E71TCP_GetCpuType(This,szCpuName,lplCpuType,lplReturnCode)	\
    (This)->lpVtbl -> GetCpuType(This,szCpuName,lplCpuType,lplReturnCode)

#define IActQJ71E71TCP_get_ActNetworkNumber(This,pVal)	\
    (This)->lpVtbl -> get_ActNetworkNumber(This,pVal)

#define IActQJ71E71TCP_put_ActNetworkNumber(This,newVal)	\
    (This)->lpVtbl -> put_ActNetworkNumber(This,newVal)

#define IActQJ71E71TCP_get_ActStationNumber(This,pVal)	\
    (This)->lpVtbl -> get_ActStationNumber(This,pVal)

#define IActQJ71E71TCP_put_ActStationNumber(This,newVal)	\
    (This)->lpVtbl -> put_ActStationNumber(This,newVal)

#define IActQJ71E71TCP_get_ActUnitNumber(This,pVal)	\
    (This)->lpVtbl -> get_ActUnitNumber(This,pVal)

#define IActQJ71E71TCP_put_ActUnitNumber(This,newVal)	\
    (This)->lpVtbl -> put_ActUnitNumber(This,newVal)

#define IActQJ71E71TCP_get_ActConnectUnitNumber(This,pVal)	\
    (This)->lpVtbl -> get_ActConnectUnitNumber(This,pVal)

#define IActQJ71E71TCP_put_ActConnectUnitNumber(This,newVal)	\
    (This)->lpVtbl -> put_ActConnectUnitNumber(This,newVal)

#define IActQJ71E71TCP_get_ActIONumber(This,pVal)	\
    (This)->lpVtbl -> get_ActIONumber(This,pVal)

#define IActQJ71E71TCP_put_ActIONumber(This,newVal)	\
    (This)->lpVtbl -> put_ActIONumber(This,newVal)

#define IActQJ71E71TCP_get_ActCpuType(This,pVal)	\
    (This)->lpVtbl -> get_ActCpuType(This,pVal)

#define IActQJ71E71TCP_put_ActCpuType(This,newVal)	\
    (This)->lpVtbl -> put_ActCpuType(This,newVal)

#define IActQJ71E71TCP_get_ActHostAddress(This,pVal)	\
    (This)->lpVtbl -> get_ActHostAddress(This,pVal)

#define IActQJ71E71TCP_put_ActHostAddress(This,newVal)	\
    (This)->lpVtbl -> put_ActHostAddress(This,newVal)

#define IActQJ71E71TCP_get_ActTimeOut(This,pVal)	\
    (This)->lpVtbl -> get_ActTimeOut(This,pVal)

#define IActQJ71E71TCP_put_ActTimeOut(This,newVal)	\
    (This)->lpVtbl -> put_ActTimeOut(This,newVal)

#define IActQJ71E71TCP_get_ActSourceNetworkNumber(This,pVal)	\
    (This)->lpVtbl -> get_ActSourceNetworkNumber(This,pVal)

#define IActQJ71E71TCP_put_ActSourceNetworkNumber(This,newVal)	\
    (This)->lpVtbl -> put_ActSourceNetworkNumber(This,newVal)

#define IActQJ71E71TCP_get_ActSourceStationNumber(This,pVal)	\
    (This)->lpVtbl -> get_ActSourceStationNumber(This,pVal)

#define IActQJ71E71TCP_put_ActSourceStationNumber(This,newVal)	\
    (This)->lpVtbl -> put_ActSourceStationNumber(This,newVal)

#define IActQJ71E71TCP_get_ActDestinationIONumber(This,pVal)	\
    (This)->lpVtbl -> get_ActDestinationIONumber(This,pVal)

#define IActQJ71E71TCP_put_ActDestinationIONumber(This,newVal)	\
    (This)->lpVtbl -> put_ActDestinationIONumber(This,newVal)

#define IActQJ71E71TCP_get_ActMultiDropChannelNumber(This,pVal)	\
    (This)->lpVtbl -> get_ActMultiDropChannelNumber(This,pVal)

#define IActQJ71E71TCP_put_ActMultiDropChannelNumber(This,newVal)	\
    (This)->lpVtbl -> put_ActMultiDropChannelNumber(This,newVal)

#define IActQJ71E71TCP_get_ActThroughNetworkType(This,pVal)	\
    (This)->lpVtbl -> get_ActThroughNetworkType(This,pVal)

#define IActQJ71E71TCP_put_ActThroughNetworkType(This,newVal)	\
    (This)->lpVtbl -> put_ActThroughNetworkType(This,newVal)

#define IActQJ71E71TCP_get_ActDidPropertyBit(This,pVal)	\
    (This)->lpVtbl -> get_ActDidPropertyBit(This,pVal)

#define IActQJ71E71TCP_put_ActDidPropertyBit(This,newVal)	\
    (This)->lpVtbl -> put_ActDidPropertyBit(This,newVal)

#define IActQJ71E71TCP_get_ActDsidPropertyBit(This,pVal)	\
    (This)->lpVtbl -> get_ActDsidPropertyBit(This,pVal)

#define IActQJ71E71TCP_put_ActDsidPropertyBit(This,newVal)	\
    (This)->lpVtbl -> put_ActDsidPropertyBit(This,newVal)

#define IActQJ71E71TCP_GetDevice(This,szDevice,lpdwData,lplReturnCode)	\
    (This)->lpVtbl -> GetDevice(This,szDevice,lpdwData,lplReturnCode)

#define IActQJ71E71TCP_CheckDeviceString(This,szDevice,lCheckType,lSize,lplDeviceType,lpszDeviceName,lplDeviceNumber,lplDeviceRadix,lplReturnCode)	\
    (This)->lpVtbl -> CheckDeviceString(This,szDevice,lCheckType,lSize,lplDeviceType,lpszDeviceName,lplDeviceNumber,lplDeviceRadix,lplReturnCode)

#endif /* COBJMACROS */


#endif 	/* C style interface */



/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE IActQJ71E71TCP_Open_Proxy( 
    IActQJ71E71TCP __RPC_FAR * This,
    /* [retval][out] */ LONG __RPC_FAR *lplReturnCode);


void __RPC_STUB IActQJ71E71TCP_Open_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE IActQJ71E71TCP_Close_Proxy( 
    IActQJ71E71TCP __RPC_FAR * This,
    /* [retval][out] */ LONG __RPC_FAR *lplReturnCode);


void __RPC_STUB IActQJ71E71TCP_Close_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE IActQJ71E71TCP_ReadDeviceBlock_Proxy( 
    IActQJ71E71TCP __RPC_FAR * This,
    /* [string][in] */ BSTR szDevice,
    /* [in] */ LONG dwSize,
    /* [size_is][out] */ LONG __RPC_FAR *lpdwData,
    /* [retval][out] */ LONG __RPC_FAR *lplReturnCode);


void __RPC_STUB IActQJ71E71TCP_ReadDeviceBlock_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE IActQJ71E71TCP_WriteDeviceBlock_Proxy( 
    IActQJ71E71TCP __RPC_FAR * This,
    /* [string][in] */ BSTR szDevice,
    /* [in] */ LONG dwSize,
    /* [size_is][in] */ LONG __RPC_FAR *lpdwData,
    /* [retval][out] */ LONG __RPC_FAR *lplReturnCode);


void __RPC_STUB IActQJ71E71TCP_WriteDeviceBlock_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE IActQJ71E71TCP_ReadDeviceRandom_Proxy( 
    IActQJ71E71TCP __RPC_FAR * This,
    /* [string][in] */ BSTR szDeviceList,
    /* [in] */ LONG dwSize,
    /* [size_is][out] */ LONG __RPC_FAR *lpdwData,
    /* [retval][out] */ LONG __RPC_FAR *lplReturnCode);


void __RPC_STUB IActQJ71E71TCP_ReadDeviceRandom_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE IActQJ71E71TCP_WriteDeviceRandom_Proxy( 
    IActQJ71E71TCP __RPC_FAR * This,
    /* [string][in] */ BSTR szDeviceList,
    /* [in] */ LONG dwSize,
    /* [size_is][in] */ LONG __RPC_FAR *lpdwData,
    /* [retval][out] */ LONG __RPC_FAR *lplReturnCode);


void __RPC_STUB IActQJ71E71TCP_WriteDeviceRandom_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE IActQJ71E71TCP_ReadBuffer_Proxy( 
    IActQJ71E71TCP __RPC_FAR * This,
    /* [in] */ LONG lStartIO,
    /* [in] */ LONG lAddress,
    /* [in] */ LONG lReadSize,
    /* [out] */ SHORT __RPC_FAR *lpwData,
    /* [retval][out] */ LONG __RPC_FAR *lplReturnCode);


void __RPC_STUB IActQJ71E71TCP_ReadBuffer_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE IActQJ71E71TCP_WriteBuffer_Proxy( 
    IActQJ71E71TCP __RPC_FAR * This,
    /* [in] */ LONG lStartIO,
    /* [in] */ LONG lAddress,
    /* [in] */ LONG lWriteSize,
    /* [out] */ SHORT __RPC_FAR *lpwData,
    /* [retval][out] */ LONG __RPC_FAR *lplReturnCode);


void __RPC_STUB IActQJ71E71TCP_WriteBuffer_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE IActQJ71E71TCP_GetClockData_Proxy( 
    IActQJ71E71TCP __RPC_FAR * This,
    /* [out] */ SHORT __RPC_FAR *lpwYear,
    /* [out] */ SHORT __RPC_FAR *lpwMonth,
    /* [out] */ SHORT __RPC_FAR *lpwDay,
    /* [out] */ SHORT __RPC_FAR *lpwDayOfWeek,
    /* [out] */ SHORT __RPC_FAR *lpwHour,
    /* [out] */ SHORT __RPC_FAR *lpwMinute,
    /* [out] */ SHORT __RPC_FAR *lpwSecond,
    /* [retval][out] */ LONG __RPC_FAR *lplReturnCode);


void __RPC_STUB IActQJ71E71TCP_GetClockData_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE IActQJ71E71TCP_SetClockData_Proxy( 
    IActQJ71E71TCP __RPC_FAR * This,
    /* [in] */ SHORT wYear,
    /* [in] */ SHORT wMonth,
    /* [in] */ SHORT wDay,
    /* [in] */ SHORT wDayOfWeek,
    /* [in] */ SHORT wHour,
    /* [in] */ SHORT wMinute,
    /* [in] */ SHORT wSecond,
    /* [retval][out] */ LONG __RPC_FAR *lplReturnCode);


void __RPC_STUB IActQJ71E71TCP_SetClockData_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE IActQJ71E71TCP_SetDevice_Proxy( 
    IActQJ71E71TCP __RPC_FAR * This,
    /* [string][in] */ BSTR szDevice,
    /* [in] */ LONG dwData,
    /* [retval][out] */ LONG __RPC_FAR *lplReturnCode);


void __RPC_STUB IActQJ71E71TCP_SetDevice_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE IActQJ71E71TCP_SetCpuStatus_Proxy( 
    IActQJ71E71TCP __RPC_FAR * This,
    /* [in] */ LONG lOperation,
    /* [retval][out] */ LONG __RPC_FAR *lplReturnCode);


void __RPC_STUB IActQJ71E71TCP_SetCpuStatus_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE IActQJ71E71TCP_GetCpuType_Proxy( 
    IActQJ71E71TCP __RPC_FAR * This,
    /* [string][out] */ BSTR __RPC_FAR *szCpuName,
    LONG __RPC_FAR *lplCpuType,
    /* [retval][out] */ LONG __RPC_FAR *lplReturnCode);


void __RPC_STUB IActQJ71E71TCP_GetCpuType_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE IActQJ71E71TCP_get_ActNetworkNumber_Proxy( 
    IActQJ71E71TCP __RPC_FAR * This,
    /* [retval][out] */ long __RPC_FAR *pVal);


void __RPC_STUB IActQJ71E71TCP_get_ActNetworkNumber_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE IActQJ71E71TCP_put_ActNetworkNumber_Proxy( 
    IActQJ71E71TCP __RPC_FAR * This,
    /* [in] */ long newVal);


void __RPC_STUB IActQJ71E71TCP_put_ActNetworkNumber_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE IActQJ71E71TCP_get_ActStationNumber_Proxy( 
    IActQJ71E71TCP __RPC_FAR * This,
    /* [retval][out] */ long __RPC_FAR *pVal);


void __RPC_STUB IActQJ71E71TCP_get_ActStationNumber_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE IActQJ71E71TCP_put_ActStationNumber_Proxy( 
    IActQJ71E71TCP __RPC_FAR * This,
    /* [in] */ long newVal);


void __RPC_STUB IActQJ71E71TCP_put_ActStationNumber_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE IActQJ71E71TCP_get_ActUnitNumber_Proxy( 
    IActQJ71E71TCP __RPC_FAR * This,
    /* [retval][out] */ long __RPC_FAR *pVal);


void __RPC_STUB IActQJ71E71TCP_get_ActUnitNumber_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE IActQJ71E71TCP_put_ActUnitNumber_Proxy( 
    IActQJ71E71TCP __RPC_FAR * This,
    /* [in] */ long newVal);


void __RPC_STUB IActQJ71E71TCP_put_ActUnitNumber_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE IActQJ71E71TCP_get_ActConnectUnitNumber_Proxy( 
    IActQJ71E71TCP __RPC_FAR * This,
    /* [retval][out] */ long __RPC_FAR *pVal);


void __RPC_STUB IActQJ71E71TCP_get_ActConnectUnitNumber_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE IActQJ71E71TCP_put_ActConnectUnitNumber_Proxy( 
    IActQJ71E71TCP __RPC_FAR * This,
    /* [in] */ long newVal);


void __RPC_STUB IActQJ71E71TCP_put_ActConnectUnitNumber_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE IActQJ71E71TCP_get_ActIONumber_Proxy( 
    IActQJ71E71TCP __RPC_FAR * This,
    /* [retval][out] */ long __RPC_FAR *pVal);


void __RPC_STUB IActQJ71E71TCP_get_ActIONumber_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE IActQJ71E71TCP_put_ActIONumber_Proxy( 
    IActQJ71E71TCP __RPC_FAR * This,
    /* [in] */ long newVal);


void __RPC_STUB IActQJ71E71TCP_put_ActIONumber_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE IActQJ71E71TCP_get_ActCpuType_Proxy( 
    IActQJ71E71TCP __RPC_FAR * This,
    /* [retval][out] */ long __RPC_FAR *pVal);


void __RPC_STUB IActQJ71E71TCP_get_ActCpuType_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE IActQJ71E71TCP_put_ActCpuType_Proxy( 
    IActQJ71E71TCP __RPC_FAR * This,
    /* [in] */ long newVal);


void __RPC_STUB IActQJ71E71TCP_put_ActCpuType_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE IActQJ71E71TCP_get_ActHostAddress_Proxy( 
    IActQJ71E71TCP __RPC_FAR * This,
    /* [retval][string][out] */ BSTR __RPC_FAR *pVal);


void __RPC_STUB IActQJ71E71TCP_get_ActHostAddress_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE IActQJ71E71TCP_put_ActHostAddress_Proxy( 
    IActQJ71E71TCP __RPC_FAR * This,
    /* [string][in] */ BSTR newVal);


void __RPC_STUB IActQJ71E71TCP_put_ActHostAddress_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE IActQJ71E71TCP_get_ActTimeOut_Proxy( 
    IActQJ71E71TCP __RPC_FAR * This,
    /* [retval][out] */ long __RPC_FAR *pVal);


void __RPC_STUB IActQJ71E71TCP_get_ActTimeOut_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE IActQJ71E71TCP_put_ActTimeOut_Proxy( 
    IActQJ71E71TCP __RPC_FAR * This,
    /* [in] */ long newVal);


void __RPC_STUB IActQJ71E71TCP_put_ActTimeOut_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE IActQJ71E71TCP_get_ActSourceNetworkNumber_Proxy( 
    IActQJ71E71TCP __RPC_FAR * This,
    /* [retval][out] */ long __RPC_FAR *pVal);


void __RPC_STUB IActQJ71E71TCP_get_ActSourceNetworkNumber_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE IActQJ71E71TCP_put_ActSourceNetworkNumber_Proxy( 
    IActQJ71E71TCP __RPC_FAR * This,
    /* [in] */ long newVal);


void __RPC_STUB IActQJ71E71TCP_put_ActSourceNetworkNumber_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE IActQJ71E71TCP_get_ActSourceStationNumber_Proxy( 
    IActQJ71E71TCP __RPC_FAR * This,
    /* [retval][out] */ long __RPC_FAR *pVal);


void __RPC_STUB IActQJ71E71TCP_get_ActSourceStationNumber_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE IActQJ71E71TCP_put_ActSourceStationNumber_Proxy( 
    IActQJ71E71TCP __RPC_FAR * This,
    /* [in] */ long newVal);


void __RPC_STUB IActQJ71E71TCP_put_ActSourceStationNumber_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE IActQJ71E71TCP_get_ActDestinationIONumber_Proxy( 
    IActQJ71E71TCP __RPC_FAR * This,
    /* [retval][out] */ long __RPC_FAR *pVal);


void __RPC_STUB IActQJ71E71TCP_get_ActDestinationIONumber_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE IActQJ71E71TCP_put_ActDestinationIONumber_Proxy( 
    IActQJ71E71TCP __RPC_FAR * This,
    /* [in] */ long newVal);


void __RPC_STUB IActQJ71E71TCP_put_ActDestinationIONumber_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE IActQJ71E71TCP_get_ActMultiDropChannelNumber_Proxy( 
    IActQJ71E71TCP __RPC_FAR * This,
    /* [retval][out] */ long __RPC_FAR *pVal);


void __RPC_STUB IActQJ71E71TCP_get_ActMultiDropChannelNumber_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE IActQJ71E71TCP_put_ActMultiDropChannelNumber_Proxy( 
    IActQJ71E71TCP __RPC_FAR * This,
    /* [in] */ long newVal);


void __RPC_STUB IActQJ71E71TCP_put_ActMultiDropChannelNumber_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE IActQJ71E71TCP_get_ActThroughNetworkType_Proxy( 
    IActQJ71E71TCP __RPC_FAR * This,
    /* [retval][out] */ long __RPC_FAR *pVal);


void __RPC_STUB IActQJ71E71TCP_get_ActThroughNetworkType_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE IActQJ71E71TCP_put_ActThroughNetworkType_Proxy( 
    IActQJ71E71TCP __RPC_FAR * This,
    /* [in] */ long newVal);


void __RPC_STUB IActQJ71E71TCP_put_ActThroughNetworkType_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE IActQJ71E71TCP_get_ActDidPropertyBit_Proxy( 
    IActQJ71E71TCP __RPC_FAR * This,
    /* [retval][out] */ long __RPC_FAR *pVal);


void __RPC_STUB IActQJ71E71TCP_get_ActDidPropertyBit_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE IActQJ71E71TCP_put_ActDidPropertyBit_Proxy( 
    IActQJ71E71TCP __RPC_FAR * This,
    /* [in] */ long newVal);


void __RPC_STUB IActQJ71E71TCP_put_ActDidPropertyBit_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE IActQJ71E71TCP_get_ActDsidPropertyBit_Proxy( 
    IActQJ71E71TCP __RPC_FAR * This,
    /* [retval][out] */ long __RPC_FAR *pVal);


void __RPC_STUB IActQJ71E71TCP_get_ActDsidPropertyBit_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE IActQJ71E71TCP_put_ActDsidPropertyBit_Proxy( 
    IActQJ71E71TCP __RPC_FAR * This,
    /* [in] */ long newVal);


void __RPC_STUB IActQJ71E71TCP_put_ActDsidPropertyBit_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE IActQJ71E71TCP_GetDevice_Proxy( 
    IActQJ71E71TCP __RPC_FAR * This,
    /* [string][in] */ BSTR szDevice,
    /* [out] */ LONG __RPC_FAR *lpdwData,
    /* [retval][out] */ LONG __RPC_FAR *lplReturnCode);


void __RPC_STUB IActQJ71E71TCP_GetDevice_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE IActQJ71E71TCP_CheckDeviceString_Proxy( 
    IActQJ71E71TCP __RPC_FAR * This,
    /* [in] */ BSTR szDevice,
    /* [in] */ LONG lCheckType,
    /* [in] */ LONG lSize,
    /* [out] */ LONG __RPC_FAR *lplDeviceType,
    /* [string][out] */ BSTR __RPC_FAR *lpszDeviceName,
    /* [out] */ LONG __RPC_FAR *lplDeviceNumber,
    /* [out] */ LONG __RPC_FAR *lplDeviceRadix,
    /* [retval][out] */ LONG __RPC_FAR *lplReturnCode);


void __RPC_STUB IActQJ71E71TCP_CheckDeviceString_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);



#endif 	/* __IActQJ71E71TCP_INTERFACE_DEFINED__ */



#ifndef __ACTETHERLib_LIBRARY_DEFINED__
#define __ACTETHERLib_LIBRARY_DEFINED__

/* library ACTETHERLib */
/* [helpstring][version][uuid] */ 


EXTERN_C const IID LIBID_ACTETHERLib;

#ifndef ___IActQJ71E71TCPEvents_DISPINTERFACE_DEFINED__
#define ___IActQJ71E71TCPEvents_DISPINTERFACE_DEFINED__

/* dispinterface _IActQJ71E71TCPEvents */
/* [helpstring][uuid] */ 


EXTERN_C const IID DIID__IActQJ71E71TCPEvents;

#if defined(__cplusplus) && !defined(CINTERFACE)

    MIDL_INTERFACE("AFEA5513-AE9C-11D3-83AE-00A024BDBF2B")
    _IActQJ71E71TCPEvents : public IDispatch
    {
    };
    
#else 	/* C style interface */

    typedef struct _IActQJ71E71TCPEventsVtbl
    {
        BEGIN_INTERFACE
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *QueryInterface )( 
            _IActQJ71E71TCPEvents __RPC_FAR * This,
            /* [in] */ REFIID riid,
            /* [iid_is][out] */ void __RPC_FAR *__RPC_FAR *ppvObject);
        
        ULONG ( STDMETHODCALLTYPE __RPC_FAR *AddRef )( 
            _IActQJ71E71TCPEvents __RPC_FAR * This);
        
        ULONG ( STDMETHODCALLTYPE __RPC_FAR *Release )( 
            _IActQJ71E71TCPEvents __RPC_FAR * This);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetTypeInfoCount )( 
            _IActQJ71E71TCPEvents __RPC_FAR * This,
            /* [out] */ UINT __RPC_FAR *pctinfo);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetTypeInfo )( 
            _IActQJ71E71TCPEvents __RPC_FAR * This,
            /* [in] */ UINT iTInfo,
            /* [in] */ LCID lcid,
            /* [out] */ ITypeInfo __RPC_FAR *__RPC_FAR *ppTInfo);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetIDsOfNames )( 
            _IActQJ71E71TCPEvents __RPC_FAR * This,
            /* [in] */ REFIID riid,
            /* [size_is][in] */ LPOLESTR __RPC_FAR *rgszNames,
            /* [in] */ UINT cNames,
            /* [in] */ LCID lcid,
            /* [size_is][out] */ DISPID __RPC_FAR *rgDispId);
        
        /* [local] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *Invoke )( 
            _IActQJ71E71TCPEvents __RPC_FAR * This,
            /* [in] */ DISPID dispIdMember,
            /* [in] */ REFIID riid,
            /* [in] */ LCID lcid,
            /* [in] */ WORD wFlags,
            /* [out][in] */ DISPPARAMS __RPC_FAR *pDispParams,
            /* [out] */ VARIANT __RPC_FAR *pVarResult,
            /* [out] */ EXCEPINFO __RPC_FAR *pExcepInfo,
            /* [out] */ UINT __RPC_FAR *puArgErr);
        
        END_INTERFACE
    } _IActQJ71E71TCPEventsVtbl;

    interface _IActQJ71E71TCPEvents
    {
        CONST_VTBL struct _IActQJ71E71TCPEventsVtbl __RPC_FAR *lpVtbl;
    };

    

#ifdef COBJMACROS


#define _IActQJ71E71TCPEvents_QueryInterface(This,riid,ppvObject)	\
    (This)->lpVtbl -> QueryInterface(This,riid,ppvObject)

#define _IActQJ71E71TCPEvents_AddRef(This)	\
    (This)->lpVtbl -> AddRef(This)

#define _IActQJ71E71TCPEvents_Release(This)	\
    (This)->lpVtbl -> Release(This)


#define _IActQJ71E71TCPEvents_GetTypeInfoCount(This,pctinfo)	\
    (This)->lpVtbl -> GetTypeInfoCount(This,pctinfo)

#define _IActQJ71E71TCPEvents_GetTypeInfo(This,iTInfo,lcid,ppTInfo)	\
    (This)->lpVtbl -> GetTypeInfo(This,iTInfo,lcid,ppTInfo)

#define _IActQJ71E71TCPEvents_GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)	\
    (This)->lpVtbl -> GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)

#define _IActQJ71E71TCPEvents_Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)	\
    (This)->lpVtbl -> Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)

#endif /* COBJMACROS */


#endif 	/* C style interface */


#endif 	/* ___IActQJ71E71TCPEvents_DISPINTERFACE_DEFINED__ */


#ifndef __IActQJ71E71UDP_INTERFACE_DEFINED__
#define __IActQJ71E71UDP_INTERFACE_DEFINED__

/* interface IActQJ71E71UDP */
/* [unique][helpstring][dual][uuid][object] */ 


EXTERN_C const IID IID_IActQJ71E71UDP;

#if defined(__cplusplus) && !defined(CINTERFACE)
    
    MIDL_INTERFACE("AFEA5514-AE9C-11D3-83AE-00A024BDBF2B")
    IActQJ71E71UDP : public IDispatch
    {
    public:
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE Open( 
            /* [retval][out] */ LONG __RPC_FAR *lplReturnCode) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE Close( 
            /* [retval][out] */ LONG __RPC_FAR *lplReturnCode) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE ReadDeviceBlock( 
            /* [string][in] */ BSTR szDevice,
            /* [in] */ LONG dwSize,
            /* [size_is][out] */ LONG __RPC_FAR *lpdwData,
            /* [retval][out] */ LONG __RPC_FAR *lplReturnCode) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE WriteDeviceBlock( 
            /* [string][in] */ BSTR szDevice,
            /* [in] */ LONG dwSize,
            /* [size_is][in] */ LONG __RPC_FAR *lpdwData,
            /* [retval][out] */ LONG __RPC_FAR *lplReturnCode) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE ReadDeviceRandom( 
            /* [string][in] */ BSTR szDeviceList,
            /* [in] */ LONG dwSize,
            /* [size_is][out] */ LONG __RPC_FAR *lpdwData,
            /* [retval][out] */ LONG __RPC_FAR *lplReturnCode) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE WriteDeviceRandom( 
            /* [string][in] */ BSTR szDeviceList,
            /* [in] */ LONG dwSize,
            /* [size_is][in] */ LONG __RPC_FAR *lpdwData,
            /* [retval][out] */ LONG __RPC_FAR *lplReturnCode) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE ReadBuffer( 
            /* [in] */ LONG lStartIO,
            /* [in] */ LONG lAddress,
            /* [in] */ LONG lReadSize,
            /* [out] */ SHORT __RPC_FAR *lpwData,
            /* [retval][out] */ LONG __RPC_FAR *lplReturnCode) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE WriteBuffer( 
            /* [in] */ LONG lStartIO,
            /* [in] */ LONG lAddress,
            /* [in] */ LONG lWriteSize,
            /* [out] */ SHORT __RPC_FAR *lpwData,
            /* [retval][out] */ LONG __RPC_FAR *lplReturnCode) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE GetClockData( 
            /* [out] */ SHORT __RPC_FAR *lpwYear,
            /* [out] */ SHORT __RPC_FAR *lpwMonth,
            /* [out] */ SHORT __RPC_FAR *lpwDay,
            /* [out] */ SHORT __RPC_FAR *lpwDayOfWeek,
            /* [out] */ SHORT __RPC_FAR *lpwHour,
            /* [out] */ SHORT __RPC_FAR *lpwMinute,
            /* [out] */ SHORT __RPC_FAR *lpwSecond,
            /* [retval][out] */ LONG __RPC_FAR *lplReturnCode) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE SetClockData( 
            /* [in] */ SHORT wYear,
            /* [in] */ SHORT wMonth,
            /* [in] */ SHORT wDay,
            /* [in] */ SHORT wDayOfWeek,
            /* [in] */ SHORT wHour,
            /* [in] */ SHORT wMinute,
            /* [in] */ SHORT wSecond,
            /* [retval][out] */ LONG __RPC_FAR *lplReturnCode) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE SetDevice( 
            /* [string][in] */ BSTR szDevice,
            /* [in] */ LONG dwData,
            /* [retval][out] */ LONG __RPC_FAR *lplReturnCode) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE SetCpuStatus( 
            /* [in] */ LONG lOperation,
            /* [retval][out] */ LONG __RPC_FAR *lplReturnCode) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE GetCpuType( 
            /* [string][out] */ BSTR __RPC_FAR *lpszCpuName,
            /* [out] */ LONG __RPC_FAR *lplCpuType,
            /* [retval][out] */ LONG __RPC_FAR *lplReturnCode) = 0;
        
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_ActNetworkNumber( 
            /* [retval][out] */ long __RPC_FAR *pVal) = 0;
        
        virtual /* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE put_ActNetworkNumber( 
            /* [in] */ long newVal) = 0;
        
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_ActStationNumber( 
            /* [retval][out] */ long __RPC_FAR *pVal) = 0;
        
        virtual /* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE put_ActStationNumber( 
            /* [in] */ long newVal) = 0;
        
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_ActUnitNumber( 
            /* [retval][out] */ long __RPC_FAR *pVal) = 0;
        
        virtual /* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE put_ActUnitNumber( 
            /* [in] */ long newVal) = 0;
        
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_ActConnectUnitNumber( 
            /* [retval][out] */ long __RPC_FAR *pVal) = 0;
        
        virtual /* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE put_ActConnectUnitNumber( 
            /* [in] */ long newVal) = 0;
        
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_ActIONumber( 
            /* [retval][out] */ long __RPC_FAR *pVal) = 0;
        
        virtual /* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE put_ActIONumber( 
            /* [in] */ long newVal) = 0;
        
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_ActCpuType( 
            /* [retval][out] */ long __RPC_FAR *pVal) = 0;
        
        virtual /* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE put_ActCpuType( 
            /* [in] */ long newVal) = 0;
        
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_ActPortNumber( 
            /* [retval][out] */ long __RPC_FAR *pVal) = 0;
        
        virtual /* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE put_ActPortNumber( 
            /* [in] */ long newVal) = 0;
        
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_ActHostAddress( 
            /* [retval][string][out] */ BSTR __RPC_FAR *pVal) = 0;
        
        virtual /* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE put_ActHostAddress( 
            /* [string][in] */ BSTR newVal) = 0;
        
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_ActTimeOut( 
            /* [retval][out] */ long __RPC_FAR *pVal) = 0;
        
        virtual /* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE put_ActTimeOut( 
            /* [in] */ long newVal) = 0;
        
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_ActSourceNetworkNumber( 
            /* [retval][out] */ long __RPC_FAR *pVal) = 0;
        
        virtual /* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE put_ActSourceNetworkNumber( 
            /* [in] */ long newVal) = 0;
        
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_ActSourceStationNumber( 
            /* [retval][out] */ long __RPC_FAR *pVal) = 0;
        
        virtual /* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE put_ActSourceStationNumber( 
            /* [in] */ long newVal) = 0;
        
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_ActDestinationIONumber( 
            /* [retval][out] */ long __RPC_FAR *pVal) = 0;
        
        virtual /* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE put_ActDestinationIONumber( 
            /* [in] */ long newVal) = 0;
        
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_ActMultiDropChannelNumber( 
            /* [retval][out] */ long __RPC_FAR *pVal) = 0;
        
        virtual /* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE put_ActMultiDropChannelNumber( 
            /* [in] */ long newVal) = 0;
        
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_ActThroughNetworkType( 
            /* [retval][out] */ long __RPC_FAR *pVal) = 0;
        
        virtual /* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE put_ActThroughNetworkType( 
            /* [in] */ long newVal) = 0;
        
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_ActDidPropertyBit( 
            /* [retval][out] */ long __RPC_FAR *pVal) = 0;
        
        virtual /* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE put_ActDidPropertyBit( 
            /* [in] */ long newVal) = 0;
        
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_ActDsidPropertyBit( 
            /* [retval][out] */ long __RPC_FAR *pVal) = 0;
        
        virtual /* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE put_ActDsidPropertyBit( 
            /* [in] */ long newVal) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE GetDevice( 
            /* [string][in] */ BSTR szDevice,
            /* [out] */ LONG __RPC_FAR *lpdwData,
            /* [retval][out] */ LONG __RPC_FAR *lplReturnCode) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE CheckDeviceString( 
            /* [in] */ BSTR szDevice,
            /* [in] */ LONG lCheckType,
            /* [in] */ LONG lSize,
            /* [out] */ LONG __RPC_FAR *lplDeviceType,
            /* [string][out] */ BSTR __RPC_FAR *lpszDeviceName,
            /* [out] */ LONG __RPC_FAR *lplDeviceNumber,
            /* [out] */ LONG __RPC_FAR *lplDeviceRadix,
            /* [retval][out] */ LONG __RPC_FAR *lplReturnCode) = 0;
        
    };
    
#else 	/* C style interface */

    typedef struct IActQJ71E71UDPVtbl
    {
        BEGIN_INTERFACE
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *QueryInterface )( 
            IActQJ71E71UDP __RPC_FAR * This,
            /* [in] */ REFIID riid,
            /* [iid_is][out] */ void __RPC_FAR *__RPC_FAR *ppvObject);
        
        ULONG ( STDMETHODCALLTYPE __RPC_FAR *AddRef )( 
            IActQJ71E71UDP __RPC_FAR * This);
        
        ULONG ( STDMETHODCALLTYPE __RPC_FAR *Release )( 
            IActQJ71E71UDP __RPC_FAR * This);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetTypeInfoCount )( 
            IActQJ71E71UDP __RPC_FAR * This,
            /* [out] */ UINT __RPC_FAR *pctinfo);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetTypeInfo )( 
            IActQJ71E71UDP __RPC_FAR * This,
            /* [in] */ UINT iTInfo,
            /* [in] */ LCID lcid,
            /* [out] */ ITypeInfo __RPC_FAR *__RPC_FAR *ppTInfo);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetIDsOfNames )( 
            IActQJ71E71UDP __RPC_FAR * This,
            /* [in] */ REFIID riid,
            /* [size_is][in] */ LPOLESTR __RPC_FAR *rgszNames,
            /* [in] */ UINT cNames,
            /* [in] */ LCID lcid,
            /* [size_is][out] */ DISPID __RPC_FAR *rgDispId);
        
        /* [local] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *Invoke )( 
            IActQJ71E71UDP __RPC_FAR * This,
            /* [in] */ DISPID dispIdMember,
            /* [in] */ REFIID riid,
            /* [in] */ LCID lcid,
            /* [in] */ WORD wFlags,
            /* [out][in] */ DISPPARAMS __RPC_FAR *pDispParams,
            /* [out] */ VARIANT __RPC_FAR *pVarResult,
            /* [out] */ EXCEPINFO __RPC_FAR *pExcepInfo,
            /* [out] */ UINT __RPC_FAR *puArgErr);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *Open )( 
            IActQJ71E71UDP __RPC_FAR * This,
            /* [retval][out] */ LONG __RPC_FAR *lplReturnCode);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *Close )( 
            IActQJ71E71UDP __RPC_FAR * This,
            /* [retval][out] */ LONG __RPC_FAR *lplReturnCode);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *ReadDeviceBlock )( 
            IActQJ71E71UDP __RPC_FAR * This,
            /* [string][in] */ BSTR szDevice,
            /* [in] */ LONG dwSize,
            /* [size_is][out] */ LONG __RPC_FAR *lpdwData,
            /* [retval][out] */ LONG __RPC_FAR *lplReturnCode);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *WriteDeviceBlock )( 
            IActQJ71E71UDP __RPC_FAR * This,
            /* [string][in] */ BSTR szDevice,
            /* [in] */ LONG dwSize,
            /* [size_is][in] */ LONG __RPC_FAR *lpdwData,
            /* [retval][out] */ LONG __RPC_FAR *lplReturnCode);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *ReadDeviceRandom )( 
            IActQJ71E71UDP __RPC_FAR * This,
            /* [string][in] */ BSTR szDeviceList,
            /* [in] */ LONG dwSize,
            /* [size_is][out] */ LONG __RPC_FAR *lpdwData,
            /* [retval][out] */ LONG __RPC_FAR *lplReturnCode);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *WriteDeviceRandom )( 
            IActQJ71E71UDP __RPC_FAR * This,
            /* [string][in] */ BSTR szDeviceList,
            /* [in] */ LONG dwSize,
            /* [size_is][in] */ LONG __RPC_FAR *lpdwData,
            /* [retval][out] */ LONG __RPC_FAR *lplReturnCode);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *ReadBuffer )( 
            IActQJ71E71UDP __RPC_FAR * This,
            /* [in] */ LONG lStartIO,
            /* [in] */ LONG lAddress,
            /* [in] */ LONG lReadSize,
            /* [out] */ SHORT __RPC_FAR *lpwData,
            /* [retval][out] */ LONG __RPC_FAR *lplReturnCode);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *WriteBuffer )( 
            IActQJ71E71UDP __RPC_FAR * This,
            /* [in] */ LONG lStartIO,
            /* [in] */ LONG lAddress,
            /* [in] */ LONG lWriteSize,
            /* [out] */ SHORT __RPC_FAR *lpwData,
            /* [retval][out] */ LONG __RPC_FAR *lplReturnCode);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetClockData )( 
            IActQJ71E71UDP __RPC_FAR * This,
            /* [out] */ SHORT __RPC_FAR *lpwYear,
            /* [out] */ SHORT __RPC_FAR *lpwMonth,
            /* [out] */ SHORT __RPC_FAR *lpwDay,
            /* [out] */ SHORT __RPC_FAR *lpwDayOfWeek,
            /* [out] */ SHORT __RPC_FAR *lpwHour,
            /* [out] */ SHORT __RPC_FAR *lpwMinute,
            /* [out] */ SHORT __RPC_FAR *lpwSecond,
            /* [retval][out] */ LONG __RPC_FAR *lplReturnCode);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *SetClockData )( 
            IActQJ71E71UDP __RPC_FAR * This,
            /* [in] */ SHORT wYear,
            /* [in] */ SHORT wMonth,
            /* [in] */ SHORT wDay,
            /* [in] */ SHORT wDayOfWeek,
            /* [in] */ SHORT wHour,
            /* [in] */ SHORT wMinute,
            /* [in] */ SHORT wSecond,
            /* [retval][out] */ LONG __RPC_FAR *lplReturnCode);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *SetDevice )( 
            IActQJ71E71UDP __RPC_FAR * This,
            /* [string][in] */ BSTR szDevice,
            /* [in] */ LONG dwData,
            /* [retval][out] */ LONG __RPC_FAR *lplReturnCode);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *SetCpuStatus )( 
            IActQJ71E71UDP __RPC_FAR * This,
            /* [in] */ LONG lOperation,
            /* [retval][out] */ LONG __RPC_FAR *lplReturnCode);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetCpuType )( 
            IActQJ71E71UDP __RPC_FAR * This,
            /* [string][out] */ BSTR __RPC_FAR *lpszCpuName,
            /* [out] */ LONG __RPC_FAR *lplCpuType,
            /* [retval][out] */ LONG __RPC_FAR *lplReturnCode);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_ActNetworkNumber )( 
            IActQJ71E71UDP __RPC_FAR * This,
            /* [retval][out] */ long __RPC_FAR *pVal);
        
        /* [helpstring][id][propput] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *put_ActNetworkNumber )( 
            IActQJ71E71UDP __RPC_FAR * This,
            /* [in] */ long newVal);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_ActStationNumber )( 
            IActQJ71E71UDP __RPC_FAR * This,
            /* [retval][out] */ long __RPC_FAR *pVal);
        
        /* [helpstring][id][propput] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *put_ActStationNumber )( 
            IActQJ71E71UDP __RPC_FAR * This,
            /* [in] */ long newVal);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_ActUnitNumber )( 
            IActQJ71E71UDP __RPC_FAR * This,
            /* [retval][out] */ long __RPC_FAR *pVal);
        
        /* [helpstring][id][propput] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *put_ActUnitNumber )( 
            IActQJ71E71UDP __RPC_FAR * This,
            /* [in] */ long newVal);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_ActConnectUnitNumber )( 
            IActQJ71E71UDP __RPC_FAR * This,
            /* [retval][out] */ long __RPC_FAR *pVal);
        
        /* [helpstring][id][propput] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *put_ActConnectUnitNumber )( 
            IActQJ71E71UDP __RPC_FAR * This,
            /* [in] */ long newVal);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_ActIONumber )( 
            IActQJ71E71UDP __RPC_FAR * This,
            /* [retval][out] */ long __RPC_FAR *pVal);
        
        /* [helpstring][id][propput] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *put_ActIONumber )( 
            IActQJ71E71UDP __RPC_FAR * This,
            /* [in] */ long newVal);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_ActCpuType )( 
            IActQJ71E71UDP __RPC_FAR * This,
            /* [retval][out] */ long __RPC_FAR *pVal);
        
        /* [helpstring][id][propput] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *put_ActCpuType )( 
            IActQJ71E71UDP __RPC_FAR * This,
            /* [in] */ long newVal);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_ActPortNumber )( 
            IActQJ71E71UDP __RPC_FAR * This,
            /* [retval][out] */ long __RPC_FAR *pVal);
        
        /* [helpstring][id][propput] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *put_ActPortNumber )( 
            IActQJ71E71UDP __RPC_FAR * This,
            /* [in] */ long newVal);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_ActHostAddress )( 
            IActQJ71E71UDP __RPC_FAR * This,
            /* [retval][string][out] */ BSTR __RPC_FAR *pVal);
        
        /* [helpstring][id][propput] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *put_ActHostAddress )( 
            IActQJ71E71UDP __RPC_FAR * This,
            /* [string][in] */ BSTR newVal);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_ActTimeOut )( 
            IActQJ71E71UDP __RPC_FAR * This,
            /* [retval][out] */ long __RPC_FAR *pVal);
        
        /* [helpstring][id][propput] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *put_ActTimeOut )( 
            IActQJ71E71UDP __RPC_FAR * This,
            /* [in] */ long newVal);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_ActSourceNetworkNumber )( 
            IActQJ71E71UDP __RPC_FAR * This,
            /* [retval][out] */ long __RPC_FAR *pVal);
        
        /* [helpstring][id][propput] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *put_ActSourceNetworkNumber )( 
            IActQJ71E71UDP __RPC_FAR * This,
            /* [in] */ long newVal);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_ActSourceStationNumber )( 
            IActQJ71E71UDP __RPC_FAR * This,
            /* [retval][out] */ long __RPC_FAR *pVal);
        
        /* [helpstring][id][propput] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *put_ActSourceStationNumber )( 
            IActQJ71E71UDP __RPC_FAR * This,
            /* [in] */ long newVal);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_ActDestinationIONumber )( 
            IActQJ71E71UDP __RPC_FAR * This,
            /* [retval][out] */ long __RPC_FAR *pVal);
        
        /* [helpstring][id][propput] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *put_ActDestinationIONumber )( 
            IActQJ71E71UDP __RPC_FAR * This,
            /* [in] */ long newVal);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_ActMultiDropChannelNumber )( 
            IActQJ71E71UDP __RPC_FAR * This,
            /* [retval][out] */ long __RPC_FAR *pVal);
        
        /* [helpstring][id][propput] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *put_ActMultiDropChannelNumber )( 
            IActQJ71E71UDP __RPC_FAR * This,
            /* [in] */ long newVal);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_ActThroughNetworkType )( 
            IActQJ71E71UDP __RPC_FAR * This,
            /* [retval][out] */ long __RPC_FAR *pVal);
        
        /* [helpstring][id][propput] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *put_ActThroughNetworkType )( 
            IActQJ71E71UDP __RPC_FAR * This,
            /* [in] */ long newVal);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_ActDidPropertyBit )( 
            IActQJ71E71UDP __RPC_FAR * This,
            /* [retval][out] */ long __RPC_FAR *pVal);
        
        /* [helpstring][id][propput] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *put_ActDidPropertyBit )( 
            IActQJ71E71UDP __RPC_FAR * This,
            /* [in] */ long newVal);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_ActDsidPropertyBit )( 
            IActQJ71E71UDP __RPC_FAR * This,
            /* [retval][out] */ long __RPC_FAR *pVal);
        
        /* [helpstring][id][propput] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *put_ActDsidPropertyBit )( 
            IActQJ71E71UDP __RPC_FAR * This,
            /* [in] */ long newVal);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetDevice )( 
            IActQJ71E71UDP __RPC_FAR * This,
            /* [string][in] */ BSTR szDevice,
            /* [out] */ LONG __RPC_FAR *lpdwData,
            /* [retval][out] */ LONG __RPC_FAR *lplReturnCode);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *CheckDeviceString )( 
            IActQJ71E71UDP __RPC_FAR * This,
            /* [in] */ BSTR szDevice,
            /* [in] */ LONG lCheckType,
            /* [in] */ LONG lSize,
            /* [out] */ LONG __RPC_FAR *lplDeviceType,
            /* [string][out] */ BSTR __RPC_FAR *lpszDeviceName,
            /* [out] */ LONG __RPC_FAR *lplDeviceNumber,
            /* [out] */ LONG __RPC_FAR *lplDeviceRadix,
            /* [retval][out] */ LONG __RPC_FAR *lplReturnCode);
        
        END_INTERFACE
    } IActQJ71E71UDPVtbl;

    interface IActQJ71E71UDP
    {
        CONST_VTBL struct IActQJ71E71UDPVtbl __RPC_FAR *lpVtbl;
    };

    

#ifdef COBJMACROS


#define IActQJ71E71UDP_QueryInterface(This,riid,ppvObject)	\
    (This)->lpVtbl -> QueryInterface(This,riid,ppvObject)

#define IActQJ71E71UDP_AddRef(This)	\
    (This)->lpVtbl -> AddRef(This)

#define IActQJ71E71UDP_Release(This)	\
    (This)->lpVtbl -> Release(This)


#define IActQJ71E71UDP_GetTypeInfoCount(This,pctinfo)	\
    (This)->lpVtbl -> GetTypeInfoCount(This,pctinfo)

#define IActQJ71E71UDP_GetTypeInfo(This,iTInfo,lcid,ppTInfo)	\
    (This)->lpVtbl -> GetTypeInfo(This,iTInfo,lcid,ppTInfo)

#define IActQJ71E71UDP_GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)	\
    (This)->lpVtbl -> GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)

#define IActQJ71E71UDP_Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)	\
    (This)->lpVtbl -> Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)


#define IActQJ71E71UDP_Open(This,lplReturnCode)	\
    (This)->lpVtbl -> Open(This,lplReturnCode)

#define IActQJ71E71UDP_Close(This,lplReturnCode)	\
    (This)->lpVtbl -> Close(This,lplReturnCode)

#define IActQJ71E71UDP_ReadDeviceBlock(This,szDevice,dwSize,lpdwData,lplReturnCode)	\
    (This)->lpVtbl -> ReadDeviceBlock(This,szDevice,dwSize,lpdwData,lplReturnCode)

#define IActQJ71E71UDP_WriteDeviceBlock(This,szDevice,dwSize,lpdwData,lplReturnCode)	\
    (This)->lpVtbl -> WriteDeviceBlock(This,szDevice,dwSize,lpdwData,lplReturnCode)

#define IActQJ71E71UDP_ReadDeviceRandom(This,szDeviceList,dwSize,lpdwData,lplReturnCode)	\
    (This)->lpVtbl -> ReadDeviceRandom(This,szDeviceList,dwSize,lpdwData,lplReturnCode)

#define IActQJ71E71UDP_WriteDeviceRandom(This,szDeviceList,dwSize,lpdwData,lplReturnCode)	\
    (This)->lpVtbl -> WriteDeviceRandom(This,szDeviceList,dwSize,lpdwData,lplReturnCode)

#define IActQJ71E71UDP_ReadBuffer(This,lStartIO,lAddress,lReadSize,lpwData,lplReturnCode)	\
    (This)->lpVtbl -> ReadBuffer(This,lStartIO,lAddress,lReadSize,lpwData,lplReturnCode)

#define IActQJ71E71UDP_WriteBuffer(This,lStartIO,lAddress,lWriteSize,lpwData,lplReturnCode)	\
    (This)->lpVtbl -> WriteBuffer(This,lStartIO,lAddress,lWriteSize,lpwData,lplReturnCode)

#define IActQJ71E71UDP_GetClockData(This,lpwYear,lpwMonth,lpwDay,lpwDayOfWeek,lpwHour,lpwMinute,lpwSecond,lplReturnCode)	\
    (This)->lpVtbl -> GetClockData(This,lpwYear,lpwMonth,lpwDay,lpwDayOfWeek,lpwHour,lpwMinute,lpwSecond,lplReturnCode)

#define IActQJ71E71UDP_SetClockData(This,wYear,wMonth,wDay,wDayOfWeek,wHour,wMinute,wSecond,lplReturnCode)	\
    (This)->lpVtbl -> SetClockData(This,wYear,wMonth,wDay,wDayOfWeek,wHour,wMinute,wSecond,lplReturnCode)

#define IActQJ71E71UDP_SetDevice(This,szDevice,dwData,lplReturnCode)	\
    (This)->lpVtbl -> SetDevice(This,szDevice,dwData,lplReturnCode)

#define IActQJ71E71UDP_SetCpuStatus(This,lOperation,lplReturnCode)	\
    (This)->lpVtbl -> SetCpuStatus(This,lOperation,lplReturnCode)

#define IActQJ71E71UDP_GetCpuType(This,lpszCpuName,lplCpuType,lplReturnCode)	\
    (This)->lpVtbl -> GetCpuType(This,lpszCpuName,lplCpuType,lplReturnCode)

#define IActQJ71E71UDP_get_ActNetworkNumber(This,pVal)	\
    (This)->lpVtbl -> get_ActNetworkNumber(This,pVal)

#define IActQJ71E71UDP_put_ActNetworkNumber(This,newVal)	\
    (This)->lpVtbl -> put_ActNetworkNumber(This,newVal)

#define IActQJ71E71UDP_get_ActStationNumber(This,pVal)	\
    (This)->lpVtbl -> get_ActStationNumber(This,pVal)

#define IActQJ71E71UDP_put_ActStationNumber(This,newVal)	\
    (This)->lpVtbl -> put_ActStationNumber(This,newVal)

#define IActQJ71E71UDP_get_ActUnitNumber(This,pVal)	\
    (This)->lpVtbl -> get_ActUnitNumber(This,pVal)

#define IActQJ71E71UDP_put_ActUnitNumber(This,newVal)	\
    (This)->lpVtbl -> put_ActUnitNumber(This,newVal)

#define IActQJ71E71UDP_get_ActConnectUnitNumber(This,pVal)	\
    (This)->lpVtbl -> get_ActConnectUnitNumber(This,pVal)

#define IActQJ71E71UDP_put_ActConnectUnitNumber(This,newVal)	\
    (This)->lpVtbl -> put_ActConnectUnitNumber(This,newVal)

#define IActQJ71E71UDP_get_ActIONumber(This,pVal)	\
    (This)->lpVtbl -> get_ActIONumber(This,pVal)

#define IActQJ71E71UDP_put_ActIONumber(This,newVal)	\
    (This)->lpVtbl -> put_ActIONumber(This,newVal)

#define IActQJ71E71UDP_get_ActCpuType(This,pVal)	\
    (This)->lpVtbl -> get_ActCpuType(This,pVal)

#define IActQJ71E71UDP_put_ActCpuType(This,newVal)	\
    (This)->lpVtbl -> put_ActCpuType(This,newVal)

#define IActQJ71E71UDP_get_ActPortNumber(This,pVal)	\
    (This)->lpVtbl -> get_ActPortNumber(This,pVal)

#define IActQJ71E71UDP_put_ActPortNumber(This,newVal)	\
    (This)->lpVtbl -> put_ActPortNumber(This,newVal)

#define IActQJ71E71UDP_get_ActHostAddress(This,pVal)	\
    (This)->lpVtbl -> get_ActHostAddress(This,pVal)

#define IActQJ71E71UDP_put_ActHostAddress(This,newVal)	\
    (This)->lpVtbl -> put_ActHostAddress(This,newVal)

#define IActQJ71E71UDP_get_ActTimeOut(This,pVal)	\
    (This)->lpVtbl -> get_ActTimeOut(This,pVal)

#define IActQJ71E71UDP_put_ActTimeOut(This,newVal)	\
    (This)->lpVtbl -> put_ActTimeOut(This,newVal)

#define IActQJ71E71UDP_get_ActSourceNetworkNumber(This,pVal)	\
    (This)->lpVtbl -> get_ActSourceNetworkNumber(This,pVal)

#define IActQJ71E71UDP_put_ActSourceNetworkNumber(This,newVal)	\
    (This)->lpVtbl -> put_ActSourceNetworkNumber(This,newVal)

#define IActQJ71E71UDP_get_ActSourceStationNumber(This,pVal)	\
    (This)->lpVtbl -> get_ActSourceStationNumber(This,pVal)

#define IActQJ71E71UDP_put_ActSourceStationNumber(This,newVal)	\
    (This)->lpVtbl -> put_ActSourceStationNumber(This,newVal)

#define IActQJ71E71UDP_get_ActDestinationIONumber(This,pVal)	\
    (This)->lpVtbl -> get_ActDestinationIONumber(This,pVal)

#define IActQJ71E71UDP_put_ActDestinationIONumber(This,newVal)	\
    (This)->lpVtbl -> put_ActDestinationIONumber(This,newVal)

#define IActQJ71E71UDP_get_ActMultiDropChannelNumber(This,pVal)	\
    (This)->lpVtbl -> get_ActMultiDropChannelNumber(This,pVal)

#define IActQJ71E71UDP_put_ActMultiDropChannelNumber(This,newVal)	\
    (This)->lpVtbl -> put_ActMultiDropChannelNumber(This,newVal)

#define IActQJ71E71UDP_get_ActThroughNetworkType(This,pVal)	\
    (This)->lpVtbl -> get_ActThroughNetworkType(This,pVal)

#define IActQJ71E71UDP_put_ActThroughNetworkType(This,newVal)	\
    (This)->lpVtbl -> put_ActThroughNetworkType(This,newVal)

#define IActQJ71E71UDP_get_ActDidPropertyBit(This,pVal)	\
    (This)->lpVtbl -> get_ActDidPropertyBit(This,pVal)

#define IActQJ71E71UDP_put_ActDidPropertyBit(This,newVal)	\
    (This)->lpVtbl -> put_ActDidPropertyBit(This,newVal)

#define IActQJ71E71UDP_get_ActDsidPropertyBit(This,pVal)	\
    (This)->lpVtbl -> get_ActDsidPropertyBit(This,pVal)

#define IActQJ71E71UDP_put_ActDsidPropertyBit(This,newVal)	\
    (This)->lpVtbl -> put_ActDsidPropertyBit(This,newVal)

#define IActQJ71E71UDP_GetDevice(This,szDevice,lpdwData,lplReturnCode)	\
    (This)->lpVtbl -> GetDevice(This,szDevice,lpdwData,lplReturnCode)

#define IActQJ71E71UDP_CheckDeviceString(This,szDevice,lCheckType,lSize,lplDeviceType,lpszDeviceName,lplDeviceNumber,lplDeviceRadix,lplReturnCode)	\
    (This)->lpVtbl -> CheckDeviceString(This,szDevice,lCheckType,lSize,lplDeviceType,lpszDeviceName,lplDeviceNumber,lplDeviceRadix,lplReturnCode)

#endif /* COBJMACROS */


#endif 	/* C style interface */



/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE IActQJ71E71UDP_Open_Proxy( 
    IActQJ71E71UDP __RPC_FAR * This,
    /* [retval][out] */ LONG __RPC_FAR *lplReturnCode);


void __RPC_STUB IActQJ71E71UDP_Open_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE IActQJ71E71UDP_Close_Proxy( 
    IActQJ71E71UDP __RPC_FAR * This,
    /* [retval][out] */ LONG __RPC_FAR *lplReturnCode);


void __RPC_STUB IActQJ71E71UDP_Close_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE IActQJ71E71UDP_ReadDeviceBlock_Proxy( 
    IActQJ71E71UDP __RPC_FAR * This,
    /* [string][in] */ BSTR szDevice,
    /* [in] */ LONG dwSize,
    /* [size_is][out] */ LONG __RPC_FAR *lpdwData,
    /* [retval][out] */ LONG __RPC_FAR *lplReturnCode);


void __RPC_STUB IActQJ71E71UDP_ReadDeviceBlock_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE IActQJ71E71UDP_WriteDeviceBlock_Proxy( 
    IActQJ71E71UDP __RPC_FAR * This,
    /* [string][in] */ BSTR szDevice,
    /* [in] */ LONG dwSize,
    /* [size_is][in] */ LONG __RPC_FAR *lpdwData,
    /* [retval][out] */ LONG __RPC_FAR *lplReturnCode);


void __RPC_STUB IActQJ71E71UDP_WriteDeviceBlock_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE IActQJ71E71UDP_ReadDeviceRandom_Proxy( 
    IActQJ71E71UDP __RPC_FAR * This,
    /* [string][in] */ BSTR szDeviceList,
    /* [in] */ LONG dwSize,
    /* [size_is][out] */ LONG __RPC_FAR *lpdwData,
    /* [retval][out] */ LONG __RPC_FAR *lplReturnCode);


void __RPC_STUB IActQJ71E71UDP_ReadDeviceRandom_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE IActQJ71E71UDP_WriteDeviceRandom_Proxy( 
    IActQJ71E71UDP __RPC_FAR * This,
    /* [string][in] */ BSTR szDeviceList,
    /* [in] */ LONG dwSize,
    /* [size_is][in] */ LONG __RPC_FAR *lpdwData,
    /* [retval][out] */ LONG __RPC_FAR *lplReturnCode);


void __RPC_STUB IActQJ71E71UDP_WriteDeviceRandom_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE IActQJ71E71UDP_ReadBuffer_Proxy( 
    IActQJ71E71UDP __RPC_FAR * This,
    /* [in] */ LONG lStartIO,
    /* [in] */ LONG lAddress,
    /* [in] */ LONG lReadSize,
    /* [out] */ SHORT __RPC_FAR *lpwData,
    /* [retval][out] */ LONG __RPC_FAR *lplReturnCode);


void __RPC_STUB IActQJ71E71UDP_ReadBuffer_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE IActQJ71E71UDP_WriteBuffer_Proxy( 
    IActQJ71E71UDP __RPC_FAR * This,
    /* [in] */ LONG lStartIO,
    /* [in] */ LONG lAddress,
    /* [in] */ LONG lWriteSize,
    /* [out] */ SHORT __RPC_FAR *lpwData,
    /* [retval][out] */ LONG __RPC_FAR *lplReturnCode);


void __RPC_STUB IActQJ71E71UDP_WriteBuffer_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE IActQJ71E71UDP_GetClockData_Proxy( 
    IActQJ71E71UDP __RPC_FAR * This,
    /* [out] */ SHORT __RPC_FAR *lpwYear,
    /* [out] */ SHORT __RPC_FAR *lpwMonth,
    /* [out] */ SHORT __RPC_FAR *lpwDay,
    /* [out] */ SHORT __RPC_FAR *lpwDayOfWeek,
    /* [out] */ SHORT __RPC_FAR *lpwHour,
    /* [out] */ SHORT __RPC_FAR *lpwMinute,
    /* [out] */ SHORT __RPC_FAR *lpwSecond,
    /* [retval][out] */ LONG __RPC_FAR *lplReturnCode);


void __RPC_STUB IActQJ71E71UDP_GetClockData_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE IActQJ71E71UDP_SetClockData_Proxy( 
    IActQJ71E71UDP __RPC_FAR * This,
    /* [in] */ SHORT wYear,
    /* [in] */ SHORT wMonth,
    /* [in] */ SHORT wDay,
    /* [in] */ SHORT wDayOfWeek,
    /* [in] */ SHORT wHour,
    /* [in] */ SHORT wMinute,
    /* [in] */ SHORT wSecond,
    /* [retval][out] */ LONG __RPC_FAR *lplReturnCode);


void __RPC_STUB IActQJ71E71UDP_SetClockData_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE IActQJ71E71UDP_SetDevice_Proxy( 
    IActQJ71E71UDP __RPC_FAR * This,
    /* [string][in] */ BSTR szDevice,
    /* [in] */ LONG dwData,
    /* [retval][out] */ LONG __RPC_FAR *lplReturnCode);


void __RPC_STUB IActQJ71E71UDP_SetDevice_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE IActQJ71E71UDP_SetCpuStatus_Proxy( 
    IActQJ71E71UDP __RPC_FAR * This,
    /* [in] */ LONG lOperation,
    /* [retval][out] */ LONG __RPC_FAR *lplReturnCode);


void __RPC_STUB IActQJ71E71UDP_SetCpuStatus_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE IActQJ71E71UDP_GetCpuType_Proxy( 
    IActQJ71E71UDP __RPC_FAR * This,
    /* [string][out] */ BSTR __RPC_FAR *lpszCpuName,
    /* [out] */ LONG __RPC_FAR *lplCpuType,
    /* [retval][out] */ LONG __RPC_FAR *lplReturnCode);


void __RPC_STUB IActQJ71E71UDP_GetCpuType_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE IActQJ71E71UDP_get_ActNetworkNumber_Proxy( 
    IActQJ71E71UDP __RPC_FAR * This,
    /* [retval][out] */ long __RPC_FAR *pVal);


void __RPC_STUB IActQJ71E71UDP_get_ActNetworkNumber_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE IActQJ71E71UDP_put_ActNetworkNumber_Proxy( 
    IActQJ71E71UDP __RPC_FAR * This,
    /* [in] */ long newVal);


void __RPC_STUB IActQJ71E71UDP_put_ActNetworkNumber_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE IActQJ71E71UDP_get_ActStationNumber_Proxy( 
    IActQJ71E71UDP __RPC_FAR * This,
    /* [retval][out] */ long __RPC_FAR *pVal);


void __RPC_STUB IActQJ71E71UDP_get_ActStationNumber_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE IActQJ71E71UDP_put_ActStationNumber_Proxy( 
    IActQJ71E71UDP __RPC_FAR * This,
    /* [in] */ long newVal);


void __RPC_STUB IActQJ71E71UDP_put_ActStationNumber_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE IActQJ71E71UDP_get_ActUnitNumber_Proxy( 
    IActQJ71E71UDP __RPC_FAR * This,
    /* [retval][out] */ long __RPC_FAR *pVal);


void __RPC_STUB IActQJ71E71UDP_get_ActUnitNumber_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE IActQJ71E71UDP_put_ActUnitNumber_Proxy( 
    IActQJ71E71UDP __RPC_FAR * This,
    /* [in] */ long newVal);


void __RPC_STUB IActQJ71E71UDP_put_ActUnitNumber_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE IActQJ71E71UDP_get_ActConnectUnitNumber_Proxy( 
    IActQJ71E71UDP __RPC_FAR * This,
    /* [retval][out] */ long __RPC_FAR *pVal);


void __RPC_STUB IActQJ71E71UDP_get_ActConnectUnitNumber_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE IActQJ71E71UDP_put_ActConnectUnitNumber_Proxy( 
    IActQJ71E71UDP __RPC_FAR * This,
    /* [in] */ long newVal);


void __RPC_STUB IActQJ71E71UDP_put_ActConnectUnitNumber_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE IActQJ71E71UDP_get_ActIONumber_Proxy( 
    IActQJ71E71UDP __RPC_FAR * This,
    /* [retval][out] */ long __RPC_FAR *pVal);


void __RPC_STUB IActQJ71E71UDP_get_ActIONumber_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE IActQJ71E71UDP_put_ActIONumber_Proxy( 
    IActQJ71E71UDP __RPC_FAR * This,
    /* [in] */ long newVal);


void __RPC_STUB IActQJ71E71UDP_put_ActIONumber_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE IActQJ71E71UDP_get_ActCpuType_Proxy( 
    IActQJ71E71UDP __RPC_FAR * This,
    /* [retval][out] */ long __RPC_FAR *pVal);


void __RPC_STUB IActQJ71E71UDP_get_ActCpuType_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE IActQJ71E71UDP_put_ActCpuType_Proxy( 
    IActQJ71E71UDP __RPC_FAR * This,
    /* [in] */ long newVal);


void __RPC_STUB IActQJ71E71UDP_put_ActCpuType_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE IActQJ71E71UDP_get_ActPortNumber_Proxy( 
    IActQJ71E71UDP __RPC_FAR * This,
    /* [retval][out] */ long __RPC_FAR *pVal);


void __RPC_STUB IActQJ71E71UDP_get_ActPortNumber_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE IActQJ71E71UDP_put_ActPortNumber_Proxy( 
    IActQJ71E71UDP __RPC_FAR * This,
    /* [in] */ long newVal);


void __RPC_STUB IActQJ71E71UDP_put_ActPortNumber_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE IActQJ71E71UDP_get_ActHostAddress_Proxy( 
    IActQJ71E71UDP __RPC_FAR * This,
    /* [retval][string][out] */ BSTR __RPC_FAR *pVal);


void __RPC_STUB IActQJ71E71UDP_get_ActHostAddress_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE IActQJ71E71UDP_put_ActHostAddress_Proxy( 
    IActQJ71E71UDP __RPC_FAR * This,
    /* [string][in] */ BSTR newVal);


void __RPC_STUB IActQJ71E71UDP_put_ActHostAddress_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE IActQJ71E71UDP_get_ActTimeOut_Proxy( 
    IActQJ71E71UDP __RPC_FAR * This,
    /* [retval][out] */ long __RPC_FAR *pVal);


void __RPC_STUB IActQJ71E71UDP_get_ActTimeOut_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE IActQJ71E71UDP_put_ActTimeOut_Proxy( 
    IActQJ71E71UDP __RPC_FAR * This,
    /* [in] */ long newVal);


void __RPC_STUB IActQJ71E71UDP_put_ActTimeOut_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE IActQJ71E71UDP_get_ActSourceNetworkNumber_Proxy( 
    IActQJ71E71UDP __RPC_FAR * This,
    /* [retval][out] */ long __RPC_FAR *pVal);


void __RPC_STUB IActQJ71E71UDP_get_ActSourceNetworkNumber_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE IActQJ71E71UDP_put_ActSourceNetworkNumber_Proxy( 
    IActQJ71E71UDP __RPC_FAR * This,
    /* [in] */ long newVal);


void __RPC_STUB IActQJ71E71UDP_put_ActSourceNetworkNumber_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE IActQJ71E71UDP_get_ActSourceStationNumber_Proxy( 
    IActQJ71E71UDP __RPC_FAR * This,
    /* [retval][out] */ long __RPC_FAR *pVal);


void __RPC_STUB IActQJ71E71UDP_get_ActSourceStationNumber_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE IActQJ71E71UDP_put_ActSourceStationNumber_Proxy( 
    IActQJ71E71UDP __RPC_FAR * This,
    /* [in] */ long newVal);


void __RPC_STUB IActQJ71E71UDP_put_ActSourceStationNumber_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE IActQJ71E71UDP_get_ActDestinationIONumber_Proxy( 
    IActQJ71E71UDP __RPC_FAR * This,
    /* [retval][out] */ long __RPC_FAR *pVal);


void __RPC_STUB IActQJ71E71UDP_get_ActDestinationIONumber_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE IActQJ71E71UDP_put_ActDestinationIONumber_Proxy( 
    IActQJ71E71UDP __RPC_FAR * This,
    /* [in] */ long newVal);


void __RPC_STUB IActQJ71E71UDP_put_ActDestinationIONumber_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE IActQJ71E71UDP_get_ActMultiDropChannelNumber_Proxy( 
    IActQJ71E71UDP __RPC_FAR * This,
    /* [retval][out] */ long __RPC_FAR *pVal);


void __RPC_STUB IActQJ71E71UDP_get_ActMultiDropChannelNumber_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE IActQJ71E71UDP_put_ActMultiDropChannelNumber_Proxy( 
    IActQJ71E71UDP __RPC_FAR * This,
    /* [in] */ long newVal);


void __RPC_STUB IActQJ71E71UDP_put_ActMultiDropChannelNumber_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE IActQJ71E71UDP_get_ActThroughNetworkType_Proxy( 
    IActQJ71E71UDP __RPC_FAR * This,
    /* [retval][out] */ long __RPC_FAR *pVal);


void __RPC_STUB IActQJ71E71UDP_get_ActThroughNetworkType_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE IActQJ71E71UDP_put_ActThroughNetworkType_Proxy( 
    IActQJ71E71UDP __RPC_FAR * This,
    /* [in] */ long newVal);


void __RPC_STUB IActQJ71E71UDP_put_ActThroughNetworkType_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE IActQJ71E71UDP_get_ActDidPropertyBit_Proxy( 
    IActQJ71E71UDP __RPC_FAR * This,
    /* [retval][out] */ long __RPC_FAR *pVal);


void __RPC_STUB IActQJ71E71UDP_get_ActDidPropertyBit_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE IActQJ71E71UDP_put_ActDidPropertyBit_Proxy( 
    IActQJ71E71UDP __RPC_FAR * This,
    /* [in] */ long newVal);


void __RPC_STUB IActQJ71E71UDP_put_ActDidPropertyBit_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE IActQJ71E71UDP_get_ActDsidPropertyBit_Proxy( 
    IActQJ71E71UDP __RPC_FAR * This,
    /* [retval][out] */ long __RPC_FAR *pVal);


void __RPC_STUB IActQJ71E71UDP_get_ActDsidPropertyBit_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE IActQJ71E71UDP_put_ActDsidPropertyBit_Proxy( 
    IActQJ71E71UDP __RPC_FAR * This,
    /* [in] */ long newVal);


void __RPC_STUB IActQJ71E71UDP_put_ActDsidPropertyBit_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE IActQJ71E71UDP_GetDevice_Proxy( 
    IActQJ71E71UDP __RPC_FAR * This,
    /* [string][in] */ BSTR szDevice,
    /* [out] */ LONG __RPC_FAR *lpdwData,
    /* [retval][out] */ LONG __RPC_FAR *lplReturnCode);


void __RPC_STUB IActQJ71E71UDP_GetDevice_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE IActQJ71E71UDP_CheckDeviceString_Proxy( 
    IActQJ71E71UDP __RPC_FAR * This,
    /* [in] */ BSTR szDevice,
    /* [in] */ LONG lCheckType,
    /* [in] */ LONG lSize,
    /* [out] */ LONG __RPC_FAR *lplDeviceType,
    /* [string][out] */ BSTR __RPC_FAR *lpszDeviceName,
    /* [out] */ LONG __RPC_FAR *lplDeviceNumber,
    /* [out] */ LONG __RPC_FAR *lplDeviceRadix,
    /* [retval][out] */ LONG __RPC_FAR *lplReturnCode);


void __RPC_STUB IActQJ71E71UDP_CheckDeviceString_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);



#endif 	/* __IActQJ71E71UDP_INTERFACE_DEFINED__ */


EXTERN_C const CLSID CLSID_ActQJ71E71TCP;

#ifdef __cplusplus

class DECLSPEC_UUID("AFEA5512-AE9C-11D3-83AE-00A024BDBF2B")
ActQJ71E71TCP;
#endif

#ifndef ___IActQJ71E71UDPEvents_DISPINTERFACE_DEFINED__
#define ___IActQJ71E71UDPEvents_DISPINTERFACE_DEFINED__

/* dispinterface _IActQJ71E71UDPEvents */
/* [helpstring][uuid] */ 


EXTERN_C const IID DIID__IActQJ71E71UDPEvents;

#if defined(__cplusplus) && !defined(CINTERFACE)

    MIDL_INTERFACE("AFEA5516-AE9C-11D3-83AE-00A024BDBF2B")
    _IActQJ71E71UDPEvents : public IDispatch
    {
    };
    
#else 	/* C style interface */

    typedef struct _IActQJ71E71UDPEventsVtbl
    {
        BEGIN_INTERFACE
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *QueryInterface )( 
            _IActQJ71E71UDPEvents __RPC_FAR * This,
            /* [in] */ REFIID riid,
            /* [iid_is][out] */ void __RPC_FAR *__RPC_FAR *ppvObject);
        
        ULONG ( STDMETHODCALLTYPE __RPC_FAR *AddRef )( 
            _IActQJ71E71UDPEvents __RPC_FAR * This);
        
        ULONG ( STDMETHODCALLTYPE __RPC_FAR *Release )( 
            _IActQJ71E71UDPEvents __RPC_FAR * This);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetTypeInfoCount )( 
            _IActQJ71E71UDPEvents __RPC_FAR * This,
            /* [out] */ UINT __RPC_FAR *pctinfo);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetTypeInfo )( 
            _IActQJ71E71UDPEvents __RPC_FAR * This,
            /* [in] */ UINT iTInfo,
            /* [in] */ LCID lcid,
            /* [out] */ ITypeInfo __RPC_FAR *__RPC_FAR *ppTInfo);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetIDsOfNames )( 
            _IActQJ71E71UDPEvents __RPC_FAR * This,
            /* [in] */ REFIID riid,
            /* [size_is][in] */ LPOLESTR __RPC_FAR *rgszNames,
            /* [in] */ UINT cNames,
            /* [in] */ LCID lcid,
            /* [size_is][out] */ DISPID __RPC_FAR *rgDispId);
        
        /* [local] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *Invoke )( 
            _IActQJ71E71UDPEvents __RPC_FAR * This,
            /* [in] */ DISPID dispIdMember,
            /* [in] */ REFIID riid,
            /* [in] */ LCID lcid,
            /* [in] */ WORD wFlags,
            /* [out][in] */ DISPPARAMS __RPC_FAR *pDispParams,
            /* [out] */ VARIANT __RPC_FAR *pVarResult,
            /* [out] */ EXCEPINFO __RPC_FAR *pExcepInfo,
            /* [out] */ UINT __RPC_FAR *puArgErr);
        
        END_INTERFACE
    } _IActQJ71E71UDPEventsVtbl;

    interface _IActQJ71E71UDPEvents
    {
        CONST_VTBL struct _IActQJ71E71UDPEventsVtbl __RPC_FAR *lpVtbl;
    };

    

#ifdef COBJMACROS


#define _IActQJ71E71UDPEvents_QueryInterface(This,riid,ppvObject)	\
    (This)->lpVtbl -> QueryInterface(This,riid,ppvObject)

#define _IActQJ71E71UDPEvents_AddRef(This)	\
    (This)->lpVtbl -> AddRef(This)

#define _IActQJ71E71UDPEvents_Release(This)	\
    (This)->lpVtbl -> Release(This)


#define _IActQJ71E71UDPEvents_GetTypeInfoCount(This,pctinfo)	\
    (This)->lpVtbl -> GetTypeInfoCount(This,pctinfo)

#define _IActQJ71E71UDPEvents_GetTypeInfo(This,iTInfo,lcid,ppTInfo)	\
    (This)->lpVtbl -> GetTypeInfo(This,iTInfo,lcid,ppTInfo)

#define _IActQJ71E71UDPEvents_GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)	\
    (This)->lpVtbl -> GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)

#define _IActQJ71E71UDPEvents_Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)	\
    (This)->lpVtbl -> Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)

#endif /* COBJMACROS */


#endif 	/* C style interface */


#endif 	/* ___IActQJ71E71UDPEvents_DISPINTERFACE_DEFINED__ */


#ifndef __IActAJ71QE71TCP_INTERFACE_DEFINED__
#define __IActAJ71QE71TCP_INTERFACE_DEFINED__

/* interface IActAJ71QE71TCP */
/* [unique][helpstring][dual][uuid][object] */ 


EXTERN_C const IID IID_IActAJ71QE71TCP;

#if defined(__cplusplus) && !defined(CINTERFACE)
    
    MIDL_INTERFACE("AFEA5517-AE9C-11D3-83AE-00A024BDBF2B")
    IActAJ71QE71TCP : public IDispatch
    {
    public:
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE Open( 
            /* [retval][out] */ LONG __RPC_FAR *lplReturnCode) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE Close( 
            /* [retval][out] */ LONG __RPC_FAR *lplReturnCode) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE ReadDeviceBlock( 
            /* [string][in] */ BSTR szDevice,
            /* [in] */ LONG dwSize,
            /* [size_is][out] */ LONG __RPC_FAR *lpdwData,
            /* [retval][out] */ LONG __RPC_FAR *lplReturnCode) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE WriteDeviceBlock( 
            /* [string][in] */ BSTR szDevice,
            /* [in] */ LONG dwSize,
            /* [size_is][in] */ LONG __RPC_FAR *lpdwData,
            /* [retval][out] */ LONG __RPC_FAR *lplReturnCode) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE ReadDeviceRandom( 
            /* [string][in] */ BSTR szDeviceList,
            /* [in] */ LONG dwSize,
            /* [size_is][out] */ LONG __RPC_FAR *lpdwData,
            /* [retval][out] */ LONG __RPC_FAR *lplReturnCode) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE WriteDeviceRandom( 
            /* [string][in] */ BSTR szDeviceList,
            /* [in] */ LONG dwSize,
            /* [size_is][in] */ LONG __RPC_FAR *lpdwData,
            /* [retval][out] */ LONG __RPC_FAR *lplReturnCode) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE SetDevice( 
            /* [string][in] */ BSTR szDevice,
            /* [in] */ LONG dwData,
            /* [retval][out] */ LONG __RPC_FAR *lplReturnCode) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE SetCpuStatus( 
            /* [in] */ LONG lOperation,
            /* [retval][out] */ LONG __RPC_FAR *lplReturnCode) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE GetCpuType( 
            /* [string][out] */ BSTR __RPC_FAR *lpszCpuName,
            /* [out] */ LONG __RPC_FAR *lplCpuType,
            /* [retval][out] */ LONG __RPC_FAR *lplReturnCode) = 0;
        
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_ActNetworkNumber( 
            /* [retval][out] */ long __RPC_FAR *pVal) = 0;
        
        virtual /* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE put_ActNetworkNumber( 
            /* [in] */ long newVal) = 0;
        
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_ActStationNumber( 
            /* [retval][out] */ long __RPC_FAR *pVal) = 0;
        
        virtual /* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE put_ActStationNumber( 
            /* [in] */ long newVal) = 0;
        
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_ActCpuType( 
            /* [retval][out] */ long __RPC_FAR *pVal) = 0;
        
        virtual /* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE put_ActCpuType( 
            /* [in] */ long newVal) = 0;
        
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_ActHostAddress( 
            /* [retval][string][out] */ BSTR __RPC_FAR *pVal) = 0;
        
        virtual /* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE put_ActHostAddress( 
            /* [string][in] */ BSTR newVal) = 0;
        
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_ActTimeOut( 
            /* [retval][out] */ long __RPC_FAR *pVal) = 0;
        
        virtual /* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE put_ActTimeOut( 
            /* [in] */ long newVal) = 0;
        
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_ActCpuTimeOut( 
            /* [retval][out] */ long __RPC_FAR *pVal) = 0;
        
        virtual /* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE put_ActCpuTimeOut( 
            /* [in] */ long newVal) = 0;
        
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_ActDestinationPortNumber( 
            /* [retval][out] */ long __RPC_FAR *pVal) = 0;
        
        virtual /* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE put_ActDestinationPortNumber( 
            /* [in] */ long newVal) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE GetDevice( 
            /* [string][in] */ BSTR szDevice,
            /* [out] */ LONG __RPC_FAR *lpdwData,
            /* [retval][out] */ LONG __RPC_FAR *lplReturnCode) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE CheckDeviceString( 
            /* [in] */ BSTR szDevice,
            /* [in] */ LONG lCheckType,
            /* [in] */ LONG lSize,
            /* [out] */ LONG __RPC_FAR *lplDeviceType,
            /* [string][out] */ BSTR __RPC_FAR *lpszDeviceName,
            /* [out] */ LONG __RPC_FAR *lplDeviceNumber,
            /* [out] */ LONG __RPC_FAR *lplDeviceRadix,
            /* [retval][out] */ LONG __RPC_FAR *lplReturnCode) = 0;
        
    };
    
#else 	/* C style interface */

    typedef struct IActAJ71QE71TCPVtbl
    {
        BEGIN_INTERFACE
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *QueryInterface )( 
            IActAJ71QE71TCP __RPC_FAR * This,
            /* [in] */ REFIID riid,
            /* [iid_is][out] */ void __RPC_FAR *__RPC_FAR *ppvObject);
        
        ULONG ( STDMETHODCALLTYPE __RPC_FAR *AddRef )( 
            IActAJ71QE71TCP __RPC_FAR * This);
        
        ULONG ( STDMETHODCALLTYPE __RPC_FAR *Release )( 
            IActAJ71QE71TCP __RPC_FAR * This);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetTypeInfoCount )( 
            IActAJ71QE71TCP __RPC_FAR * This,
            /* [out] */ UINT __RPC_FAR *pctinfo);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetTypeInfo )( 
            IActAJ71QE71TCP __RPC_FAR * This,
            /* [in] */ UINT iTInfo,
            /* [in] */ LCID lcid,
            /* [out] */ ITypeInfo __RPC_FAR *__RPC_FAR *ppTInfo);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetIDsOfNames )( 
            IActAJ71QE71TCP __RPC_FAR * This,
            /* [in] */ REFIID riid,
            /* [size_is][in] */ LPOLESTR __RPC_FAR *rgszNames,
            /* [in] */ UINT cNames,
            /* [in] */ LCID lcid,
            /* [size_is][out] */ DISPID __RPC_FAR *rgDispId);
        
        /* [local] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *Invoke )( 
            IActAJ71QE71TCP __RPC_FAR * This,
            /* [in] */ DISPID dispIdMember,
            /* [in] */ REFIID riid,
            /* [in] */ LCID lcid,
            /* [in] */ WORD wFlags,
            /* [out][in] */ DISPPARAMS __RPC_FAR *pDispParams,
            /* [out] */ VARIANT __RPC_FAR *pVarResult,
            /* [out] */ EXCEPINFO __RPC_FAR *pExcepInfo,
            /* [out] */ UINT __RPC_FAR *puArgErr);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *Open )( 
            IActAJ71QE71TCP __RPC_FAR * This,
            /* [retval][out] */ LONG __RPC_FAR *lplReturnCode);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *Close )( 
            IActAJ71QE71TCP __RPC_FAR * This,
            /* [retval][out] */ LONG __RPC_FAR *lplReturnCode);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *ReadDeviceBlock )( 
            IActAJ71QE71TCP __RPC_FAR * This,
            /* [string][in] */ BSTR szDevice,
            /* [in] */ LONG dwSize,
            /* [size_is][out] */ LONG __RPC_FAR *lpdwData,
            /* [retval][out] */ LONG __RPC_FAR *lplReturnCode);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *WriteDeviceBlock )( 
            IActAJ71QE71TCP __RPC_FAR * This,
            /* [string][in] */ BSTR szDevice,
            /* [in] */ LONG dwSize,
            /* [size_is][in] */ LONG __RPC_FAR *lpdwData,
            /* [retval][out] */ LONG __RPC_FAR *lplReturnCode);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *ReadDeviceRandom )( 
            IActAJ71QE71TCP __RPC_FAR * This,
            /* [string][in] */ BSTR szDeviceList,
            /* [in] */ LONG dwSize,
            /* [size_is][out] */ LONG __RPC_FAR *lpdwData,
            /* [retval][out] */ LONG __RPC_FAR *lplReturnCode);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *WriteDeviceRandom )( 
            IActAJ71QE71TCP __RPC_FAR * This,
            /* [string][in] */ BSTR szDeviceList,
            /* [in] */ LONG dwSize,
            /* [size_is][in] */ LONG __RPC_FAR *lpdwData,
            /* [retval][out] */ LONG __RPC_FAR *lplReturnCode);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *SetDevice )( 
            IActAJ71QE71TCP __RPC_FAR * This,
            /* [string][in] */ BSTR szDevice,
            /* [in] */ LONG dwData,
            /* [retval][out] */ LONG __RPC_FAR *lplReturnCode);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *SetCpuStatus )( 
            IActAJ71QE71TCP __RPC_FAR * This,
            /* [in] */ LONG lOperation,
            /* [retval][out] */ LONG __RPC_FAR *lplReturnCode);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetCpuType )( 
            IActAJ71QE71TCP __RPC_FAR * This,
            /* [string][out] */ BSTR __RPC_FAR *lpszCpuName,
            /* [out] */ LONG __RPC_FAR *lplCpuType,
            /* [retval][out] */ LONG __RPC_FAR *lplReturnCode);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_ActNetworkNumber )( 
            IActAJ71QE71TCP __RPC_FAR * This,
            /* [retval][out] */ long __RPC_FAR *pVal);
        
        /* [helpstring][id][propput] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *put_ActNetworkNumber )( 
            IActAJ71QE71TCP __RPC_FAR * This,
            /* [in] */ long newVal);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_ActStationNumber )( 
            IActAJ71QE71TCP __RPC_FAR * This,
            /* [retval][out] */ long __RPC_FAR *pVal);
        
        /* [helpstring][id][propput] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *put_ActStationNumber )( 
            IActAJ71QE71TCP __RPC_FAR * This,
            /* [in] */ long newVal);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_ActCpuType )( 
            IActAJ71QE71TCP __RPC_FAR * This,
            /* [retval][out] */ long __RPC_FAR *pVal);
        
        /* [helpstring][id][propput] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *put_ActCpuType )( 
            IActAJ71QE71TCP __RPC_FAR * This,
            /* [in] */ long newVal);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_ActHostAddress )( 
            IActAJ71QE71TCP __RPC_FAR * This,
            /* [retval][string][out] */ BSTR __RPC_FAR *pVal);
        
        /* [helpstring][id][propput] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *put_ActHostAddress )( 
            IActAJ71QE71TCP __RPC_FAR * This,
            /* [string][in] */ BSTR newVal);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_ActTimeOut )( 
            IActAJ71QE71TCP __RPC_FAR * This,
            /* [retval][out] */ long __RPC_FAR *pVal);
        
        /* [helpstring][id][propput] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *put_ActTimeOut )( 
            IActAJ71QE71TCP __RPC_FAR * This,
            /* [in] */ long newVal);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_ActCpuTimeOut )( 
            IActAJ71QE71TCP __RPC_FAR * This,
            /* [retval][out] */ long __RPC_FAR *pVal);
        
        /* [helpstring][id][propput] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *put_ActCpuTimeOut )( 
            IActAJ71QE71TCP __RPC_FAR * This,
            /* [in] */ long newVal);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_ActDestinationPortNumber )( 
            IActAJ71QE71TCP __RPC_FAR * This,
            /* [retval][out] */ long __RPC_FAR *pVal);
        
        /* [helpstring][id][propput] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *put_ActDestinationPortNumber )( 
            IActAJ71QE71TCP __RPC_FAR * This,
            /* [in] */ long newVal);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetDevice )( 
            IActAJ71QE71TCP __RPC_FAR * This,
            /* [string][in] */ BSTR szDevice,
            /* [out] */ LONG __RPC_FAR *lpdwData,
            /* [retval][out] */ LONG __RPC_FAR *lplReturnCode);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *CheckDeviceString )( 
            IActAJ71QE71TCP __RPC_FAR * This,
            /* [in] */ BSTR szDevice,
            /* [in] */ LONG lCheckType,
            /* [in] */ LONG lSize,
            /* [out] */ LONG __RPC_FAR *lplDeviceType,
            /* [string][out] */ BSTR __RPC_FAR *lpszDeviceName,
            /* [out] */ LONG __RPC_FAR *lplDeviceNumber,
            /* [out] */ LONG __RPC_FAR *lplDeviceRadix,
            /* [retval][out] */ LONG __RPC_FAR *lplReturnCode);
        
        END_INTERFACE
    } IActAJ71QE71TCPVtbl;

    interface IActAJ71QE71TCP
    {
        CONST_VTBL struct IActAJ71QE71TCPVtbl __RPC_FAR *lpVtbl;
    };

    

#ifdef COBJMACROS


#define IActAJ71QE71TCP_QueryInterface(This,riid,ppvObject)	\
    (This)->lpVtbl -> QueryInterface(This,riid,ppvObject)

#define IActAJ71QE71TCP_AddRef(This)	\
    (This)->lpVtbl -> AddRef(This)

#define IActAJ71QE71TCP_Release(This)	\
    (This)->lpVtbl -> Release(This)


#define IActAJ71QE71TCP_GetTypeInfoCount(This,pctinfo)	\
    (This)->lpVtbl -> GetTypeInfoCount(This,pctinfo)

#define IActAJ71QE71TCP_GetTypeInfo(This,iTInfo,lcid,ppTInfo)	\
    (This)->lpVtbl -> GetTypeInfo(This,iTInfo,lcid,ppTInfo)

#define IActAJ71QE71TCP_GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)	\
    (This)->lpVtbl -> GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)

#define IActAJ71QE71TCP_Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)	\
    (This)->lpVtbl -> Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)


#define IActAJ71QE71TCP_Open(This,lplReturnCode)	\
    (This)->lpVtbl -> Open(This,lplReturnCode)

#define IActAJ71QE71TCP_Close(This,lplReturnCode)	\
    (This)->lpVtbl -> Close(This,lplReturnCode)

#define IActAJ71QE71TCP_ReadDeviceBlock(This,szDevice,dwSize,lpdwData,lplReturnCode)	\
    (This)->lpVtbl -> ReadDeviceBlock(This,szDevice,dwSize,lpdwData,lplReturnCode)

#define IActAJ71QE71TCP_WriteDeviceBlock(This,szDevice,dwSize,lpdwData,lplReturnCode)	\
    (This)->lpVtbl -> WriteDeviceBlock(This,szDevice,dwSize,lpdwData,lplReturnCode)

#define IActAJ71QE71TCP_ReadDeviceRandom(This,szDeviceList,dwSize,lpdwData,lplReturnCode)	\
    (This)->lpVtbl -> ReadDeviceRandom(This,szDeviceList,dwSize,lpdwData,lplReturnCode)

#define IActAJ71QE71TCP_WriteDeviceRandom(This,szDeviceList,dwSize,lpdwData,lplReturnCode)	\
    (This)->lpVtbl -> WriteDeviceRandom(This,szDeviceList,dwSize,lpdwData,lplReturnCode)

#define IActAJ71QE71TCP_SetDevice(This,szDevice,dwData,lplReturnCode)	\
    (This)->lpVtbl -> SetDevice(This,szDevice,dwData,lplReturnCode)

#define IActAJ71QE71TCP_SetCpuStatus(This,lOperation,lplReturnCode)	\
    (This)->lpVtbl -> SetCpuStatus(This,lOperation,lplReturnCode)

#define IActAJ71QE71TCP_GetCpuType(This,lpszCpuName,lplCpuType,lplReturnCode)	\
    (This)->lpVtbl -> GetCpuType(This,lpszCpuName,lplCpuType,lplReturnCode)

#define IActAJ71QE71TCP_get_ActNetworkNumber(This,pVal)	\
    (This)->lpVtbl -> get_ActNetworkNumber(This,pVal)

#define IActAJ71QE71TCP_put_ActNetworkNumber(This,newVal)	\
    (This)->lpVtbl -> put_ActNetworkNumber(This,newVal)

#define IActAJ71QE71TCP_get_ActStationNumber(This,pVal)	\
    (This)->lpVtbl -> get_ActStationNumber(This,pVal)

#define IActAJ71QE71TCP_put_ActStationNumber(This,newVal)	\
    (This)->lpVtbl -> put_ActStationNumber(This,newVal)

#define IActAJ71QE71TCP_get_ActCpuType(This,pVal)	\
    (This)->lpVtbl -> get_ActCpuType(This,pVal)

#define IActAJ71QE71TCP_put_ActCpuType(This,newVal)	\
    (This)->lpVtbl -> put_ActCpuType(This,newVal)

#define IActAJ71QE71TCP_get_ActHostAddress(This,pVal)	\
    (This)->lpVtbl -> get_ActHostAddress(This,pVal)

#define IActAJ71QE71TCP_put_ActHostAddress(This,newVal)	\
    (This)->lpVtbl -> put_ActHostAddress(This,newVal)

#define IActAJ71QE71TCP_get_ActTimeOut(This,pVal)	\
    (This)->lpVtbl -> get_ActTimeOut(This,pVal)

#define IActAJ71QE71TCP_put_ActTimeOut(This,newVal)	\
    (This)->lpVtbl -> put_ActTimeOut(This,newVal)

#define IActAJ71QE71TCP_get_ActCpuTimeOut(This,pVal)	\
    (This)->lpVtbl -> get_ActCpuTimeOut(This,pVal)

#define IActAJ71QE71TCP_put_ActCpuTimeOut(This,newVal)	\
    (This)->lpVtbl -> put_ActCpuTimeOut(This,newVal)

#define IActAJ71QE71TCP_get_ActDestinationPortNumber(This,pVal)	\
    (This)->lpVtbl -> get_ActDestinationPortNumber(This,pVal)

#define IActAJ71QE71TCP_put_ActDestinationPortNumber(This,newVal)	\
    (This)->lpVtbl -> put_ActDestinationPortNumber(This,newVal)

#define IActAJ71QE71TCP_GetDevice(This,szDevice,lpdwData,lplReturnCode)	\
    (This)->lpVtbl -> GetDevice(This,szDevice,lpdwData,lplReturnCode)

#define IActAJ71QE71TCP_CheckDeviceString(This,szDevice,lCheckType,lSize,lplDeviceType,lpszDeviceName,lplDeviceNumber,lplDeviceRadix,lplReturnCode)	\
    (This)->lpVtbl -> CheckDeviceString(This,szDevice,lCheckType,lSize,lplDeviceType,lpszDeviceName,lplDeviceNumber,lplDeviceRadix,lplReturnCode)

#endif /* COBJMACROS */


#endif 	/* C style interface */



/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE IActAJ71QE71TCP_Open_Proxy( 
    IActAJ71QE71TCP __RPC_FAR * This,
    /* [retval][out] */ LONG __RPC_FAR *lplReturnCode);


void __RPC_STUB IActAJ71QE71TCP_Open_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE IActAJ71QE71TCP_Close_Proxy( 
    IActAJ71QE71TCP __RPC_FAR * This,
    /* [retval][out] */ LONG __RPC_FAR *lplReturnCode);


void __RPC_STUB IActAJ71QE71TCP_Close_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE IActAJ71QE71TCP_ReadDeviceBlock_Proxy( 
    IActAJ71QE71TCP __RPC_FAR * This,
    /* [string][in] */ BSTR szDevice,
    /* [in] */ LONG dwSize,
    /* [size_is][out] */ LONG __RPC_FAR *lpdwData,
    /* [retval][out] */ LONG __RPC_FAR *lplReturnCode);


void __RPC_STUB IActAJ71QE71TCP_ReadDeviceBlock_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE IActAJ71QE71TCP_WriteDeviceBlock_Proxy( 
    IActAJ71QE71TCP __RPC_FAR * This,
    /* [string][in] */ BSTR szDevice,
    /* [in] */ LONG dwSize,
    /* [size_is][in] */ LONG __RPC_FAR *lpdwData,
    /* [retval][out] */ LONG __RPC_FAR *lplReturnCode);


void __RPC_STUB IActAJ71QE71TCP_WriteDeviceBlock_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE IActAJ71QE71TCP_ReadDeviceRandom_Proxy( 
    IActAJ71QE71TCP __RPC_FAR * This,
    /* [string][in] */ BSTR szDeviceList,
    /* [in] */ LONG dwSize,
    /* [size_is][out] */ LONG __RPC_FAR *lpdwData,
    /* [retval][out] */ LONG __RPC_FAR *lplReturnCode);


void __RPC_STUB IActAJ71QE71TCP_ReadDeviceRandom_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE IActAJ71QE71TCP_WriteDeviceRandom_Proxy( 
    IActAJ71QE71TCP __RPC_FAR * This,
    /* [string][in] */ BSTR szDeviceList,
    /* [in] */ LONG dwSize,
    /* [size_is][in] */ LONG __RPC_FAR *lpdwData,
    /* [retval][out] */ LONG __RPC_FAR *lplReturnCode);


void __RPC_STUB IActAJ71QE71TCP_WriteDeviceRandom_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE IActAJ71QE71TCP_SetDevice_Proxy( 
    IActAJ71QE71TCP __RPC_FAR * This,
    /* [string][in] */ BSTR szDevice,
    /* [in] */ LONG dwData,
    /* [retval][out] */ LONG __RPC_FAR *lplReturnCode);


void __RPC_STUB IActAJ71QE71TCP_SetDevice_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE IActAJ71QE71TCP_SetCpuStatus_Proxy( 
    IActAJ71QE71TCP __RPC_FAR * This,
    /* [in] */ LONG lOperation,
    /* [retval][out] */ LONG __RPC_FAR *lplReturnCode);


void __RPC_STUB IActAJ71QE71TCP_SetCpuStatus_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE IActAJ71QE71TCP_GetCpuType_Proxy( 
    IActAJ71QE71TCP __RPC_FAR * This,
    /* [string][out] */ BSTR __RPC_FAR *lpszCpuName,
    /* [out] */ LONG __RPC_FAR *lplCpuType,
    /* [retval][out] */ LONG __RPC_FAR *lplReturnCode);


void __RPC_STUB IActAJ71QE71TCP_GetCpuType_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE IActAJ71QE71TCP_get_ActNetworkNumber_Proxy( 
    IActAJ71QE71TCP __RPC_FAR * This,
    /* [retval][out] */ long __RPC_FAR *pVal);


void __RPC_STUB IActAJ71QE71TCP_get_ActNetworkNumber_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE IActAJ71QE71TCP_put_ActNetworkNumber_Proxy( 
    IActAJ71QE71TCP __RPC_FAR * This,
    /* [in] */ long newVal);


void __RPC_STUB IActAJ71QE71TCP_put_ActNetworkNumber_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE IActAJ71QE71TCP_get_ActStationNumber_Proxy( 
    IActAJ71QE71TCP __RPC_FAR * This,
    /* [retval][out] */ long __RPC_FAR *pVal);


void __RPC_STUB IActAJ71QE71TCP_get_ActStationNumber_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE IActAJ71QE71TCP_put_ActStationNumber_Proxy( 
    IActAJ71QE71TCP __RPC_FAR * This,
    /* [in] */ long newVal);


void __RPC_STUB IActAJ71QE71TCP_put_ActStationNumber_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE IActAJ71QE71TCP_get_ActCpuType_Proxy( 
    IActAJ71QE71TCP __RPC_FAR * This,
    /* [retval][out] */ long __RPC_FAR *pVal);


void __RPC_STUB IActAJ71QE71TCP_get_ActCpuType_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE IActAJ71QE71TCP_put_ActCpuType_Proxy( 
    IActAJ71QE71TCP __RPC_FAR * This,
    /* [in] */ long newVal);


void __RPC_STUB IActAJ71QE71TCP_put_ActCpuType_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE IActAJ71QE71TCP_get_ActHostAddress_Proxy( 
    IActAJ71QE71TCP __RPC_FAR * This,
    /* [retval][string][out] */ BSTR __RPC_FAR *pVal);


void __RPC_STUB IActAJ71QE71TCP_get_ActHostAddress_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE IActAJ71QE71TCP_put_ActHostAddress_Proxy( 
    IActAJ71QE71TCP __RPC_FAR * This,
    /* [string][in] */ BSTR newVal);


void __RPC_STUB IActAJ71QE71TCP_put_ActHostAddress_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE IActAJ71QE71TCP_get_ActTimeOut_Proxy( 
    IActAJ71QE71TCP __RPC_FAR * This,
    /* [retval][out] */ long __RPC_FAR *pVal);


void __RPC_STUB IActAJ71QE71TCP_get_ActTimeOut_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE IActAJ71QE71TCP_put_ActTimeOut_Proxy( 
    IActAJ71QE71TCP __RPC_FAR * This,
    /* [in] */ long newVal);


void __RPC_STUB IActAJ71QE71TCP_put_ActTimeOut_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE IActAJ71QE71TCP_get_ActCpuTimeOut_Proxy( 
    IActAJ71QE71TCP __RPC_FAR * This,
    /* [retval][out] */ long __RPC_FAR *pVal);


void __RPC_STUB IActAJ71QE71TCP_get_ActCpuTimeOut_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE IActAJ71QE71TCP_put_ActCpuTimeOut_Proxy( 
    IActAJ71QE71TCP __RPC_FAR * This,
    /* [in] */ long newVal);


void __RPC_STUB IActAJ71QE71TCP_put_ActCpuTimeOut_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE IActAJ71QE71TCP_get_ActDestinationPortNumber_Proxy( 
    IActAJ71QE71TCP __RPC_FAR * This,
    /* [retval][out] */ long __RPC_FAR *pVal);


void __RPC_STUB IActAJ71QE71TCP_get_ActDestinationPortNumber_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE IActAJ71QE71TCP_put_ActDestinationPortNumber_Proxy( 
    IActAJ71QE71TCP __RPC_FAR * This,
    /* [in] */ long newVal);


void __RPC_STUB IActAJ71QE71TCP_put_ActDestinationPortNumber_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE IActAJ71QE71TCP_GetDevice_Proxy( 
    IActAJ71QE71TCP __RPC_FAR * This,
    /* [string][in] */ BSTR szDevice,
    /* [out] */ LONG __RPC_FAR *lpdwData,
    /* [retval][out] */ LONG __RPC_FAR *lplReturnCode);


void __RPC_STUB IActAJ71QE71TCP_GetDevice_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE IActAJ71QE71TCP_CheckDeviceString_Proxy( 
    IActAJ71QE71TCP __RPC_FAR * This,
    /* [in] */ BSTR szDevice,
    /* [in] */ LONG lCheckType,
    /* [in] */ LONG lSize,
    /* [out] */ LONG __RPC_FAR *lplDeviceType,
    /* [string][out] */ BSTR __RPC_FAR *lpszDeviceName,
    /* [out] */ LONG __RPC_FAR *lplDeviceNumber,
    /* [out] */ LONG __RPC_FAR *lplDeviceRadix,
    /* [retval][out] */ LONG __RPC_FAR *lplReturnCode);


void __RPC_STUB IActAJ71QE71TCP_CheckDeviceString_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);



#endif 	/* __IActAJ71QE71TCP_INTERFACE_DEFINED__ */


EXTERN_C const CLSID CLSID_ActQJ71E71UDP;

#ifdef __cplusplus

class DECLSPEC_UUID("AFEA5515-AE9C-11D3-83AE-00A024BDBF2B")
ActQJ71E71UDP;
#endif

#ifndef ___IActAJ71QE71TCPEvents_DISPINTERFACE_DEFINED__
#define ___IActAJ71QE71TCPEvents_DISPINTERFACE_DEFINED__

/* dispinterface _IActAJ71QE71TCPEvents */
/* [helpstring][uuid] */ 


EXTERN_C const IID DIID__IActAJ71QE71TCPEvents;

#if defined(__cplusplus) && !defined(CINTERFACE)

    MIDL_INTERFACE("AFEA5519-AE9C-11D3-83AE-00A024BDBF2B")
    _IActAJ71QE71TCPEvents : public IDispatch
    {
    };
    
#else 	/* C style interface */

    typedef struct _IActAJ71QE71TCPEventsVtbl
    {
        BEGIN_INTERFACE
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *QueryInterface )( 
            _IActAJ71QE71TCPEvents __RPC_FAR * This,
            /* [in] */ REFIID riid,
            /* [iid_is][out] */ void __RPC_FAR *__RPC_FAR *ppvObject);
        
        ULONG ( STDMETHODCALLTYPE __RPC_FAR *AddRef )( 
            _IActAJ71QE71TCPEvents __RPC_FAR * This);
        
        ULONG ( STDMETHODCALLTYPE __RPC_FAR *Release )( 
            _IActAJ71QE71TCPEvents __RPC_FAR * This);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetTypeInfoCount )( 
            _IActAJ71QE71TCPEvents __RPC_FAR * This,
            /* [out] */ UINT __RPC_FAR *pctinfo);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetTypeInfo )( 
            _IActAJ71QE71TCPEvents __RPC_FAR * This,
            /* [in] */ UINT iTInfo,
            /* [in] */ LCID lcid,
            /* [out] */ ITypeInfo __RPC_FAR *__RPC_FAR *ppTInfo);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetIDsOfNames )( 
            _IActAJ71QE71TCPEvents __RPC_FAR * This,
            /* [in] */ REFIID riid,
            /* [size_is][in] */ LPOLESTR __RPC_FAR *rgszNames,
            /* [in] */ UINT cNames,
            /* [in] */ LCID lcid,
            /* [size_is][out] */ DISPID __RPC_FAR *rgDispId);
        
        /* [local] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *Invoke )( 
            _IActAJ71QE71TCPEvents __RPC_FAR * This,
            /* [in] */ DISPID dispIdMember,
            /* [in] */ REFIID riid,
            /* [in] */ LCID lcid,
            /* [in] */ WORD wFlags,
            /* [out][in] */ DISPPARAMS __RPC_FAR *pDispParams,
            /* [out] */ VARIANT __RPC_FAR *pVarResult,
            /* [out] */ EXCEPINFO __RPC_FAR *pExcepInfo,
            /* [out] */ UINT __RPC_FAR *puArgErr);
        
        END_INTERFACE
    } _IActAJ71QE71TCPEventsVtbl;

    interface _IActAJ71QE71TCPEvents
    {
        CONST_VTBL struct _IActAJ71QE71TCPEventsVtbl __RPC_FAR *lpVtbl;
    };

    

#ifdef COBJMACROS


#define _IActAJ71QE71TCPEvents_QueryInterface(This,riid,ppvObject)	\
    (This)->lpVtbl -> QueryInterface(This,riid,ppvObject)

#define _IActAJ71QE71TCPEvents_AddRef(This)	\
    (This)->lpVtbl -> AddRef(This)

#define _IActAJ71QE71TCPEvents_Release(This)	\
    (This)->lpVtbl -> Release(This)


#define _IActAJ71QE71TCPEvents_GetTypeInfoCount(This,pctinfo)	\
    (This)->lpVtbl -> GetTypeInfoCount(This,pctinfo)

#define _IActAJ71QE71TCPEvents_GetTypeInfo(This,iTInfo,lcid,ppTInfo)	\
    (This)->lpVtbl -> GetTypeInfo(This,iTInfo,lcid,ppTInfo)

#define _IActAJ71QE71TCPEvents_GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)	\
    (This)->lpVtbl -> GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)

#define _IActAJ71QE71TCPEvents_Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)	\
    (This)->lpVtbl -> Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)

#endif /* COBJMACROS */


#endif 	/* C style interface */


#endif 	/* ___IActAJ71QE71TCPEvents_DISPINTERFACE_DEFINED__ */


#ifndef __IActAJ71QE71UDP_INTERFACE_DEFINED__
#define __IActAJ71QE71UDP_INTERFACE_DEFINED__

/* interface IActAJ71QE71UDP */
/* [unique][helpstring][dual][uuid][object] */ 


EXTERN_C const IID IID_IActAJ71QE71UDP;

#if defined(__cplusplus) && !defined(CINTERFACE)
    
    MIDL_INTERFACE("AFEA551A-AE9C-11D3-83AE-00A024BDBF2B")
    IActAJ71QE71UDP : public IDispatch
    {
    public:
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE Open( 
            /* [retval][out] */ LONG __RPC_FAR *lplReturnCode) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE Close( 
            /* [retval][out] */ LONG __RPC_FAR *lplReturnCode) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE ReadDeviceBlock( 
            /* [string][in] */ BSTR szDevice,
            /* [in] */ LONG dwSize,
            /* [size_is][out] */ LONG __RPC_FAR *lpdwData,
            /* [retval][out] */ LONG __RPC_FAR *lplReturnCode) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE WriteDeviceBlock( 
            /* [string][in] */ BSTR szDevice,
            /* [in] */ LONG dwSize,
            /* [size_is][in] */ LONG __RPC_FAR *lpdwData,
            /* [retval][out] */ LONG __RPC_FAR *lplReturnCode) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE ReadDeviceRandom( 
            /* [string][in] */ BSTR szDeviceList,
            /* [in] */ LONG dwSize,
            /* [size_is][out] */ LONG __RPC_FAR *lpdwData,
            /* [retval][out] */ LONG __RPC_FAR *lplReturnCode) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE WriteDeviceRandom( 
            /* [string][in] */ BSTR szDeviceList,
            /* [in] */ LONG dwSize,
            /* [size_is][in] */ LONG __RPC_FAR *lpdwData,
            /* [retval][out] */ LONG __RPC_FAR *lplReturnCode) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE ReadBuffer( 
            /* [in] */ LONG lStartIO,
            /* [in] */ LONG lAddress,
            /* [in] */ LONG lReadSize,
            /* [out] */ SHORT __RPC_FAR *lpwData,
            /* [retval][out] */ LONG __RPC_FAR *lplReturnCode) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE WriteBuffer( 
            /* [in] */ LONG lStartIO,
            /* [in] */ LONG lAddress,
            /* [in] */ LONG lWriteSize,
            /* [out] */ SHORT __RPC_FAR *lpwData,
            /* [retval][out] */ LONG __RPC_FAR *lplReturnCode) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE GetClockData( 
            /* [out] */ SHORT __RPC_FAR *lpwYear,
            /* [out] */ SHORT __RPC_FAR *lpwMonth,
            /* [out] */ SHORT __RPC_FAR *lpwDay,
            /* [out] */ SHORT __RPC_FAR *lpwDayOfWeek,
            /* [out] */ SHORT __RPC_FAR *lpwHour,
            /* [out] */ SHORT __RPC_FAR *lpwMinute,
            /* [out] */ SHORT __RPC_FAR *lpwSecond,
            /* [retval][out] */ LONG __RPC_FAR *lplReturnCode) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE SetClockData( 
            /* [in] */ SHORT wYear,
            /* [in] */ SHORT wMonth,
            /* [in] */ SHORT wDay,
            /* [in] */ SHORT wDayOfWeek,
            /* [in] */ SHORT wHour,
            /* [in] */ SHORT wMinute,
            /* [in] */ SHORT wSecond,
            /* [retval][out] */ LONG __RPC_FAR *lplReturnCode) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE SetDevice( 
            /* [string][in] */ BSTR szDevice,
            /* [in] */ LONG dwData,
            /* [retval][out] */ LONG __RPC_FAR *lplReturnCode) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE SetCpuStatus( 
            /* [in] */ LONG lOperation,
            /* [retval][out] */ LONG __RPC_FAR *lplReturnCode) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE GetCpuType( 
            /* [string][out] */ BSTR __RPC_FAR *lpszCpuName,
            /* [out] */ LONG __RPC_FAR *lplCpuType,
            /* [retval][out] */ LONG __RPC_FAR *lplReturnCode) = 0;
        
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_ActNetworkNumber( 
            /* [retval][out] */ long __RPC_FAR *pVal) = 0;
        
        virtual /* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE put_ActNetworkNumber( 
            /* [in] */ long newVal) = 0;
        
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_ActStationNumber( 
            /* [retval][out] */ long __RPC_FAR *pVal) = 0;
        
        virtual /* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE put_ActStationNumber( 
            /* [in] */ long newVal) = 0;
        
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_ActUnitNumber( 
            /* [retval][out] */ long __RPC_FAR *pVal) = 0;
        
        virtual /* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE put_ActUnitNumber( 
            /* [in] */ long newVal) = 0;
        
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_ActConnectUnitNumber( 
            /* [retval][out] */ long __RPC_FAR *pVal) = 0;
        
        virtual /* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE put_ActConnectUnitNumber( 
            /* [in] */ long newVal) = 0;
        
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_ActIONumber( 
            /* [retval][out] */ long __RPC_FAR *pVal) = 0;
        
        virtual /* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE put_ActIONumber( 
            /* [in] */ long newVal) = 0;
        
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_ActCpuType( 
            /* [retval][out] */ long __RPC_FAR *pVal) = 0;
        
        virtual /* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE put_ActCpuType( 
            /* [in] */ long newVal) = 0;
        
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_ActPortNumber( 
            /* [retval][out] */ long __RPC_FAR *pVal) = 0;
        
        virtual /* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE put_ActPortNumber( 
            /* [in] */ long newVal) = 0;
        
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_ActHostAddress( 
            /* [retval][string][out] */ BSTR __RPC_FAR *pVal) = 0;
        
        virtual /* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE put_ActHostAddress( 
            /* [string][in] */ BSTR newVal) = 0;
        
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_ActTimeOut( 
            /* [retval][out] */ long __RPC_FAR *pVal) = 0;
        
        virtual /* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE put_ActTimeOut( 
            /* [in] */ long newVal) = 0;
        
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_ActSourceNetworkNumber( 
            /* [retval][out] */ long __RPC_FAR *pVal) = 0;
        
        virtual /* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE put_ActSourceNetworkNumber( 
            /* [in] */ long newVal) = 0;
        
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_ActSourceStationNumber( 
            /* [retval][out] */ long __RPC_FAR *pVal) = 0;
        
        virtual /* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE put_ActSourceStationNumber( 
            /* [in] */ long newVal) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE GetDevice( 
            /* [string][in] */ BSTR szDevice,
            /* [out] */ LONG __RPC_FAR *lpdwData,
            /* [retval][out] */ LONG __RPC_FAR *lplReturnCode) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE CheckDeviceString( 
            /* [in] */ BSTR szDevice,
            /* [in] */ LONG lCheckType,
            /* [in] */ LONG lSize,
            /* [out] */ LONG __RPC_FAR *lplDeviceType,
            /* [string][out] */ BSTR __RPC_FAR *lpszDeviceName,
            /* [out] */ LONG __RPC_FAR *lplDeviceNumber,
            /* [out] */ LONG __RPC_FAR *lplDeviceRadix,
            /* [retval][out] */ LONG __RPC_FAR *lplReturnCode) = 0;
        
    };
    
#else 	/* C style interface */

    typedef struct IActAJ71QE71UDPVtbl
    {
        BEGIN_INTERFACE
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *QueryInterface )( 
            IActAJ71QE71UDP __RPC_FAR * This,
            /* [in] */ REFIID riid,
            /* [iid_is][out] */ void __RPC_FAR *__RPC_FAR *ppvObject);
        
        ULONG ( STDMETHODCALLTYPE __RPC_FAR *AddRef )( 
            IActAJ71QE71UDP __RPC_FAR * This);
        
        ULONG ( STDMETHODCALLTYPE __RPC_FAR *Release )( 
            IActAJ71QE71UDP __RPC_FAR * This);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetTypeInfoCount )( 
            IActAJ71QE71UDP __RPC_FAR * This,
            /* [out] */ UINT __RPC_FAR *pctinfo);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetTypeInfo )( 
            IActAJ71QE71UDP __RPC_FAR * This,
            /* [in] */ UINT iTInfo,
            /* [in] */ LCID lcid,
            /* [out] */ ITypeInfo __RPC_FAR *__RPC_FAR *ppTInfo);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetIDsOfNames )( 
            IActAJ71QE71UDP __RPC_FAR * This,
            /* [in] */ REFIID riid,
            /* [size_is][in] */ LPOLESTR __RPC_FAR *rgszNames,
            /* [in] */ UINT cNames,
            /* [in] */ LCID lcid,
            /* [size_is][out] */ DISPID __RPC_FAR *rgDispId);
        
        /* [local] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *Invoke )( 
            IActAJ71QE71UDP __RPC_FAR * This,
            /* [in] */ DISPID dispIdMember,
            /* [in] */ REFIID riid,
            /* [in] */ LCID lcid,
            /* [in] */ WORD wFlags,
            /* [out][in] */ DISPPARAMS __RPC_FAR *pDispParams,
            /* [out] */ VARIANT __RPC_FAR *pVarResult,
            /* [out] */ EXCEPINFO __RPC_FAR *pExcepInfo,
            /* [out] */ UINT __RPC_FAR *puArgErr);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *Open )( 
            IActAJ71QE71UDP __RPC_FAR * This,
            /* [retval][out] */ LONG __RPC_FAR *lplReturnCode);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *Close )( 
            IActAJ71QE71UDP __RPC_FAR * This,
            /* [retval][out] */ LONG __RPC_FAR *lplReturnCode);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *ReadDeviceBlock )( 
            IActAJ71QE71UDP __RPC_FAR * This,
            /* [string][in] */ BSTR szDevice,
            /* [in] */ LONG dwSize,
            /* [size_is][out] */ LONG __RPC_FAR *lpdwData,
            /* [retval][out] */ LONG __RPC_FAR *lplReturnCode);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *WriteDeviceBlock )( 
            IActAJ71QE71UDP __RPC_FAR * This,
            /* [string][in] */ BSTR szDevice,
            /* [in] */ LONG dwSize,
            /* [size_is][in] */ LONG __RPC_FAR *lpdwData,
            /* [retval][out] */ LONG __RPC_FAR *lplReturnCode);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *ReadDeviceRandom )( 
            IActAJ71QE71UDP __RPC_FAR * This,
            /* [string][in] */ BSTR szDeviceList,
            /* [in] */ LONG dwSize,
            /* [size_is][out] */ LONG __RPC_FAR *lpdwData,
            /* [retval][out] */ LONG __RPC_FAR *lplReturnCode);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *WriteDeviceRandom )( 
            IActAJ71QE71UDP __RPC_FAR * This,
            /* [string][in] */ BSTR szDeviceList,
            /* [in] */ LONG dwSize,
            /* [size_is][in] */ LONG __RPC_FAR *lpdwData,
            /* [retval][out] */ LONG __RPC_FAR *lplReturnCode);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *ReadBuffer )( 
            IActAJ71QE71UDP __RPC_FAR * This,
            /* [in] */ LONG lStartIO,
            /* [in] */ LONG lAddress,
            /* [in] */ LONG lReadSize,
            /* [out] */ SHORT __RPC_FAR *lpwData,
            /* [retval][out] */ LONG __RPC_FAR *lplReturnCode);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *WriteBuffer )( 
            IActAJ71QE71UDP __RPC_FAR * This,
            /* [in] */ LONG lStartIO,
            /* [in] */ LONG lAddress,
            /* [in] */ LONG lWriteSize,
            /* [out] */ SHORT __RPC_FAR *lpwData,
            /* [retval][out] */ LONG __RPC_FAR *lplReturnCode);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetClockData )( 
            IActAJ71QE71UDP __RPC_FAR * This,
            /* [out] */ SHORT __RPC_FAR *lpwYear,
            /* [out] */ SHORT __RPC_FAR *lpwMonth,
            /* [out] */ SHORT __RPC_FAR *lpwDay,
            /* [out] */ SHORT __RPC_FAR *lpwDayOfWeek,
            /* [out] */ SHORT __RPC_FAR *lpwHour,
            /* [out] */ SHORT __RPC_FAR *lpwMinute,
            /* [out] */ SHORT __RPC_FAR *lpwSecond,
            /* [retval][out] */ LONG __RPC_FAR *lplReturnCode);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *SetClockData )( 
            IActAJ71QE71UDP __RPC_FAR * This,
            /* [in] */ SHORT wYear,
            /* [in] */ SHORT wMonth,
            /* [in] */ SHORT wDay,
            /* [in] */ SHORT wDayOfWeek,
            /* [in] */ SHORT wHour,
            /* [in] */ SHORT wMinute,
            /* [in] */ SHORT wSecond,
            /* [retval][out] */ LONG __RPC_FAR *lplReturnCode);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *SetDevice )( 
            IActAJ71QE71UDP __RPC_FAR * This,
            /* [string][in] */ BSTR szDevice,
            /* [in] */ LONG dwData,
            /* [retval][out] */ LONG __RPC_FAR *lplReturnCode);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *SetCpuStatus )( 
            IActAJ71QE71UDP __RPC_FAR * This,
            /* [in] */ LONG lOperation,
            /* [retval][out] */ LONG __RPC_FAR *lplReturnCode);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetCpuType )( 
            IActAJ71QE71UDP __RPC_FAR * This,
            /* [string][out] */ BSTR __RPC_FAR *lpszCpuName,
            /* [out] */ LONG __RPC_FAR *lplCpuType,
            /* [retval][out] */ LONG __RPC_FAR *lplReturnCode);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_ActNetworkNumber )( 
            IActAJ71QE71UDP __RPC_FAR * This,
            /* [retval][out] */ long __RPC_FAR *pVal);
        
        /* [helpstring][id][propput] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *put_ActNetworkNumber )( 
            IActAJ71QE71UDP __RPC_FAR * This,
            /* [in] */ long newVal);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_ActStationNumber )( 
            IActAJ71QE71UDP __RPC_FAR * This,
            /* [retval][out] */ long __RPC_FAR *pVal);
        
        /* [helpstring][id][propput] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *put_ActStationNumber )( 
            IActAJ71QE71UDP __RPC_FAR * This,
            /* [in] */ long newVal);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_ActUnitNumber )( 
            IActAJ71QE71UDP __RPC_FAR * This,
            /* [retval][out] */ long __RPC_FAR *pVal);
        
        /* [helpstring][id][propput] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *put_ActUnitNumber )( 
            IActAJ71QE71UDP __RPC_FAR * This,
            /* [in] */ long newVal);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_ActConnectUnitNumber )( 
            IActAJ71QE71UDP __RPC_FAR * This,
            /* [retval][out] */ long __RPC_FAR *pVal);
        
        /* [helpstring][id][propput] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *put_ActConnectUnitNumber )( 
            IActAJ71QE71UDP __RPC_FAR * This,
            /* [in] */ long newVal);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_ActIONumber )( 
            IActAJ71QE71UDP __RPC_FAR * This,
            /* [retval][out] */ long __RPC_FAR *pVal);
        
        /* [helpstring][id][propput] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *put_ActIONumber )( 
            IActAJ71QE71UDP __RPC_FAR * This,
            /* [in] */ long newVal);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_ActCpuType )( 
            IActAJ71QE71UDP __RPC_FAR * This,
            /* [retval][out] */ long __RPC_FAR *pVal);
        
        /* [helpstring][id][propput] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *put_ActCpuType )( 
            IActAJ71QE71UDP __RPC_FAR * This,
            /* [in] */ long newVal);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_ActPortNumber )( 
            IActAJ71QE71UDP __RPC_FAR * This,
            /* [retval][out] */ long __RPC_FAR *pVal);
        
        /* [helpstring][id][propput] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *put_ActPortNumber )( 
            IActAJ71QE71UDP __RPC_FAR * This,
            /* [in] */ long newVal);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_ActHostAddress )( 
            IActAJ71QE71UDP __RPC_FAR * This,
            /* [retval][string][out] */ BSTR __RPC_FAR *pVal);
        
        /* [helpstring][id][propput] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *put_ActHostAddress )( 
            IActAJ71QE71UDP __RPC_FAR * This,
            /* [string][in] */ BSTR newVal);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_ActTimeOut )( 
            IActAJ71QE71UDP __RPC_FAR * This,
            /* [retval][out] */ long __RPC_FAR *pVal);
        
        /* [helpstring][id][propput] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *put_ActTimeOut )( 
            IActAJ71QE71UDP __RPC_FAR * This,
            /* [in] */ long newVal);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_ActSourceNetworkNumber )( 
            IActAJ71QE71UDP __RPC_FAR * This,
            /* [retval][out] */ long __RPC_FAR *pVal);
        
        /* [helpstring][id][propput] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *put_ActSourceNetworkNumber )( 
            IActAJ71QE71UDP __RPC_FAR * This,
            /* [in] */ long newVal);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_ActSourceStationNumber )( 
            IActAJ71QE71UDP __RPC_FAR * This,
            /* [retval][out] */ long __RPC_FAR *pVal);
        
        /* [helpstring][id][propput] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *put_ActSourceStationNumber )( 
            IActAJ71QE71UDP __RPC_FAR * This,
            /* [in] */ long newVal);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetDevice )( 
            IActAJ71QE71UDP __RPC_FAR * This,
            /* [string][in] */ BSTR szDevice,
            /* [out] */ LONG __RPC_FAR *lpdwData,
            /* [retval][out] */ LONG __RPC_FAR *lplReturnCode);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *CheckDeviceString )( 
            IActAJ71QE71UDP __RPC_FAR * This,
            /* [in] */ BSTR szDevice,
            /* [in] */ LONG lCheckType,
            /* [in] */ LONG lSize,
            /* [out] */ LONG __RPC_FAR *lplDeviceType,
            /* [string][out] */ BSTR __RPC_FAR *lpszDeviceName,
            /* [out] */ LONG __RPC_FAR *lplDeviceNumber,
            /* [out] */ LONG __RPC_FAR *lplDeviceRadix,
            /* [retval][out] */ LONG __RPC_FAR *lplReturnCode);
        
        END_INTERFACE
    } IActAJ71QE71UDPVtbl;

    interface IActAJ71QE71UDP
    {
        CONST_VTBL struct IActAJ71QE71UDPVtbl __RPC_FAR *lpVtbl;
    };

    

#ifdef COBJMACROS


#define IActAJ71QE71UDP_QueryInterface(This,riid,ppvObject)	\
    (This)->lpVtbl -> QueryInterface(This,riid,ppvObject)

#define IActAJ71QE71UDP_AddRef(This)	\
    (This)->lpVtbl -> AddRef(This)

#define IActAJ71QE71UDP_Release(This)	\
    (This)->lpVtbl -> Release(This)


#define IActAJ71QE71UDP_GetTypeInfoCount(This,pctinfo)	\
    (This)->lpVtbl -> GetTypeInfoCount(This,pctinfo)

#define IActAJ71QE71UDP_GetTypeInfo(This,iTInfo,lcid,ppTInfo)	\
    (This)->lpVtbl -> GetTypeInfo(This,iTInfo,lcid,ppTInfo)

#define IActAJ71QE71UDP_GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)	\
    (This)->lpVtbl -> GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)

#define IActAJ71QE71UDP_Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)	\
    (This)->lpVtbl -> Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)


#define IActAJ71QE71UDP_Open(This,lplReturnCode)	\
    (This)->lpVtbl -> Open(This,lplReturnCode)

#define IActAJ71QE71UDP_Close(This,lplReturnCode)	\
    (This)->lpVtbl -> Close(This,lplReturnCode)

#define IActAJ71QE71UDP_ReadDeviceBlock(This,szDevice,dwSize,lpdwData,lplReturnCode)	\
    (This)->lpVtbl -> ReadDeviceBlock(This,szDevice,dwSize,lpdwData,lplReturnCode)

#define IActAJ71QE71UDP_WriteDeviceBlock(This,szDevice,dwSize,lpdwData,lplReturnCode)	\
    (This)->lpVtbl -> WriteDeviceBlock(This,szDevice,dwSize,lpdwData,lplReturnCode)

#define IActAJ71QE71UDP_ReadDeviceRandom(This,szDeviceList,dwSize,lpdwData,lplReturnCode)	\
    (This)->lpVtbl -> ReadDeviceRandom(This,szDeviceList,dwSize,lpdwData,lplReturnCode)

#define IActAJ71QE71UDP_WriteDeviceRandom(This,szDeviceList,dwSize,lpdwData,lplReturnCode)	\
    (This)->lpVtbl -> WriteDeviceRandom(This,szDeviceList,dwSize,lpdwData,lplReturnCode)

#define IActAJ71QE71UDP_ReadBuffer(This,lStartIO,lAddress,lReadSize,lpwData,lplReturnCode)	\
    (This)->lpVtbl -> ReadBuffer(This,lStartIO,lAddress,lReadSize,lpwData,lplReturnCode)

#define IActAJ71QE71UDP_WriteBuffer(This,lStartIO,lAddress,lWriteSize,lpwData,lplReturnCode)	\
    (This)->lpVtbl -> WriteBuffer(This,lStartIO,lAddress,lWriteSize,lpwData,lplReturnCode)

#define IActAJ71QE71UDP_GetClockData(This,lpwYear,lpwMonth,lpwDay,lpwDayOfWeek,lpwHour,lpwMinute,lpwSecond,lplReturnCode)	\
    (This)->lpVtbl -> GetClockData(This,lpwYear,lpwMonth,lpwDay,lpwDayOfWeek,lpwHour,lpwMinute,lpwSecond,lplReturnCode)

#define IActAJ71QE71UDP_SetClockData(This,wYear,wMonth,wDay,wDayOfWeek,wHour,wMinute,wSecond,lplReturnCode)	\
    (This)->lpVtbl -> SetClockData(This,wYear,wMonth,wDay,wDayOfWeek,wHour,wMinute,wSecond,lplReturnCode)

#define IActAJ71QE71UDP_SetDevice(This,szDevice,dwData,lplReturnCode)	\
    (This)->lpVtbl -> SetDevice(This,szDevice,dwData,lplReturnCode)

#define IActAJ71QE71UDP_SetCpuStatus(This,lOperation,lplReturnCode)	\
    (This)->lpVtbl -> SetCpuStatus(This,lOperation,lplReturnCode)

#define IActAJ71QE71UDP_GetCpuType(This,lpszCpuName,lplCpuType,lplReturnCode)	\
    (This)->lpVtbl -> GetCpuType(This,lpszCpuName,lplCpuType,lplReturnCode)

#define IActAJ71QE71UDP_get_ActNetworkNumber(This,pVal)	\
    (This)->lpVtbl -> get_ActNetworkNumber(This,pVal)

#define IActAJ71QE71UDP_put_ActNetworkNumber(This,newVal)	\
    (This)->lpVtbl -> put_ActNetworkNumber(This,newVal)

#define IActAJ71QE71UDP_get_ActStationNumber(This,pVal)	\
    (This)->lpVtbl -> get_ActStationNumber(This,pVal)

#define IActAJ71QE71UDP_put_ActStationNumber(This,newVal)	\
    (This)->lpVtbl -> put_ActStationNumber(This,newVal)

#define IActAJ71QE71UDP_get_ActUnitNumber(This,pVal)	\
    (This)->lpVtbl -> get_ActUnitNumber(This,pVal)

#define IActAJ71QE71UDP_put_ActUnitNumber(This,newVal)	\
    (This)->lpVtbl -> put_ActUnitNumber(This,newVal)

#define IActAJ71QE71UDP_get_ActConnectUnitNumber(This,pVal)	\
    (This)->lpVtbl -> get_ActConnectUnitNumber(This,pVal)

#define IActAJ71QE71UDP_put_ActConnectUnitNumber(This,newVal)	\
    (This)->lpVtbl -> put_ActConnectUnitNumber(This,newVal)

#define IActAJ71QE71UDP_get_ActIONumber(This,pVal)	\
    (This)->lpVtbl -> get_ActIONumber(This,pVal)

#define IActAJ71QE71UDP_put_ActIONumber(This,newVal)	\
    (This)->lpVtbl -> put_ActIONumber(This,newVal)

#define IActAJ71QE71UDP_get_ActCpuType(This,pVal)	\
    (This)->lpVtbl -> get_ActCpuType(This,pVal)

#define IActAJ71QE71UDP_put_ActCpuType(This,newVal)	\
    (This)->lpVtbl -> put_ActCpuType(This,newVal)

#define IActAJ71QE71UDP_get_ActPortNumber(This,pVal)	\
    (This)->lpVtbl -> get_ActPortNumber(This,pVal)

#define IActAJ71QE71UDP_put_ActPortNumber(This,newVal)	\
    (This)->lpVtbl -> put_ActPortNumber(This,newVal)

#define IActAJ71QE71UDP_get_ActHostAddress(This,pVal)	\
    (This)->lpVtbl -> get_ActHostAddress(This,pVal)

#define IActAJ71QE71UDP_put_ActHostAddress(This,newVal)	\
    (This)->lpVtbl -> put_ActHostAddress(This,newVal)

#define IActAJ71QE71UDP_get_ActTimeOut(This,pVal)	\
    (This)->lpVtbl -> get_ActTimeOut(This,pVal)

#define IActAJ71QE71UDP_put_ActTimeOut(This,newVal)	\
    (This)->lpVtbl -> put_ActTimeOut(This,newVal)

#define IActAJ71QE71UDP_get_ActSourceNetworkNumber(This,pVal)	\
    (This)->lpVtbl -> get_ActSourceNetworkNumber(This,pVal)

#define IActAJ71QE71UDP_put_ActSourceNetworkNumber(This,newVal)	\
    (This)->lpVtbl -> put_ActSourceNetworkNumber(This,newVal)

#define IActAJ71QE71UDP_get_ActSourceStationNumber(This,pVal)	\
    (This)->lpVtbl -> get_ActSourceStationNumber(This,pVal)

#define IActAJ71QE71UDP_put_ActSourceStationNumber(This,newVal)	\
    (This)->lpVtbl -> put_ActSourceStationNumber(This,newVal)

#define IActAJ71QE71UDP_GetDevice(This,szDevice,lpdwData,lplReturnCode)	\
    (This)->lpVtbl -> GetDevice(This,szDevice,lpdwData,lplReturnCode)

#define IActAJ71QE71UDP_CheckDeviceString(This,szDevice,lCheckType,lSize,lplDeviceType,lpszDeviceName,lplDeviceNumber,lplDeviceRadix,lplReturnCode)	\
    (This)->lpVtbl -> CheckDeviceString(This,szDevice,lCheckType,lSize,lplDeviceType,lpszDeviceName,lplDeviceNumber,lplDeviceRadix,lplReturnCode)

#endif /* COBJMACROS */


#endif 	/* C style interface */



/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE IActAJ71QE71UDP_Open_Proxy( 
    IActAJ71QE71UDP __RPC_FAR * This,
    /* [retval][out] */ LONG __RPC_FAR *lplReturnCode);


void __RPC_STUB IActAJ71QE71UDP_Open_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE IActAJ71QE71UDP_Close_Proxy( 
    IActAJ71QE71UDP __RPC_FAR * This,
    /* [retval][out] */ LONG __RPC_FAR *lplReturnCode);


void __RPC_STUB IActAJ71QE71UDP_Close_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE IActAJ71QE71UDP_ReadDeviceBlock_Proxy( 
    IActAJ71QE71UDP __RPC_FAR * This,
    /* [string][in] */ BSTR szDevice,
    /* [in] */ LONG dwSize,
    /* [size_is][out] */ LONG __RPC_FAR *lpdwData,
    /* [retval][out] */ LONG __RPC_FAR *lplReturnCode);


void __RPC_STUB IActAJ71QE71UDP_ReadDeviceBlock_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE IActAJ71QE71UDP_WriteDeviceBlock_Proxy( 
    IActAJ71QE71UDP __RPC_FAR * This,
    /* [string][in] */ BSTR szDevice,
    /* [in] */ LONG dwSize,
    /* [size_is][in] */ LONG __RPC_FAR *lpdwData,
    /* [retval][out] */ LONG __RPC_FAR *lplReturnCode);


void __RPC_STUB IActAJ71QE71UDP_WriteDeviceBlock_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE IActAJ71QE71UDP_ReadDeviceRandom_Proxy( 
    IActAJ71QE71UDP __RPC_FAR * This,
    /* [string][in] */ BSTR szDeviceList,
    /* [in] */ LONG dwSize,
    /* [size_is][out] */ LONG __RPC_FAR *lpdwData,
    /* [retval][out] */ LONG __RPC_FAR *lplReturnCode);


void __RPC_STUB IActAJ71QE71UDP_ReadDeviceRandom_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE IActAJ71QE71UDP_WriteDeviceRandom_Proxy( 
    IActAJ71QE71UDP __RPC_FAR * This,
    /* [string][in] */ BSTR szDeviceList,
    /* [in] */ LONG dwSize,
    /* [size_is][in] */ LONG __RPC_FAR *lpdwData,
    /* [retval][out] */ LONG __RPC_FAR *lplReturnCode);


void __RPC_STUB IActAJ71QE71UDP_WriteDeviceRandom_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE IActAJ71QE71UDP_ReadBuffer_Proxy( 
    IActAJ71QE71UDP __RPC_FAR * This,
    /* [in] */ LONG lStartIO,
    /* [in] */ LONG lAddress,
    /* [in] */ LONG lReadSize,
    /* [out] */ SHORT __RPC_FAR *lpwData,
    /* [retval][out] */ LONG __RPC_FAR *lplReturnCode);


void __RPC_STUB IActAJ71QE71UDP_ReadBuffer_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE IActAJ71QE71UDP_WriteBuffer_Proxy( 
    IActAJ71QE71UDP __RPC_FAR * This,
    /* [in] */ LONG lStartIO,
    /* [in] */ LONG lAddress,
    /* [in] */ LONG lWriteSize,
    /* [out] */ SHORT __RPC_FAR *lpwData,
    /* [retval][out] */ LONG __RPC_FAR *lplReturnCode);


void __RPC_STUB IActAJ71QE71UDP_WriteBuffer_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE IActAJ71QE71UDP_GetClockData_Proxy( 
    IActAJ71QE71UDP __RPC_FAR * This,
    /* [out] */ SHORT __RPC_FAR *lpwYear,
    /* [out] */ SHORT __RPC_FAR *lpwMonth,
    /* [out] */ SHORT __RPC_FAR *lpwDay,
    /* [out] */ SHORT __RPC_FAR *lpwDayOfWeek,
    /* [out] */ SHORT __RPC_FAR *lpwHour,
    /* [out] */ SHORT __RPC_FAR *lpwMinute,
    /* [out] */ SHORT __RPC_FAR *lpwSecond,
    /* [retval][out] */ LONG __RPC_FAR *lplReturnCode);


void __RPC_STUB IActAJ71QE71UDP_GetClockData_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE IActAJ71QE71UDP_SetClockData_Proxy( 
    IActAJ71QE71UDP __RPC_FAR * This,
    /* [in] */ SHORT wYear,
    /* [in] */ SHORT wMonth,
    /* [in] */ SHORT wDay,
    /* [in] */ SHORT wDayOfWeek,
    /* [in] */ SHORT wHour,
    /* [in] */ SHORT wMinute,
    /* [in] */ SHORT wSecond,
    /* [retval][out] */ LONG __RPC_FAR *lplReturnCode);


void __RPC_STUB IActAJ71QE71UDP_SetClockData_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE IActAJ71QE71UDP_SetDevice_Proxy( 
    IActAJ71QE71UDP __RPC_FAR * This,
    /* [string][in] */ BSTR szDevice,
    /* [in] */ LONG dwData,
    /* [retval][out] */ LONG __RPC_FAR *lplReturnCode);


void __RPC_STUB IActAJ71QE71UDP_SetDevice_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE IActAJ71QE71UDP_SetCpuStatus_Proxy( 
    IActAJ71QE71UDP __RPC_FAR * This,
    /* [in] */ LONG lOperation,
    /* [retval][out] */ LONG __RPC_FAR *lplReturnCode);


void __RPC_STUB IActAJ71QE71UDP_SetCpuStatus_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE IActAJ71QE71UDP_GetCpuType_Proxy( 
    IActAJ71QE71UDP __RPC_FAR * This,
    /* [string][out] */ BSTR __RPC_FAR *lpszCpuName,
    /* [out] */ LONG __RPC_FAR *lplCpuType,
    /* [retval][out] */ LONG __RPC_FAR *lplReturnCode);


void __RPC_STUB IActAJ71QE71UDP_GetCpuType_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE IActAJ71QE71UDP_get_ActNetworkNumber_Proxy( 
    IActAJ71QE71UDP __RPC_FAR * This,
    /* [retval][out] */ long __RPC_FAR *pVal);


void __RPC_STUB IActAJ71QE71UDP_get_ActNetworkNumber_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE IActAJ71QE71UDP_put_ActNetworkNumber_Proxy( 
    IActAJ71QE71UDP __RPC_FAR * This,
    /* [in] */ long newVal);


void __RPC_STUB IActAJ71QE71UDP_put_ActNetworkNumber_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE IActAJ71QE71UDP_get_ActStationNumber_Proxy( 
    IActAJ71QE71UDP __RPC_FAR * This,
    /* [retval][out] */ long __RPC_FAR *pVal);


void __RPC_STUB IActAJ71QE71UDP_get_ActStationNumber_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE IActAJ71QE71UDP_put_ActStationNumber_Proxy( 
    IActAJ71QE71UDP __RPC_FAR * This,
    /* [in] */ long newVal);


void __RPC_STUB IActAJ71QE71UDP_put_ActStationNumber_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE IActAJ71QE71UDP_get_ActUnitNumber_Proxy( 
    IActAJ71QE71UDP __RPC_FAR * This,
    /* [retval][out] */ long __RPC_FAR *pVal);


void __RPC_STUB IActAJ71QE71UDP_get_ActUnitNumber_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE IActAJ71QE71UDP_put_ActUnitNumber_Proxy( 
    IActAJ71QE71UDP __RPC_FAR * This,
    /* [in] */ long newVal);


void __RPC_STUB IActAJ71QE71UDP_put_ActUnitNumber_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE IActAJ71QE71UDP_get_ActConnectUnitNumber_Proxy( 
    IActAJ71QE71UDP __RPC_FAR * This,
    /* [retval][out] */ long __RPC_FAR *pVal);


void __RPC_STUB IActAJ71QE71UDP_get_ActConnectUnitNumber_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE IActAJ71QE71UDP_put_ActConnectUnitNumber_Proxy( 
    IActAJ71QE71UDP __RPC_FAR * This,
    /* [in] */ long newVal);


void __RPC_STUB IActAJ71QE71UDP_put_ActConnectUnitNumber_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE IActAJ71QE71UDP_get_ActIONumber_Proxy( 
    IActAJ71QE71UDP __RPC_FAR * This,
    /* [retval][out] */ long __RPC_FAR *pVal);


void __RPC_STUB IActAJ71QE71UDP_get_ActIONumber_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE IActAJ71QE71UDP_put_ActIONumber_Proxy( 
    IActAJ71QE71UDP __RPC_FAR * This,
    /* [in] */ long newVal);


void __RPC_STUB IActAJ71QE71UDP_put_ActIONumber_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE IActAJ71QE71UDP_get_ActCpuType_Proxy( 
    IActAJ71QE71UDP __RPC_FAR * This,
    /* [retval][out] */ long __RPC_FAR *pVal);


void __RPC_STUB IActAJ71QE71UDP_get_ActCpuType_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE IActAJ71QE71UDP_put_ActCpuType_Proxy( 
    IActAJ71QE71UDP __RPC_FAR * This,
    /* [in] */ long newVal);


void __RPC_STUB IActAJ71QE71UDP_put_ActCpuType_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE IActAJ71QE71UDP_get_ActPortNumber_Proxy( 
    IActAJ71QE71UDP __RPC_FAR * This,
    /* [retval][out] */ long __RPC_FAR *pVal);


void __RPC_STUB IActAJ71QE71UDP_get_ActPortNumber_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE IActAJ71QE71UDP_put_ActPortNumber_Proxy( 
    IActAJ71QE71UDP __RPC_FAR * This,
    /* [in] */ long newVal);


void __RPC_STUB IActAJ71QE71UDP_put_ActPortNumber_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE IActAJ71QE71UDP_get_ActHostAddress_Proxy( 
    IActAJ71QE71UDP __RPC_FAR * This,
    /* [retval][string][out] */ BSTR __RPC_FAR *pVal);


void __RPC_STUB IActAJ71QE71UDP_get_ActHostAddress_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE IActAJ71QE71UDP_put_ActHostAddress_Proxy( 
    IActAJ71QE71UDP __RPC_FAR * This,
    /* [string][in] */ BSTR newVal);


void __RPC_STUB IActAJ71QE71UDP_put_ActHostAddress_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE IActAJ71QE71UDP_get_ActTimeOut_Proxy( 
    IActAJ71QE71UDP __RPC_FAR * This,
    /* [retval][out] */ long __RPC_FAR *pVal);


void __RPC_STUB IActAJ71QE71UDP_get_ActTimeOut_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE IActAJ71QE71UDP_put_ActTimeOut_Proxy( 
    IActAJ71QE71UDP __RPC_FAR * This,
    /* [in] */ long newVal);


void __RPC_STUB IActAJ71QE71UDP_put_ActTimeOut_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE IActAJ71QE71UDP_get_ActSourceNetworkNumber_Proxy( 
    IActAJ71QE71UDP __RPC_FAR * This,
    /* [retval][out] */ long __RPC_FAR *pVal);


void __RPC_STUB IActAJ71QE71UDP_get_ActSourceNetworkNumber_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE IActAJ71QE71UDP_put_ActSourceNetworkNumber_Proxy( 
    IActAJ71QE71UDP __RPC_FAR * This,
    /* [in] */ long newVal);


void __RPC_STUB IActAJ71QE71UDP_put_ActSourceNetworkNumber_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE IActAJ71QE71UDP_get_ActSourceStationNumber_Proxy( 
    IActAJ71QE71UDP __RPC_FAR * This,
    /* [retval][out] */ long __RPC_FAR *pVal);


void __RPC_STUB IActAJ71QE71UDP_get_ActSourceStationNumber_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE IActAJ71QE71UDP_put_ActSourceStationNumber_Proxy( 
    IActAJ71QE71UDP __RPC_FAR * This,
    /* [in] */ long newVal);


void __RPC_STUB IActAJ71QE71UDP_put_ActSourceStationNumber_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE IActAJ71QE71UDP_GetDevice_Proxy( 
    IActAJ71QE71UDP __RPC_FAR * This,
    /* [string][in] */ BSTR szDevice,
    /* [out] */ LONG __RPC_FAR *lpdwData,
    /* [retval][out] */ LONG __RPC_FAR *lplReturnCode);


void __RPC_STUB IActAJ71QE71UDP_GetDevice_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE IActAJ71QE71UDP_CheckDeviceString_Proxy( 
    IActAJ71QE71UDP __RPC_FAR * This,
    /* [in] */ BSTR szDevice,
    /* [in] */ LONG lCheckType,
    /* [in] */ LONG lSize,
    /* [out] */ LONG __RPC_FAR *lplDeviceType,
    /* [string][out] */ BSTR __RPC_FAR *lpszDeviceName,
    /* [out] */ LONG __RPC_FAR *lplDeviceNumber,
    /* [out] */ LONG __RPC_FAR *lplDeviceRadix,
    /* [retval][out] */ LONG __RPC_FAR *lplReturnCode);


void __RPC_STUB IActAJ71QE71UDP_CheckDeviceString_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);



#endif 	/* __IActAJ71QE71UDP_INTERFACE_DEFINED__ */


EXTERN_C const CLSID CLSID_ActAJ71QE71TCP;

#ifdef __cplusplus

class DECLSPEC_UUID("AFEA5518-AE9C-11D3-83AE-00A024BDBF2B")
ActAJ71QE71TCP;
#endif

#ifndef ___IActAJ71QE71UDPEvents_DISPINTERFACE_DEFINED__
#define ___IActAJ71QE71UDPEvents_DISPINTERFACE_DEFINED__

/* dispinterface _IActAJ71QE71UDPEvents */
/* [helpstring][uuid] */ 


EXTERN_C const IID DIID__IActAJ71QE71UDPEvents;

#if defined(__cplusplus) && !defined(CINTERFACE)

    MIDL_INTERFACE("AFEA551C-AE9C-11D3-83AE-00A024BDBF2B")
    _IActAJ71QE71UDPEvents : public IDispatch
    {
    };
    
#else 	/* C style interface */

    typedef struct _IActAJ71QE71UDPEventsVtbl
    {
        BEGIN_INTERFACE
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *QueryInterface )( 
            _IActAJ71QE71UDPEvents __RPC_FAR * This,
            /* [in] */ REFIID riid,
            /* [iid_is][out] */ void __RPC_FAR *__RPC_FAR *ppvObject);
        
        ULONG ( STDMETHODCALLTYPE __RPC_FAR *AddRef )( 
            _IActAJ71QE71UDPEvents __RPC_FAR * This);
        
        ULONG ( STDMETHODCALLTYPE __RPC_FAR *Release )( 
            _IActAJ71QE71UDPEvents __RPC_FAR * This);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetTypeInfoCount )( 
            _IActAJ71QE71UDPEvents __RPC_FAR * This,
            /* [out] */ UINT __RPC_FAR *pctinfo);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetTypeInfo )( 
            _IActAJ71QE71UDPEvents __RPC_FAR * This,
            /* [in] */ UINT iTInfo,
            /* [in] */ LCID lcid,
            /* [out] */ ITypeInfo __RPC_FAR *__RPC_FAR *ppTInfo);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetIDsOfNames )( 
            _IActAJ71QE71UDPEvents __RPC_FAR * This,
            /* [in] */ REFIID riid,
            /* [size_is][in] */ LPOLESTR __RPC_FAR *rgszNames,
            /* [in] */ UINT cNames,
            /* [in] */ LCID lcid,
            /* [size_is][out] */ DISPID __RPC_FAR *rgDispId);
        
        /* [local] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *Invoke )( 
            _IActAJ71QE71UDPEvents __RPC_FAR * This,
            /* [in] */ DISPID dispIdMember,
            /* [in] */ REFIID riid,
            /* [in] */ LCID lcid,
            /* [in] */ WORD wFlags,
            /* [out][in] */ DISPPARAMS __RPC_FAR *pDispParams,
            /* [out] */ VARIANT __RPC_FAR *pVarResult,
            /* [out] */ EXCEPINFO __RPC_FAR *pExcepInfo,
            /* [out] */ UINT __RPC_FAR *puArgErr);
        
        END_INTERFACE
    } _IActAJ71QE71UDPEventsVtbl;

    interface _IActAJ71QE71UDPEvents
    {
        CONST_VTBL struct _IActAJ71QE71UDPEventsVtbl __RPC_FAR *lpVtbl;
    };

    

#ifdef COBJMACROS


#define _IActAJ71QE71UDPEvents_QueryInterface(This,riid,ppvObject)	\
    (This)->lpVtbl -> QueryInterface(This,riid,ppvObject)

#define _IActAJ71QE71UDPEvents_AddRef(This)	\
    (This)->lpVtbl -> AddRef(This)

#define _IActAJ71QE71UDPEvents_Release(This)	\
    (This)->lpVtbl -> Release(This)


#define _IActAJ71QE71UDPEvents_GetTypeInfoCount(This,pctinfo)	\
    (This)->lpVtbl -> GetTypeInfoCount(This,pctinfo)

#define _IActAJ71QE71UDPEvents_GetTypeInfo(This,iTInfo,lcid,ppTInfo)	\
    (This)->lpVtbl -> GetTypeInfo(This,iTInfo,lcid,ppTInfo)

#define _IActAJ71QE71UDPEvents_GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)	\
    (This)->lpVtbl -> GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)

#define _IActAJ71QE71UDPEvents_Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)	\
    (This)->lpVtbl -> Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)

#endif /* COBJMACROS */


#endif 	/* C style interface */


#endif 	/* ___IActAJ71QE71UDPEvents_DISPINTERFACE_DEFINED__ */


#ifndef __IActAJ71E71TCP_INTERFACE_DEFINED__
#define __IActAJ71E71TCP_INTERFACE_DEFINED__

/* interface IActAJ71E71TCP */
/* [unique][helpstring][dual][uuid][object] */ 


EXTERN_C const IID IID_IActAJ71E71TCP;

#if defined(__cplusplus) && !defined(CINTERFACE)
    
    MIDL_INTERFACE("AFEA551D-AE9C-11D3-83AE-00A024BDBF2B")
    IActAJ71E71TCP : public IDispatch
    {
    public:
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE Open( 
            /* [retval][out] */ LONG __RPC_FAR *lplReturnCode) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE Close( 
            /* [retval][out] */ LONG __RPC_FAR *lplReturnCode) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE ReadDeviceBlock( 
            /* [string][in] */ BSTR szDevice,
            /* [in] */ LONG dwSize,
            /* [size_is][out] */ LONG __RPC_FAR *lpdwData,
            /* [retval][out] */ LONG __RPC_FAR *lplReturnCode) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE WriteDeviceBlock( 
            /* [string][in] */ BSTR szDevice,
            /* [in] */ LONG dwSize,
            /* [size_is][in] */ LONG __RPC_FAR *lpdwData,
            /* [retval][out] */ LONG __RPC_FAR *lplReturnCode) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE ReadDeviceRandom( 
            /* [string][in] */ BSTR szDeviceList,
            /* [in] */ LONG dwSize,
            /* [size_is][out] */ LONG __RPC_FAR *lpdwData,
            /* [retval][out] */ LONG __RPC_FAR *lplReturnCode) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE WriteDeviceRandom( 
            /* [string][in] */ BSTR szDeviceList,
            /* [in] */ LONG dwSize,
            /* [size_is][in] */ LONG __RPC_FAR *lpdwData,
            /* [retval][out] */ LONG __RPC_FAR *lplReturnCode) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE SetDevice( 
            /* [string][in] */ BSTR szDevice,
            /* [in] */ LONG dwData,
            /* [retval][out] */ LONG __RPC_FAR *lplReturnCode) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE SetCpuStatus( 
            /* [in] */ LONG lOperation,
            /* [retval][out] */ LONG __RPC_FAR *lplReturnCode) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE GetCpuType( 
            /* [string][out] */ BSTR __RPC_FAR *lpszCpuName,
            /* [out] */ LONG __RPC_FAR *lplCpuType,
            /* [retval][out] */ LONG __RPC_FAR *lplReturnCode) = 0;
        
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_ActStationNumber( 
            /* [retval][out] */ long __RPC_FAR *pVal) = 0;
        
        virtual /* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE put_ActStationNumber( 
            /* [in] */ long newVal) = 0;
        
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_ActCpuType( 
            /* [retval][out] */ long __RPC_FAR *pVal) = 0;
        
        virtual /* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE put_ActCpuType( 
            /* [in] */ long newVal) = 0;
        
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_ActHostAddress( 
            /* [retval][string][out] */ BSTR __RPC_FAR *pVal) = 0;
        
        virtual /* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE put_ActHostAddress( 
            /* [string][in] */ BSTR newVal) = 0;
        
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_ActCpuTimeOut( 
            /* [retval][out] */ long __RPC_FAR *pVal) = 0;
        
        virtual /* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE put_ActCpuTimeOut( 
            /* [in] */ long newVal) = 0;
        
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_ActTimeOut( 
            /* [retval][out] */ long __RPC_FAR *pVal) = 0;
        
        virtual /* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE put_ActTimeOut( 
            /* [in] */ long newVal) = 0;
        
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_ActDestinationPortNumber( 
            /* [retval][out] */ long __RPC_FAR *pVal) = 0;
        
        virtual /* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE put_ActDestinationPortNumber( 
            /* [in] */ long newVal) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE GetDevice( 
            /* [string][in] */ BSTR szDevice,
            /* [out] */ LONG __RPC_FAR *lpdwData,
            /* [retval][out] */ LONG __RPC_FAR *lplReturnCode) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE CheckDeviceString( 
            /* [in] */ BSTR szDevice,
            /* [in] */ LONG lCheckType,
            /* [in] */ LONG lSize,
            /* [out] */ LONG __RPC_FAR *lplDeviceType,
            /* [string][out] */ BSTR __RPC_FAR *lpszDeviceName,
            /* [out] */ LONG __RPC_FAR *lplDeviceNumber,
            /* [out] */ LONG __RPC_FAR *lplDeviceRadix,
            /* [retval][out] */ LONG __RPC_FAR *lplReturnCode) = 0;
        
    };
    
#else 	/* C style interface */

    typedef struct IActAJ71E71TCPVtbl
    {
        BEGIN_INTERFACE
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *QueryInterface )( 
            IActAJ71E71TCP __RPC_FAR * This,
            /* [in] */ REFIID riid,
            /* [iid_is][out] */ void __RPC_FAR *__RPC_FAR *ppvObject);
        
        ULONG ( STDMETHODCALLTYPE __RPC_FAR *AddRef )( 
            IActAJ71E71TCP __RPC_FAR * This);
        
        ULONG ( STDMETHODCALLTYPE __RPC_FAR *Release )( 
            IActAJ71E71TCP __RPC_FAR * This);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetTypeInfoCount )( 
            IActAJ71E71TCP __RPC_FAR * This,
            /* [out] */ UINT __RPC_FAR *pctinfo);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetTypeInfo )( 
            IActAJ71E71TCP __RPC_FAR * This,
            /* [in] */ UINT iTInfo,
            /* [in] */ LCID lcid,
            /* [out] */ ITypeInfo __RPC_FAR *__RPC_FAR *ppTInfo);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetIDsOfNames )( 
            IActAJ71E71TCP __RPC_FAR * This,
            /* [in] */ REFIID riid,
            /* [size_is][in] */ LPOLESTR __RPC_FAR *rgszNames,
            /* [in] */ UINT cNames,
            /* [in] */ LCID lcid,
            /* [size_is][out] */ DISPID __RPC_FAR *rgDispId);
        
        /* [local] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *Invoke )( 
            IActAJ71E71TCP __RPC_FAR * This,
            /* [in] */ DISPID dispIdMember,
            /* [in] */ REFIID riid,
            /* [in] */ LCID lcid,
            /* [in] */ WORD wFlags,
            /* [out][in] */ DISPPARAMS __RPC_FAR *pDispParams,
            /* [out] */ VARIANT __RPC_FAR *pVarResult,
            /* [out] */ EXCEPINFO __RPC_FAR *pExcepInfo,
            /* [out] */ UINT __RPC_FAR *puArgErr);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *Open )( 
            IActAJ71E71TCP __RPC_FAR * This,
            /* [retval][out] */ LONG __RPC_FAR *lplReturnCode);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *Close )( 
            IActAJ71E71TCP __RPC_FAR * This,
            /* [retval][out] */ LONG __RPC_FAR *lplReturnCode);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *ReadDeviceBlock )( 
            IActAJ71E71TCP __RPC_FAR * This,
            /* [string][in] */ BSTR szDevice,
            /* [in] */ LONG dwSize,
            /* [size_is][out] */ LONG __RPC_FAR *lpdwData,
            /* [retval][out] */ LONG __RPC_FAR *lplReturnCode);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *WriteDeviceBlock )( 
            IActAJ71E71TCP __RPC_FAR * This,
            /* [string][in] */ BSTR szDevice,
            /* [in] */ LONG dwSize,
            /* [size_is][in] */ LONG __RPC_FAR *lpdwData,
            /* [retval][out] */ LONG __RPC_FAR *lplReturnCode);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *ReadDeviceRandom )( 
            IActAJ71E71TCP __RPC_FAR * This,
            /* [string][in] */ BSTR szDeviceList,
            /* [in] */ LONG dwSize,
            /* [size_is][out] */ LONG __RPC_FAR *lpdwData,
            /* [retval][out] */ LONG __RPC_FAR *lplReturnCode);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *WriteDeviceRandom )( 
            IActAJ71E71TCP __RPC_FAR * This,
            /* [string][in] */ BSTR szDeviceList,
            /* [in] */ LONG dwSize,
            /* [size_is][in] */ LONG __RPC_FAR *lpdwData,
            /* [retval][out] */ LONG __RPC_FAR *lplReturnCode);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *SetDevice )( 
            IActAJ71E71TCP __RPC_FAR * This,
            /* [string][in] */ BSTR szDevice,
            /* [in] */ LONG dwData,
            /* [retval][out] */ LONG __RPC_FAR *lplReturnCode);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *SetCpuStatus )( 
            IActAJ71E71TCP __RPC_FAR * This,
            /* [in] */ LONG lOperation,
            /* [retval][out] */ LONG __RPC_FAR *lplReturnCode);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetCpuType )( 
            IActAJ71E71TCP __RPC_FAR * This,
            /* [string][out] */ BSTR __RPC_FAR *lpszCpuName,
            /* [out] */ LONG __RPC_FAR *lplCpuType,
            /* [retval][out] */ LONG __RPC_FAR *lplReturnCode);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_ActStationNumber )( 
            IActAJ71E71TCP __RPC_FAR * This,
            /* [retval][out] */ long __RPC_FAR *pVal);
        
        /* [helpstring][id][propput] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *put_ActStationNumber )( 
            IActAJ71E71TCP __RPC_FAR * This,
            /* [in] */ long newVal);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_ActCpuType )( 
            IActAJ71E71TCP __RPC_FAR * This,
            /* [retval][out] */ long __RPC_FAR *pVal);
        
        /* [helpstring][id][propput] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *put_ActCpuType )( 
            IActAJ71E71TCP __RPC_FAR * This,
            /* [in] */ long newVal);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_ActHostAddress )( 
            IActAJ71E71TCP __RPC_FAR * This,
            /* [retval][string][out] */ BSTR __RPC_FAR *pVal);
        
        /* [helpstring][id][propput] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *put_ActHostAddress )( 
            IActAJ71E71TCP __RPC_FAR * This,
            /* [string][in] */ BSTR newVal);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_ActCpuTimeOut )( 
            IActAJ71E71TCP __RPC_FAR * This,
            /* [retval][out] */ long __RPC_FAR *pVal);
        
        /* [helpstring][id][propput] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *put_ActCpuTimeOut )( 
            IActAJ71E71TCP __RPC_FAR * This,
            /* [in] */ long newVal);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_ActTimeOut )( 
            IActAJ71E71TCP __RPC_FAR * This,
            /* [retval][out] */ long __RPC_FAR *pVal);
        
        /* [helpstring][id][propput] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *put_ActTimeOut )( 
            IActAJ71E71TCP __RPC_FAR * This,
            /* [in] */ long newVal);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_ActDestinationPortNumber )( 
            IActAJ71E71TCP __RPC_FAR * This,
            /* [retval][out] */ long __RPC_FAR *pVal);
        
        /* [helpstring][id][propput] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *put_ActDestinationPortNumber )( 
            IActAJ71E71TCP __RPC_FAR * This,
            /* [in] */ long newVal);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetDevice )( 
            IActAJ71E71TCP __RPC_FAR * This,
            /* [string][in] */ BSTR szDevice,
            /* [out] */ LONG __RPC_FAR *lpdwData,
            /* [retval][out] */ LONG __RPC_FAR *lplReturnCode);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *CheckDeviceString )( 
            IActAJ71E71TCP __RPC_FAR * This,
            /* [in] */ BSTR szDevice,
            /* [in] */ LONG lCheckType,
            /* [in] */ LONG lSize,
            /* [out] */ LONG __RPC_FAR *lplDeviceType,
            /* [string][out] */ BSTR __RPC_FAR *lpszDeviceName,
            /* [out] */ LONG __RPC_FAR *lplDeviceNumber,
            /* [out] */ LONG __RPC_FAR *lplDeviceRadix,
            /* [retval][out] */ LONG __RPC_FAR *lplReturnCode);
        
        END_INTERFACE
    } IActAJ71E71TCPVtbl;

    interface IActAJ71E71TCP
    {
        CONST_VTBL struct IActAJ71E71TCPVtbl __RPC_FAR *lpVtbl;
    };

    

#ifdef COBJMACROS


#define IActAJ71E71TCP_QueryInterface(This,riid,ppvObject)	\
    (This)->lpVtbl -> QueryInterface(This,riid,ppvObject)

#define IActAJ71E71TCP_AddRef(This)	\
    (This)->lpVtbl -> AddRef(This)

#define IActAJ71E71TCP_Release(This)	\
    (This)->lpVtbl -> Release(This)


#define IActAJ71E71TCP_GetTypeInfoCount(This,pctinfo)	\
    (This)->lpVtbl -> GetTypeInfoCount(This,pctinfo)

#define IActAJ71E71TCP_GetTypeInfo(This,iTInfo,lcid,ppTInfo)	\
    (This)->lpVtbl -> GetTypeInfo(This,iTInfo,lcid,ppTInfo)

#define IActAJ71E71TCP_GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)	\
    (This)->lpVtbl -> GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)

#define IActAJ71E71TCP_Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)	\
    (This)->lpVtbl -> Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)


#define IActAJ71E71TCP_Open(This,lplReturnCode)	\
    (This)->lpVtbl -> Open(This,lplReturnCode)

#define IActAJ71E71TCP_Close(This,lplReturnCode)	\
    (This)->lpVtbl -> Close(This,lplReturnCode)

#define IActAJ71E71TCP_ReadDeviceBlock(This,szDevice,dwSize,lpdwData,lplReturnCode)	\
    (This)->lpVtbl -> ReadDeviceBlock(This,szDevice,dwSize,lpdwData,lplReturnCode)

#define IActAJ71E71TCP_WriteDeviceBlock(This,szDevice,dwSize,lpdwData,lplReturnCode)	\
    (This)->lpVtbl -> WriteDeviceBlock(This,szDevice,dwSize,lpdwData,lplReturnCode)

#define IActAJ71E71TCP_ReadDeviceRandom(This,szDeviceList,dwSize,lpdwData,lplReturnCode)	\
    (This)->lpVtbl -> ReadDeviceRandom(This,szDeviceList,dwSize,lpdwData,lplReturnCode)

#define IActAJ71E71TCP_WriteDeviceRandom(This,szDeviceList,dwSize,lpdwData,lplReturnCode)	\
    (This)->lpVtbl -> WriteDeviceRandom(This,szDeviceList,dwSize,lpdwData,lplReturnCode)

#define IActAJ71E71TCP_SetDevice(This,szDevice,dwData,lplReturnCode)	\
    (This)->lpVtbl -> SetDevice(This,szDevice,dwData,lplReturnCode)

#define IActAJ71E71TCP_SetCpuStatus(This,lOperation,lplReturnCode)	\
    (This)->lpVtbl -> SetCpuStatus(This,lOperation,lplReturnCode)

#define IActAJ71E71TCP_GetCpuType(This,lpszCpuName,lplCpuType,lplReturnCode)	\
    (This)->lpVtbl -> GetCpuType(This,lpszCpuName,lplCpuType,lplReturnCode)

#define IActAJ71E71TCP_get_ActStationNumber(This,pVal)	\
    (This)->lpVtbl -> get_ActStationNumber(This,pVal)

#define IActAJ71E71TCP_put_ActStationNumber(This,newVal)	\
    (This)->lpVtbl -> put_ActStationNumber(This,newVal)

#define IActAJ71E71TCP_get_ActCpuType(This,pVal)	\
    (This)->lpVtbl -> get_ActCpuType(This,pVal)

#define IActAJ71E71TCP_put_ActCpuType(This,newVal)	\
    (This)->lpVtbl -> put_ActCpuType(This,newVal)

#define IActAJ71E71TCP_get_ActHostAddress(This,pVal)	\
    (This)->lpVtbl -> get_ActHostAddress(This,pVal)

#define IActAJ71E71TCP_put_ActHostAddress(This,newVal)	\
    (This)->lpVtbl -> put_ActHostAddress(This,newVal)

#define IActAJ71E71TCP_get_ActCpuTimeOut(This,pVal)	\
    (This)->lpVtbl -> get_ActCpuTimeOut(This,pVal)

#define IActAJ71E71TCP_put_ActCpuTimeOut(This,newVal)	\
    (This)->lpVtbl -> put_ActCpuTimeOut(This,newVal)

#define IActAJ71E71TCP_get_ActTimeOut(This,pVal)	\
    (This)->lpVtbl -> get_ActTimeOut(This,pVal)

#define IActAJ71E71TCP_put_ActTimeOut(This,newVal)	\
    (This)->lpVtbl -> put_ActTimeOut(This,newVal)

#define IActAJ71E71TCP_get_ActDestinationPortNumber(This,pVal)	\
    (This)->lpVtbl -> get_ActDestinationPortNumber(This,pVal)

#define IActAJ71E71TCP_put_ActDestinationPortNumber(This,newVal)	\
    (This)->lpVtbl -> put_ActDestinationPortNumber(This,newVal)

#define IActAJ71E71TCP_GetDevice(This,szDevice,lpdwData,lplReturnCode)	\
    (This)->lpVtbl -> GetDevice(This,szDevice,lpdwData,lplReturnCode)

#define IActAJ71E71TCP_CheckDeviceString(This,szDevice,lCheckType,lSize,lplDeviceType,lpszDeviceName,lplDeviceNumber,lplDeviceRadix,lplReturnCode)	\
    (This)->lpVtbl -> CheckDeviceString(This,szDevice,lCheckType,lSize,lplDeviceType,lpszDeviceName,lplDeviceNumber,lplDeviceRadix,lplReturnCode)

#endif /* COBJMACROS */


#endif 	/* C style interface */



/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE IActAJ71E71TCP_Open_Proxy( 
    IActAJ71E71TCP __RPC_FAR * This,
    /* [retval][out] */ LONG __RPC_FAR *lplReturnCode);


void __RPC_STUB IActAJ71E71TCP_Open_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE IActAJ71E71TCP_Close_Proxy( 
    IActAJ71E71TCP __RPC_FAR * This,
    /* [retval][out] */ LONG __RPC_FAR *lplReturnCode);


void __RPC_STUB IActAJ71E71TCP_Close_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE IActAJ71E71TCP_ReadDeviceBlock_Proxy( 
    IActAJ71E71TCP __RPC_FAR * This,
    /* [string][in] */ BSTR szDevice,
    /* [in] */ LONG dwSize,
    /* [size_is][out] */ LONG __RPC_FAR *lpdwData,
    /* [retval][out] */ LONG __RPC_FAR *lplReturnCode);


void __RPC_STUB IActAJ71E71TCP_ReadDeviceBlock_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE IActAJ71E71TCP_WriteDeviceBlock_Proxy( 
    IActAJ71E71TCP __RPC_FAR * This,
    /* [string][in] */ BSTR szDevice,
    /* [in] */ LONG dwSize,
    /* [size_is][in] */ LONG __RPC_FAR *lpdwData,
    /* [retval][out] */ LONG __RPC_FAR *lplReturnCode);


void __RPC_STUB IActAJ71E71TCP_WriteDeviceBlock_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE IActAJ71E71TCP_ReadDeviceRandom_Proxy( 
    IActAJ71E71TCP __RPC_FAR * This,
    /* [string][in] */ BSTR szDeviceList,
    /* [in] */ LONG dwSize,
    /* [size_is][out] */ LONG __RPC_FAR *lpdwData,
    /* [retval][out] */ LONG __RPC_FAR *lplReturnCode);


void __RPC_STUB IActAJ71E71TCP_ReadDeviceRandom_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE IActAJ71E71TCP_WriteDeviceRandom_Proxy( 
    IActAJ71E71TCP __RPC_FAR * This,
    /* [string][in] */ BSTR szDeviceList,
    /* [in] */ LONG dwSize,
    /* [size_is][in] */ LONG __RPC_FAR *lpdwData,
    /* [retval][out] */ LONG __RPC_FAR *lplReturnCode);


void __RPC_STUB IActAJ71E71TCP_WriteDeviceRandom_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE IActAJ71E71TCP_SetDevice_Proxy( 
    IActAJ71E71TCP __RPC_FAR * This,
    /* [string][in] */ BSTR szDevice,
    /* [in] */ LONG dwData,
    /* [retval][out] */ LONG __RPC_FAR *lplReturnCode);


void __RPC_STUB IActAJ71E71TCP_SetDevice_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE IActAJ71E71TCP_SetCpuStatus_Proxy( 
    IActAJ71E71TCP __RPC_FAR * This,
    /* [in] */ LONG lOperation,
    /* [retval][out] */ LONG __RPC_FAR *lplReturnCode);


void __RPC_STUB IActAJ71E71TCP_SetCpuStatus_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE IActAJ71E71TCP_GetCpuType_Proxy( 
    IActAJ71E71TCP __RPC_FAR * This,
    /* [string][out] */ BSTR __RPC_FAR *lpszCpuName,
    /* [out] */ LONG __RPC_FAR *lplCpuType,
    /* [retval][out] */ LONG __RPC_FAR *lplReturnCode);


void __RPC_STUB IActAJ71E71TCP_GetCpuType_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE IActAJ71E71TCP_get_ActStationNumber_Proxy( 
    IActAJ71E71TCP __RPC_FAR * This,
    /* [retval][out] */ long __RPC_FAR *pVal);


void __RPC_STUB IActAJ71E71TCP_get_ActStationNumber_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE IActAJ71E71TCP_put_ActStationNumber_Proxy( 
    IActAJ71E71TCP __RPC_FAR * This,
    /* [in] */ long newVal);


void __RPC_STUB IActAJ71E71TCP_put_ActStationNumber_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE IActAJ71E71TCP_get_ActCpuType_Proxy( 
    IActAJ71E71TCP __RPC_FAR * This,
    /* [retval][out] */ long __RPC_FAR *pVal);


void __RPC_STUB IActAJ71E71TCP_get_ActCpuType_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE IActAJ71E71TCP_put_ActCpuType_Proxy( 
    IActAJ71E71TCP __RPC_FAR * This,
    /* [in] */ long newVal);


void __RPC_STUB IActAJ71E71TCP_put_ActCpuType_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE IActAJ71E71TCP_get_ActHostAddress_Proxy( 
    IActAJ71E71TCP __RPC_FAR * This,
    /* [retval][string][out] */ BSTR __RPC_FAR *pVal);


void __RPC_STUB IActAJ71E71TCP_get_ActHostAddress_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE IActAJ71E71TCP_put_ActHostAddress_Proxy( 
    IActAJ71E71TCP __RPC_FAR * This,
    /* [string][in] */ BSTR newVal);


void __RPC_STUB IActAJ71E71TCP_put_ActHostAddress_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE IActAJ71E71TCP_get_ActCpuTimeOut_Proxy( 
    IActAJ71E71TCP __RPC_FAR * This,
    /* [retval][out] */ long __RPC_FAR *pVal);


void __RPC_STUB IActAJ71E71TCP_get_ActCpuTimeOut_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE IActAJ71E71TCP_put_ActCpuTimeOut_Proxy( 
    IActAJ71E71TCP __RPC_FAR * This,
    /* [in] */ long newVal);


void __RPC_STUB IActAJ71E71TCP_put_ActCpuTimeOut_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE IActAJ71E71TCP_get_ActTimeOut_Proxy( 
    IActAJ71E71TCP __RPC_FAR * This,
    /* [retval][out] */ long __RPC_FAR *pVal);


void __RPC_STUB IActAJ71E71TCP_get_ActTimeOut_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE IActAJ71E71TCP_put_ActTimeOut_Proxy( 
    IActAJ71E71TCP __RPC_FAR * This,
    /* [in] */ long newVal);


void __RPC_STUB IActAJ71E71TCP_put_ActTimeOut_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE IActAJ71E71TCP_get_ActDestinationPortNumber_Proxy( 
    IActAJ71E71TCP __RPC_FAR * This,
    /* [retval][out] */ long __RPC_FAR *pVal);


void __RPC_STUB IActAJ71E71TCP_get_ActDestinationPortNumber_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE IActAJ71E71TCP_put_ActDestinationPortNumber_Proxy( 
    IActAJ71E71TCP __RPC_FAR * This,
    /* [in] */ long newVal);


void __RPC_STUB IActAJ71E71TCP_put_ActDestinationPortNumber_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE IActAJ71E71TCP_GetDevice_Proxy( 
    IActAJ71E71TCP __RPC_FAR * This,
    /* [string][in] */ BSTR szDevice,
    /* [out] */ LONG __RPC_FAR *lpdwData,
    /* [retval][out] */ LONG __RPC_FAR *lplReturnCode);


void __RPC_STUB IActAJ71E71TCP_GetDevice_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE IActAJ71E71TCP_CheckDeviceString_Proxy( 
    IActAJ71E71TCP __RPC_FAR * This,
    /* [in] */ BSTR szDevice,
    /* [in] */ LONG lCheckType,
    /* [in] */ LONG lSize,
    /* [out] */ LONG __RPC_FAR *lplDeviceType,
    /* [string][out] */ BSTR __RPC_FAR *lpszDeviceName,
    /* [out] */ LONG __RPC_FAR *lplDeviceNumber,
    /* [out] */ LONG __RPC_FAR *lplDeviceRadix,
    /* [retval][out] */ LONG __RPC_FAR *lplReturnCode);


void __RPC_STUB IActAJ71E71TCP_CheckDeviceString_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);



#endif 	/* __IActAJ71E71TCP_INTERFACE_DEFINED__ */


EXTERN_C const CLSID CLSID_ActAJ71QE71UDP;

#ifdef __cplusplus

class DECLSPEC_UUID("AFEA551B-AE9C-11D3-83AE-00A024BDBF2B")
ActAJ71QE71UDP;
#endif

#ifndef ___IActAJ71E71TCPEvents_DISPINTERFACE_DEFINED__
#define ___IActAJ71E71TCPEvents_DISPINTERFACE_DEFINED__

/* dispinterface _IActAJ71E71TCPEvents */
/* [helpstring][uuid] */ 


EXTERN_C const IID DIID__IActAJ71E71TCPEvents;

#if defined(__cplusplus) && !defined(CINTERFACE)

    MIDL_INTERFACE("AFEA551F-AE9C-11D3-83AE-00A024BDBF2B")
    _IActAJ71E71TCPEvents : public IDispatch
    {
    };
    
#else 	/* C style interface */

    typedef struct _IActAJ71E71TCPEventsVtbl
    {
        BEGIN_INTERFACE
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *QueryInterface )( 
            _IActAJ71E71TCPEvents __RPC_FAR * This,
            /* [in] */ REFIID riid,
            /* [iid_is][out] */ void __RPC_FAR *__RPC_FAR *ppvObject);
        
        ULONG ( STDMETHODCALLTYPE __RPC_FAR *AddRef )( 
            _IActAJ71E71TCPEvents __RPC_FAR * This);
        
        ULONG ( STDMETHODCALLTYPE __RPC_FAR *Release )( 
            _IActAJ71E71TCPEvents __RPC_FAR * This);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetTypeInfoCount )( 
            _IActAJ71E71TCPEvents __RPC_FAR * This,
            /* [out] */ UINT __RPC_FAR *pctinfo);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetTypeInfo )( 
            _IActAJ71E71TCPEvents __RPC_FAR * This,
            /* [in] */ UINT iTInfo,
            /* [in] */ LCID lcid,
            /* [out] */ ITypeInfo __RPC_FAR *__RPC_FAR *ppTInfo);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetIDsOfNames )( 
            _IActAJ71E71TCPEvents __RPC_FAR * This,
            /* [in] */ REFIID riid,
            /* [size_is][in] */ LPOLESTR __RPC_FAR *rgszNames,
            /* [in] */ UINT cNames,
            /* [in] */ LCID lcid,
            /* [size_is][out] */ DISPID __RPC_FAR *rgDispId);
        
        /* [local] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *Invoke )( 
            _IActAJ71E71TCPEvents __RPC_FAR * This,
            /* [in] */ DISPID dispIdMember,
            /* [in] */ REFIID riid,
            /* [in] */ LCID lcid,
            /* [in] */ WORD wFlags,
            /* [out][in] */ DISPPARAMS __RPC_FAR *pDispParams,
            /* [out] */ VARIANT __RPC_FAR *pVarResult,
            /* [out] */ EXCEPINFO __RPC_FAR *pExcepInfo,
            /* [out] */ UINT __RPC_FAR *puArgErr);
        
        END_INTERFACE
    } _IActAJ71E71TCPEventsVtbl;

    interface _IActAJ71E71TCPEvents
    {
        CONST_VTBL struct _IActAJ71E71TCPEventsVtbl __RPC_FAR *lpVtbl;
    };

    

#ifdef COBJMACROS


#define _IActAJ71E71TCPEvents_QueryInterface(This,riid,ppvObject)	\
    (This)->lpVtbl -> QueryInterface(This,riid,ppvObject)

#define _IActAJ71E71TCPEvents_AddRef(This)	\
    (This)->lpVtbl -> AddRef(This)

#define _IActAJ71E71TCPEvents_Release(This)	\
    (This)->lpVtbl -> Release(This)


#define _IActAJ71E71TCPEvents_GetTypeInfoCount(This,pctinfo)	\
    (This)->lpVtbl -> GetTypeInfoCount(This,pctinfo)

#define _IActAJ71E71TCPEvents_GetTypeInfo(This,iTInfo,lcid,ppTInfo)	\
    (This)->lpVtbl -> GetTypeInfo(This,iTInfo,lcid,ppTInfo)

#define _IActAJ71E71TCPEvents_GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)	\
    (This)->lpVtbl -> GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)

#define _IActAJ71E71TCPEvents_Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)	\
    (This)->lpVtbl -> Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)

#endif /* COBJMACROS */


#endif 	/* C style interface */


#endif 	/* ___IActAJ71E71TCPEvents_DISPINTERFACE_DEFINED__ */


#ifndef __IActAJ71E71UDP_INTERFACE_DEFINED__
#define __IActAJ71E71UDP_INTERFACE_DEFINED__

/* interface IActAJ71E71UDP */
/* [unique][helpstring][dual][uuid][object] */ 


EXTERN_C const IID IID_IActAJ71E71UDP;

#if defined(__cplusplus) && !defined(CINTERFACE)
    
    MIDL_INTERFACE("AFEA5520-AE9C-11D3-83AE-00A024BDBF2B")
    IActAJ71E71UDP : public IDispatch
    {
    public:
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE Open( 
            /* [retval][out] */ LONG __RPC_FAR *lplReturnCode) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE Close( 
            /* [retval][out] */ LONG __RPC_FAR *lplReturnCode) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE ReadDeviceBlock( 
            /* [string][in] */ BSTR szDevice,
            /* [in] */ LONG dwSize,
            /* [size_is][out] */ LONG __RPC_FAR *lpdwData,
            /* [retval][out] */ LONG __RPC_FAR *lplReturnCode) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE WriteDeviceBlock( 
            /* [string][in] */ BSTR szDevice,
            /* [in] */ LONG dwSize,
            /* [size_is][in] */ LONG __RPC_FAR *lpdwData,
            /* [retval][out] */ LONG __RPC_FAR *lplReturnCode) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE ReadDeviceRandom( 
            /* [string][in] */ BSTR szDeviceList,
            /* [in] */ LONG dwSize,
            /* [size_is][out] */ LONG __RPC_FAR *lpdwData,
            /* [retval][out] */ LONG __RPC_FAR *lplReturnCode) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE WriteDeviceRandom( 
            /* [string][in] */ BSTR szDeviceList,
            /* [in] */ LONG dwSize,
            /* [size_is][in] */ LONG __RPC_FAR *lpdwData,
            /* [retval][out] */ LONG __RPC_FAR *lplReturnCode) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE ReadBuffer( 
            /* [in] */ LONG lStartIO,
            /* [in] */ LONG lAddress,
            /* [in] */ LONG lReadSize,
            /* [out] */ SHORT __RPC_FAR *lpwData,
            /* [retval][out] */ LONG __RPC_FAR *lplReturnCode) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE WriteBuffer( 
            /* [in] */ LONG lStartIO,
            /* [in] */ LONG lAddress,
            /* [in] */ LONG lWriteSize,
            /* [out] */ SHORT __RPC_FAR *lpwData,
            /* [retval][out] */ LONG __RPC_FAR *lplReturnCode) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE GetClockData( 
            /* [out] */ SHORT __RPC_FAR *lpwYear,
            /* [out] */ SHORT __RPC_FAR *lpwMonth,
            /* [out] */ SHORT __RPC_FAR *lpwDay,
            /* [out] */ SHORT __RPC_FAR *lpwDayOfWeek,
            /* [out] */ SHORT __RPC_FAR *lpwHour,
            /* [out] */ SHORT __RPC_FAR *lpwMinute,
            /* [out] */ SHORT __RPC_FAR *lpwSecond,
            /* [retval][out] */ LONG __RPC_FAR *lplReturnCode) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE SetClockData( 
            /* [in] */ SHORT wYear,
            /* [in] */ SHORT wMonth,
            /* [in] */ SHORT wDay,
            /* [in] */ SHORT wDayOfWeek,
            /* [in] */ SHORT wHour,
            /* [in] */ SHORT wMinute,
            /* [in] */ SHORT wSecond,
            /* [retval][out] */ LONG __RPC_FAR *lplReturnCode) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE SetDevice( 
            /* [string][in] */ BSTR szDevice,
            /* [in] */ LONG dwData,
            /* [retval][out] */ LONG __RPC_FAR *lplReturnCode) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE SetCpuStatus( 
            /* [in] */ LONG lOperation,
            /* [retval][out] */ LONG __RPC_FAR *lplReturnCode) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE GetCpuType( 
            /* [string][out] */ BSTR __RPC_FAR *lpszCpuName,
            /* [out] */ LONG __RPC_FAR *lplCpuType,
            /* [retval][out] */ LONG __RPC_FAR *lplReturnCode) = 0;
        
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_ActStationNumber( 
            /* [retval][out] */ long __RPC_FAR *pVal) = 0;
        
        virtual /* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE put_ActStationNumber( 
            /* [in] */ long newVal) = 0;
        
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_ActCpuType( 
            /* [retval][out] */ long __RPC_FAR *pVal) = 0;
        
        virtual /* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE put_ActCpuType( 
            /* [in] */ long newVal) = 0;
        
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_ActPortNumber( 
            /* [retval][out] */ long __RPC_FAR *pVal) = 0;
        
        virtual /* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE put_ActPortNumber( 
            /* [in] */ long newVal) = 0;
        
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_ActHostAddress( 
            /* [retval][string][out] */ BSTR __RPC_FAR *pVal) = 0;
        
        virtual /* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE put_ActHostAddress( 
            /* [string][in] */ BSTR newVal) = 0;
        
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_ActCpuTimeOut( 
            /* [retval][out] */ long __RPC_FAR *pVal) = 0;
        
        virtual /* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE put_ActCpuTimeOut( 
            /* [in] */ long newVal) = 0;
        
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_ActTimeOut( 
            /* [retval][out] */ long __RPC_FAR *pVal) = 0;
        
        virtual /* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE put_ActTimeOut( 
            /* [in] */ long newVal) = 0;
        
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_ActDestinationPortNumber( 
            /* [retval][out] */ long __RPC_FAR *pVal) = 0;
        
        virtual /* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE put_ActDestinationPortNumber( 
            /* [in] */ long newVal) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE GetDevice( 
            /* [string][in] */ BSTR szDevice,
            /* [out] */ LONG __RPC_FAR *lpdwData,
            /* [retval][out] */ LONG __RPC_FAR *lplReturnCode) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE CheckDeviceString( 
            /* [in] */ BSTR szDevice,
            /* [in] */ LONG lCheckType,
            /* [in] */ LONG lSize,
            /* [out] */ LONG __RPC_FAR *lplDeviceType,
            /* [string][out] */ BSTR __RPC_FAR *lpszDeviceName,
            /* [out] */ LONG __RPC_FAR *lplDeviceNumber,
            /* [out] */ LONG __RPC_FAR *lplDeviceRadix,
            /* [retval][out] */ LONG __RPC_FAR *lplReturnCode) = 0;
        
    };
    
#else 	/* C style interface */

    typedef struct IActAJ71E71UDPVtbl
    {
        BEGIN_INTERFACE
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *QueryInterface )( 
            IActAJ71E71UDP __RPC_FAR * This,
            /* [in] */ REFIID riid,
            /* [iid_is][out] */ void __RPC_FAR *__RPC_FAR *ppvObject);
        
        ULONG ( STDMETHODCALLTYPE __RPC_FAR *AddRef )( 
            IActAJ71E71UDP __RPC_FAR * This);
        
        ULONG ( STDMETHODCALLTYPE __RPC_FAR *Release )( 
            IActAJ71E71UDP __RPC_FAR * This);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetTypeInfoCount )( 
            IActAJ71E71UDP __RPC_FAR * This,
            /* [out] */ UINT __RPC_FAR *pctinfo);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetTypeInfo )( 
            IActAJ71E71UDP __RPC_FAR * This,
            /* [in] */ UINT iTInfo,
            /* [in] */ LCID lcid,
            /* [out] */ ITypeInfo __RPC_FAR *__RPC_FAR *ppTInfo);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetIDsOfNames )( 
            IActAJ71E71UDP __RPC_FAR * This,
            /* [in] */ REFIID riid,
            /* [size_is][in] */ LPOLESTR __RPC_FAR *rgszNames,
            /* [in] */ UINT cNames,
            /* [in] */ LCID lcid,
            /* [size_is][out] */ DISPID __RPC_FAR *rgDispId);
        
        /* [local] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *Invoke )( 
            IActAJ71E71UDP __RPC_FAR * This,
            /* [in] */ DISPID dispIdMember,
            /* [in] */ REFIID riid,
            /* [in] */ LCID lcid,
            /* [in] */ WORD wFlags,
            /* [out][in] */ DISPPARAMS __RPC_FAR *pDispParams,
            /* [out] */ VARIANT __RPC_FAR *pVarResult,
            /* [out] */ EXCEPINFO __RPC_FAR *pExcepInfo,
            /* [out] */ UINT __RPC_FAR *puArgErr);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *Open )( 
            IActAJ71E71UDP __RPC_FAR * This,
            /* [retval][out] */ LONG __RPC_FAR *lplReturnCode);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *Close )( 
            IActAJ71E71UDP __RPC_FAR * This,
            /* [retval][out] */ LONG __RPC_FAR *lplReturnCode);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *ReadDeviceBlock )( 
            IActAJ71E71UDP __RPC_FAR * This,
            /* [string][in] */ BSTR szDevice,
            /* [in] */ LONG dwSize,
            /* [size_is][out] */ LONG __RPC_FAR *lpdwData,
            /* [retval][out] */ LONG __RPC_FAR *lplReturnCode);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *WriteDeviceBlock )( 
            IActAJ71E71UDP __RPC_FAR * This,
            /* [string][in] */ BSTR szDevice,
            /* [in] */ LONG dwSize,
            /* [size_is][in] */ LONG __RPC_FAR *lpdwData,
            /* [retval][out] */ LONG __RPC_FAR *lplReturnCode);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *ReadDeviceRandom )( 
            IActAJ71E71UDP __RPC_FAR * This,
            /* [string][in] */ BSTR szDeviceList,
            /* [in] */ LONG dwSize,
            /* [size_is][out] */ LONG __RPC_FAR *lpdwData,
            /* [retval][out] */ LONG __RPC_FAR *lplReturnCode);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *WriteDeviceRandom )( 
            IActAJ71E71UDP __RPC_FAR * This,
            /* [string][in] */ BSTR szDeviceList,
            /* [in] */ LONG dwSize,
            /* [size_is][in] */ LONG __RPC_FAR *lpdwData,
            /* [retval][out] */ LONG __RPC_FAR *lplReturnCode);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *ReadBuffer )( 
            IActAJ71E71UDP __RPC_FAR * This,
            /* [in] */ LONG lStartIO,
            /* [in] */ LONG lAddress,
            /* [in] */ LONG lReadSize,
            /* [out] */ SHORT __RPC_FAR *lpwData,
            /* [retval][out] */ LONG __RPC_FAR *lplReturnCode);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *WriteBuffer )( 
            IActAJ71E71UDP __RPC_FAR * This,
            /* [in] */ LONG lStartIO,
            /* [in] */ LONG lAddress,
            /* [in] */ LONG lWriteSize,
            /* [out] */ SHORT __RPC_FAR *lpwData,
            /* [retval][out] */ LONG __RPC_FAR *lplReturnCode);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetClockData )( 
            IActAJ71E71UDP __RPC_FAR * This,
            /* [out] */ SHORT __RPC_FAR *lpwYear,
            /* [out] */ SHORT __RPC_FAR *lpwMonth,
            /* [out] */ SHORT __RPC_FAR *lpwDay,
            /* [out] */ SHORT __RPC_FAR *lpwDayOfWeek,
            /* [out] */ SHORT __RPC_FAR *lpwHour,
            /* [out] */ SHORT __RPC_FAR *lpwMinute,
            /* [out] */ SHORT __RPC_FAR *lpwSecond,
            /* [retval][out] */ LONG __RPC_FAR *lplReturnCode);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *SetClockData )( 
            IActAJ71E71UDP __RPC_FAR * This,
            /* [in] */ SHORT wYear,
            /* [in] */ SHORT wMonth,
            /* [in] */ SHORT wDay,
            /* [in] */ SHORT wDayOfWeek,
            /* [in] */ SHORT wHour,
            /* [in] */ SHORT wMinute,
            /* [in] */ SHORT wSecond,
            /* [retval][out] */ LONG __RPC_FAR *lplReturnCode);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *SetDevice )( 
            IActAJ71E71UDP __RPC_FAR * This,
            /* [string][in] */ BSTR szDevice,
            /* [in] */ LONG dwData,
            /* [retval][out] */ LONG __RPC_FAR *lplReturnCode);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *SetCpuStatus )( 
            IActAJ71E71UDP __RPC_FAR * This,
            /* [in] */ LONG lOperation,
            /* [retval][out] */ LONG __RPC_FAR *lplReturnCode);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetCpuType )( 
            IActAJ71E71UDP __RPC_FAR * This,
            /* [string][out] */ BSTR __RPC_FAR *lpszCpuName,
            /* [out] */ LONG __RPC_FAR *lplCpuType,
            /* [retval][out] */ LONG __RPC_FAR *lplReturnCode);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_ActStationNumber )( 
            IActAJ71E71UDP __RPC_FAR * This,
            /* [retval][out] */ long __RPC_FAR *pVal);
        
        /* [helpstring][id][propput] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *put_ActStationNumber )( 
            IActAJ71E71UDP __RPC_FAR * This,
            /* [in] */ long newVal);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_ActCpuType )( 
            IActAJ71E71UDP __RPC_FAR * This,
            /* [retval][out] */ long __RPC_FAR *pVal);
        
        /* [helpstring][id][propput] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *put_ActCpuType )( 
            IActAJ71E71UDP __RPC_FAR * This,
            /* [in] */ long newVal);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_ActPortNumber )( 
            IActAJ71E71UDP __RPC_FAR * This,
            /* [retval][out] */ long __RPC_FAR *pVal);
        
        /* [helpstring][id][propput] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *put_ActPortNumber )( 
            IActAJ71E71UDP __RPC_FAR * This,
            /* [in] */ long newVal);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_ActHostAddress )( 
            IActAJ71E71UDP __RPC_FAR * This,
            /* [retval][string][out] */ BSTR __RPC_FAR *pVal);
        
        /* [helpstring][id][propput] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *put_ActHostAddress )( 
            IActAJ71E71UDP __RPC_FAR * This,
            /* [string][in] */ BSTR newVal);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_ActCpuTimeOut )( 
            IActAJ71E71UDP __RPC_FAR * This,
            /* [retval][out] */ long __RPC_FAR *pVal);
        
        /* [helpstring][id][propput] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *put_ActCpuTimeOut )( 
            IActAJ71E71UDP __RPC_FAR * This,
            /* [in] */ long newVal);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_ActTimeOut )( 
            IActAJ71E71UDP __RPC_FAR * This,
            /* [retval][out] */ long __RPC_FAR *pVal);
        
        /* [helpstring][id][propput] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *put_ActTimeOut )( 
            IActAJ71E71UDP __RPC_FAR * This,
            /* [in] */ long newVal);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_ActDestinationPortNumber )( 
            IActAJ71E71UDP __RPC_FAR * This,
            /* [retval][out] */ long __RPC_FAR *pVal);
        
        /* [helpstring][id][propput] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *put_ActDestinationPortNumber )( 
            IActAJ71E71UDP __RPC_FAR * This,
            /* [in] */ long newVal);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetDevice )( 
            IActAJ71E71UDP __RPC_FAR * This,
            /* [string][in] */ BSTR szDevice,
            /* [out] */ LONG __RPC_FAR *lpdwData,
            /* [retval][out] */ LONG __RPC_FAR *lplReturnCode);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *CheckDeviceString )( 
            IActAJ71E71UDP __RPC_FAR * This,
            /* [in] */ BSTR szDevice,
            /* [in] */ LONG lCheckType,
            /* [in] */ LONG lSize,
            /* [out] */ LONG __RPC_FAR *lplDeviceType,
            /* [string][out] */ BSTR __RPC_FAR *lpszDeviceName,
            /* [out] */ LONG __RPC_FAR *lplDeviceNumber,
            /* [out] */ LONG __RPC_FAR *lplDeviceRadix,
            /* [retval][out] */ LONG __RPC_FAR *lplReturnCode);
        
        END_INTERFACE
    } IActAJ71E71UDPVtbl;

    interface IActAJ71E71UDP
    {
        CONST_VTBL struct IActAJ71E71UDPVtbl __RPC_FAR *lpVtbl;
    };

    

#ifdef COBJMACROS


#define IActAJ71E71UDP_QueryInterface(This,riid,ppvObject)	\
    (This)->lpVtbl -> QueryInterface(This,riid,ppvObject)

#define IActAJ71E71UDP_AddRef(This)	\
    (This)->lpVtbl -> AddRef(This)

#define IActAJ71E71UDP_Release(This)	\
    (This)->lpVtbl -> Release(This)


#define IActAJ71E71UDP_GetTypeInfoCount(This,pctinfo)	\
    (This)->lpVtbl -> GetTypeInfoCount(This,pctinfo)

#define IActAJ71E71UDP_GetTypeInfo(This,iTInfo,lcid,ppTInfo)	\
    (This)->lpVtbl -> GetTypeInfo(This,iTInfo,lcid,ppTInfo)

#define IActAJ71E71UDP_GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)	\
    (This)->lpVtbl -> GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)

#define IActAJ71E71UDP_Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)	\
    (This)->lpVtbl -> Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)


#define IActAJ71E71UDP_Open(This,lplReturnCode)	\
    (This)->lpVtbl -> Open(This,lplReturnCode)

#define IActAJ71E71UDP_Close(This,lplReturnCode)	\
    (This)->lpVtbl -> Close(This,lplReturnCode)

#define IActAJ71E71UDP_ReadDeviceBlock(This,szDevice,dwSize,lpdwData,lplReturnCode)	\
    (This)->lpVtbl -> ReadDeviceBlock(This,szDevice,dwSize,lpdwData,lplReturnCode)

#define IActAJ71E71UDP_WriteDeviceBlock(This,szDevice,dwSize,lpdwData,lplReturnCode)	\
    (This)->lpVtbl -> WriteDeviceBlock(This,szDevice,dwSize,lpdwData,lplReturnCode)

#define IActAJ71E71UDP_ReadDeviceRandom(This,szDeviceList,dwSize,lpdwData,lplReturnCode)	\
    (This)->lpVtbl -> ReadDeviceRandom(This,szDeviceList,dwSize,lpdwData,lplReturnCode)

#define IActAJ71E71UDP_WriteDeviceRandom(This,szDeviceList,dwSize,lpdwData,lplReturnCode)	\
    (This)->lpVtbl -> WriteDeviceRandom(This,szDeviceList,dwSize,lpdwData,lplReturnCode)

#define IActAJ71E71UDP_ReadBuffer(This,lStartIO,lAddress,lReadSize,lpwData,lplReturnCode)	\
    (This)->lpVtbl -> ReadBuffer(This,lStartIO,lAddress,lReadSize,lpwData,lplReturnCode)

#define IActAJ71E71UDP_WriteBuffer(This,lStartIO,lAddress,lWriteSize,lpwData,lplReturnCode)	\
    (This)->lpVtbl -> WriteBuffer(This,lStartIO,lAddress,lWriteSize,lpwData,lplReturnCode)

#define IActAJ71E71UDP_GetClockData(This,lpwYear,lpwMonth,lpwDay,lpwDayOfWeek,lpwHour,lpwMinute,lpwSecond,lplReturnCode)	\
    (This)->lpVtbl -> GetClockData(This,lpwYear,lpwMonth,lpwDay,lpwDayOfWeek,lpwHour,lpwMinute,lpwSecond,lplReturnCode)

#define IActAJ71E71UDP_SetClockData(This,wYear,wMonth,wDay,wDayOfWeek,wHour,wMinute,wSecond,lplReturnCode)	\
    (This)->lpVtbl -> SetClockData(This,wYear,wMonth,wDay,wDayOfWeek,wHour,wMinute,wSecond,lplReturnCode)

#define IActAJ71E71UDP_SetDevice(This,szDevice,dwData,lplReturnCode)	\
    (This)->lpVtbl -> SetDevice(This,szDevice,dwData,lplReturnCode)

#define IActAJ71E71UDP_SetCpuStatus(This,lOperation,lplReturnCode)	\
    (This)->lpVtbl -> SetCpuStatus(This,lOperation,lplReturnCode)

#define IActAJ71E71UDP_GetCpuType(This,lpszCpuName,lplCpuType,lplReturnCode)	\
    (This)->lpVtbl -> GetCpuType(This,lpszCpuName,lplCpuType,lplReturnCode)

#define IActAJ71E71UDP_get_ActStationNumber(This,pVal)	\
    (This)->lpVtbl -> get_ActStationNumber(This,pVal)

#define IActAJ71E71UDP_put_ActStationNumber(This,newVal)	\
    (This)->lpVtbl -> put_ActStationNumber(This,newVal)

#define IActAJ71E71UDP_get_ActCpuType(This,pVal)	\
    (This)->lpVtbl -> get_ActCpuType(This,pVal)

#define IActAJ71E71UDP_put_ActCpuType(This,newVal)	\
    (This)->lpVtbl -> put_ActCpuType(This,newVal)

#define IActAJ71E71UDP_get_ActPortNumber(This,pVal)	\
    (This)->lpVtbl -> get_ActPortNumber(This,pVal)

#define IActAJ71E71UDP_put_ActPortNumber(This,newVal)	\
    (This)->lpVtbl -> put_ActPortNumber(This,newVal)

#define IActAJ71E71UDP_get_ActHostAddress(This,pVal)	\
    (This)->lpVtbl -> get_ActHostAddress(This,pVal)

#define IActAJ71E71UDP_put_ActHostAddress(This,newVal)	\
    (This)->lpVtbl -> put_ActHostAddress(This,newVal)

#define IActAJ71E71UDP_get_ActCpuTimeOut(This,pVal)	\
    (This)->lpVtbl -> get_ActCpuTimeOut(This,pVal)

#define IActAJ71E71UDP_put_ActCpuTimeOut(This,newVal)	\
    (This)->lpVtbl -> put_ActCpuTimeOut(This,newVal)

#define IActAJ71E71UDP_get_ActTimeOut(This,pVal)	\
    (This)->lpVtbl -> get_ActTimeOut(This,pVal)

#define IActAJ71E71UDP_put_ActTimeOut(This,newVal)	\
    (This)->lpVtbl -> put_ActTimeOut(This,newVal)

#define IActAJ71E71UDP_get_ActDestinationPortNumber(This,pVal)	\
    (This)->lpVtbl -> get_ActDestinationPortNumber(This,pVal)

#define IActAJ71E71UDP_put_ActDestinationPortNumber(This,newVal)	\
    (This)->lpVtbl -> put_ActDestinationPortNumber(This,newVal)

#define IActAJ71E71UDP_GetDevice(This,szDevice,lpdwData,lplReturnCode)	\
    (This)->lpVtbl -> GetDevice(This,szDevice,lpdwData,lplReturnCode)

#define IActAJ71E71UDP_CheckDeviceString(This,szDevice,lCheckType,lSize,lplDeviceType,lpszDeviceName,lplDeviceNumber,lplDeviceRadix,lplReturnCode)	\
    (This)->lpVtbl -> CheckDeviceString(This,szDevice,lCheckType,lSize,lplDeviceType,lpszDeviceName,lplDeviceNumber,lplDeviceRadix,lplReturnCode)

#endif /* COBJMACROS */


#endif 	/* C style interface */



/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE IActAJ71E71UDP_Open_Proxy( 
    IActAJ71E71UDP __RPC_FAR * This,
    /* [retval][out] */ LONG __RPC_FAR *lplReturnCode);


void __RPC_STUB IActAJ71E71UDP_Open_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE IActAJ71E71UDP_Close_Proxy( 
    IActAJ71E71UDP __RPC_FAR * This,
    /* [retval][out] */ LONG __RPC_FAR *lplReturnCode);


void __RPC_STUB IActAJ71E71UDP_Close_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE IActAJ71E71UDP_ReadDeviceBlock_Proxy( 
    IActAJ71E71UDP __RPC_FAR * This,
    /* [string][in] */ BSTR szDevice,
    /* [in] */ LONG dwSize,
    /* [size_is][out] */ LONG __RPC_FAR *lpdwData,
    /* [retval][out] */ LONG __RPC_FAR *lplReturnCode);


void __RPC_STUB IActAJ71E71UDP_ReadDeviceBlock_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE IActAJ71E71UDP_WriteDeviceBlock_Proxy( 
    IActAJ71E71UDP __RPC_FAR * This,
    /* [string][in] */ BSTR szDevice,
    /* [in] */ LONG dwSize,
    /* [size_is][in] */ LONG __RPC_FAR *lpdwData,
    /* [retval][out] */ LONG __RPC_FAR *lplReturnCode);


void __RPC_STUB IActAJ71E71UDP_WriteDeviceBlock_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE IActAJ71E71UDP_ReadDeviceRandom_Proxy( 
    IActAJ71E71UDP __RPC_FAR * This,
    /* [string][in] */ BSTR szDeviceList,
    /* [in] */ LONG dwSize,
    /* [size_is][out] */ LONG __RPC_FAR *lpdwData,
    /* [retval][out] */ LONG __RPC_FAR *lplReturnCode);


void __RPC_STUB IActAJ71E71UDP_ReadDeviceRandom_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE IActAJ71E71UDP_WriteDeviceRandom_Proxy( 
    IActAJ71E71UDP __RPC_FAR * This,
    /* [string][in] */ BSTR szDeviceList,
    /* [in] */ LONG dwSize,
    /* [size_is][in] */ LONG __RPC_FAR *lpdwData,
    /* [retval][out] */ LONG __RPC_FAR *lplReturnCode);


void __RPC_STUB IActAJ71E71UDP_WriteDeviceRandom_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE IActAJ71E71UDP_ReadBuffer_Proxy( 
    IActAJ71E71UDP __RPC_FAR * This,
    /* [in] */ LONG lStartIO,
    /* [in] */ LONG lAddress,
    /* [in] */ LONG lReadSize,
    /* [out] */ SHORT __RPC_FAR *lpwData,
    /* [retval][out] */ LONG __RPC_FAR *lplReturnCode);


void __RPC_STUB IActAJ71E71UDP_ReadBuffer_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE IActAJ71E71UDP_WriteBuffer_Proxy( 
    IActAJ71E71UDP __RPC_FAR * This,
    /* [in] */ LONG lStartIO,
    /* [in] */ LONG lAddress,
    /* [in] */ LONG lWriteSize,
    /* [out] */ SHORT __RPC_FAR *lpwData,
    /* [retval][out] */ LONG __RPC_FAR *lplReturnCode);


void __RPC_STUB IActAJ71E71UDP_WriteBuffer_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE IActAJ71E71UDP_GetClockData_Proxy( 
    IActAJ71E71UDP __RPC_FAR * This,
    /* [out] */ SHORT __RPC_FAR *lpwYear,
    /* [out] */ SHORT __RPC_FAR *lpwMonth,
    /* [out] */ SHORT __RPC_FAR *lpwDay,
    /* [out] */ SHORT __RPC_FAR *lpwDayOfWeek,
    /* [out] */ SHORT __RPC_FAR *lpwHour,
    /* [out] */ SHORT __RPC_FAR *lpwMinute,
    /* [out] */ SHORT __RPC_FAR *lpwSecond,
    /* [retval][out] */ LONG __RPC_FAR *lplReturnCode);


void __RPC_STUB IActAJ71E71UDP_GetClockData_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE IActAJ71E71UDP_SetClockData_Proxy( 
    IActAJ71E71UDP __RPC_FAR * This,
    /* [in] */ SHORT wYear,
    /* [in] */ SHORT wMonth,
    /* [in] */ SHORT wDay,
    /* [in] */ SHORT wDayOfWeek,
    /* [in] */ SHORT wHour,
    /* [in] */ SHORT wMinute,
    /* [in] */ SHORT wSecond,
    /* [retval][out] */ LONG __RPC_FAR *lplReturnCode);


void __RPC_STUB IActAJ71E71UDP_SetClockData_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE IActAJ71E71UDP_SetDevice_Proxy( 
    IActAJ71E71UDP __RPC_FAR * This,
    /* [string][in] */ BSTR szDevice,
    /* [in] */ LONG dwData,
    /* [retval][out] */ LONG __RPC_FAR *lplReturnCode);


void __RPC_STUB IActAJ71E71UDP_SetDevice_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE IActAJ71E71UDP_SetCpuStatus_Proxy( 
    IActAJ71E71UDP __RPC_FAR * This,
    /* [in] */ LONG lOperation,
    /* [retval][out] */ LONG __RPC_FAR *lplReturnCode);


void __RPC_STUB IActAJ71E71UDP_SetCpuStatus_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE IActAJ71E71UDP_GetCpuType_Proxy( 
    IActAJ71E71UDP __RPC_FAR * This,
    /* [string][out] */ BSTR __RPC_FAR *lpszCpuName,
    /* [out] */ LONG __RPC_FAR *lplCpuType,
    /* [retval][out] */ LONG __RPC_FAR *lplReturnCode);


void __RPC_STUB IActAJ71E71UDP_GetCpuType_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE IActAJ71E71UDP_get_ActStationNumber_Proxy( 
    IActAJ71E71UDP __RPC_FAR * This,
    /* [retval][out] */ long __RPC_FAR *pVal);


void __RPC_STUB IActAJ71E71UDP_get_ActStationNumber_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE IActAJ71E71UDP_put_ActStationNumber_Proxy( 
    IActAJ71E71UDP __RPC_FAR * This,
    /* [in] */ long newVal);


void __RPC_STUB IActAJ71E71UDP_put_ActStationNumber_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE IActAJ71E71UDP_get_ActCpuType_Proxy( 
    IActAJ71E71UDP __RPC_FAR * This,
    /* [retval][out] */ long __RPC_FAR *pVal);


void __RPC_STUB IActAJ71E71UDP_get_ActCpuType_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE IActAJ71E71UDP_put_ActCpuType_Proxy( 
    IActAJ71E71UDP __RPC_FAR * This,
    /* [in] */ long newVal);


void __RPC_STUB IActAJ71E71UDP_put_ActCpuType_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE IActAJ71E71UDP_get_ActPortNumber_Proxy( 
    IActAJ71E71UDP __RPC_FAR * This,
    /* [retval][out] */ long __RPC_FAR *pVal);


void __RPC_STUB IActAJ71E71UDP_get_ActPortNumber_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE IActAJ71E71UDP_put_ActPortNumber_Proxy( 
    IActAJ71E71UDP __RPC_FAR * This,
    /* [in] */ long newVal);


void __RPC_STUB IActAJ71E71UDP_put_ActPortNumber_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE IActAJ71E71UDP_get_ActHostAddress_Proxy( 
    IActAJ71E71UDP __RPC_FAR * This,
    /* [retval][string][out] */ BSTR __RPC_FAR *pVal);


void __RPC_STUB IActAJ71E71UDP_get_ActHostAddress_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE IActAJ71E71UDP_put_ActHostAddress_Proxy( 
    IActAJ71E71UDP __RPC_FAR * This,
    /* [string][in] */ BSTR newVal);


void __RPC_STUB IActAJ71E71UDP_put_ActHostAddress_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE IActAJ71E71UDP_get_ActCpuTimeOut_Proxy( 
    IActAJ71E71UDP __RPC_FAR * This,
    /* [retval][out] */ long __RPC_FAR *pVal);


void __RPC_STUB IActAJ71E71UDP_get_ActCpuTimeOut_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE IActAJ71E71UDP_put_ActCpuTimeOut_Proxy( 
    IActAJ71E71UDP __RPC_FAR * This,
    /* [in] */ long newVal);


void __RPC_STUB IActAJ71E71UDP_put_ActCpuTimeOut_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE IActAJ71E71UDP_get_ActTimeOut_Proxy( 
    IActAJ71E71UDP __RPC_FAR * This,
    /* [retval][out] */ long __RPC_FAR *pVal);


void __RPC_STUB IActAJ71E71UDP_get_ActTimeOut_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE IActAJ71E71UDP_put_ActTimeOut_Proxy( 
    IActAJ71E71UDP __RPC_FAR * This,
    /* [in] */ long newVal);


void __RPC_STUB IActAJ71E71UDP_put_ActTimeOut_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE IActAJ71E71UDP_get_ActDestinationPortNumber_Proxy( 
    IActAJ71E71UDP __RPC_FAR * This,
    /* [retval][out] */ long __RPC_FAR *pVal);


void __RPC_STUB IActAJ71E71UDP_get_ActDestinationPortNumber_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE IActAJ71E71UDP_put_ActDestinationPortNumber_Proxy( 
    IActAJ71E71UDP __RPC_FAR * This,
    /* [in] */ long newVal);


void __RPC_STUB IActAJ71E71UDP_put_ActDestinationPortNumber_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE IActAJ71E71UDP_GetDevice_Proxy( 
    IActAJ71E71UDP __RPC_FAR * This,
    /* [string][in] */ BSTR szDevice,
    /* [out] */ LONG __RPC_FAR *lpdwData,
    /* [retval][out] */ LONG __RPC_FAR *lplReturnCode);


void __RPC_STUB IActAJ71E71UDP_GetDevice_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE IActAJ71E71UDP_CheckDeviceString_Proxy( 
    IActAJ71E71UDP __RPC_FAR * This,
    /* [in] */ BSTR szDevice,
    /* [in] */ LONG lCheckType,
    /* [in] */ LONG lSize,
    /* [out] */ LONG __RPC_FAR *lplDeviceType,
    /* [string][out] */ BSTR __RPC_FAR *lpszDeviceName,
    /* [out] */ LONG __RPC_FAR *lplDeviceNumber,
    /* [out] */ LONG __RPC_FAR *lplDeviceRadix,
    /* [retval][out] */ LONG __RPC_FAR *lplReturnCode);


void __RPC_STUB IActAJ71E71UDP_CheckDeviceString_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);



#endif 	/* __IActAJ71E71UDP_INTERFACE_DEFINED__ */


EXTERN_C const CLSID CLSID_ActAJ71E71TCP;

#ifdef __cplusplus

class DECLSPEC_UUID("AFEA551E-AE9C-11D3-83AE-00A024BDBF2B")
ActAJ71E71TCP;
#endif

#ifndef ___IActAJ71E71UDPEvents_DISPINTERFACE_DEFINED__
#define ___IActAJ71E71UDPEvents_DISPINTERFACE_DEFINED__

/* dispinterface _IActAJ71E71UDPEvents */
/* [helpstring][uuid] */ 


EXTERN_C const IID DIID__IActAJ71E71UDPEvents;

#if defined(__cplusplus) && !defined(CINTERFACE)

    MIDL_INTERFACE("AFEA5522-AE9C-11D3-83AE-00A024BDBF2B")
    _IActAJ71E71UDPEvents : public IDispatch
    {
    };
    
#else 	/* C style interface */

    typedef struct _IActAJ71E71UDPEventsVtbl
    {
        BEGIN_INTERFACE
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *QueryInterface )( 
            _IActAJ71E71UDPEvents __RPC_FAR * This,
            /* [in] */ REFIID riid,
            /* [iid_is][out] */ void __RPC_FAR *__RPC_FAR *ppvObject);
        
        ULONG ( STDMETHODCALLTYPE __RPC_FAR *AddRef )( 
            _IActAJ71E71UDPEvents __RPC_FAR * This);
        
        ULONG ( STDMETHODCALLTYPE __RPC_FAR *Release )( 
            _IActAJ71E71UDPEvents __RPC_FAR * This);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetTypeInfoCount )( 
            _IActAJ71E71UDPEvents __RPC_FAR * This,
            /* [out] */ UINT __RPC_FAR *pctinfo);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetTypeInfo )( 
            _IActAJ71E71UDPEvents __RPC_FAR * This,
            /* [in] */ UINT iTInfo,
            /* [in] */ LCID lcid,
            /* [out] */ ITypeInfo __RPC_FAR *__RPC_FAR *ppTInfo);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetIDsOfNames )( 
            _IActAJ71E71UDPEvents __RPC_FAR * This,
            /* [in] */ REFIID riid,
            /* [size_is][in] */ LPOLESTR __RPC_FAR *rgszNames,
            /* [in] */ UINT cNames,
            /* [in] */ LCID lcid,
            /* [size_is][out] */ DISPID __RPC_FAR *rgDispId);
        
        /* [local] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *Invoke )( 
            _IActAJ71E71UDPEvents __RPC_FAR * This,
            /* [in] */ DISPID dispIdMember,
            /* [in] */ REFIID riid,
            /* [in] */ LCID lcid,
            /* [in] */ WORD wFlags,
            /* [out][in] */ DISPPARAMS __RPC_FAR *pDispParams,
            /* [out] */ VARIANT __RPC_FAR *pVarResult,
            /* [out] */ EXCEPINFO __RPC_FAR *pExcepInfo,
            /* [out] */ UINT __RPC_FAR *puArgErr);
        
        END_INTERFACE
    } _IActAJ71E71UDPEventsVtbl;

    interface _IActAJ71E71UDPEvents
    {
        CONST_VTBL struct _IActAJ71E71UDPEventsVtbl __RPC_FAR *lpVtbl;
    };

    

#ifdef COBJMACROS


#define _IActAJ71E71UDPEvents_QueryInterface(This,riid,ppvObject)	\
    (This)->lpVtbl -> QueryInterface(This,riid,ppvObject)

#define _IActAJ71E71UDPEvents_AddRef(This)	\
    (This)->lpVtbl -> AddRef(This)

#define _IActAJ71E71UDPEvents_Release(This)	\
    (This)->lpVtbl -> Release(This)


#define _IActAJ71E71UDPEvents_GetTypeInfoCount(This,pctinfo)	\
    (This)->lpVtbl -> GetTypeInfoCount(This,pctinfo)

#define _IActAJ71E71UDPEvents_GetTypeInfo(This,iTInfo,lcid,ppTInfo)	\
    (This)->lpVtbl -> GetTypeInfo(This,iTInfo,lcid,ppTInfo)

#define _IActAJ71E71UDPEvents_GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)	\
    (This)->lpVtbl -> GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)

#define _IActAJ71E71UDPEvents_Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)	\
    (This)->lpVtbl -> Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)

#endif /* COBJMACROS */


#endif 	/* C style interface */


#endif 	/* ___IActAJ71E71UDPEvents_DISPINTERFACE_DEFINED__ */


EXTERN_C const CLSID CLSID_ActAJ71E71UDP;

#ifdef __cplusplus

class DECLSPEC_UUID("AFEA5521-AE9C-11D3-83AE-00A024BDBF2B")
ActAJ71E71UDP;
#endif
#endif /* __ACTETHERLib_LIBRARY_DEFINED__ */

/* Additional Prototypes for ALL interfaces */

unsigned long             __RPC_USER  BSTR_UserSize(     unsigned long __RPC_FAR *, unsigned long            , BSTR __RPC_FAR * ); 
unsigned char __RPC_FAR * __RPC_USER  BSTR_UserMarshal(  unsigned long __RPC_FAR *, unsigned char __RPC_FAR *, BSTR __RPC_FAR * ); 
unsigned char __RPC_FAR * __RPC_USER  BSTR_UserUnmarshal(unsigned long __RPC_FAR *, unsigned char __RPC_FAR *, BSTR __RPC_FAR * ); 
void                      __RPC_USER  BSTR_UserFree(     unsigned long __RPC_FAR *, BSTR __RPC_FAR * ); 

/* end of Additional Prototypes */

#ifdef __cplusplus
}
#endif

#endif
