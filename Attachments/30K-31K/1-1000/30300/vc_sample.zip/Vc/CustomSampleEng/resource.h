//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by CustomSampleEng.rc
//
#define IDM_ABOUTBOX                    0x0010
#define IDD_ABOUTBOX                    100
#define IDS_ABOUTBOX                    101
#define IDD_CUSTOMSAMPLEENG_DIALOG      102
#define IDS_STRING102                   102
#define IDS_STRING103                   103
#define IDR_MAINFRAME                   128
#define IDC_GetDevice                   1002
#define IDC_SetDevice                   1003
#define IDC_RET                         1004
#define IDC_OpenCom                     1007
#define IDC_CloseCom                    1008
#define IDC_RADIO1                      1010
#define IDC_RADIO2                      1011
#define IDC_DEVICE                      1013
#define IDC_DEVVALUE                    1014
#define IDC_RET2                        1015
#define IDC_GetCpuType                  1016
#define IDC_RET3                        1017

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        129
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1000
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
