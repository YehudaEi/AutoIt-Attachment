// CustomSampleEngDlg.cpp : implementation file
//

#include "stdafx.h"
#include "CustomSampleEng.h"

/***************************************************/
#include "ActMulti.h"	// For ActEasyIF Contorol
#include "ActEther.h"	// For Ethernet Communication Contorol
#include "ActDefine.h"	// ACT Common Macro Header 

#include "ActMulti_i.c"	// For CustomInterface
#include "ActEther_i.c"	// For CustomInterface
/***************************************************/

#include "CustomSampleEngDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CAboutDlg dialog used for App About

class CAboutDlg : public CDialog
{
public:
	CAboutDlg();

// Dialog Data
	//{{AFX_DATA(CAboutDlg)
	enum { IDD = IDD_ABOUTBOX };
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CAboutDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	//{{AFX_MSG(CAboutDlg)
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

CAboutDlg::CAboutDlg() : CDialog(CAboutDlg::IDD)
{
	//{{AFX_DATA_INIT(CAboutDlg)
	//}}AFX_DATA_INIT
}

void CAboutDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CAboutDlg)
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CAboutDlg, CDialog)
	//{{AFX_MSG_MAP(CAboutDlg)
		// No message handlers
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CCustomSampleEngDlg dialog

CCustomSampleEngDlg::CCustomSampleEngDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CCustomSampleEngDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CCustomSampleEngDlg)
	m_Device = _T("");
	m_DeviceValue = 0;
	m_SelectCntl = 0;
	m_RetVal = _T("");
	m_RetVal2 = _T("");
	m_RetVal3 = _T("");
	//}}AFX_DATA_INIT
	// Note that LoadIcon does not require a subsequent DestroyIcon in Win32
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
}

void CCustomSampleEngDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CCustomSampleEngDlg)
	DDX_Text(pDX, IDC_DEVICE, m_Device);
	DDX_Text(pDX, IDC_DEVVALUE, m_DeviceValue);
	DDX_Radio(pDX, IDC_RADIO1, m_SelectCntl);
	DDX_Text(pDX, IDC_RET, m_RetVal);
	DDX_Text(pDX, IDC_RET2, m_RetVal2);
	DDX_Text(pDX, IDC_RET3, m_RetVal3);
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CCustomSampleEngDlg, CDialog)
	//{{AFX_MSG_MAP(CCustomSampleEngDlg)
	ON_WM_SYSCOMMAND()
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	ON_BN_CLICKED(IDC_OpenCom, OnOpenCom)
	ON_BN_CLICKED(IDC_GetCpuType, OnGetCpuType)
	ON_BN_CLICKED(IDC_GetDevice, OnGetDevice)
	ON_BN_CLICKED(IDC_SetDevice, OnSetDevice)
	ON_BN_CLICKED(IDC_CloseCom, OnCloseCom)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CCustomSampleEngDlg message handlers

BOOL CCustomSampleEngDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	// Add "About..." menu item to system menu.

	// IDM_ABOUTBOX must be in the system command range.
	ASSERT((IDM_ABOUTBOX & 0xFFF0) == IDM_ABOUTBOX);
	ASSERT(IDM_ABOUTBOX < 0xF000);

	CMenu* pSysMenu = GetSystemMenu(FALSE);
	if (pSysMenu != NULL)
	{
		CString strAboutMenu;
		strAboutMenu.LoadString(IDS_ABOUTBOX);
		if (!strAboutMenu.IsEmpty())
		{
			pSysMenu->AppendMenu(MF_SEPARATOR);
			pSysMenu->AppendMenu(MF_STRING, IDM_ABOUTBOX, strAboutMenu);
		}
	}

	// Set the icon for this dialog.  The framework does this automatically
	//  when the application's main window is not a dialog
	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon
	
	// TODO: Add extra initialization here
    /***************************************************/
	/* ACT Compornent Instance Create                  */	
	// ActAJ71QE71UDP Control 
	HRESULT	hr = CoCreateInstance(	CLSID_ActAJ71QE71UDP,
									NULL,
									CLSCTX_INPROC_SERVER,
									IID_IActAJ71QE71UDP,
									(LPVOID*)&mp_IAJ71QE71UDP);
	if(!SUCCEEDED(hr)){
		AfxMessageBox("CoCrateInstance() Failed.");
		exit(0);	
	}
	// ActEasyIF Control
	hr = CoCreateInstance(	CLSID_ActEasyIF,
							NULL,
							CLSCTX_INPROC_SERVER,
							IID_IActEasyIF,
							(LPVOID*)&mp_IEasyIF);
	if(!SUCCEEDED(hr)){
		AfxMessageBox("CoCrateInstance() Failed.");
		exit(0);
	}	
	/*                                                 */
	/***************************************************/	
	
	return TRUE;  // return TRUE  unless you set the focus to a control
}

void CCustomSampleEngDlg::OnSysCommand(UINT nID, LPARAM lParam)
{
	if ((nID & 0xFFF0) == IDM_ABOUTBOX)
	{
		CAboutDlg dlgAbout;
		dlgAbout.DoModal();
	}
	else
	{
		CDialog::OnSysCommand(nID, lParam);
	}
}

// If you add a minimize button to your dialog, you will need the code below
//  to draw the icon.  For MFC applications using the document/view model,
//  this is automatically done for you by the framework.

void CCustomSampleEngDlg::OnPaint() 
{
	if (IsIconic())
	{
		CPaintDC dc(this); // device context for painting

		SendMessage(WM_ICONERASEBKGND, (WPARAM) dc.GetSafeHdc(), 0);

		// Center icon in client rectangle
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// Draw the icon
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialog::OnPaint();
	}
}

// The system calls this to obtain the cursor to display while the user drags
//  the minimized window.
HCURSOR CCustomSampleEngDlg::OnQueryDragIcon()
{
	return (HCURSOR) m_hIcon;
}

/****************************************************/
/*  Open Communication Route                        */
/****************************************************/
void CCustomSampleEngDlg::OnOpenCom() 
{
long	lRet;
HRESULT	hr;
BSTR szAdr = NULL;
wchar_t wsz[] = L"1.1.1.2";	//HostAddress Example
CString	MsgStr;

	CWnd::UpdateData(TRUE);

	// Clear ReturnValue Display
	m_RetVal= "";
	m_RetVal2 = "";
	m_RetVal3 = "";

	if (m_SelectCntl == 0 ){	// ActAJ71QE71UDP Control (Custom Interface)
		// If you don't use default values, please set their properties before OPEN method call.
		// (If you call the set-property method after OPEN method, it isn't reflected to the communication.)
		// (You can use methods to set and get the value for all properties.)
		// ---> Example: Change CPU type to "Q2A-S1" from default value.
		//				 Change the Baudrate to 9600bps from default value.
		//			     The other is default.
		hr = mp_IAJ71QE71UDP->put_ActCpuType(CPU_Q2AS1CPU);			// Exec set-property method
		if(SUCCEEDED(hr)){	// Compornent Communication is succeeded?
			szAdr = ::SysAllocString(wsz);	// Allocate the BSTR-Type String area.
											// (After use, you have to free it.)
			hr = mp_IAJ71QE71UDP->put_ActHostAddress(szAdr);
			if(SUCCEEDED(hr)){	// Compornent Communication is succeeded?
				hr = mp_IAJ71QE71UDP->Open(&lRet);	// Exec Open Method
			}
		}
		// Free the allocated area.
		::SysFreeString(szAdr);
	}
	else{						// ActEasyIF Control (Custom Interface)
		// If you don't use default values, please set their properties before OPEN method call.
		//---> Example: Change the Logical station number to "2" from default value.
		hr = mp_IEasyIF->put_ActLogicalStationNumber(2);	// Exec set-property method
		if(SUCCEEDED(hr)){	// Compornent Communication is succeeded?
			hr = mp_IEasyIF->Open(&lRet);	// Exec Open Method
		}
	}
	if(SUCCEEDED(hr)){	// Compornent Communication is succeeded?
		// Renew ReturnValue
		m_RetVal.Format("0x%08x",lRet);
	}
	else{	// Failed Compornent Communication
		MsgStr.LoadString(IDS_STRING103);
		AfxMessageBox(MsgStr, MB_ICONINFORMATION);
	}

	CWnd::UpdateData(FALSE);
		

}

/*******************************************************************/
/*  Get CpuType of the connected CPU (confirmation of connecting)  */
/*******************************************************************/
void CCustomSampleEngDlg::OnGetCpuType() 
{
long	lRet;
long	lCpuCode	= 0;
BSTR	szCpuName	= NULL;
HRESULT	hr;
CString	MsgStr;

	// Clear ReturnValue Display
	m_RetVal= "";
	m_RetVal2 = "";
	m_RetVal3 = "";

	if (m_SelectCntl == 0 ){	// ActAJ71QE71UDP Control (Custom Interface)
		hr = mp_IAJ71QE71UDP->GetCpuType(&szCpuName,&lCpuCode,&lRet);	// Exec GetCpuType Method
	}
	else{						// ActEasyIF Control (Custom Interface)
		hr = mp_IEasyIF->GetCpuType(&szCpuName,&lCpuCode,&lRet);	// Exec GetCpuType Method
	}
	if(SUCCEEDED(hr)){	// Compornent Communication is succeeded?
		if(lRet == 0x00){	// Success
			m_RetVal2.Format("0x%x(%d)",lCpuCode,lCpuCode);
			m_RetVal3 = szCpuName;
		}
		// Renew ReturnValue
		m_RetVal.Format("0x%08x",lRet);
	}
	else{
		MsgStr.LoadString(IDS_STRING103);
		AfxMessageBox(MsgStr, MB_ICONINFORMATION);
	}
	// If the Method has the Output value of BSTR-type, you have to free the allocated area.
	
	::SysFreeString(szCpuName);

	CWnd::UpdateData(FALSE);	
}

/****************************************************/
/*  Get Device Value                                */
/****************************************************/
void CCustomSampleEngDlg::OnGetDevice() 
{
long lRet;
long lValue;
CString	MsgStr;
BSTR szDev = NULL;
HRESULT	hr;

	CWnd::UpdateData(TRUE);

	// Clear ReturnValue Display
	m_RetVal= "";
	m_RetVal2 = "";
	m_RetVal3 = "";

	if (m_Device == ""){
		// Not Enter DeviceName Error
		MsgStr.LoadString(IDS_STRING102);
		AfxMessageBox(MsgStr, MB_ICONINFORMATION);
		return;
	}
	szDev = m_Device.AllocSysString();	// Allocate the BSTR-Type String area. 
										// (After use, you have to free it.)
	if (m_SelectCntl == 0 ){	// ActAJ71QE71UDP Control (Custom Interface)
		hr = mp_IAJ71QE71UDP->GetDevice(m_Device.AllocSysString(),&lValue,&lRet);	// Exec GetDevice Method
	}
	else{						// ActEasyIF Control (Custom Interface)
		hr = mp_IEasyIF->GetDevice(m_Device.AllocSysString(),&lValue,&lRet);	// Exec GetDevice Method
	}
	if(SUCCEEDED(hr)){	// Compornent Communication is succeeded?
		if(lRet == 0x00){	// Success
			m_RetVal2.Format("0x%04x(%d)",lValue,lValue);	// Device Value
		}
		// Renew ReturnValue
		m_RetVal.Format("0x%08x",lRet);
	}
	else{
		MsgStr.LoadString(IDS_STRING103);
		AfxMessageBox(MsgStr, MB_ICONINFORMATION);
	}
	// Free the allocated area.
	::SysFreeString(szDev);

	CWnd::UpdateData(FALSE);	

}

/****************************************************/
/*  Set Device Value                                */
/****************************************************/
void CCustomSampleEngDlg::OnSetDevice() 
{
long lValue;
long lRet;
CString	MsgStr;
HRESULT	hr;
BSTR szDev = NULL;

	CWnd::UpdateData(TRUE);

	// Clear ReturnValue Display
	m_RetVal= "";
	m_RetVal2 = "";
	m_RetVal3 = "";

	if (m_Device == ""){
		// Not Enter DeviceName Error
		MsgStr.LoadString(IDS_STRING102);
		AfxMessageBox(MsgStr, MB_ICONINFORMATION);
		return;
	}
	lValue = m_DeviceValue;
	szDev = m_Device.AllocSysString();	// Allocate the BSTR-Type String area. 
										// (After use, you have to free it.)
	if (m_SelectCntl == 0 ){	// ActAJ71QE71UDP Control (Custom Interface)
		hr = mp_IAJ71QE71UDP->SetDevice(m_Device.AllocSysString(),lValue,&lRet);	// Exec GetDevice Method
	}
	else{						// ActEasyIF Control (Custom Interface)
		hr = mp_IEasyIF->SetDevice(m_Device.AllocSysString(),lValue,&lRet);	// Exec GetDevice Method
	}
	if(SUCCEEDED(hr)){	// Compornent Communication is succeeded?
		// Renew ReturnValue
		m_RetVal.Format("0x%08x",lRet);
	}
	else{
		MsgStr.LoadString(IDS_STRING103);
		AfxMessageBox(MsgStr, MB_ICONINFORMATION);
	}
	// Free the allocated area.
	::SysFreeString(szDev);

	CWnd::UpdateData(FALSE);	
}

/****************************************************/
/*  Close Communication Route                       */
/****************************************************/
void CCustomSampleEngDlg::OnCloseCom() 
{
long lRet;
HRESULT	hr;
CString	MsgStr;

	CWnd::UpdateData(TRUE);

	// Clear ReturnValue Display
	m_RetVal= "";
	m_RetVal2 = "";
	m_RetVal3 = "";

	if (m_SelectCntl == 0 ){	// ActAJ71QE71UDP Control (Custom Interface)
		hr = mp_IAJ71QE71UDP->Close(&lRet);// Exec Close Method
	}
	else{						// ActEasyIF Control (Custom Interface)
		hr = mp_IEasyIF->Close(&lRet);	// Exec Close Method
	}
	if(SUCCEEDED(hr)){	// Compornent Communication is succeeded?
		// Renew ReturnValue
		m_RetVal.Format("0x%08x",lRet);
	}
	else{
		MsgStr.LoadString(IDS_STRING103);
		AfxMessageBox(MsgStr, MB_ICONINFORMATION);
	}

	CWnd::UpdateData(FALSE);	
}



/*******************************************************/
/*  Destroy Window  ( Free ACT Compornent )        */
/*******************************************************/
BOOL CCustomSampleEngDlg::DestroyWindow() 
{
	/*****************************************/
	/* Free the Custom-Interface Compornent  */
	mp_IAJ71QE71UDP->Release();
	mp_IEasyIF->Release();
	/*                                       */
	/*****************************************/

	return CDialog::DestroyWindow();
}
