
To use CgiWeb.dll in Autoit3:  Register the DLL by running "regsvr32.exe cgiweb.dll"

$wc=ObjCreate("webCGI.CGIweb")        Set up the Com/DLL


Prefix any of these routines with $wc.     Example: $wc.CgiInfo(8,0) will bring back the name "QUERY_STRING"
				               $wc.CgiInfo(8,1) will bring back the content of QUERY_STRING  	

CgiInfo(xIndex,yIndex) 		Get 29 Standard CGI Variables
				CgiInfo(0)=HTTP_ACCEPT
				CgiInfo(1)=AUTH_TYPE
				CgiInfo(2)=CONTENT_LENGTH
				CgiInfo(3)=CONTENT_TYPE
				CgiInfo(4)=HTTP_COOKIE
				CgiInfo(5)=GATEWAY_INTERFACE
				CgiInfo(6)=PATH_INFO
				CgiInfo(7)=PATH_TRANSLATED
				CgiInfo(8)=QUERY_STRING
				CgiInfo(9)=HTTP_REFERER
				CgiInfo(10)=REMOTE_ADDR
				CgiInfo(11)=REMOTE_HOST
				CgiInfo(12)=REMOTE_IDENT
				CgiInfo(13)=REMOTE_USER
				CgiInfo(14)=REQUEST_METHOD
				CgiInfo(15)=SCRIPT_NAME
				CgiInfo(16)=SERVER_SOFTWARE
				CgiInfo(17)=SERVER_NAME
				CgiInfo(18)=SERVER_PORT
				CgiInfo(19)=SERVER_PROTOCOL
				CgiInfo(20)=HTTP_USER_AGENT
				CgiInfo(21)=HTTP_HOST
				CgiInfo(22)=HTTP_CONNECTION
				CgiInfo(23)=HTTP_PRAGMA
				CgiInfo(24)=HTTPS
				CgiInfo(25)=HTTP_ACCEPT_LANGUAGE
				CgiInfo(26)=HTTP_ACCEPT_CHARSET
				CgiInfo(27)=HTTP_ACCEPT_ENCODING
				CgiInfo(28)=SERVER_PORT_SECURE

GetCgiValue(cgiName)	 Get a Cgi Value of a Name Pair or Multiple values by a ;
				$wc.GetCgiValue("Letters") 

SendHeader(WebTitle)	 Write Standard Cgi Title of Web Header to Stdout
				$wc.Send('<html>')
				$wc.Send('<head>')
  				$wc.Send('<title>Hello World Demonstration Document</title>')
				$wc.Send('</head>')
			Replace the above with
				$wc.SendHeader('Hello World Demonstration Document')

Send(WebData)		Write Cgi Web Data to Client Stdout
				$wc.SendHeader('Hello World Demonstration Document')
				$wc.Send('<body>')
  				$wc.Send('<h1>Hello, World!</h1>')
  				$wc.SendFooter()

SendB(WebData)		 Write Cgi Web Data to Client Stdout with no CRLF
				Use when sending binary data    

SendFooter()		 Write Standard Cgi End of Web to Stdout
				$wc.Send('</body>')
				$wc.Send('</html>')
			  Replace the above with
				$wc.SendFooter()


