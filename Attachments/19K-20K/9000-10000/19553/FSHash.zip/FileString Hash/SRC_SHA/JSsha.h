/*
    Modified by Jarvis Stubblefield for use with an AutoIt Plugin
    Copyright (C) 2006-2008 Jarvis Stubblefield <jstubblefield at vortexrevolutions dot com>
    Vortex Revolutions  - http://www.vortexrevolutions.com/
    AutoIt Homepage     - http://www.autoitscript.com/


	100% free public domain implementation of the SHA-1 algorithm
	by Dominik Reichl <dominik.reichl@t-online.de>
	Web: http://www.dominik-reichl.de/

	Version 1.6 - 2005-02-07 (thanks to Howard Kapustein for patches)
	- You can set the endianness in your files, no need to modify the
	  header file of the CSHA1 class any more
	- Aligned data support
	- Made support/compilation of the utility functions (ReportHash
	  and HashFile) optional (useful, if bytes count, for example in
	  embedded environments)

	Version 1.5 - 2005-01-01
	- 64-bit compiler compatibility added
	- Made variable wiping optional (define SHA1_WIPE_VARIABLES)
	- Removed unnecessary variable initializations
	- ROL32 improvement for the Microsoft compiler (using _rotl)

	======== Test Vectors (from FIPS PUB 180-1) ========

	SHA1("abc") =
		A9993E36 4706816A BA3E2571 7850C26C 9CD0D89D

	SHA1("abcdbcdecdefdefgefghfghighijhijkijkljklmklmnlmnomnopnopq") =
		84983E44 1C3BD26E BAAE4AA1 F95129E5 E54670F1

	SHA1(A million repetitions of "a") =
		34AA973C D4C4DAA4 F61EEB2B DBAD2731 6534016F
*/

//Type Definitions
typedef unsigned char uChar;
typedef unsigned  int uInt4;

//Declare Functions for use in JSsha.cpp
char * ReturnSHAEncrypt(uChar DigestSHA[20]);
char * FileSHAEncrypt(char* sFilename);
char * StringSHAEncrypt(char* sString);

// Declare SHA1 workspace
typedef union
{
	uChar  c[64];
	uInt4  l[16];
} SHA1_WORKSPACE_BLOCK;

class clSHA
{
public:
	// Constructor and Destructor
	clSHA();
	~clSHA();

	uInt4 m_state[5];
	uInt4 m_count[2];
	uInt4 __reserved1[1];
	uChar  m_buffer[64];
	uChar  m_digest[20];
	uInt4 __reserved2[3];

	void initial();
	void change(uChar* sIn, uInt4 lenIn);
	bool hashfile(char *szFileName);
	void final();
    uChar* digest() { return m_digest; }
private:
	// Private SHA-1 transformation
	void Transform(uInt4 *state, uChar *buffer);
	// Member variables
	uChar m_workspace[64];
	SHA1_WORKSPACE_BLOCK *m_block; // SHA1 pointer to the byte array above
};



