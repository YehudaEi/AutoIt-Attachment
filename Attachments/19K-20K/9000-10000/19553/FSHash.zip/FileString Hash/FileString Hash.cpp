/*
 * Plugin for AutoItv3
 * FileHash() and StringHash()
 * MD5 and SHA-1 Hashes supported.
 * MD5 functions by Jarvis Stubblefield (jjs at vortexrevolutions dot com)
 * SHA functions by Jarvis Stubblefield (jjs at vortexrevolutions dot com)
 * Copyright (C) 2006-2008 Jarvis Stubblefield <jstubblefield at vortexrevolutions dot com>
 * Special thanks to all the supporters.
 * Plugin_SDK and AutoItv3 Jon Bennett and his team of Developers
 *
 * FileString Hash.cpp
 */

#include <stdio.h>
#include <windows.h>
#include "SRC_SDK\au3plugin.h"
#include "SRC_MD5\JSmd5.h"
#include "SRC_SHA\JSsha.h"


/****************************************************************************
 * Function List
 *
 * This is where you define the functions available to AutoIt.  Including
 * the function name (Must be the same case as your exported DLL name), the
 * minimum and maximum number of parameters that the function takes.
 *
 ****************************************************************************/

/* "FunctionName", min_params, max_params */
AU3_PLUGIN_FUNC g_AU3_Funcs[2] =
{
    {"FileHash", 2, 3},
    {"StringHash", 2, 3}
};

/****************************************************************************
 * AU3_GetPluginDetails()
 *
 * This function is called by AutoIt when the plugin dll is first loaded to
 * query the plugin about what functions it supports.  DO NOT MODIFY.
 *
 ****************************************************************************/

AU3_PLUGINAPI int AU3_GetPluginDetails(int *n_AU3_NumFuncs, AU3_PLUGIN_FUNC **p_AU3_Func)
{
	/* Pass back the number of functions that this DLL supports */
	*n_AU3_NumFuncs	= sizeof(g_AU3_Funcs)/sizeof(AU3_PLUGIN_FUNC);;

	/* Pack back the address of the global function table */
	*p_AU3_Func = g_AU3_Funcs;

	return AU3_PLUGIN_OK;
}

/****************************************************************************
 * DllMain()
 *
 * This function is called when the DLL is loaded and unloaded.  Do not
 * modify it unless you understand what it does...
 *
 ****************************************************************************/

BOOL WINAPI DllMain(HANDLE hInst, ULONG ul_reason_for_call, LPVOID lpReserved)
{
    switch (ul_reason_for_call)
	{
		case DLL_PROCESS_ATTACH:
		case DLL_THREAD_ATTACH:
		case DLL_THREAD_DETACH:
		case DLL_PROCESS_DETACH:
			break;
    }
    return TRUE;
}

/****************************************************************************
 * FileHash()
 *
 * This function should return a hash of the chosen file, it accepts 3
 * parameters:
 *
 * FileHash(string FileName, int HashType[, bool ReturnCase])
 * FileHash("filename.exe", 1[, 0])
 *
 * 1st Parameter = The file you wish to return a hash value of.
 * 2nd Parameter = Type of hash to be performed.
 * 3rd Parameter = Uppercase or Lowercase return string. **Optional**
 *
 ****************************************************************************/

AU3_PLUGIN_DEFINE(FileHash)
{
	/* The inputs to a plugin function are:
	 *		n_AU3_NumParams		- The number of parameters being passed
	 *		p_AU3_Params		- An array of variant like variables used by AutoIt
	 *
	 * The outputs of a plugin function are:
	 *		p_AU3_Result		- A pointer to a variant variable for the result
	 *		n_AU3_ErrorCode		- The value for @Error
	 *		n_AU3_ExtCode		- The value for @Extended
	 */

	AU3_PLUGIN_VAR	*p_HashResult;
	char            *s_String, *s_Hash;
	int             i_Hash;
	bool            b_Case;

	/* Allocate and build the return variable */
	p_HashResult = AU3_AllocVar();

	/* Check to be sure the variables are of the right types. */
	//Set @error to 1 if first variable is not a string.
	if (AU3_GetType(&p_AU3_Params[0]) != AU3_PLUGIN_STRING) {
	    AU3_SetInt32(p_HashResult, 0);
		*p_AU3_Result		= p_HashResult;
		*n_AU3_ErrorCode	= 1;
		*n_AU3_ExtCode		= 0;

		return AU3_PLUGIN_OK;
	}
	else {
	    //Note: Free s_String when finished.
	    s_String = AU3_GetString(&p_AU3_Params[0]);
	}
	//Set @error to 2 if second variable is not an integer
	if (AU3_GetType(&p_AU3_Params[1]) != AU3_PLUGIN_INT32) {
	    AU3_SetInt32(p_HashResult, 0);
		*p_AU3_Result		= p_HashResult;
		*n_AU3_ErrorCode	= 2;
		*n_AU3_ExtCode		= 0;

		return AU3_PLUGIN_OK;
	}
	else {
	    i_Hash = AU3_GetInt32(&p_AU3_Params[1]);
	}
	//Set @error to 2 if second variable isnt 1 or 2 and set @extended to 1
	if (i_Hash == 1) {
	    s_Hash = FileMD5Encrypt(s_String);
	}
	else if (i_Hash == 2) {
	    s_Hash = FileSHAEncrypt(s_String);
	}
    else {
        AU3_SetInt32(p_HashResult, 0);
		*p_AU3_Result		= p_HashResult;
		*n_AU3_ErrorCode	= 2;
		*n_AU3_ExtCode		= 1;

		return AU3_PLUGIN_OK;
    }
	//Set @error to 3 if third variable exists, and isnt an integer
	if (n_AU3_NumParams == 3) {
	    if (AU3_GetType(&p_AU3_Params[2]) != AU3_PLUGIN_INT32) {
            AU3_SetInt32(p_HashResult, 0);
            *p_AU3_Result		= p_HashResult;
            *n_AU3_ErrorCode	= 3;
            *n_AU3_ExtCode		= 0;

            return AU3_PLUGIN_OK;
	    }
	    else {
	        b_Case = (bool)AU3_GetInt32(&p_AU3_Params[2]);
	    }
	}
	else {
	    b_Case = false;
	}
	//Set @error to 4 if s_Hash = false
	if (s_Hash == false) {
        AU3_SetInt32(p_HashResult, 0);
        *p_AU3_Result		= p_HashResult;
        *n_AU3_ErrorCode	= 1;
        *n_AU3_ExtCode		= 1;

        return AU3_PLUGIN_OK;
	}
    //Set hash to Upper or Lower case.
    if (b_Case) {
        strupr(s_Hash);
    }
    else {
        strlwr(s_Hash);
    }

    AU3_SetString(p_HashResult, s_Hash);

    //From note above. Freeing s_String
	AU3_FreeString(s_String);

	/* Pass back the result, error code and extended code. */
	*p_AU3_Result		= p_HashResult;
	*n_AU3_ErrorCode    = 0;
	*n_AU3_ExtCode		= 0;

	return AU3_PLUGIN_OK;
}

/****************************************************************************
 * StringHash()
 *
 * This function should return a hash of the chosen string, it accepts 3
 * parameters:
 *
 * StringHash(string String, int HashType[, bool ReturnCase])
 * StringHash("string", 1[, 0])
 *
 * 1st Parameter = The string you wish to return a hash value of.
 * 2nd Parameter = Type of hash to be performed.
 * 3rd Parameter = Uppercase or Lowercase return string. **Optional**
 *
 ****************************************************************************/

AU3_PLUGIN_DEFINE(StringHash)
{
	/* The inputs to a plugin function are:
	 *		n_AU3_NumParams		- The number of parameters being passed
	 *		p_AU3_Params		- An array of variant like variables used by AutoIt
	 *
	 * The outputs of a plugin function are:
	 *		p_AU3_Result		- A pointer to a variant variable for the result
	 *		n_AU3_ErrorCode		- The value for @Error
	 *		n_AU3_ExtCode		- The value for @Extended
	 */

	AU3_PLUGIN_VAR	*p_HashResult;
	char            *s_String, *s_Hash;
	int             i_Hash;
	bool            b_Case;

	/* Allocate and build the return variable */
	p_HashResult = AU3_AllocVar();

	/* Check to be sure the variables are of the right types. */
	//Set @error to 1 if first variable is not a string.
	if (AU3_GetType(&p_AU3_Params[0]) != AU3_PLUGIN_STRING) {
	    AU3_SetInt32(p_HashResult, 0);
		*p_AU3_Result		= p_HashResult;
		*n_AU3_ErrorCode	= 1;
		*n_AU3_ExtCode		= 0;

		return AU3_PLUGIN_OK;
	}
	else {
	    //Note: Free s_String when finished.
	    s_String = AU3_GetString(&p_AU3_Params[0]);
	}
	//Set @error to 2 if second variable is not an integer
	if (AU3_GetType(&p_AU3_Params[1]) != AU3_PLUGIN_INT32) {
	    AU3_SetInt32(p_HashResult, 0);
		*p_AU3_Result		= p_HashResult;
		*n_AU3_ErrorCode	= 2;
		*n_AU3_ExtCode		= 0;

		return AU3_PLUGIN_OK;
	}
	else {
	    i_Hash = AU3_GetInt32(&p_AU3_Params[1]);
	}

	//Set @error to 2 if second variable isnt 1 or 2 and set @extended to 1
	if (i_Hash == 1) {
	    s_Hash = StringMD5Encrypt(s_String);
	}
	else if (i_Hash == 2) {
	    s_Hash = StringSHAEncrypt(s_String);
	}
    else {
        AU3_SetInt32(p_HashResult, 0);
		*p_AU3_Result		= p_HashResult;
		*n_AU3_ErrorCode	= 2;
		*n_AU3_ExtCode		= 1;
    }
	//Set @error to 3 if third variable exists, and isnt an integer
	if (n_AU3_NumParams == 3) {
	    if (AU3_GetType(&p_AU3_Params[2]) != AU3_PLUGIN_INT32) {
            AU3_SetInt32(p_HashResult, 0);
            *p_AU3_Result		= p_HashResult;
            *n_AU3_ErrorCode	= 3;
            *n_AU3_ExtCode		= 0;

            return AU3_PLUGIN_OK;
	    }
	    else {
	        b_Case = (bool)AU3_GetInt32(&p_AU3_Params[2]);
	    }
	}
	else {
	    b_Case = false;
	}
    //Set hash to Upper or Lower case.
    if (b_Case) {
        strupr(s_Hash);
    }
    else {
        strlwr(s_Hash);
    }

    AU3_SetString(p_HashResult, s_Hash);

    //From note above. Freeing s_String
	AU3_FreeString(s_String);

	/* Pass back the result, error code and extended code. */
	*p_AU3_Result		= p_HashResult;
	*n_AU3_ErrorCode    = 0;
	*n_AU3_ExtCode		= 0;

	return AU3_PLUGIN_OK;
}
