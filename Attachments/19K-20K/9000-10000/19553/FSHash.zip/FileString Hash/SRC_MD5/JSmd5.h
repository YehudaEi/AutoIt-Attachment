/*
    Modified by Jarvis Stubblefield for use with an AutoIt Plugin
    Copyright (C) 2006-2008 Jarvis Stubblefield <jstubblefield at vortexrevolutions dot com>
    Vortex Revolutions  - http://www.vortexrevolutions.com/
    AutoIt Homepage     - http://www.autoitscript.com/


Copyright (C) 1991-2, RSA Data Security, Inc. Created 1991. All
rights reserved.

License to copy and use this software is granted provided that it
is identified as the "RSA Data Security, Inc. MD5 Message-Digest
Algorithm" in all material mentioning or referencing this software
or this function.

License is also granted to make and use derivative works provided
that such works are identified as "derived from the RSA Data
Security, Inc. MD5 Message-Digest Algorithm" in all material
mentioning or referencing the derived work.

RSA Data Security, Inc. makes no representations concerning either
the merchantability of this software or the suitability of this
software for any particular purpose. It is provided "as is"
without express or implied warranty of any kind.

These notices must be retained in any copies of any part of this
documentation and/or software.
 */

//Variables taken from globals.h
typedef unsigned       int uInt4;
typedef unsigned short int uInt2;
typedef unsigned      char uChar;

//Declare Functions for use in JSmd5.cpp
char * ReturnMD5Encrypt(uChar DigestMD5[16]);
char * StringMD5Encrypt(char * sString);
char * FileMD5Encrypt(char * sFilename);

class clMD5
{
    public:
        clMD5()
        {
            initial();
        }
        void initial();
        void change(uChar* sIn, uInt4 lenIn);
        void final();
        uChar* digest() { return mDigest; }

    private:
        void trans(uChar* block);
        void code(uInt4* src, uChar* dest, uInt4 len);
        void decode(uChar* src, uInt4* dest, uInt4 len);

      	inline	uInt4	rotateL(uInt4 x, uInt4 n)
    	                 { return ((x << n) | (x >> (32-n))); }
    	inline	uInt4	F(uInt4 x, uInt4 y, uInt4 z)
    	                 { return ((x & y) | (~x & z)); }
    	inline  uInt4	G(uInt4 x, uInt4 y, uInt4 z)
    	                 { return ((x & z) | (y & ~z)); }
    	inline  uInt4	H(uInt4 x, uInt4 y, uInt4 z)
    	                 { return (x ^ y ^ z); }
    	inline  uInt4	I(uInt4 x, uInt4 y, uInt4 z)
    	                 { return (y ^ (x | ~z)); }

    	inline	void	FF(uInt4& a, uInt4 b, uInt4 c, uInt4 d, uInt4 x, uInt4 s, uInt4 ac)
    	                 { a += F(b, c, d) + x + ac; a = rotateL(a, s); a += b; }
    	inline	void	GG(uInt4& a, uInt4 b, uInt4 c, uInt4 d, uInt4 x, uInt4 s, uInt4 ac)
                         { a += G(b, c, d) + x + ac; a = rotateL(a, s); a += b; }
    	inline	void	HH(uInt4& a, uInt4 b, uInt4 c, uInt4 d, uInt4 x, uInt4 s, uInt4 ac)
                         { a += H(b, c, d) + x + ac; a = rotateL(a, s); a += b; }
    	inline	void	II(uInt4& a, uInt4 b, uInt4 c, uInt4 d, uInt4 x, uInt4 s, uInt4 ac)
                         { a += I(b, c, d) + x + ac; a = rotateL(a, s); a += b; }

    private:
    	uInt4		mState[4];
    	uInt4		mCount[2];
    	uChar		mBuffer[64];
    	uChar		mDigest[16];
    	uChar		mFinal;
};
