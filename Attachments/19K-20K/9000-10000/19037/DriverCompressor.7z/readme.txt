
----------------------------------
Features:
----------------------------------
- Driver compression: THIS WORKS ONLY FOR DRIVERS WITH .INF FILES!
- Multi directory / multi inf files
- Cab files support
- Driver version check
- Class/Provider dir structure creation
- nVidia international driver support
- XP installation CD driver integration


----------------------------------
Known errors:
----------------------------------
- When using Provider Disk Structure in combination with Realtek and VIA vinyl
  audio drivers, it creates a directory for every .inf file and copies the same
  drivers to all the dirs.
- If there are 2 SourceDiskFiles sections it scans only the first one and won't
  copy files in the sections afterwards. (Logitech mouse drivers)


----------------------------------
How does this work?
----------------------------------
Driver Compressor searches in the source directory for .inf files. From this
file it gets all the necessary information. Then it copies the source files to
a new destination and compresses it.

WARNING: The source dir cannot be part of the destination dir. This causes
loops. Ex.: 'C:\drivers' is part of 'C:\drivers\destination'.

Options:

- Source
  The original drivers location.

- Destination
  The location for the compressed drivers. When integrating drivers, point this
  to the Windows \i386 folder.

- Type
  The type of drivers you want to copy.
    .x86: Windows XP
    .AMD64: Windows XP AMD 64 bit
    .IA64: Windows XP Intell 64 bit

These last two haven't been tested, but they should be working in theory.

- Keep WHQL driver signing
  Copies catalog files as well. This will keep WHQL driver signing if
  available. You don't need this if you have patched SFC.

- Use Provider Disk Structure
  It creates a directory structure like destination\Class\Provider. Ex:

    c:\drivers\system\nvidia\...

  Caution with this option. If you use for example 'BTS DriverPacks', it happens
  that some inf files are not correctly written and you get directories like:

    c:\drivers\%VENDER_CLASS%\...

  Or it overwrites drivers. For example if you copy all the nvidia nforce 1-4
  drivers, you will end up with only 1 dir in stead of 4.

  Another possibility is when you compress the Realtek drivers, you end up with
  about 50 extra dirs, what could have been done in 2.

  If you only use the drivers for your system, it shouldn't give any problems.

- International drivers (nVidia)

  Auto detection of the current OS language and copies the proper language
  files. The language can be selected manual too.
  This works only with the nVidia international drivers.

- Integrate drivers into XP

  This will integrate the drivers into a Windows XP installation. Make sure
  the destination points to the Windows \i386 folder.

  How does this work?
  All needed driver files are copied to \i386\DRIVERS. After that they will be
  integrated into DOSNET.INF and TXTSETUP.SIF so they will be copied to
  %WINDIR%\DRIVERS during textmode installation. The paths will be added
  to the DevicePath in DOSNET.INF. And finally the drivers will be compressed.

----------------------------------
Changelog:
----------------------------------
2007.08.09 Added XP installation CD driver integration.
2007.08.03 Renamed next button into Start.
2007.08.03 Fixed cancel button so the program exits.
2007.07.19 Fixed compatibility with Win98 as host OS.
2007.07.17 Added nVidia international driver support
2007.05.19 Improved check for source and destination dir.
2007.05.17 Added about link to readme.txt.
2007.05.17 Added some debug info to the log file.
2007.05.17 Fixed error 'Parameter format not correct'.
2007.05.16 Added check for same source and destination dir.
2007.05.16 Added displaying version.
2007.05.16 Copy catalog is selected by default.
2006.03.07 Disabled warning message for missing .com, .sys, .dos and .vxd files.
2006.03.06 Fixed error with files extensions less than 3 characters (ATI).
