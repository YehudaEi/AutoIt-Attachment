#include "add.h"
#include <stdio.h>

int add(int x, int y){
     return (x + y);
}
