/*all we need for a dll. the header, source and .def file and compile as dll*/
#ifndef ADD
#define ADD

int add(int, int);
#endif
