#include <stdio.h>
#include "add.h"//proto for the functions we'll need

int main(void){
    /*call the function from the library*/
    int ans = add(5,10);
    printf("5 and 10 is %d",ans);
    getchar();
    return 0;
}
