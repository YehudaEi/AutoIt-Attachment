Copy MyExtras folder to AutoIT include folder

Create a folder called C:\INPUT and a folder called C:\OUTPUT

Put the .zip file in the INPUT folder and run the Main.au3 code.