#include <stdlib.h>
#include <gl/glut.h>
#include "glfunc.h"
#include "mesh.h"
#include "light.h"
#include "camera.h"
#include "ambient.h"
#include "texture.h"

CWindowConfig g_WinConfig;
bool g_CanDrawScene;
HINSTANCE g_hInstance;

/****************************************************************************
 * CWindowConfig
 *
 ****************************************************************************/
HWND CWindowConfig::DefineGlWindow( char* WinTitle, const int Width = -1, const int Height = -1, const int Left = -1, const int Top = -1 )
{
    if( this->Hwnd == NULL )
    {
        this->IsFullScreen = false;
        if( Width == -1 && Height == -1 )
        {
            this->IsFullScreen = true;
        }
        if( Width > 0 )
        {
            this->Width = Width;
        }
        if( Height > 0 )
        {
            this->Height = Height;
        }
        this->Left = Left;
        this->Top = Top;
        strncpy( this->Title, WinTitle, sizeof( this->Title) );

        _StartMainLoop( );

        while( 1 )
        {
            this->Hwnd = FindWindowEx( NULL, NULL, "GLUT", WinTitle );
            if( this->Hwnd ) break;
        }
        return ( this->Hwnd );
    }
    return 0;
}

//----------------------------------------------------------------------------
HWND CWindowConfig::SetToWindow( const HWND ParentHwnd, const int Left, const int Top, const int Width, const int Height )
{
    if( this->Hwnd == NULL )
    {
        this->Left = Left;
        this->Top = Top;
        this->Width = Width;
        this->Height = Height;

        char Title[256] = "GlutEmbeded";
        this->DefineGlWindow( Title, Width, Height );

        HWND GlutWindowHwnd = 0;
        while( 1 )
        {
            GlutWindowHwnd = FindWindowEx( NULL, NULL, "GLUT", Title ); //gets hwnd of glut window
            if( GlutWindowHwnd ) break;
        }
        this->Hwnd = GlutWindowHwnd;

        long ParentStyle = GetWindowLong( ParentHwnd, GWL_STYLE );
        SetWindowLong( ParentHwnd, GWL_STYLE, ParentStyle + WS_CLIPCHILDREN );

        SetParent( GlutWindowHwnd, ParentHwnd );
        SetWindowPos( GlutWindowHwnd, 0, Left, Top, Width, Height, SWP_SHOWWINDOW );

        SetWindowLong( GlutWindowHwnd, GWL_STYLE, 0x96000000 );
        SetWindowLong( GlutWindowHwnd, GWL_EXSTYLE, WS_EX_RIGHT );

        ShowWindow( GlutWindowHwnd, SW_SHOW );

        return ( this->Hwnd );
    }
    return 0;
}

//----------------------------------------------------------------------------
void CWindowConfig::CreateGlWindow( void )
{
	glutInitDisplayMode( GLUT_DOUBLE | GLUT_RGB | GLUT_DEPTH );
	glHint(GL_PERSPECTIVE_CORRECTION_HINT, GL_NICEST);
	glutInitWindowSize( this->Width, this->Height );
    int MainWindow = glutCreateWindow( this->Title );
    //glutCreateSubWindow( MainWindow, this->Left, this->Top, this->Width, this->Height);
    if( this->Left < 0 )
    {
        this->Left = ( glutGet( GLUT_SCREEN_WIDTH ) - glutGet( GLUT_WINDOW_WIDTH ) ) / 2;
    }
    if( this->Top < 0 )
    {
        this->Top = ( glutGet( GLUT_SCREEN_HEIGHT ) - glutGet( GLUT_WINDOW_HEIGHT ) ) / 2;
    }
	glutPositionWindow( this->Left, this->Top );
}

//----------------------------------------------------------------------------
CWindowConfig::CWindowConfig( void )
{
    this->Hwnd = NULL;
	this->Width = 300;
	this->Height = 300;
	this->Left = -1;
	this->Top = -1;
    this->IsFullScreen = 0;
	strncpy( this->Title, "", sizeof( this->Title ) );
}

/****************************************************************************
 * Normal Functions
 *
 ****************************************************************************/

void NormalizeAngles( double *X, double *Y, double *Z )
{
    if( *X >= 360 ) *X -= 360;
    if( *Y >= 360 ) *Y -= 360;
    if( *Z >= 360 ) *Z -= 360;

    if( *X < 0 ) *X += 360;
    if( *Y < 0 ) *Y += 360;
    if( *Z < 0 ) *Z += 360;
}

//----------------------------------------------------------------------------
void SceneDraw( void )
{
    g_AmbientConfig.SetClearColour( );
	glClear( GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT );
	glMatrixMode( GL_MODELVIEW );

	g_CameraConfig.DefineView( );
	g_LightManage.SetLights( );

	g_MeshRepository.PrintPulledObjects( );

	glutSwapBuffers();
	g_CanDrawScene = false;
}

//----------------------------------------------------------------------------
// callback function to draw
void __Draw( void )
{
    Sleep( 1 );
    if( g_CanDrawScene == true )
    {
        SceneDraw( );
    }
    glutPostRedisplay();
}

//----------------------------------------------------------------------------
void TimerFunction( int value )
{
	glutTimerFunc( value, TimerFunction, 30 );
}

//----------------------------------------------------------------------------
// callback function to rezize window
void __WindowResize( GLsizei Width, GLsizei Height )
{
	if ( Height == 0 ) Height = 1;
	glViewport( 0, 0, Width, Height );
	g_CameraConfig.fAspect = (GLfloat) Width / (GLfloat) Height;

	g_CameraConfig.DefineView( );
	SceneDraw( );
}

//----------------------------------------------------------------------------
void __Test( void )
{
    Sleep( 1 );
}

//----------------------------------------------------------------------------
// Main routine - thread callback
DWORD __stdcall __MainLoop( void* Param )
{
    g_CanDrawScene = false;
    g_WinConfig.CreateGlWindow( );

	glutDisplayFunc( __Draw );
	glutReshapeFunc( __WindowResize );
	//glutIdleFunc( __Test );
	//glutTimerFunc( g_CameraConfig.WaitFrameTime, TimerFunction, g_CameraConfig.WaitFrameTime );
	g_AmbientConfig.SetAmbient( );
    if( g_WinConfig.IsFullScreen == true )
    {
        glutFullScreen( );
    }
	glutMainLoop( );

	return 0;
}

//----------------------------------------------------------------------------
HANDLE _StartMainLoop( void )
{
    DWORD ThreadId = (DWORD) NULL;
    return CreateThread( NULL, 0, __MainLoop, NULL, 0, &ThreadId );
}

//----------------------------------------------------------------------------

