#ifndef __CAMERA_H
#define __CAMERA_H

#include <gl/glut.h>
#include "types.h"

//----------------------------------------------------------------------------
class CCameraConfig
{
    private:
        TPOS3D EyePos, Target, Up;

    public:
        GLfloat Angle;
        GLfloat Near;
        GLfloat Far;
        GLfloat fAspect;

        //functions
        void SetCamera( const double EyeX, const double EyeY, const double EyeZ, const double TargetX, const double TargetY, const double TargetZ );
        double CameraRotate( const char Axis, const double Angle, const bool Incremental = true );
        void CameraTranslate( const double X, const double Y, const double Z );
        void SetCameraUp( const double X, const double Y, const double Z );
        void DefineView( void );

        //constructor
        CCameraConfig( void );
};

//----------------------------------------------------------------------------

extern CCameraConfig g_CameraConfig;

#endif
