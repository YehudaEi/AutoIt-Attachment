#ifndef __LIGHT_H
#define __LIGHT_H

#include "types.h"

//----------------------------------------------------------------------------
typedef struct tagCONSTLIGHT
{
    int Number;
    TPOS3D Position;
    //TPOS3D SpotTarget;
    TRGBA Ambient;
    TRGBA Diffuse;
    TRGBA Specular;

	//for linked list
	tagCONSTLIGHT *PreviousNode;
	tagCONSTLIGHT *NextNode;
} TCONSTLIGHT;

//----------------------------------------------------------------------------
class CLightManage
{
	//Coming soon ;D
    private:
        tagCONSTLIGHT *LightsPtr;

        //FUNCTIONS
        int SetPropertieColour( int LightNumber, int PropCode, TRGBA Colour );
        void SetSingleLight( tagCONSTLIGHT* Config );

    public:
        //FUNCTIONS
        int CreateLight( int Number, TPOS3D Position );
        int SetLightAmbient( int LightNumber, TRGBA Colour );
        int SetLightDiffuse( int LightNumber, TRGBA Colour );
        int SetLightSpecular( int LightNumber, TRGBA Colour );
        int SetLightPosition( int LightNumber, TPOS3D Position );

        void SetLights( void );

        //constructor
        CLightManage( void );
};

//----------------------------------------------------------------------------

extern CLightManage g_LightManage;

#endif
