#ifndef __GLFUNC_H
#define __GLFUNC_H

#include <windows.h>
#include "types.h"

/****************************************************************************
 * classes
 *
 ****************************************************************************/
class CWindowConfig
{
    private:
        int Width, Height, Top, Left;
        char Title[200];
    public:
        HWND Hwnd;
        bool IsFullScreen;

        //functions
        HWND DefineGlWindow( char* WinTitle, const int Width, const int Height, const int Left, const int Top );
        HWND SetToWindow( const HWND Hwnd, const int Left, const int Top, const int Width, const int Height );
        void CreateGlWindow( void );

        //constructor
        CWindowConfig( void );
};

/****************************************************************************
 * global variables
 *
 ****************************************************************************/
extern CWindowConfig g_WinConfig;
extern bool g_CanDrawScene;
extern HINSTANCE g_hInstance;

/****************************************************************************
 * prototipes
 *
 ****************************************************************************/
void NormalizeAngles( double *X, double *Y, double *Z );
void _DefaultConfig( void );
void _DefineGlWindow( int Width, int Height, char* WinTitle );
HANDLE _StartMainLoop( );

#endif

//----------------------------------------------------------------------------
