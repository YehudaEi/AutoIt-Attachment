#include <gl/glut.h>
#include <windows.h>
#include "light.h"

CLightManage g_LightManage;

/****************************************************************************
 * CLightManage
 *
 ****************************************************************************/
int CLightManage::CreateLight( int Number, TPOS3D Position )
{
    int RetVal = 1;
    if( Number >= 0 )
    {
        TRGBA Colour;
        Colour.Red = 0;
        Colour.Blue = 0;
        Colour.Green = 0;
        Colour.Alpha = 0;

        tagCONSTLIGHT *NewLight, *Temp;
        NewLight = new tagCONSTLIGHT;

        NewLight->Number = Number;
        NewLight->Position = Position;
        NewLight->Ambient = Colour;
        NewLight->Diffuse = Colour;
        NewLight->Specular = Colour;
        NewLight->PreviousNode = NULL;
        NewLight->NextNode = NULL;

		if( LightsPtr == NULL )
		{
			LightsPtr = NewLight;
		}
		else
		{
			Temp = LightsPtr;

			// We know this is not NULL - list not empty!
			while ( Temp->NextNode != NULL )
			{
				Temp = Temp->NextNode;
			}
			//Is NULL? then feeds
			NewLight->PreviousNode = Temp;
			Temp->NextNode = NewLight;
		}

        RetVal = 0;
    }

    return RetVal;
}

//----------------------------------------------------------------------------
int CLightManage::SetPropertieColour( int LightNumber, int PropCode, TRGBA Colour )
{
    int RetVal = 1;
    if( LightNumber >= 0 )
    {
        tagCONSTLIGHT *Lights = LightsPtr;
        do
        {
            if( Lights->Number == LightNumber )
            {
                switch ( PropCode )
                {
                    case 1:
                        Lights->Ambient = Colour;
                        RetVal = 0;
                        break;

                    case 2:
                        Lights->Diffuse = Colour;
                        RetVal = 0;
                        break;

                    case 3:
                        Lights->Specular = Colour;
                        RetVal = 0;
                        break;
                }
                break;
            }
            Lights = Lights->NextNode;
        }while( Lights != NULL );
    }
    return RetVal;
}

//----------------------------------------------------------------------------
int CLightManage::SetLightAmbient( int LightNumber, TRGBA Colour )
{
    return SetPropertieColour( LightNumber, 1, Colour );
}

//----------------------------------------------------------------------------
int CLightManage::SetLightDiffuse( int LightNumber, TRGBA Colour )
{
    return SetPropertieColour( LightNumber, 2, Colour );
}

//----------------------------------------------------------------------------
int CLightManage::SetLightSpecular( int LightNumber, TRGBA Colour )
{
    return SetPropertieColour( LightNumber, 3, Colour );
}

//----------------------------------------------------------------------------
void CLightManage::SetSingleLight( tagCONSTLIGHT* Config )
{
    GLenum CurrLight;

    //it's temporary - working only with const lights
    switch ( Config->Number )
    {
        case 0:
            CurrLight = GL_LIGHT0;
            break;

        case 1:
            CurrLight = GL_LIGHT1;
            break;

        case 2:
            CurrLight = GL_LIGHT2;
            break;

        case 3:
            CurrLight = GL_LIGHT3;
            break;

        case 4:
            CurrLight = GL_LIGHT4;
            break;

        case 5:
            CurrLight = GL_LIGHT5;
            break;

        case 6:
            CurrLight = GL_LIGHT6;
            break;

        case 7:
            CurrLight = GL_LIGHT7;
            break;
    }


	GLfloat AmbientLight[4] = {Config->Ambient.Red, Config->Ambient.Green, Config->Ambient.Blue, Config->Ambient.Alpha};
	GLfloat DifuseLight[4]  = {Config->Diffuse.Red, Config->Diffuse.Green, Config->Diffuse.Blue, Config->Diffuse.Alpha};	   // "color"
	GLfloat SpecularLight[4]= {Config->Specular.Red, Config->Specular.Green, Config->Specular.Blue, Config->Specular.Alpha};       // "bright"
	GLfloat LightPos[4]     = {Config->Position.X, Config->Position.Y, Config->Position.Z, 1.0};

	glLightfv( CurrLight, GL_AMBIENT, AmbientLight );
	glLightfv( CurrLight, GL_DIFFUSE, DifuseLight );
	glLightfv( CurrLight, GL_SPECULAR, SpecularLight );
	glLightfv( CurrLight, GL_POSITION, LightPos );
	glEnable( CurrLight );

	// Capacidade de brilho do material
	GLfloat especularidade[4]={1.0,1.0,1.0,1.0};
	GLint especMaterial = 30;

	glEnable( GL_COLOR_MATERIAL );
	glMaterialfv( GL_FRONT, GL_SPECULAR, especularidade ); //reflect
	glMateriali( GL_FRONT, GL_SHININESS, especMaterial ); //bright
    //MessageBox(NULL, "2", "Test", MB_OK);
}

//----------------------------------------------------------------------------
void CLightManage::SetLights( void )
{

	glEnable( GL_LIGHTING ); //enable light
	glShadeModel( GL_SMOOTH );
	glColorMaterial ( GL_FRONT, GL_AMBIENT_AND_DIFFUSE );
	glEnable ( GL_COLOR_MATERIAL );

	// Activate ambient light
    GLfloat AmbientLight[4]={0.2,0.2,0.2,1.0};     // "ambient light"
	glLightModelfv( GL_LIGHT_MODEL_AMBIENT, AmbientLight );

    if( LightsPtr != NULL )
    {
        tagCONSTLIGHT *Lights = LightsPtr;
        do
        {
            SetSingleLight( Lights );
            Lights = Lights->NextNode;
        } while ( Lights != NULL );
    }
}

//----------------------------------------------------------------------------
int CLightManage::SetLightPosition( int LightNumber, TPOS3D Position )
{
    int RetVal = 1;
    if( LightNumber >= 0 )
    {
        tagCONSTLIGHT *Lights = LightsPtr;
        do
        {
            if( Lights->Number == LightNumber )
            {
                Lights->Position = Position;
                break;
            }
            Lights = Lights->NextNode;
        }while( Lights != NULL );
    }
    return RetVal;
}

//----------------------------------------------------------------------------
CLightManage::CLightManage( void )
{
    LightsPtr = NULL;
}
