#include <malloc.h>
#include <stdio.h>
#include <windows.h>
#include <gl\gl.h>
#include <gl\glut.h>
#include <gl\glaux.h>
#include "mesh.h"
#include "texture.h"


CMeshRepository g_MeshRepository;

/****************************************************************************
 * CMeshRepository
 *
 ****************************************************************************/

//----------------------------------------------------------------------------
tagOBJECT* CMeshRepository::CheckIfObjExists( int ObjAddress )
{
	tagOBJECT *RetVal = NULL;

    if( ObjectsPtr != NULL )
	{
		tagOBJECT *Temp = ObjectsPtr;
		while ( Temp != NULL )
		{
			if( ObjAddress == ( (int) Temp ) )
			{
				RetVal = Temp;
				break;
			}
			Temp = Temp->NextNode;
		}
	}

	return RetVal;
}

//----------------------------------------------------------------------------
int CMeshRepository::CheckIfSubObjExists( int FatherObjAddress, int TargetAddress )
{
    tagOBJECT *ObjectsPtr = CheckIfObjExists( FatherObjAddress );
    if( ObjectsPtr != NULL )
	{
        for( int i = 0; i < ObjectsPtr->ChildCounter; i++ )
        {
            if( (int) ObjectsPtr->ChildObjects[i] == TargetAddress )
            {
                return i;
            }
        }
	}

	return -1;
}

//----------------------------------------------------------------------------
TtagSHAPE* CMeshRepository::GetShapePtr( int ObjAddress, int ShapeIndex )
{
    tagOBJECT *ObjectsPtr = CheckIfObjExists( ObjAddress );
    if( ObjectsPtr != NULL )
	{
        if( ShapeIndex < ObjectsPtr->ShapeCounter && ShapeIndex >= 0 )
        {
            return ObjectsPtr->Shapes[ShapeIndex];
        }
	}

	return NULL;
}

//----------------------------------------------------------------------------
tagOBJECT* CMeshRepository::CreateNewObject( void )
{
    tagOBJECT *NewObject;
    NewObject = new tagOBJECT;

    NewObject->Hide = false;

	NewObject->ShapeCounter = 0;
	NewObject->Shapes = NULL;

    NewObject->Rotate.X = 0;
    NewObject->Rotate.Y = 0;
    NewObject->Rotate.Z = 0;

    NewObject->Translate.X = 0;
    NewObject->Translate.Y = 0;
    NewObject->Translate.Z = 0;

    NewObject->Scale.X = 1;
    NewObject->Scale.Y = 1;
    NewObject->Scale.Z = 1;

    NewObject->ChildObjects = NULL;
    NewObject->ChildCounter = 0;

    NewObject->PreviousNode = NULL;
    NewObject->NextNode = NULL;

    return NewObject;
}

//----------------------------------------------------------------------------
TtagSHAPE* CMeshRepository::CreateNewShape( void )
{
    TtagSHAPE* NewShape;
    NewShape = new TtagSHAPE;

	NewShape->Translate.X = 0;
	NewShape->Translate.Y = 0;
	NewShape->Translate.Z = 0;
	NewShape->Rotate.X = 0;
	NewShape->Rotate.Y = 0;
	NewShape->Rotate.Z = 0;
	NewShape->Scale.X = 1;
	NewShape->Scale.Y = 1;
	NewShape->Scale.Z = 1;

	NewShape->TextureID = -1;
    NewShape->Color.Red = 0.0;
	NewShape->Color.Green = 0.0;
	NewShape->Color.Blue = 0.0;
	NewShape->Color.Alpha = 1.0;

	NewShape->ShapeType = 0;
	NewShape->ShapeData = NULL;

	return NewShape;
}

//----------------------------------------------------------------------------
int CMeshRepository::AddObject( void )
{
    int RetVal = 0;

	tagOBJECT *NewObject, *Temp;

    //feeds NewObject
    NewObject = CreateNewObject( );

	if( ObjectsPtr == NULL )
	{
		ObjectsPtr = NewObject;
		RetVal = (int) NewObject;
	}
	else
	{
		Temp = ObjectsPtr;

		// We know this is not NULL - list not empty!
		while ( Temp->NextNode != NULL )
		{
			Temp = Temp->NextNode;
		}
		//Is NULL? then feeds
		NewObject->PreviousNode = Temp;
		Temp->NextNode = NewObject;
		RetVal = (int) NewObject;
	}

    return RetVal;
}

//----------------------------------------------------------------------------
int CMeshRepository::DeleteObject( const int ObjAddress )
{
    int RetVal = 1;

    if( ObjectsPtr != NULL )
	{
		tagOBJECT *TargetObject;
		TargetObject = CheckIfObjExists( ObjAddress );
		if( TargetObject != NULL )
		{
            //deleting object referencies from groups
	        tagOBJECT *Temp = ObjectsPtr;
			long int Current;
			long int Target = (long int) TargetObject;
	        while ( Temp != NULL )
	        {
				Current = (long int) Temp;
				if( Current != Target )
				{
					UnSetObj( Current, Target );
				}
		        Temp = Temp->NextNode;
	        }

			RemObject( (int) TargetObject );

			//deleting object itself
			_DeleteObject( TargetObject );

            delete TargetObject;

			RetVal = 0;
		}
	}

    return RetVal;
}

//----------------------------------------------------------------------------
void CMeshRepository::_DeleteObject( tagOBJECT* TargetPtr )
{
    if( TargetPtr->PreviousNode != NULL )
    {
        tagOBJECT *Previous, *Next;
        if( TargetPtr->NextNode != NULL )
        {
            //realloc if not start or end item
            //
            Previous = TargetPtr->PreviousNode;
            Next = TargetPtr->NextNode;

            Previous->NextNode = Next;
            Next->PreviousNode = Previous;
        }
        else
        {
            //working on end item
            //
            tagOBJECT *Temp;
            Temp = TargetPtr->PreviousNode;
            Temp->NextNode = NULL;
        }
    }
    else
    {
        //working on start item
        //
        tagOBJECT *Temp;
        if( TargetPtr->NextNode != NULL )
        {
            Temp = TargetPtr->NextNode;
            Temp->PreviousNode = NULL;
            ObjectsPtr = Temp;
        }
        else
        {
            ObjectsPtr = NULL;
        }
    }
}

//----------------------------------------------------------------------------
void CMeshRepository::TranslateObject( const int ObjAddress, const TPOS3D NewPos )
{
	tagOBJECT *TargetObject = CheckIfObjExists( ObjAddress );
    if( TargetObject != NULL )
    {
		TargetObject->Translate = NewPos;
	}
}

//----------------------------------------------------------------------------
void CMeshRepository::RotateObject( const int ObjAddress, const TPOS3D Angles )
{
	tagOBJECT *TargetObject = CheckIfObjExists( ObjAddress );
    if( TargetObject != NULL )
    {
		TargetObject->Rotate = Angles;
	}
}

//----------------------------------------------------------------------------
void CMeshRepository::ScaleObject( const int ObjAddress, const TPOS3D Scales )
{
	tagOBJECT *TargetObject = CheckIfObjExists( ObjAddress );
    if( TargetObject != NULL )
    {
		TargetObject->Scale = Scales;
	}
}

//----------------------------------------------------------------------------
void CMeshRepository::ScaleShape( const int ObjAddress, const int ShapeIndex, const TPOS3D Scales )
{
	TtagSHAPE *TargetShape = GetShapePtr( ObjAddress, ShapeIndex );
    if( TargetShape != NULL )
    {
		TargetShape->Scale = Scales;
	}
}

//----------------------------------------------------------------------------
void CMeshRepository::RotateShape( const int ObjAddress, const int ShapeIndex, const TPOS3D Angles )
{
	TtagSHAPE *TargetShape = GetShapePtr( ObjAddress, ShapeIndex );
    if( TargetShape != NULL )
    {
		TargetShape->Rotate = Angles;
	}
}

//----------------------------------------------------------------------------
void CMeshRepository::TranslateShape( const int ObjAddress, const int ShapeIndex, const TPOS3D NewPos )
{
	TtagSHAPE *TargetShape = GetShapePtr( ObjAddress, ShapeIndex );
    if( TargetShape != NULL )
    {
		TargetShape->Translate = NewPos;
	}
}

//----------------------------------------------------------------------------
void CMeshRepository::SetObjToObj( tagOBJECT* TargetObj, tagOBJECT* ObjectPtr )
{
    if( ObjectPtr == TargetObj ) return;

    long Size = sizeof( tagOBJECT* );
    int Counter = TargetObj->ChildCounter;
    long LastSize = Size * Counter;
    long NewSize = LastSize + Size;
    if( Counter > 0 )
    {
        TargetObj->ChildObjects = (tagOBJECT**) realloc( TargetObj->ChildObjects, NewSize );
    }
    else
    {
        TargetObj->ChildObjects = (tagOBJECT**) malloc( NewSize );
    }
    tagOBJECT** ObjectRepository = (tagOBJECT**) ( TargetObj->ChildObjects + Counter );
    memcpy( ObjectRepository, &ObjectPtr, Size );
    (TargetObj->ChildCounter)++;
}

//----------------------------------------------------------------------------
int CMeshRepository::UnSetObj( const int TargetObjAddress, const int ObjAddress )
{
	tagOBJECT* TargetGrp = CheckIfObjExists( TargetObjAddress );
	if( TargetGrp != NULL )
	{
		long Size = sizeof( tagOBJECT* );
		int Counter = TargetGrp->ChildCounter;
		long LastSize = Size * Counter;
		long NewSize = LastSize - Size;
		if ( NewSize < 0 ) NewSize = 0;

		if( Counter >= 0 )
		{
			for( long i = 0; i < Counter; i++ )
			{
				if( (int) TargetGrp->ChildObjects[i] == ObjAddress )
				{
					(TargetGrp->ChildCounter)--;
					//copying the data after curr point
					if( i + 1 < Counter )
					{
						tagOBJECT** CurrPtr = (tagOBJECT**)TargetGrp->ChildObjects[i+1];
						memcpy( TargetGrp->ChildObjects, &CurrPtr, LastSize - ( Size * ( i + 1 ) ) );
					}
					//realocating memory
					TargetGrp->ChildObjects = (tagOBJECT**) realloc( TargetGrp->ChildObjects, NewSize );
					return 0;
				}
			}
		}
	}
    return 1;
}

//----------------------------------------------------------------------------
int CMeshRepository::SetToObject( const int DestObjAddress, const int ObjAddress )
{
    int RetVal = 1;

	tagOBJECT *TargetGroup = CheckIfObjExists( DestObjAddress );
    if( TargetGroup != NULL )
	{
		tagOBJECT *TargetObject = CheckIfObjExists( ObjAddress );
		if( TargetObject != NULL )
		{
            SetObjToObj( TargetGroup, TargetObject );
 		}
		RetVal = 0;
	}

	return RetVal;
}

//----------------------------------------------------------------------------
int CMeshRepository::SetInvisibleObject( const int ObjAddress, const bool ObjectStatus )
{
    int RetVal = 1;

	tagOBJECT *TargetObject = CheckIfObjExists( ObjAddress );
    if( TargetObject != NULL )
	{
	    TargetObject->Hide = ObjectStatus;
		RetVal = 0;
	}

	return RetVal;
}

//----------------------------------------------------------------------------
int CMeshRepository::AddShape( const int ObjAddress, TtagSHAPE* Shape )
{
    int RetVal = 0;

	tagOBJECT *TargetObject = CheckIfObjExists( ObjAddress );
    if( TargetObject != NULL )
    {
		long Size = sizeof( TtagSHAPE );
		int Counter = TargetObject->ShapeCounter;
		long LastSize = Size * Counter;
		long NewSize = LastSize + Size;
		if( Counter > 0 )
		{
			TargetObject->Shapes = (TtagSHAPE**) realloc( TargetObject->Shapes, NewSize );
		}
		else
		{
			TargetObject->Shapes = (TtagSHAPE**) malloc( NewSize );
		}

		//add new shape
		TtagSHAPE* ShapeRepository = (TtagSHAPE*) ( TargetObject->Shapes + Counter );
		memcpy( ShapeRepository, &Shape, Size );
        RetVal = TargetObject->ShapeCounter; //return shape index
		(TargetObject->ShapeCounter)++;
		//RetVal = (int) Shape;
	}

	return RetVal;
}

//----------------------------------------------------------------------------
void CMeshRepository::PrintGlSpheres( const TtagSHAPE* ShapePtr )
{
	double Red, Green, Blue, Alpha;
	TGLSPHERE*  SpherePtr = (TGLSPHERE*)(ShapePtr->ShapeData);

	Red = ShapePtr->Color.Red;
	Green = ShapePtr->Color.Green;
	Blue = ShapePtr->Color.Blue;
	Alpha = ShapePtr->Color.Alpha;

	double X = SpherePtr->Vertex.X;
	double Y = SpherePtr->Vertex.Y;
	double Z = SpherePtr->Vertex.Z;

	if( textureManager.textureMode )
    {
        if( ShapePtr->TextureID >= 0 ) glBindTexture( GL_TEXTURE_2D, textureManager.generatedTextures[ShapePtr->TextureID] );
        else glBindTexture( GL_TEXTURE_2D, textureManager.emptyTex );
    }

    glColor4f( Red, Green, Blue, Alpha );
	glTranslatef ( X, Y, Z );
    glRotatef( -90, 1, 0, 0 );
	GLUquadricObj *QuadricObj = NULL;
    QuadricObj = gluNewQuadric( );
    gluQuadricDrawStyle ( QuadricObj, GLU_FILL   );
    gluQuadricNormals   ( QuadricObj, GLU_SMOOTH );
    gluQuadricTexture   ( QuadricObj, GL_TRUE    );
    gluSphere( QuadricObj, SpherePtr->Radius, SpherePtr->Slices, SpherePtr->Stacks );
    gluDeleteQuadric ( QuadricObj );
}

//----------------------------------------------------------------------------
void CMeshRepository::PrintGlCylinders( const TtagSHAPE* ShapePtr )
{
	double Red, Green, Blue, Alpha;
    TGLCYLINDER*  CylinderPtr = (TGLCYLINDER*)(ShapePtr->ShapeData);

	Red = ShapePtr->Color.Red;
	Green = ShapePtr->Color.Green;
	Blue = ShapePtr->Color.Blue;
	Alpha = ShapePtr->Color.Alpha;

	double X = CylinderPtr->Base.X;
	double Y = CylinderPtr->Base.Y;
	double Z = CylinderPtr->Base.Z;

    glDisable(GL_CULL_FACE);
	if( textureManager.textureMode )
    {
        if( ShapePtr->TextureID >= 0 ) glBindTexture( GL_TEXTURE_2D, textureManager.generatedTextures[ShapePtr->TextureID] );
        else glBindTexture( GL_TEXTURE_2D, textureManager.emptyTex );
    }

    glColor4f( Red, Green, Blue, Alpha );
	glTranslatef ( X, Y, Z );
    glRotatef( -90, 1, 0, 0 );
	GLUquadricObj *QuadricObj = NULL;
    QuadricObj = gluNewQuadric( );
    gluQuadricDrawStyle ( QuadricObj, GLU_FILL   );
    gluQuadricNormals   ( QuadricObj, GLU_SMOOTH );
    gluQuadricTexture   ( QuadricObj, GL_TRUE    );
    gluCylinder( QuadricObj, CylinderPtr->Radius1, CylinderPtr->Radius2, CylinderPtr->Height, CylinderPtr->Slices, CylinderPtr->Stacks );
    //gluCylinder (	quad, base, top, height, slices, stacks )
    gluDeleteQuadric ( QuadricObj );
    glEnable(GL_CULL_FACE);
}

//----------------------------------------------------------------------------
void CMeshRepository::PrintLines( const TtagSHAPE* ShapePtr )
{

	double Red, Green, Blue, Alpha;
    TLINE*  LinePtr = (TLINE*)(ShapePtr->ShapeData);

	if( LinePtr->Shaded == false )
	{
		glDisable( GL_LIGHTING ); //disable light
	}

	Red = ShapePtr->Color.Red;
	Green = ShapePtr->Color.Green;
	Blue = ShapePtr->Color.Blue;
	Alpha = ShapePtr->Color.Alpha;

	glColor4f( Red, Green, Blue, Alpha );
	glBegin( GL_LINES );
	for( int k = 0; k < 2; k++ )
	{
		glVertex3f( LinePtr->Vertex[k].X, LinePtr->Vertex[k].Y, LinePtr->Vertex[k].Z );
	}
	glEnd();

	glEnable( GL_LIGHTING ); //enable light
}

//----------------------------------------------------------------------------
void CMeshRepository::PrintTriangles( const TtagSHAPE* ShapePtr )
{
	double NormalX, NormalY, NormalZ, Red, Green, Blue, Alpha;
    TTRIANGLE*  TrianglePtr = (TTRIANGLE*)(ShapePtr->ShapeData);

	Red = ShapePtr->Color.Red;
	Green = ShapePtr->Color.Green;
	Blue = ShapePtr->Color.Blue;
	Alpha = ShapePtr->Color.Alpha;

	NormalX = TrianglePtr->Normal.X;
	NormalY = TrianglePtr->Normal.Y;
	NormalZ = TrianglePtr->Normal.Z;

    if( textureManager.textureMode )
    {
        if( ShapePtr->TextureID >= 0 ) glBindTexture( GL_TEXTURE_2D,textureManager.generatedTextures[ShapePtr->TextureID] );
        else glBindTexture( GL_TEXTURE_2D,textureManager.emptyTex );
    }

    glColor4f( Red, Green, Blue, Alpha );
	glBegin( GL_TRIANGLES );
        glNormal3f( NormalX, NormalY, NormalZ );

        //texture map
        glTexCoord2f(1.0f,0.0f); glVertex3f( TrianglePtr->Vertex[0].X, TrianglePtr->Vertex[0].Y, TrianglePtr->Vertex[0].Z );
        glTexCoord2f(0.0f,0.0f); glVertex3f( TrianglePtr->Vertex[1].X, TrianglePtr->Vertex[1].Y, TrianglePtr->Vertex[1].Z );
        glTexCoord2f(0.0f,1.0f); glVertex3f( TrianglePtr->Vertex[2].X, TrianglePtr->Vertex[2].Y, TrianglePtr->Vertex[2].Z );
	glEnd();
}

//----------------------------------------------------------------------------
void CMeshRepository::PrintQuads( const TtagSHAPE* ShapePtr )
{
	double NormalX, NormalY, NormalZ, Red, Green, Blue, Alpha;
    TQUAD*  QuadPtr = (TQUAD*)(ShapePtr->ShapeData);

	Red = ShapePtr->Color.Red;
	Green = ShapePtr->Color.Green;
	Blue = ShapePtr->Color.Blue;
	Alpha = ShapePtr->Color.Alpha;

    NormalX = QuadPtr->Normal.X;
    NormalY = QuadPtr->Normal.Y;
    NormalZ = QuadPtr->Normal.Z;

    if( textureManager.textureMode )
    {
        if( ShapePtr->TextureID >= 0 ) glBindTexture( GL_TEXTURE_2D, textureManager.generatedTextures[ShapePtr->TextureID] );
        else glBindTexture( GL_TEXTURE_2D, textureManager.emptyTex );
    }

    glColor4f( Red, Green, Blue, Alpha );
	glBegin( GL_QUADS );
        glNormal3f( NormalX, NormalY, NormalZ );

        //texture map
        glTexCoord2f(0.0f,0.0f); glVertex3f( QuadPtr->Vertex[0].X, QuadPtr->Vertex[0].Y, QuadPtr->Vertex[0].Z );
        glTexCoord2f(1.0f,0.0f); glVertex3f( QuadPtr->Vertex[1].X, QuadPtr->Vertex[1].Y, QuadPtr->Vertex[1].Z );
        glTexCoord2f(1.0f,1.0f); glVertex3f( QuadPtr->Vertex[2].X, QuadPtr->Vertex[2].Y, QuadPtr->Vertex[2].Z );
        glTexCoord2f(0.0f,1.0f); glVertex3f( QuadPtr->Vertex[3].X, QuadPtr->Vertex[3].Y, QuadPtr->Vertex[3].Z );
	glEnd();
}

//----------------------------------------------------------------------------
void CMeshRepository::PrintGlChars( const TtagSHAPE* ShapePtr )
{
	double Red, Green, Blue;
    TGLCHAR*  GlCharPtr = (TGLCHAR*)(ShapePtr->ShapeData);

	Red = ShapePtr->Color.Red;
	Green = ShapePtr->Color.Green;
	Blue = ShapePtr->Color.Blue;

	glDisable( GL_LIGHTING );
	glColor3f( Red, Green, Blue );

	double X = GlCharPtr->Pos.X;
	double Y = GlCharPtr->Pos.Y;
	double Z = GlCharPtr->Pos.Z;

	glTranslatef ( X, Y, Z );
	if( GlCharPtr->Type == 1 ) glRasterPos3f( 0, 0, 0 );
	int index = 0;
	while( GlCharPtr->CharArray[index] != '\0' )
	{
	    switch( GlCharPtr->Type )
	    {
	        case 0:
                glutStrokeCharacter( GLUT_STROKE_ROMAN, GlCharPtr->CharArray[index] );
                break;
            case 1:
                glutBitmapCharacter( GLUT_BITMAP_HELVETICA_12, GlCharPtr->CharArray[index] );
                break;
	    }
		index++;
	}
    glEnable( GL_LIGHTING );
}

//----------------------------------------------------------------------------
void CMeshRepository::PrintPartialDisks( const TtagSHAPE* ShapePtr )
{
	double Red, Green, Blue, Alpha;
    TPARTDISK*  PartDskPtr = (TPARTDISK*)(ShapePtr->ShapeData);

	Red = ShapePtr->Color.Red;
	Green = ShapePtr->Color.Green;
	Blue = ShapePtr->Color.Blue;
	Alpha = ShapePtr->Color.Alpha;

	double X = PartDskPtr->Base.X;
	double Y = PartDskPtr->Base.Y;
	double Z = PartDskPtr->Base.Z;

    glDisable(GL_CULL_FACE);
	if( textureManager.textureMode )
    {
        if( ShapePtr->TextureID >= 0 ) glBindTexture( GL_TEXTURE_2D, textureManager.generatedTextures[ShapePtr->TextureID] );
        else glBindTexture( GL_TEXTURE_2D, textureManager.emptyTex );
    }

    glColor4f( Red, Green, Blue, Alpha );
	glTranslatef ( X, Y, Z );
    glRotatef( -90, 1, 0, 0 );
	GLUquadricObj *QuadricObj = NULL;
    QuadricObj = gluNewQuadric( );
    gluQuadricDrawStyle ( QuadricObj, GLU_FILL   );
    gluQuadricNormals   ( QuadricObj, GLU_SMOOTH );
    gluQuadricTexture   ( QuadricObj, GL_TRUE    );
    gluPartialDisk ( QuadricObj, PartDskPtr->Radius1, PartDskPtr->Radius2, PartDskPtr->Slices, PartDskPtr->Stacks, PartDskPtr->StartAngle, PartDskPtr->SweepAngle );
    //gluPartialDisk( quadObject, innerRadius, outerRadius, slices, loops, startAngle, sweepAngle );
    gluDeleteQuadric ( QuadricObj );
    glEnable(GL_CULL_FACE);
}

//----------------------------------------------------------------------------
void CMeshRepository::PrintCubes( const TtagSHAPE* ShapePtr )
{
	double Red, Green, Blue, Alpha;
    TPOS3D*  CubePtr = (TPOS3D*)(ShapePtr->ShapeData);

	Red = ShapePtr->Color.Red;
	Green = ShapePtr->Color.Green;
	Blue = ShapePtr->Color.Blue;
	Alpha = ShapePtr->Color.Alpha;

    double wid = CubePtr->X;
    double hgt = CubePtr->Y;
    double dep = CubePtr->Z;

    if( textureManager.textureMode )
    {
        if( ShapePtr->TextureID >= 0 ) glBindTexture( GL_TEXTURE_2D, textureManager.generatedTextures[ShapePtr->TextureID] );
        else glBindTexture( GL_TEXTURE_2D, textureManager.emptyTex );
    }

    glColor4f( Red, Green, Blue, Alpha );

    glBegin(GL_QUADS);
        // Top
        glNormal3d( 0, 1, 0 );
        glTexCoord2f(0.0f,0.0f); glVertex3d( -wid/2, hgt/2, dep/2 );
        glTexCoord2f(1.0f,0.0f); glVertex3d( wid/2, hgt/2, dep/2 );
        glTexCoord2f(1.0f,1.0f); glVertex3d( wid/2, hgt/2, -dep/2 );
        glTexCoord2f(0.0f,1.0f); glVertex3d( -wid/2, hgt/2, -dep/2 );
        // Back
        glNormal3d( 0,0,1 );
        glTexCoord2f(0.0f,1.0f); glVertex3d( -wid/2, hgt/2, dep/2 );
        glTexCoord2f(0.0f,0.0f); glVertex3d( -wid/2, -hgt/2, dep/2 );
        glTexCoord2f(1.0f,0.0f); glVertex3d( wid/2, -hgt/2, dep/2 );
        glTexCoord2f(1.0f,1.0f); glVertex3d( wid/2, hgt/2, dep/2 );
        // Front
        glNormal3d( 0,0,-1 );
        glTexCoord2f(1.0f,1.0f); glVertex3d( -wid/2, hgt/2, -dep/2 );
        glTexCoord2f(0.0f,1.0f); glVertex3d( wid/2, hgt/2, -dep/2 );
        glTexCoord2f(0.0f,0.0f); glVertex3d( wid/2, -hgt/2, -dep/2 );
        glTexCoord2f(1.0f,0.0f); glVertex3d( -wid/2, -hgt/2, -dep/2 );
        // Left
        glNormal3d( 1,0,0 );
        glTexCoord2f(1.0f,1.0f); glVertex3d( wid/2, hgt/2, -dep/2 );
        glTexCoord2f(0.0f,1.0f); glVertex3d( wid/2, hgt/2, dep/2 );
        glTexCoord2f(0.0f,0.0f); glVertex3d( wid/2, -hgt/2, dep/2 );
        glTexCoord2f(1.0f,0.0f); glVertex3d( wid/2, -hgt/2, -dep/2 );
        // Right
        glNormal3d( -1,0,0 );
        glTexCoord2f(1.0f,1.0f); glVertex3d( -wid/2, hgt/2, dep/2 );
        glTexCoord2f(0.0f,1.0f); glVertex3d( -wid/2, hgt/2, -dep/2 );
        glTexCoord2f(0.0f,0.0f); glVertex3d( -wid/2, -hgt/2, -dep/2 );
        glTexCoord2f(1.0f,0.0f); glVertex3d( -wid/2, -hgt/2, dep/2 );
        // Bottom
        glNormal3d( 0,-1,0 );
        glTexCoord2f(0.0f,1.0f); glVertex3d( -wid/2, -hgt/2, dep/2 );
        glTexCoord2f(0.0f,0.0f); glVertex3d( -wid/2, -hgt/2, -dep/2 );
        glTexCoord2f(1.0f,0.0f); glVertex3d( wid/2, -hgt/2, -dep/2 );
        glTexCoord2f(1.0f,1.0f); glVertex3d( wid/2, -hgt/2, dep/2 );
    glEnd();
}

//----------------------------------------------------------------------------
void CMeshRepository::PrintObjShapes( const tagOBJECT* ObjectPtr )
{
	//show single objects
	if( ObjectPtr != NULL )
	{
        for( int j = 0; j < ObjectPtr->ShapeCounter; j++ )
	    {
            TtagSHAPE*  ShapePtr = (TtagSHAPE*) ObjectPtr->Shapes[j];

		    glPushMatrix();

		    glTranslatef ( ShapePtr->Translate.X, ShapePtr->Translate.Y, ShapePtr->Translate.Z );

		    glRotatef( ShapePtr->Rotate.X, 1, 0, 0 );
		    glRotatef( ShapePtr->Rotate.Y, 0, 1, 0 );
		    glRotatef( ShapePtr->Rotate.Z, 0, 0, 1 );

		    glScalef( ShapePtr->Scale.X, ShapePtr->Scale.Y, ShapePtr->Scale.Z );

            switch( ShapePtr->ShapeType )
            {
                case 0:
                    PrintGlSpheres( ShapePtr );
                    break;
                case 1:
                    PrintGlCylinders( ShapePtr );
                    break;
                case 2:
                    PrintTriangles( ShapePtr );
                    break;
                case 3:
                    PrintQuads( ShapePtr );
                    break;
                case 4:
                    PrintLines( ShapePtr );
                    break;
                case 5:
                    PrintGlChars( ShapePtr );
                    break;
                case 6:
                    PrintPartialDisks( ShapePtr );
                    break;
                case 7:
                    PrintCubes( ShapePtr );
                    break;
            }

		    glPopMatrix( );
        }
	}
}

//----------------------------------------------------------------------------
bool CMeshRepository::CheckIfObjInPool( const tagOBJECT *DesiredObject )
{
	for( int i = 0; i < PoolCounter; i++ )
	{
		if( DesiredObject == Pool[i] )
		{
			return true;
		}
	}
	return false;
}

//----------------------------------------------------------------------------
int CMeshRepository::PutObject( const int ObjAddress )
{
	tagOBJECT *DesiredObject = CheckIfObjExists( ObjAddress );
    if( DesiredObject != NULL )
    {
		if( CheckIfObjInPool( DesiredObject ) == false )
		{
			long Size = sizeof( tagOBJECT* );
			int Counter = PoolCounter;
			long LastSize = Size * Counter;
			long NewSize = LastSize + Size;
			if( Counter > 0 )
			{
				Pool = (tagOBJECT**) realloc( Pool, NewSize );
			}
			else
			{
				Pool = (tagOBJECT**) malloc( NewSize );
			}

			//add object
			tagOBJECT* ObjectRepository = (tagOBJECT*) ( Pool + Counter );
			memcpy( ObjectRepository, &DesiredObject, Size );
			(PoolCounter)++;
			return 0;
		}
	}
	return 1;
}

//----------------------------------------------------------------------------
int CMeshRepository::RemObject( const int ObjAddress )
{
	tagOBJECT *DesiredObject = CheckIfObjExists( ObjAddress );
    if( DesiredObject != NULL )
    {
		if( CheckIfObjInPool( DesiredObject ) == true )
		{
			long Size = sizeof( tagOBJECT* );
			int Counter = PoolCounter;
			long LastSize = Size * Counter;
			long NewSize = LastSize - Size;
			if( Counter > 0 )
			{
				for( int i = 0; i < Counter; i++ )
				{
					if( (tagOBJECT*) Pool[i] == DesiredObject )
					{
						(PoolCounter)--;
						//copying the data after curr point
						if( i + 1 < Counter )
						{
							tagOBJECT** NextPtr = &Pool[i+1];
							tagOBJECT** PoolPtr = &Pool[i];
							memcpy( PoolPtr, NextPtr, LastSize - ( Size * ( i - 1 ) ) );
						}
						//realocating memory
						Pool = (tagOBJECT**) realloc( Pool, NewSize );
						return 0;
					}
				}
			}
		}
	}
	return 1;
}

//----------------------------------------------------------------------------
void CMeshRepository::ClearPrintBuffer( void )
{
	free( Pool );
	Pool = NULL;
	PoolCounter = 0;
}

//----------------------------------------------------------------------------
void CMeshRepository::PrintObject( const tagOBJECT *RootObject )
{
    if( RootObject->Hide == false )
    {
        glPushMatrix();

        glTranslatef ( RootObject->Translate.X, RootObject->Translate.Y, RootObject->Translate.Z );

        glRotatef( RootObject->Rotate.X, 1, 0, 0 );
        glRotatef( RootObject->Rotate.Y, 0, 1, 0 );
        glRotatef( RootObject->Rotate.Z, 0, 0, 1 );

		glScalef( RootObject->Scale.X, RootObject->Scale.Y, RootObject->Scale.Z );

	    PrintObjShapes( RootObject );
        for( int i = 0; i < RootObject->ChildCounter; i++ )
	    {
            PrintObject( (tagOBJECT*) RootObject->ChildObjects[i] );
		}

	    glPopMatrix();
    }
}

//----------------------------------------------------------------------------
void CMeshRepository::PrintPulledObjects( void )
{
	for( int i = 0; i < PoolCounter; i++ )
	{
		PrintObject( Pool[i] );
	}
}

//----------------------------------------------------------------------------
CMeshRepository::CMeshRepository( void )
{
	ObjectsPtr = NULL;

	Pool = NULL;
	PoolCounter = 0;
}

//----------------------------------------------------------------------------
