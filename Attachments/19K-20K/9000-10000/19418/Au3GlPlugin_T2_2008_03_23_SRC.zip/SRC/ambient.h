#ifndef __AMBIENT_H
#define __AMBIENT_H

#include <gl/glut.h>
#include "types.h"

//----------------------------------------------------------------------------
class CAmbientConfig
{
    private:
        TRGBA ClearColor;
    public:
        //functions
        void SetClearColor( float Red, float Green, float Blue, float Alpha );
        void SetAmbient( void );
        void SetClearColour( void );

        //constructor
        CAmbientConfig( void );
};

//----------------------------------------------------------------------------

extern CAmbientConfig g_AmbientConfig;

#endif
