#include <stdio.h>
#include <math.h>
#include "types.h"
#include "camera.h"

CCameraConfig g_CameraConfig;

/****************************************************************************
 * CCameraConfig
 *
 ****************************************************************************/
void CCameraConfig::SetCamera( const double EyeX, const double EyeY, const double EyeZ, const double TargetX, const double TargetY, const double TargetZ )
{
    this->EyePos.X = EyeX;
    this->EyePos.Y = EyeY;
    this->EyePos.Z = EyeZ;
    this->Target.X = TargetX;
    this->Target.Y = TargetY;
    this->Target.Z = TargetZ;
}

//----------------------------------------------------------------------------
double GetHipotenuse( const double LegA, const double LegB )
{
    return sqrt( pow( LegA, 2 ) + pow( LegB, 2 ) ); // h^2 = a^2 + b^2 //by Pitagoras
}

//----------------------------------------------------------------------------
double GetAngle( const double OppositeLeg, const double AdjacentLeg, const double Hip )
{
    double RetVal = 0;
    double TAngle = atan( OppositeLeg / AdjacentLeg ) * ( 180 / pi );
    double SAngle = asin( OppositeLeg / Hip ) * 180 / pi;
    double CAngle = acos( AdjacentLeg / Hip ) * 180 / pi;

    if( TAngle >= 0 && TAngle <= 90 && SAngle >= 0 && SAngle <= 90 && CAngle >= 0 && CAngle <= 90 )
    {
        RetVal = CAngle; // I
    }
    if( TAngle >= -90 && TAngle < 0 && SAngle <= 90 && SAngle > 0 && CAngle < 180 && CAngle >= 90 )
    {
        RetVal = CAngle; // II
    }
    if( CAngle == 180 )
    {
        RetVal = CAngle; //180
    }
    if( TAngle > 0 && TAngle <= 90 && SAngle < 0 && SAngle >= -90 && CAngle < 180 && CAngle >= 90 )
    {
        RetVal = 360 - CAngle; // III
    }
    if( TAngle > -90 && TAngle < 0 && SAngle >= -90 && SAngle < 0 && CAngle < 90 && CAngle > 0 )
    {
        RetVal = 360 - CAngle; // IV
    }

    return RetVal;
}

//----------------------------------------------------------------------------
double Rotate( const double Angle, const double StartX, const double StartY, double* TargetX, double* TargetY, const bool Incremental = true )
{
	double Cat1 = *TargetY - StartY;
	double Cat2 = *TargetX - StartX;
    double Hip = GetHipotenuse( Cat1, Cat2 );
    double CurrAngle = 0;

    //incremental angle
    if( Incremental )
    {
        CurrAngle = GetAngle( Cat2, Cat1, Hip );
    }
    //end incremental
    if( CurrAngle <= 272 )
    {
        CurrAngle = CurrAngle;
    }

    CurrAngle += Angle;
    double RadAngle = ( pi / 180 ) * CurrAngle;

    //convertion to X/Y
    *TargetY = Hip * cos( RadAngle );
    *TargetX = Hip * sin( RadAngle );

    *TargetY += StartY;
    *TargetX += StartX;

    return CurrAngle;
}

//----------------------------------------------------------------------------
double CCameraConfig::CameraRotate( const char Axis, const double Angle, const bool Incremental )
{
    switch( Axis )
    {
        case 'X':
            return Rotate( Angle, this->EyePos.Z, this->EyePos.Y, &this->Target.Z, &this->Target.Y, Incremental );
        case 'Y':
            return Rotate( Angle, this->EyePos.X, this->EyePos.Z, &this->Target.X, &this->Target.Z, Incremental );
    }
    return 0;
}

//----------------------------------------------------------------------------
void CCameraConfig::CameraTranslate( const double X, const double Y, const double Z )
{
    this->Target.X = ( this->Target.X - this->EyePos.X ) + X;
    this->Target.Y = ( this->Target.Y - this->EyePos.Y ) + Y;
    this->Target.Z = ( this->Target.Z - this->EyePos.Z ) + Z;
    this->EyePos.X = X;
    this->EyePos.Y = Y;
    this->EyePos.Z = Z;
}

//----------------------------------------------------------------------------
void CCameraConfig::SetCameraUp( const double X, const double Y, const double Z )
{
    this->Up.X = X;
    this->Up.Y = Y;
    this->Up.Z = Z;
}

//----------------------------------------------------------------------------
void CCameraConfig::DefineView( void )
{
	glMatrixMode( GL_PROJECTION );
	glLoadIdentity( );

	// Perspective projection
	gluPerspective( this->Angle, this->fAspect, this->Near, this->Far );

	glMatrixMode( GL_MODELVIEW );
	glLoadIdentity( );
	glEnable( GL_DEPTH_TEST );

	// observer and tarjet positions
	gluLookAt( this->EyePos.X, this->EyePos.Y, this->EyePos.Z, this->Target.X, this->Target.Y, this->Target.Z, this->Up.X, this->Up.Y, this->Up.Z );
}

//----------------------------------------------------------------------------
CCameraConfig::CCameraConfig( void )
{
    //Set camera defaults
    this->fAspect = 1;
    this->Near = 0.1;
    this->Far = 1000;
    this->Angle = 45;
    SetCameraUp( 0, 1, 0 );
    SetCamera( 0, 0, 0, 0, 0, 0 );
}
