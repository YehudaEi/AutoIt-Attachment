Put all these files on SRC folder and you be able
to open "au3plugin.dsw" file on VC6.