#include <stdio.h>
#include <windows.h>
#include <math.h>
#include <gl\gl.h>
#include <gl\glu.h>
#include <gl\glaux.h>
#include "AU3_Plugin_SDK\au3plugin.h"
#include "texture.h"
#include "mesh.h"


texManager textureManager;
texManager::texManager()
{
 	this->textureCount = 0;
	this->onlyTextures = true;
	this->emptyTex = this->EmptyTexture( );
    this->generatedTextures = NULL;
}

int texManager::defineTextureBufferSize( int size )
{
	TextureData *pTextures = new TextureData [size];
	textures = pTextures;
	GLuint *pGLTextures = new GLuint[size];
	generatedTextures = pGLTextures;
	return AU3_PLUGIN_OK;
}

AUX_RGBImageRec *texManager::loadTextureFile(char *name, char *path)
{
	FILE *File=NULL;
	/*if (!*path)
	{
		return AU3_PLUGIN_ERR;
	}*/

	File=fopen(path,"r");
	if (File)
	{
		this->textures[this->textureCount].name				= name;
		this->textures[this->textureCount].path				= path;
		this->textures[this->textureCount].textureBitmap	= auxDIBImageLoad(path);
		this->textures[this->textureCount].textureId		= this->textureCount;
		this->textureCount++;
		fclose(File);
	}
	return AU3_PLUGIN_OK;
}

bool ResizeImage( TextureData *Texture )
{
    //adapted from example at http://www.cs.wisc.edu/graphics/Courses/559-f2006/Main/Tutorial10#toc3
    int NewWidth = (int) pow( 2, ceil ( log( Texture->textureBitmap->sizeX ) / log( 2.f ) ) );
    int NewHeight = (int) pow( 2, ceil( log( Texture->textureBitmap->sizeY ) / log( 2.f ) ) );

    if ( NewWidth != Texture->textureBitmap->sizeX && NewHeight != Texture->textureBitmap->sizeY )
    {
        unsigned char* ScaledData = new unsigned char[ NewWidth * NewHeight * 4 ];
        if( gluScaleImage( GL_RGB, Texture->textureBitmap->sizeX, Texture->textureBitmap->sizeY, GL_UNSIGNED_BYTE, Texture->textureBitmap->data, NewWidth, NewHeight, GL_UNSIGNED_BYTE, ScaledData ) != 0 )
        {
            ScaledData = NULL;
            return false;
        }
        Texture->textureBitmap->data = ScaledData;
        Texture->textureBitmap->sizeX = NewWidth;
        Texture->textureBitmap->sizeY = NewHeight;
    }
    return true;
}

int texManager::InitTextures( )
{
    glEnable( GL_TEXTURE_2D );
    glPixelStorei( GL_UNPACK_ALIGNMENT, 1 );
    if( onlyTextures == 1 )
    {
        glTexEnvf( GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_DECAL );
    }
	glGenTextures( this->textureCount, this->generatedTextures ); //&this->generatedTextures[0]

	for( GLuint i = 0; i < this->textureCount; i++ )
	{
	    glPushMatrix();

		glBindTexture( GL_TEXTURE_2D, this->generatedTextures[i] );
		glTexParameteri( GL_TEXTURE_2D,GL_TEXTURE_MAG_FILTER,GL_LINEAR );
		glTexParameteri( GL_TEXTURE_2D,GL_TEXTURE_MIN_FILTER,GL_LINEAR );

        ResizeImage( &this->textures[i] );

		glTexImage2D( GL_TEXTURE_2D, 0, 3, this->textures[i].textureBitmap->sizeX, this->textures[i].textureBitmap->sizeY, 0, GL_RGB, GL_UNSIGNED_BYTE, this->textures[i].textureBitmap->data );

        glPopMatrix();
		free( this->textures[i].textureBitmap->data );
        free( this->textures[i].textureBitmap );
	}

	return AU3_PLUGIN_OK;
}

int texManager::bindTexture( const int ObjAddress, const int ShapeIndex, char *texName )
{
	TtagSHAPE *ret = g_MeshRepository.GetShapePtr( ObjAddress, ShapeIndex );
	if( ret != NULL )
    {

        ret->TextureID = -1;
        for( GLuint i = 0; i < this->textureCount; i++ )
        {
            if( strcmp( texName, this->textures[i].name ) == 0 )
            {
                ret->TextureID = this->textures[i].textureId;
                break;
            }
        }
    }

	return AU3_PLUGIN_OK;
}

GLuint texManager::EmptyTexture()           // Create An Empty Texture
{
        GLuint txtnumber;                   // Texture ID
        unsigned int* data;                 // Stored Data

        // Create Storage Space For Texture Data (128x128x4)
        data = (unsigned int*) new GLuint[( ( 128 * 128 )* 4 * sizeof( unsigned int ) )];
        ZeroMemory( data, ( ( 128 * 128 ) * 4 * sizeof( unsigned int ) ) );                 // Clear Storage Memory

        glGenTextures( 1, &txtnumber );                                         // Create 1 Texture
        glBindTexture( GL_TEXTURE_2D, txtnumber );                              // Bind The Texture
        glTexImage2D( GL_TEXTURE_2D, 0, 4, 128, 128, 0,
                GL_RGBA, GL_UNSIGNED_BYTE, data );                              // Build Texture Using Information In data
        glTexParameteri( GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR );
        glTexParameteri( GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR );

        delete [] data;                 // Release data

        return txtnumber;               // Return The Texture ID
}
