#ifndef __MESH_H
#define __MESH_H

#include "types.h"

//----------------------------------------------------------------------------
typedef struct
{
	TPOS3D Vertex[3];
	TPOS3D Normal;
} TTRIANGLE;

//----------------------------------------------------------------------------
typedef struct
{
	TPOS3D Vertex[4];
	TPOS3D Normal;
} TQUAD;

//----------------------------------------------------------------------------
typedef struct
{
	TPOS3D Vertex[2];
	bool Shaded;
} TLINE;

//----------------------------------------------------------------------------
typedef struct
{
	TPOS3D Vertex;
	double Radius;
	long Slices;
	long Stacks;
} TGLSPHERE;

//----------------------------------------------------------------------------
typedef struct
{
	TPOS3D Base;
	double Radius1;
	double Radius2;
	double Height;
	long Slices;
	long Stacks;
} TGLCYLINDER;

//----------------------------------------------------------------------------
typedef struct
{
	TPOS3D Base;
	double Radius1;
	double Radius2;
	long Slices;
	long Stacks;
	double StartAngle;
	double SweepAngle;
} TPARTDISK;

//----------------------------------------------------------------------------
typedef struct
{
	TPOS3D Pos;
	int Type;
	char CharArray[256];
} TGLCHAR;

//----------------------------------------------------------------------------
typedef struct tagSHAPE
{
	TPOS3D Translate;
	TPOS3D Rotate;
	TPOS3D Scale;

	int TextureID;
    TRGBA Color;

	int ShapeType;
	LPARAM *ShapeData;

} TtagSHAPE;

//----------------------------------------------------------------------------
typedef struct tagOBJECT
{
    bool Hide;

	long ShapeCounter;
	TtagSHAPE **Shapes;

	TPOS3D Translate;
	TPOS3D Rotate;
	TPOS3D Scale;

	tagOBJECT **ChildObjects;
	long ChildCounter;

	//for linked list
	tagOBJECT *PreviousNode;
	tagOBJECT *NextNode;

} TtagOBJECT;

//----------------------------------------------------------------------------
class CMeshRepository
{
    private:
		tagOBJECT* ObjectsPtr;

		tagOBJECT** Pool;
		int PoolCounter;

		//methods
        tagOBJECT* CreateNewObject( void );
		bool CheckIfObjInPool( const tagOBJECT *DesiredObject );

        void _DeleteObject( tagOBJECT* ObjectPtr );

		void PrintTriangles( const TtagSHAPE* ShapePtr );
		void PrintQuads( const TtagSHAPE* ShapePtr );
		void PrintLines( const TtagSHAPE* ShapePtr );
		void PrintGlSpheres( const TtagSHAPE* ShapePtr );
		void PrintGlCylinders( const TtagSHAPE* ShapePtr );
		void PrintGlChars( const TtagSHAPE* ShapePtr );
		void PrintPartialDisks( const TtagSHAPE* ShapePtr );
        void PrintCubes( const TtagSHAPE* ShapePtr );

		void PrintObjShapes( const tagOBJECT* ObjectPtr );

        void SetObjToObj( tagOBJECT* TargetObject, tagOBJECT* ObjectPtr );

    public:
		tagOBJECT* CheckIfObjExists( int ObjAddress );
        int CheckIfSubObjExists( int FatherObjAddress, int TargetAddress );
		TtagSHAPE* CreateNewShape( void );
        TtagSHAPE* GetShapePtr( int ObjAddress, int ShapeIndex );

		//manage objects
        int AddObject( void );
		int DeleteObject( const int ObjAddress );

		//set object states
		void TranslateObject( const int ObjAddress, const TPOS3D NewPos );
		void RotateObject( const int ObjAddress, const TPOS3D Angles );
		void ScaleObject( const int ObjAddress, const TPOS3D Scales );
		int SetInvisibleObject( const int ObjAddress, const bool ObjectStatus );

		//set shape state
		void RotateShape( const int ObjAddress, const int ShapeIndex, const TPOS3D Angles );
		void TranslateShape( const int ObjAddress, const int ShapeIndex, const TPOS3D NewPos );
		void ScaleShape( const int ObjAddress, const int ShapeIndex, const TPOS3D Scales );

		//link objects
		int SetToObject( const int DestObjAddress, const int ObjAddress );
        int UnSetObj( const int DestObjAddress, const int ObjAddress );

        //add shape
		int AddShape( const int ObjAddress, TtagSHAPE* Shape );

		//show
		int PutObject( const int ObjAddress );
		int RemObject( const int ObjAddress );
		void ClearPrintBuffer( void );

		void PrintObject( const tagOBJECT *RootObject );
		void PrintPulledObjects( void );

        //constructor
        CMeshRepository( void );
};

//----------------------------------------------------------------------------

extern CMeshRepository g_MeshRepository;

#endif
