#include <gl\glaux.h>

typedef struct
{
	char			*name;
	char			*path;
	AUX_RGBImageRec *textureBitmap;
	int 		    textureId;
}TextureData;

class texManager {
private:
	//Fields
	TextureData *textures;
	GLuint		textureCount;
	//Methods
	GLuint EmptyTexture( );

public:
	//Fields
	BOOL textureMode;
	BOOL onlyTextures;
	GLuint		*generatedTextures;
	GLuint		emptyTex;
	//Methods
	texManager( );
	AUX_RGBImageRec *loadTextureFile( char *name, char *path );
	int defineTextureBufferSize( int size );
	int InitTextures( );
	int bindTexture( const int ObjAddress, const int ShapeIndex, char *texName );
};

extern texManager textureManager;
