#include <windows.h>
#include "AU3_Plugin_SDK\au3plugin.h"
#include "glfunc.h"
#include "mesh.h"
#include "light.h"
#include "camera.h"
#include "ambient.h"
#include "texture.h"

#ifdef BUILD_DLL
    #define DLL_EXPORT __declspec(dllexport)
#else
    #define DLL_EXPORT
#endif
#define _CRT_SECURE_NO_DEPRECATE

/*
// a sample exported function
void DLL_EXPORT SomeFunction(const LPCSTR sometext)
{
    MessageBoxA(0, sometext, "DLL Message", MB_OK | MB_ICONINFORMATION);
    char Message[265] = "";
	itoa( value, Message, 10 );
	MessageBoxA(0, Message, "DLL Message", MB_OK | MB_ICONINFORMATION);
}*/

/****************************************************************************
 * Function List
 *
 * This is where you define the functions available to AutoIt.  Including
 * the function name (Must be the same case as your exported DLL name), the
 * minimum and maximum number of parameters that the function takes.
 *
 ****************************************************************************/
/* "FunctionName", min_params, max_params */
AU3_PLUGIN_FUNC g_AU3_Funcs[] =
{
	{ "DefineGlWindow", 1, 5 },
	{ "EmbedGlWindow", 5, 5 },
	{ "SetClearColor", 3, 3 },
	{ "SetCamera", 6, 6 },
	{ "SetCameraPos", 3, 3 },
	{ "SetCameraRotate", 2, 2 },
	{ "SetCameraUp", 3, 3 },
	{ "SetCameraView", 2, 2 },
    { "SceneDraw", 0, 0 },
	{ "SetToObject", 2, 2 },
	{ "UnsetFromObject", 2, 2 },
	{ "ObjectCreate", 0, 0 },
    { "ObjectDelete", 1, 1 },
	{ "ObjectTranslate", 4, 4 },
	{ "ObjectRotate", 4, 4 },
	{ "ObjectScale", 4, 4 },
	{ "ObjectHide", 1, 1 },
	{ "ObjectShow", 1, 1 },
	{ "SetPrint", 1, 1 },
	{ "UnsetPrint", 1, 1 },
	{ "ClearPrintBuffer", 0, 0 },
	{ "AddLine", 11, 12 },
	{ "AddTriangle", 17, 17 },
	{ "AddQuad", 20, 20 },
	{ "AddSphere", 11, 11 },
	{ "AddCylinder", 13, 13 },
	{ "AddStrokeText", 8, 8 },
	{ "AddBitmapText", 8, 8 },
	{ "AddPartialDisk", 14, 14 },
    { "AddCube", 8, 8 },
	{ "ShapeTranslate", 5, 5 },
	{ "ShapeRotate", 5, 5 },
	{ "ShapeScale", 5, 5 },
	{ "CreateLight", 4, 4 },
	{ "SetLightAmbient", 4, 4 },
	{ "SetLightDiffuse", 4, 4 },
	{ "SetLightSpecular", 4, 4 },
	{ "SetLightPosition", 4, 4 },
	{ "TextureSetMode", 0, 1 },
	{ "TextureSetBuffer", 1, 1 },
	{ "TextureAdd"		, 2, 2 },
	{ "TextureBind"		, 3, 3 }
};

/****************************************************************************
 * AU3_GetPluginDetails()
 *
 * This function is called by AutoIt when the plugin dll is first loaded to
 * query the plugin about what functions it supports.  DO NOT MODIFY.
 *
 ****************************************************************************/
AU3_PLUGINAPI int AU3_GetPluginDetails( int *n_AU3_NumFuncs, AU3_PLUGIN_FUNC **p_AU3_Func )
{
	/* Pass back the number of functions that this DLL supports */
	*n_AU3_NumFuncs	= sizeof(g_AU3_Funcs)/sizeof(AU3_PLUGIN_FUNC);

	/* Pack back the address of the global function table */
	*p_AU3_Func = g_AU3_Funcs;

	return AU3_PLUGIN_OK;
}

/****************************************************************************
 * DllMain()
 ****************************************************************************/
BOOL WINAPI DllMain(HINSTANCE hinstDLL, DWORD fdwReason, LPVOID lpvReserved)
{
    switch (fdwReason)
    {
        case DLL_PROCESS_ATTACH:
            // attach to process
            // return FALSE to fail DLL load
            break;

        case DLL_PROCESS_DETACH:
            // detach from process
            break;

        case DLL_THREAD_ATTACH:
            // attach to thread
            break;

        case DLL_THREAD_DETACH:
            // detach from thread
            break;
    }
    g_hInstance = hinstDLL;
    return TRUE; // succesful
}

/****************************************************************************
 * Auto It Functions
 ****************************************************************************/

/****************************************************************************
 * DefineGlWindow( )
 *
 * DefineGlWindow( WinTitle[, Width, Height, Left, Top] )
 *
 ****************************************************************************/
AU3_PLUGIN_DEFINE( DefineGlWindow )
{
	/* The inputs to a plugin function are:
	 *		n_AU3_NumParams		- The number of parameters being passed
	 *		p_AU3_Params		- An array of variant like variables used by AutoIt
	 *
	 * The outputs of a plugin function are:
	 *		p_AU3_Result		- A pointer to a variant variable for the result
	 *		n_AU3_ErrorCode		- The value for @Error
	 *		n_AU3_ExtCode		- The value for @Extended
	 */

	AU3_PLUGIN_VAR	*pMyResult;
    int             Width = -1, Height = -1, Left = -1, Top = -1;
	char			*Title;

    Title	       = AU3_GetString(&p_AU3_Params[0]);
    if( n_AU3_NumParams > 1 )
        Width          = AU3_GetInt32(&p_AU3_Params[1]);
    if( n_AU3_NumParams > 2 )
        Height         = AU3_GetInt32(&p_AU3_Params[2]);
    if( n_AU3_NumParams > 3 )
        Left           = AU3_GetInt32(&p_AU3_Params[3]);
    if( n_AU3_NumParams > 4 )
        Top            = AU3_GetInt32(&p_AU3_Params[4]);

	/* set window parameters */
	int MainHwnd = (int) g_WinConfig.DefineGlWindow( Title, Width, Height, Left, Top );

	/* Free temporary storage */
	AU3_FreeString( Title );

	/* Allocate and build the return variable */
	pMyResult = AU3_AllocVar( );
	AU3_SetInt32( pMyResult, MainHwnd );


	/* Pass back the result, error code and extended code.
	 * Note: AutoIt is responsible for freeing the memory used in p_AU3_Result
	 */
	*p_AU3_Result		= pMyResult;
	*n_AU3_ErrorCode	= 0;
	*n_AU3_ExtCode		= 0;

	return AU3_PLUGIN_OK;
}

/****************************************************************************
 * EmbedGlWindow( )
 *
 * EmbedGlWindow( Hwnd, Width, Height, Left, Top )
 *
 ****************************************************************************/
AU3_PLUGIN_DEFINE( EmbedGlWindow )
{
	AU3_PLUGIN_VAR	*pMyResult;
    HWND            Hwnd;
    int             Left, Top, Width, Height;

    Hwnd    = (HWND) AU3_GetInt32(&p_AU3_Params[0]);
    Width   = AU3_GetInt32(&p_AU3_Params[1]);
    Height  = AU3_GetInt32(&p_AU3_Params[2]);
    Left    = AU3_GetInt32(&p_AU3_Params[3]);
    Top     = AU3_GetInt32(&p_AU3_Params[4]);

	/* set window parameters */
	int ChildHwnd = (int) g_WinConfig.SetToWindow( Hwnd, Left, Top, Width, Height );

	/* Allocate and build the return variable */
	pMyResult = AU3_AllocVar( );
	AU3_SetInt32( pMyResult, ChildHwnd );

	/* Pass back the result, error code and extended code.
	 * Note: AutoIt is responsible for freeing the memory used in p_AU3_Result
	 */
	*p_AU3_Result		= pMyResult;
	*n_AU3_ErrorCode	= 0;
	*n_AU3_ExtCode		= 0;

	return AU3_PLUGIN_OK;
}

/****************************************************************************
 * SetClearColor( )
 *
 * SetClearColor( Red, Green, Blue )
 *
 ****************************************************************************/
AU3_PLUGIN_DEFINE( SetClearColor )
{

	AU3_PLUGIN_VAR	*pMyResult;
    float            Red, Green, Blue;

    Red   = AU3_GetDouble(&p_AU3_Params[0]);
    Green = AU3_GetDouble(&p_AU3_Params[1]);
    Blue  = AU3_GetDouble(&p_AU3_Params[2]);

	g_AmbientConfig.SetClearColor( Red, Green, Blue, 1.0 );

	/* Allocate and build the return variable */
	pMyResult = AU3_AllocVar();
	AU3_SetInt32(pMyResult, 0);


	/* Pass back the result, error code and extended code.
	 * Note: AutoIt is responsible for freeing the memory used in p_AU3_Result
	 */
	*p_AU3_Result		= pMyResult;
	*n_AU3_ErrorCode	= 0;
	*n_AU3_ExtCode		= 0;

	return AU3_PLUGIN_OK;
}

/****************************************************************************
 * SetCamera( )
 *
 * SetCamera( EyeX, EyeY, EyeZ, TargetX, TargetY, TargetZ )
 *
 ****************************************************************************/
AU3_PLUGIN_DEFINE( SetCamera )
{

	AU3_PLUGIN_VAR	*pMyResult;
    double            EyeX, EyeY, EyeZ, TargetX, TargetY, TargetZ;

    EyeX    = AU3_GetDouble(&p_AU3_Params[0]);
    EyeY    = AU3_GetDouble(&p_AU3_Params[1]);
    EyeZ    = AU3_GetDouble(&p_AU3_Params[2]);
    TargetX = AU3_GetDouble(&p_AU3_Params[3]);
    TargetY = AU3_GetDouble(&p_AU3_Params[4]);
    TargetZ = AU3_GetDouble(&p_AU3_Params[5]);

	g_CameraConfig.SetCamera( EyeX, EyeY, EyeZ, TargetX, TargetY, TargetZ );

	/* Allocate and build the return variable */
	pMyResult = AU3_AllocVar();
	AU3_SetInt32(pMyResult, 0);


	/* Pass back the result, error code and extended code.
	 * Note: AutoIt is responsible for freeing the memory used in p_AU3_Result
	 */
	*p_AU3_Result		= pMyResult;
	*n_AU3_ErrorCode	= 0;
	*n_AU3_ExtCode		= 0;

	return AU3_PLUGIN_OK;
}

/****************************************************************************
 * SetCameraPos( )
 *
 * SetCameraPos( X, Y, Z )
 *
 ****************************************************************************/
AU3_PLUGIN_DEFINE( SetCameraPos )
{

	AU3_PLUGIN_VAR	*pMyResult;
    double          X = AU3_GetDouble(&p_AU3_Params[0]);
    double          Y = AU3_GetDouble(&p_AU3_Params[1]);
    double          Z = AU3_GetDouble(&p_AU3_Params[2]);

	g_CameraConfig.CameraTranslate( X, Y, Z );

	/* Allocate and build the return variable */
	pMyResult = AU3_AllocVar();
	AU3_SetInt32(pMyResult, 0);


	/* Pass back the result, error code and extended code.
	 * Note: AutoIt is responsible for freeing the memory used in p_AU3_Result
	 */
	*p_AU3_Result		= pMyResult;
	*n_AU3_ErrorCode	= 0;
	*n_AU3_ExtCode		= 0;

	return AU3_PLUGIN_OK;
}

/****************************************************************************
 * SetCameraRotate( )
 *
 * SetCameraRotate( Axis, Angle )
 *
 ****************************************************************************/
AU3_PLUGIN_DEFINE( SetCameraRotate )
{

	AU3_PLUGIN_VAR	*pMyResult;
    char*           Axis = AU3_GetString(&p_AU3_Params[0]);
    double          Angle = AU3_GetDouble(&p_AU3_Params[1]);

    NormalizeAngles( &Angle, &Angle, &Angle );
	g_CameraConfig.CameraRotate( Axis[0], Angle );

	/* Allocate and build the return variable */
	pMyResult = AU3_AllocVar();
	AU3_SetInt32(pMyResult, 0);


	/* Pass back the result, error code and extended code.
	 * Note: AutoIt is responsible for freeing the memory used in p_AU3_Result
	 */
	*p_AU3_Result		= pMyResult;
	*n_AU3_ErrorCode	= 0;
	*n_AU3_ExtCode		= 0;

	return AU3_PLUGIN_OK;
}

/****************************************************************************
 * SetCameraUp( )
 *
 * SetCameraUp( X, Y, Z )
 *
 ****************************************************************************/
AU3_PLUGIN_DEFINE( SetCameraUp )
{

	AU3_PLUGIN_VAR	*pMyResult;
    double            X, Y, Z;

    X    = AU3_GetDouble(&p_AU3_Params[0]);
    Y    = AU3_GetDouble(&p_AU3_Params[1]);
    Z    = AU3_GetDouble(&p_AU3_Params[2]);

	g_CameraConfig.SetCameraUp( X, Y, Z );

	/* Allocate and build the return variable */
	pMyResult = AU3_AllocVar();
	AU3_SetInt32(pMyResult, 0);


	/* Pass back the result, error code and extended code.
	 * Note: AutoIt is responsible for freeing the memory used in p_AU3_Result
	 */
	*p_AU3_Result		= pMyResult;
	*n_AU3_ErrorCode	= 0;
	*n_AU3_ExtCode		= 0;

	return AU3_PLUGIN_OK;
}

/****************************************************************************
 * SetCameraView( )
 *
 * SetCameraView( Near, Far )
 *
 ****************************************************************************/
AU3_PLUGIN_DEFINE( SetCameraView )
{

	AU3_PLUGIN_VAR	*pMyResult;
    double            Near, Far;

    Near = AU3_GetDouble(&p_AU3_Params[0]);
    Far  = AU3_GetDouble(&p_AU3_Params[1]);

	g_CameraConfig.Near = Near;
	g_CameraConfig.Far = Far;

	/* Allocate and build the return variable */
	pMyResult = AU3_AllocVar();
	AU3_SetInt32(pMyResult, 0);


	/* Pass back the result, error code and extended code.
	 * Note: AutoIt is responsible for freeing the memory used in p_AU3_Result
	 */
	*p_AU3_Result		= pMyResult;
	*n_AU3_ErrorCode	= 0;
	*n_AU3_ExtCode		= 0;

	return AU3_PLUGIN_OK;
}

/****************************************************************************
 * SceneDraw( )
 *
 ****************************************************************************/
AU3_PLUGIN_DEFINE( SceneDraw )
{
	AU3_PLUGIN_VAR	*pMyResult;

    g_CanDrawScene = true;

	/* Allocate and build the return variable */
	pMyResult = AU3_AllocVar();
	AU3_SetInt32(pMyResult, 0);


	/* Pass back the result, error code and extended code.
	 * Note: AutoIt is responsible for freeing the memory used in p_AU3_Result
	 */
	*p_AU3_Result		= pMyResult;
	*n_AU3_ErrorCode	= 0;
	*n_AU3_ExtCode		= 0;

	return AU3_PLUGIN_OK;
}

/****************************************************************************
 * SetToObject( )
 *
 * SetToObject( TargetObjectId, ObjectId )
 *
 ****************************************************************************/
AU3_PLUGIN_DEFINE( SetToObject )
{

	AU3_PLUGIN_VAR	*pMyResult;

	int TargetObjectId = AU3_GetInt32(&p_AU3_Params[0]);
	int ObjectId = AU3_GetInt32(&p_AU3_Params[1]);

	int RetVal = g_MeshRepository.SetToObject( TargetObjectId, ObjectId );

	/* Allocate and build the return variable */
	pMyResult = AU3_AllocVar();
	AU3_SetInt32(pMyResult, 0);


	/* Pass back the result, error code and extended code.
	 * Note: AutoIt is responsible for freeing the memory used in p_AU3_Result
	 */
	*p_AU3_Result		= pMyResult;
	*n_AU3_ErrorCode	= RetVal;
	*n_AU3_ExtCode		= 0;

	return AU3_PLUGIN_OK;
}

/****************************************************************************
 * UnsetFromObject( )
 *
 * UnsetFromObject( TargetObjectId, ObjectId )
 *
 ****************************************************************************/
AU3_PLUGIN_DEFINE( UnsetFromObject )
{

	AU3_PLUGIN_VAR	*pMyResult;

	int TargetObjectId = AU3_GetInt32(&p_AU3_Params[0]);
	int ObjectId = AU3_GetInt32(&p_AU3_Params[1]);

	int RetVal = g_MeshRepository.UnSetObj( TargetObjectId, ObjectId );

	/* Allocate and build the return variable */
	pMyResult = AU3_AllocVar();
	AU3_SetInt32(pMyResult, 0);


	/* Pass back the result, error code and extended code.
	 * Note: AutoIt is responsible for freeing the memory used in p_AU3_Result
	 */
	*p_AU3_Result		= pMyResult;
	*n_AU3_ErrorCode	= RetVal;
	*n_AU3_ExtCode		= 0;

	return AU3_PLUGIN_OK;
}

/****************************************************************************
 * ObjectCreate( )
 *
 * ObjectCreate( )
 *
 ****************************************************************************/
AU3_PLUGIN_DEFINE( ObjectCreate )
{

	AU3_PLUGIN_VAR	*pMyResult;

	int RetVal = g_MeshRepository.AddObject( );

	/* Allocate and build the return variable */
	pMyResult = AU3_AllocVar();
	AU3_SetInt32(pMyResult, RetVal);


	/* Pass back the result, error code and extended code.
	 * Note: AutoIt is responsible for freeing the memory used in p_AU3_Result
	 */
	*p_AU3_Result		= pMyResult;
	*n_AU3_ErrorCode	= 0;
	*n_AU3_ExtCode		= 0;

	return AU3_PLUGIN_OK;
}

/****************************************************************************
 * ObjectDelete()
 *
 * ObjectDelete( ObjId )
 *
 ****************************************************************************/
AU3_PLUGIN_DEFINE( ObjectDelete )
{

	AU3_PLUGIN_VAR	*pMyResult;
    int ObjId = AU3_GetInt32(&p_AU3_Params[0]);

	int RetVal = g_MeshRepository.DeleteObject( ObjId );

	//Allocate and build the return variable
	pMyResult = AU3_AllocVar();
	AU3_SetInt32(pMyResult, 0);


	//Pass back the result, error code and extended code.
	//Note: AutoIt is responsible for freeing the memory used in p_AU3_Result

	*p_AU3_Result		= pMyResult;
	*n_AU3_ErrorCode	= RetVal;
	*n_AU3_ExtCode		= 0;

	return AU3_PLUGIN_OK;
}

/****************************************************************************
 * ObjectTranslate()
 *
 * ObjectTranslate( ObjId, X, Y, Z )
 *
 ****************************************************************************/
AU3_PLUGIN_DEFINE( ObjectTranslate )
{

	AU3_PLUGIN_VAR	*pMyResult;
    int             ObjId;
	double          X, Y, Z;

	ObjId = AU3_GetInt32(&p_AU3_Params[0]);

	X     = AU3_GetDouble(&p_AU3_Params[1]);
	Y     = AU3_GetDouble(&p_AU3_Params[2]);
	Z     = AU3_GetDouble(&p_AU3_Params[3]);

	TPOS3D NewPos;
	NewPos.X = X;
	NewPos.Y = Y;
	NewPos.Z = Z;

	g_MeshRepository.TranslateObject( ObjId, NewPos );

	/* Allocate and build the return variable */
	pMyResult = AU3_AllocVar();
	AU3_SetInt32(pMyResult, 0);


	/* Pass back the result, error code and extended code.
	 * Note: AutoIt is responsible for freeing the memory used in p_AU3_Result
	 */
	*p_AU3_Result		= pMyResult;
	*n_AU3_ErrorCode	= 0;
	*n_AU3_ExtCode		= 0;

	return AU3_PLUGIN_OK;
}

/****************************************************************************
 * ObjectRotate()
 *
 * ObjectRotate( ObjId, X, Y, Z )
 *
 ****************************************************************************/
AU3_PLUGIN_DEFINE( ObjectRotate )
{

	AU3_PLUGIN_VAR	*pMyResult;
    int             ObjId;
	double          X, Y, Z;

	ObjId = AU3_GetInt32(&p_AU3_Params[0]);

	X     = AU3_GetDouble(&p_AU3_Params[1]);
	Y     = AU3_GetDouble(&p_AU3_Params[2]);
	Z     = AU3_GetDouble(&p_AU3_Params[3]);

    NormalizeAngles( &X, &Y, &Z );

	TPOS3D Angles;
	Angles.X = X;
	Angles.Y = Y;
	Angles.Z = Z;

	g_MeshRepository.RotateObject( ObjId, Angles );

	/* Allocate and build the return variable */
	pMyResult = AU3_AllocVar();
	AU3_SetInt32(pMyResult, 0);


	/* Pass back the result, error code and extended code.
	 * Note: AutoIt is responsible for freeing the memory used in p_AU3_Result
	 */
	*p_AU3_Result		= pMyResult;
	*n_AU3_ErrorCode	= 0;
	*n_AU3_ExtCode		= 0;

	return AU3_PLUGIN_OK;
}

/****************************************************************************
 * ObjectScale()
 *
 * ObjectScale( ObjId, X, Y, Z )
 *
 ****************************************************************************/
AU3_PLUGIN_DEFINE( ObjectScale )
{

	AU3_PLUGIN_VAR	*pMyResult;
    int             ObjId;
	double          X, Y, Z;

	ObjId = AU3_GetInt32(&p_AU3_Params[0]);

	X     = AU3_GetDouble(&p_AU3_Params[1]);
	Y     = AU3_GetDouble(&p_AU3_Params[2]);
	Z     = AU3_GetDouble(&p_AU3_Params[3]);

	TPOS3D Scales;
	Scales.X = X;
	Scales.Y = Y;
	Scales.Z = Z;

	g_MeshRepository.ScaleObject( ObjId, Scales );

	/* Allocate and build the return variable */
	pMyResult = AU3_AllocVar();
	AU3_SetInt32(pMyResult, 0);


	/* Pass back the result, error code and extended code.
	 * Note: AutoIt is responsible for freeing the memory used in p_AU3_Result
	 */
	*p_AU3_Result		= pMyResult;
	*n_AU3_ErrorCode	= 0;
	*n_AU3_ExtCode		= 0;

	return AU3_PLUGIN_OK;
}

/****************************************************************************
 * ObjectHide( )
 *
 * ObjectHide( ObjId )
 *
 ****************************************************************************/
AU3_PLUGIN_DEFINE( ObjectHide )
{

	AU3_PLUGIN_VAR	*pMyResult;
    int ObjId = AU3_GetInt32(&p_AU3_Params[0]);

	int RetVal = g_MeshRepository.SetInvisibleObject( ObjId, true );

	/* Allocate and build the return variable */
	pMyResult = AU3_AllocVar();
	AU3_SetInt32(pMyResult, 0);


	/* Pass back the result, error code and extended code.
	 * Note: AutoIt is responsible for freeing the memory used in p_AU3_Result
	 */
	*p_AU3_Result		= pMyResult;
	*n_AU3_ErrorCode	= RetVal;
	*n_AU3_ExtCode		= 0;

	return AU3_PLUGIN_OK;
}

/****************************************************************************
 * ObjectShow( )
 *
 * ObjectShow( ObjId )
 *
 ****************************************************************************/
AU3_PLUGIN_DEFINE( ObjectShow )
{

	AU3_PLUGIN_VAR	*pMyResult;
    int ObjId = AU3_GetInt32(&p_AU3_Params[0]);

	int RetVal = g_MeshRepository.SetInvisibleObject( ObjId, false );

	/* Allocate and build the return variable */
	pMyResult = AU3_AllocVar();
	AU3_SetInt32(pMyResult, 0);


	/* Pass back the result, error code and extended code.
	 * Note: AutoIt is responsible for freeing the memory used in p_AU3_Result
	 */
	*p_AU3_Result		= pMyResult;
	*n_AU3_ErrorCode	= RetVal;
	*n_AU3_ExtCode		= 0;

	return AU3_PLUGIN_OK;
}

/****************************************************************************
 * SetPrint( )
 *
 * SetPrint( ObjId )
 *
 ****************************************************************************/
AU3_PLUGIN_DEFINE( SetPrint )
{

	AU3_PLUGIN_VAR	*pMyResult;
    int ObjId = AU3_GetInt32(&p_AU3_Params[0]);

	int RetVal = g_MeshRepository.PutObject( ObjId );

	/* Allocate and build the return variable */
	pMyResult = AU3_AllocVar( );
	AU3_SetInt32(pMyResult, 0);


	/* Pass back the result, error code and extended code.
	 * Note: AutoIt is responsible for freeing the memory used in p_AU3_Result
	 */
	*p_AU3_Result		= pMyResult;
	*n_AU3_ErrorCode	= RetVal;
	*n_AU3_ExtCode		= 0;

	return AU3_PLUGIN_OK;
}

/****************************************************************************
 * UnsetPrint( )
 *
 * UnsetPrint( ObjId )
 *
 ****************************************************************************/
AU3_PLUGIN_DEFINE( UnsetPrint )
{

	AU3_PLUGIN_VAR	*pMyResult;
    int ObjId = AU3_GetInt32(&p_AU3_Params[0]);

	int RetVal = g_MeshRepository.RemObject( ObjId );

	/* Allocate and build the return variable */
	pMyResult = AU3_AllocVar( );
	AU3_SetInt32(pMyResult, 0);


	/* Pass back the result, error code and extended code.
	 * Note: AutoIt is responsible for freeing the memory used in p_AU3_Result
	 */
	*p_AU3_Result		= pMyResult;
	*n_AU3_ErrorCode	= RetVal;
	*n_AU3_ExtCode		= 0;

	return AU3_PLUGIN_OK;
}

/****************************************************************************
 * ClearPrintBuffer( )
 *
 * ClearPrintBuffer( )
 *
 ****************************************************************************/
AU3_PLUGIN_DEFINE( ClearPrintBuffer )
{

	AU3_PLUGIN_VAR	*pMyResult;
    int ObjId = AU3_GetInt32(&p_AU3_Params[0]);

	g_MeshRepository.ClearPrintBuffer( );

	/* Allocate and build the return variable */
	pMyResult = AU3_AllocVar( );
	AU3_SetInt32(pMyResult, 0);


	/* Pass back the result, error code and extended code.
	 * Note: AutoIt is responsible for freeing the memory used in p_AU3_Result
	 */
	*p_AU3_Result		= pMyResult;
	*n_AU3_ErrorCode	= 0;
	*n_AU3_ExtCode		= 0;

	return AU3_PLUGIN_OK;
}

/****************************************************************************
 * AddLine()
 *
 * AddLine( ObjId, Xv1, Yv1, Zv1, Xv2, Yv2, Zv2, Red, Green, Blue, Alpha )
 *
 ****************************************************************************/
AU3_PLUGIN_DEFINE( AddLine )
{
	AU3_PLUGIN_VAR	*pMyResult;
	TtagSHAPE		*Shape = g_MeshRepository.CreateNewShape( );
	TLINE           *Line = new TLINE;

	int ObjId = AU3_GetInt32(&p_AU3_Params[0]);

    Line->Vertex[0].X = AU3_GetDouble(&p_AU3_Params[1]);
    Line->Vertex[0].Y = AU3_GetDouble(&p_AU3_Params[2]);
    Line->Vertex[0].Z = AU3_GetDouble(&p_AU3_Params[3]);

    Line->Vertex[1].X = AU3_GetDouble(&p_AU3_Params[4]);
    Line->Vertex[1].Y = AU3_GetDouble(&p_AU3_Params[5]);
    Line->Vertex[1].Z = AU3_GetDouble(&p_AU3_Params[6]);

	Shape->Color.Red   = AU3_GetDouble(&p_AU3_Params[7]);
	Shape->Color.Green = AU3_GetDouble(&p_AU3_Params[8]);
	Shape->Color.Blue  = AU3_GetDouble(&p_AU3_Params[9]);
	Shape->Color.Alpha = AU3_GetDouble(&p_AU3_Params[10]);

	int iShaded =        AU3_GetInt32(&p_AU3_Params[11]);
	Line->Shaded = false;
	if( iShaded > 0 )
	{
		Line->Shaded = true;
	}

    Shape->ShapeType = 4;
	Shape->ShapeData = (LPARAM*)(Line);
	int RetVal = g_MeshRepository.AddShape( ObjId, Shape );

	/* Allocate and build the return variable */
	pMyResult = AU3_AllocVar();
	AU3_SetInt32(pMyResult, RetVal);

	/* Pass back the result, error code and extended code.
	 * Note: AutoIt is responsible for freeing the memory used in p_AU3_Result
	 */
	*p_AU3_Result		= pMyResult;
	*n_AU3_ErrorCode	= 0;
	*n_AU3_ExtCode		= 0;

	return AU3_PLUGIN_OK;
}

/****************************************************************************
 * AddTriangle()
 *
 * AddTriangle( ObjId, Xv1, Yv1, Zv1, Xv2, Yv2, Zv2, Xv3, Yv3, Zv3, Xn, Yn, Zn, Red, Green, Blue, Alpha )
 *
 ****************************************************************************/
AU3_PLUGIN_DEFINE( AddTriangle )
{
	AU3_PLUGIN_VAR	*pMyResult;
	TtagSHAPE		*Shape = g_MeshRepository.CreateNewShape( );
	TTRIANGLE       *Triangle = new TTRIANGLE;

	int ObjId = AU3_GetInt32(&p_AU3_Params[0]);

    Triangle->Vertex[0].X = AU3_GetDouble(&p_AU3_Params[1]);
    Triangle->Vertex[0].Y = AU3_GetDouble(&p_AU3_Params[2]);
    Triangle->Vertex[0].Z = AU3_GetDouble(&p_AU3_Params[3]);

    Triangle->Vertex[1].X = AU3_GetDouble(&p_AU3_Params[4]);
    Triangle->Vertex[1].Y = AU3_GetDouble(&p_AU3_Params[5]);
    Triangle->Vertex[1].Z = AU3_GetDouble(&p_AU3_Params[6]);

    Triangle->Vertex[2].X = AU3_GetDouble(&p_AU3_Params[7]);
    Triangle->Vertex[2].Y = AU3_GetDouble(&p_AU3_Params[8]);
    Triangle->Vertex[2].Z = AU3_GetDouble(&p_AU3_Params[9]);

    Triangle->Normal.X = AU3_GetDouble(&p_AU3_Params[10]);
    Triangle->Normal.Y = AU3_GetDouble(&p_AU3_Params[11]);
    Triangle->Normal.Z = AU3_GetDouble(&p_AU3_Params[12]);

	Shape->Color.Red   = AU3_GetDouble(&p_AU3_Params[13]);
	Shape->Color.Green = AU3_GetDouble(&p_AU3_Params[14]);
	Shape->Color.Blue  = AU3_GetDouble(&p_AU3_Params[15]);
	Shape->Color.Alpha = AU3_GetDouble(&p_AU3_Params[16]);

    Shape->ShapeType = 2;
	Shape->ShapeData = (LPARAM*)(Triangle);
	int RetVal = g_MeshRepository.AddShape( ObjId, Shape );

	/* Allocate and build the return variable */
	pMyResult = AU3_AllocVar();
	AU3_SetInt32(pMyResult, RetVal);

	/* Pass back the result, error code and extended code.
	 * Note: AutoIt is responsible for freeing the memory used in p_AU3_Result
	 */
	*p_AU3_Result		= pMyResult;
	*n_AU3_ErrorCode	= 0;
	*n_AU3_ExtCode		= 0;

	return AU3_PLUGIN_OK;
}

/****************************************************************************
 * AddQuad()
 *
 * AddQuad( ObjId, Xv1, Yv1, Zv1, Xv2, Yv2, Zv2, Xv3, Yv3, Zv3, Xv4, Yv4, Zv4, Xn, Yn, Zn, Red, Green, Blue, Alpha )
 *
 ****************************************************************************/
AU3_PLUGIN_DEFINE( AddQuad )
{
	AU3_PLUGIN_VAR	*pMyResult;
	TtagSHAPE		*Shape = g_MeshRepository.CreateNewShape( );
	TQUAD           *Quad = new TQUAD;

	int ObjId = AU3_GetInt32(&p_AU3_Params[0]);

    Quad->Vertex[0].X = AU3_GetDouble(&p_AU3_Params[1]);
    Quad->Vertex[0].Y = AU3_GetDouble(&p_AU3_Params[2]);
    Quad->Vertex[0].Z = AU3_GetDouble(&p_AU3_Params[3]);

    Quad->Vertex[1].X = AU3_GetDouble(&p_AU3_Params[4]);
    Quad->Vertex[1].Y = AU3_GetDouble(&p_AU3_Params[5]);
    Quad->Vertex[1].Z = AU3_GetDouble(&p_AU3_Params[6]);

    Quad->Vertex[2].X = AU3_GetDouble(&p_AU3_Params[7]);
    Quad->Vertex[2].Y = AU3_GetDouble(&p_AU3_Params[8]);
    Quad->Vertex[2].Z = AU3_GetDouble(&p_AU3_Params[9]);

    Quad->Vertex[3].X = AU3_GetDouble(&p_AU3_Params[10]);
    Quad->Vertex[3].Y = AU3_GetDouble(&p_AU3_Params[11]);
    Quad->Vertex[3].Z = AU3_GetDouble(&p_AU3_Params[12]);

    Quad->Normal.X = AU3_GetDouble(&p_AU3_Params[13]);
    Quad->Normal.Y = AU3_GetDouble(&p_AU3_Params[14]);
    Quad->Normal.Z = AU3_GetDouble(&p_AU3_Params[15]);

	Shape->Color.Red   = AU3_GetDouble(&p_AU3_Params[16]);
	Shape->Color.Green = AU3_GetDouble(&p_AU3_Params[17]);
	Shape->Color.Blue  = AU3_GetDouble(&p_AU3_Params[18]);
	Shape->Color.Alpha = AU3_GetDouble(&p_AU3_Params[19]);

    Shape->ShapeType = 3;
	Shape->ShapeData = (LPARAM*)(Quad);
	int RetVal = g_MeshRepository.AddShape( ObjId, Shape );

	/* Allocate and build the return variable */
	pMyResult = AU3_AllocVar();
	AU3_SetInt32(pMyResult, RetVal);

	/* Pass back the result, error code and extended code.
	 * Note: AutoIt is responsible for freeing the memory used in p_AU3_Result
	 */
	*p_AU3_Result		= pMyResult;
	*n_AU3_ErrorCode	= 0;
	*n_AU3_ExtCode		= 0;

	return AU3_PLUGIN_OK;
}

/****************************************************************************
 * AddSphere()
 *
 * AddSphere( ObjId, X, Y, Z, Radius, Slices, Stacks, Red, Green, Blue, Alpha )
 *
 ****************************************************************************/
AU3_PLUGIN_DEFINE( AddSphere )
{

	AU3_PLUGIN_VAR	*pMyResult;
	TtagSHAPE		*Shape = g_MeshRepository.CreateNewShape( );
	TGLSPHERE       *GlSphere = new TGLSPHERE;

	int ObjId = AU3_GetInt32(&p_AU3_Params[0]);

    GlSphere->Vertex.X = AU3_GetDouble(&p_AU3_Params[1]);
    GlSphere->Vertex.Y = AU3_GetDouble(&p_AU3_Params[2]);
    GlSphere->Vertex.Z = AU3_GetDouble(&p_AU3_Params[3]);

    GlSphere->Radius = AU3_GetDouble(&p_AU3_Params[4]);
    GlSphere->Slices = AU3_GetInt32(&p_AU3_Params[5]);
    GlSphere->Stacks = AU3_GetInt32(&p_AU3_Params[6]);

	Shape->Color.Red   = AU3_GetDouble(&p_AU3_Params[7]);
	Shape->Color.Green = AU3_GetDouble(&p_AU3_Params[8]);
	Shape->Color.Blue  = AU3_GetDouble(&p_AU3_Params[9]);
	Shape->Color.Alpha = AU3_GetDouble(&p_AU3_Params[10]);

    Shape->ShapeType = 0;
	Shape->ShapeData = (LPARAM*)(GlSphere);
	int RetVal = g_MeshRepository.AddShape( ObjId, Shape );

	/* Allocate and build the return variable */
	pMyResult = AU3_AllocVar();
	AU3_SetInt32(pMyResult, RetVal);


	/* Pass back the result, error code and extended code.
	 * Note: AutoIt is responsible for freeing the memory used in p_AU3_Result
	 */
	*p_AU3_Result		= pMyResult;
	*n_AU3_ErrorCode	= 0;
	*n_AU3_ExtCode		= 0;

	return AU3_PLUGIN_OK;
}

/****************************************************************************
 * AddCylinder()
 *
 * AddCylinder( ObjId, X, Y, Z, BRadius, TRadius, Height, Slices, Stacks, Red, Green, Blue, Alpha )
 *
 ****************************************************************************/
AU3_PLUGIN_DEFINE( AddCylinder )
{
	AU3_PLUGIN_VAR	*pMyResult;
	TtagSHAPE		*Shape = g_MeshRepository.CreateNewShape( );
	TGLCYLINDER     *GlCylinder = new TGLCYLINDER;

	int ObjId = AU3_GetInt32(&p_AU3_Params[0]);

    GlCylinder->Base.X = AU3_GetDouble(&p_AU3_Params[1]);
    GlCylinder->Base.Y = AU3_GetDouble(&p_AU3_Params[2]);
    GlCylinder->Base.Z = AU3_GetDouble(&p_AU3_Params[3]);

    GlCylinder->Radius1 = AU3_GetDouble(&p_AU3_Params[4]);
    GlCylinder->Radius2 = AU3_GetDouble(&p_AU3_Params[5]);
    GlCylinder->Height = AU3_GetDouble(&p_AU3_Params[6]);
    GlCylinder->Slices = AU3_GetInt32(&p_AU3_Params[7]);
    GlCylinder->Stacks = AU3_GetInt32(&p_AU3_Params[8]);

	Shape->Color.Red   = AU3_GetDouble(&p_AU3_Params[9]);
	Shape->Color.Green = AU3_GetDouble(&p_AU3_Params[10]);
	Shape->Color.Blue  = AU3_GetDouble(&p_AU3_Params[11]);
	Shape->Color.Alpha = AU3_GetDouble(&p_AU3_Params[12]);

    Shape->ShapeType = 1;
	Shape->ShapeData = (LPARAM*)(GlCylinder);
	int RetVal = g_MeshRepository.AddShape( ObjId, Shape );

	/* Allocate and build the return variable */
	pMyResult = AU3_AllocVar();
	AU3_SetInt32(pMyResult, RetVal);

	/* Pass back the result, error code and extended code.
	 * Note: AutoIt is responsible for freeing the memory used in p_AU3_Result
	 */
	*p_AU3_Result		= pMyResult;
	*n_AU3_ErrorCode	= 0;
	*n_AU3_ExtCode		= 0;

	return AU3_PLUGIN_OK;
}

/****************************************************************************
 * AddStrokeText()
 *
 * AddStrokeText( ObjId, X, Y, Z, Red, Green, Blue, Text )
 *
 ****************************************************************************/
AU3_PLUGIN_DEFINE( AddStrokeText )
{
	AU3_PLUGIN_VAR	*pMyResult;
	TtagSHAPE		*Shape = g_MeshRepository.CreateNewShape( );
	TGLCHAR         *GlChar = new TGLCHAR;

    int ObjId = AU3_GetInt32(&p_AU3_Params[0]);

    GlChar->Type = 0;
    GlChar->Pos.X = AU3_GetDouble(&p_AU3_Params[1]);
    GlChar->Pos.Y = AU3_GetDouble(&p_AU3_Params[2]);
    GlChar->Pos.Z = AU3_GetDouble(&p_AU3_Params[3]);

	Shape->Color.Red   = AU3_GetDouble(&p_AU3_Params[4]);
	Shape->Color.Green = AU3_GetDouble(&p_AU3_Params[5]);
	Shape->Color.Blue  = AU3_GetDouble(&p_AU3_Params[6]);

	char *CharArray = AU3_GetString(&p_AU3_Params[7]);
	strncpy( GlChar->CharArray, CharArray, sizeof( GlChar->CharArray ) );

    Shape->ShapeType = 5;
	Shape->ShapeData = (LPARAM*)(GlChar);
	int RetVal = g_MeshRepository.AddShape( ObjId, Shape );

	/* Allocate and build the return variable */
	pMyResult = AU3_AllocVar( );
	AU3_SetInt32(pMyResult, RetVal);

	/* Pass back the result, error code and extended code.
	 * Note: AutoIt is responsible for freeing the memory used in p_AU3_Result
	 */
	*p_AU3_Result		= pMyResult;
	*n_AU3_ErrorCode	= 0;
	*n_AU3_ExtCode		= 0;

	return AU3_PLUGIN_OK;
}

/****************************************************************************
 * AddBitmapText()
 *
 * AddBitmapText( ObjId, X, Y, Z, Red, Green, Blue, Text )
 *
 ****************************************************************************/
AU3_PLUGIN_DEFINE( AddBitmapText )
{
	AU3_PLUGIN_VAR	*pMyResult;
	TtagSHAPE		*Shape = g_MeshRepository.CreateNewShape( );
	TGLCHAR         *GlChar = new TGLCHAR;

    int ObjId = AU3_GetInt32(&p_AU3_Params[0]);

    GlChar->Type = 1;
    GlChar->Pos.X = AU3_GetDouble(&p_AU3_Params[1]);
    GlChar->Pos.Y = AU3_GetDouble(&p_AU3_Params[2]);
    GlChar->Pos.Z = AU3_GetDouble(&p_AU3_Params[3]);

	Shape->Color.Red   = AU3_GetDouble(&p_AU3_Params[4]);
	Shape->Color.Green = AU3_GetDouble(&p_AU3_Params[5]);
	Shape->Color.Blue  = AU3_GetDouble(&p_AU3_Params[6]);

	char *CharArray = AU3_GetString(&p_AU3_Params[7]);
	strncpy( GlChar->CharArray, CharArray, sizeof( GlChar->CharArray ) );

    Shape->ShapeType = 5;
	Shape->ShapeData = (LPARAM*)(GlChar);
	int RetVal = g_MeshRepository.AddShape( ObjId, Shape );

	/* Allocate and build the return variable */
	pMyResult = AU3_AllocVar( );
	AU3_SetInt32(pMyResult, RetVal);

	/* Pass back the result, error code and extended code.
	 * Note: AutoIt is responsible for freeing the memory used in p_AU3_Result
	 */
	*p_AU3_Result		= pMyResult;
	*n_AU3_ErrorCode	= 0;
	*n_AU3_ExtCode		= 0;

	return AU3_PLUGIN_OK;
}

/****************************************************************************
 * AddPartialDisk()
 *
 * AddPartialDisk( ObjId, X, Y, Z, InnerRadius, OuterRadius, Slices, Stacks, StartAngle, SweepAngle, Red, Green, Blue, Alpha )
 *
 ****************************************************************************/
AU3_PLUGIN_DEFINE( AddPartialDisk )
{
	AU3_PLUGIN_VAR	*pMyResult;
	TtagSHAPE		*Shape = g_MeshRepository.CreateNewShape( );
	TPARTDISK       *PartDisk = new TPARTDISK;

	int ObjId = AU3_GetInt32(&p_AU3_Params[0]);

    PartDisk->Base.X = AU3_GetDouble(&p_AU3_Params[1]);
    PartDisk->Base.Y = AU3_GetDouble(&p_AU3_Params[2]);
    PartDisk->Base.Z = AU3_GetDouble(&p_AU3_Params[3]);

    PartDisk->Radius1 = AU3_GetDouble(&p_AU3_Params[4]);
    PartDisk->Radius2 = AU3_GetDouble(&p_AU3_Params[5]);
    PartDisk->Slices = AU3_GetInt32(&p_AU3_Params[6]);
    PartDisk->Stacks = AU3_GetInt32(&p_AU3_Params[7]);

    PartDisk->StartAngle = AU3_GetDouble(&p_AU3_Params[8]);
    PartDisk->SweepAngle = AU3_GetDouble(&p_AU3_Params[9]);

	Shape->Color.Red   = AU3_GetDouble(&p_AU3_Params[10]);
	Shape->Color.Green = AU3_GetDouble(&p_AU3_Params[11]);
	Shape->Color.Blue  = AU3_GetDouble(&p_AU3_Params[12]);
	Shape->Color.Alpha = AU3_GetDouble(&p_AU3_Params[13]);

    Shape->ShapeType = 6;
	Shape->ShapeData = (LPARAM*)(PartDisk);
	int RetVal = g_MeshRepository.AddShape( ObjId, Shape );

	/* Allocate and build the return variable */
	pMyResult = AU3_AllocVar();
	AU3_SetInt32(pMyResult, RetVal);

	/* Pass back the result, error code and extended code.
	 * Note: AutoIt is responsible for freeing the memory used in p_AU3_Result
	 */
	*p_AU3_Result		= pMyResult;
	*n_AU3_ErrorCode	= 0;
	*n_AU3_ExtCode		= 0;

	return AU3_PLUGIN_OK;
}

/****************************************************************************
 * AddCube()
 *
 * AddCube( ObjId, Width, Height, Deph, Red, Green, Blue, Alpha )
 *
 ****************************************************************************/
AU3_PLUGIN_DEFINE( AddCube )
{
	AU3_PLUGIN_VAR	*pMyResult;
	TtagSHAPE		*Shape = g_MeshRepository.CreateNewShape( );
	TPOS3D          *Cube = new TPOS3D;

	int ObjId = AU3_GetInt32(&p_AU3_Params[0]);

    Cube->X = AU3_GetDouble(&p_AU3_Params[1]);
    Cube->Y = AU3_GetDouble(&p_AU3_Params[2]);
    Cube->Z = AU3_GetDouble(&p_AU3_Params[3]);

	Shape->Color.Red   = AU3_GetDouble(&p_AU3_Params[4]);
	Shape->Color.Green = AU3_GetDouble(&p_AU3_Params[5]);
	Shape->Color.Blue  = AU3_GetDouble(&p_AU3_Params[6]);
	Shape->Color.Alpha = AU3_GetDouble(&p_AU3_Params[7]);

    Shape->ShapeType = 7;
	Shape->ShapeData = (LPARAM*)(Cube);
	int RetVal = g_MeshRepository.AddShape( ObjId, Shape );

	/* Allocate and build the return variable */
	pMyResult = AU3_AllocVar();
	AU3_SetInt32(pMyResult, RetVal);

	/* Pass back the result, error code and extended code.
	 * Note: AutoIt is responsible for freeing the memory used in p_AU3_Result
	 */
	*p_AU3_Result		= pMyResult;
	*n_AU3_ErrorCode	= 0;
	*n_AU3_ExtCode		= 0;

	return AU3_PLUGIN_OK;
}

/****************************************************************************
 * ShapeTranslate()
 *
 * ShapeTranslate( ObjId, ShapeIndex, X, Y, Z )
 *
 ****************************************************************************/
AU3_PLUGIN_DEFINE( ShapeTranslate )
{

	AU3_PLUGIN_VAR	*pMyResult;
    int             ObjId;
	int             ShapeIndex;
	double          X, Y, Z;

	ObjId = AU3_GetInt32(&p_AU3_Params[0]);
	ShapeIndex = AU3_GetInt32(&p_AU3_Params[1]);

	X     = AU3_GetDouble(&p_AU3_Params[2]);
	Y     = AU3_GetDouble(&p_AU3_Params[3]);
	Z     = AU3_GetDouble(&p_AU3_Params[4]);

	TPOS3D NewPos;
	NewPos.X = X;
	NewPos.Y = Y;
	NewPos.Z = Z;

	g_MeshRepository.TranslateShape( ObjId, ShapeIndex, NewPos );

	/* Allocate and build the return variable */
	pMyResult = AU3_AllocVar();
	AU3_SetInt32(pMyResult, 0);


	/* Pass back the result, error code and extended code.
	 * Note: AutoIt is responsible for freeing the memory used in p_AU3_Result
	 */
	*p_AU3_Result		= pMyResult;
	*n_AU3_ErrorCode	= 0;
	*n_AU3_ExtCode		= 0;

	return AU3_PLUGIN_OK;
}

/****************************************************************************
 * ShapeRotate()
 *
 * ShapeRotate( ObjId, ShapeIndex, X, Y, Z )
 *
 ****************************************************************************/
AU3_PLUGIN_DEFINE( ShapeRotate )
{

	AU3_PLUGIN_VAR	*pMyResult;
    int             ObjId;
	int             ShapeIndex;
	double          X, Y, Z;

	ObjId = AU3_GetInt32(&p_AU3_Params[0]);
	ShapeIndex = AU3_GetInt32(&p_AU3_Params[1]);

	X     = AU3_GetDouble(&p_AU3_Params[2]);
	Y     = AU3_GetDouble(&p_AU3_Params[3]);
	Z     = AU3_GetDouble(&p_AU3_Params[4]);

    NormalizeAngles( &X, &Y, &Z );

	TPOS3D Angles;
	Angles.X = X;
	Angles.Y = Y;
	Angles.Z = Z;

	g_MeshRepository.RotateShape( ObjId, ShapeIndex, Angles );

	/* Allocate and build the return variable */
	pMyResult = AU3_AllocVar();
	AU3_SetInt32(pMyResult, 0);


	/* Pass back the result, error code and extended code.
	 * Note: AutoIt is responsible for freeing the memory used in p_AU3_Result
	 */
	*p_AU3_Result		= pMyResult;
	*n_AU3_ErrorCode	= 0;
	*n_AU3_ExtCode		= 0;

	return AU3_PLUGIN_OK;
}

/****************************************************************************
 * ShapeScale()
 *
 * ShapeScale( ObjId, ShapeIndex, X, Y, Z )
 *
 ****************************************************************************/
AU3_PLUGIN_DEFINE( ShapeScale )
{

	AU3_PLUGIN_VAR	*pMyResult;
    int             ObjId;
	int             ShapeIndex;
	double          X, Y, Z;

	ObjId = AU3_GetInt32(&p_AU3_Params[0]);
	ShapeIndex = AU3_GetInt32(&p_AU3_Params[1]);

	X     = AU3_GetDouble(&p_AU3_Params[2]);
	Y     = AU3_GetDouble(&p_AU3_Params[3]);
	Z     = AU3_GetDouble(&p_AU3_Params[4]);

	TPOS3D Scales;
	Scales.X = X;
	Scales.Y = Y;
	Scales.Z = Z;

	g_MeshRepository.ScaleShape( ObjId, ShapeIndex, Scales );

	/* Allocate and build the return variable */
	pMyResult = AU3_AllocVar();
	AU3_SetInt32(pMyResult, 0);


	/* Pass back the result, error code and extended code.
	 * Note: AutoIt is responsible for freeing the memory used in p_AU3_Result
	 */
	*p_AU3_Result		= pMyResult;
	*n_AU3_ErrorCode	= 0;
	*n_AU3_ExtCode		= 0;

	return AU3_PLUGIN_OK;
}

/****************************************************************************
 * CreateLight()
 *
 * CreateLight( Number, X, Y, Z )
 *
 ****************************************************************************/
AU3_PLUGIN_DEFINE( CreateLight )
{

	AU3_PLUGIN_VAR	*pMyResult;
	int             Number;
    TPOS3D          Position;

    Number      = AU3_GetInt32(&p_AU3_Params[0]);
    Position.X  = AU3_GetDouble(&p_AU3_Params[1]);
    Position.Y  = AU3_GetDouble(&p_AU3_Params[2]);
    Position.Z  = AU3_GetDouble(&p_AU3_Params[3]);

    int RetVal = g_LightManage.CreateLight( Number, Position );

	/* Allocate and build the return variable */
	pMyResult = AU3_AllocVar();
	AU3_SetInt32(pMyResult, 0);


	/* Pass back the result, error code and extended code.
	 * Note: AutoIt is responsible for freeing the memory used in p_AU3_Result
	 */
	*p_AU3_Result		= pMyResult;
	*n_AU3_ErrorCode	= RetVal;
	*n_AU3_ExtCode		= 0;

	return AU3_PLUGIN_OK;
}

/****************************************************************************
 * SetLightAmbient()
 *
 * SetLightAmbient( LightNumber, Red, Green, Blue )
 *
 ****************************************************************************/
AU3_PLUGIN_DEFINE( SetLightAmbient )
{

	AU3_PLUGIN_VAR	*pMyResult;
	int             LightNumber;
    TRGBA           Colour;

    LightNumber     = AU3_GetInt32(&p_AU3_Params[0]);
    Colour.Red      = AU3_GetDouble(&p_AU3_Params[1]);
    Colour.Green    = AU3_GetDouble(&p_AU3_Params[2]);
    Colour.Blue     = AU3_GetDouble(&p_AU3_Params[3]);
    Colour.Alpha    = 1.0;

    int RetVal = g_LightManage.SetLightAmbient( LightNumber, Colour );

	/* Allocate and build the return variable */
	pMyResult = AU3_AllocVar();
	AU3_SetInt32(pMyResult, 0);


	/* Pass back the result, error code and extended code.
	 * Note: AutoIt is responsible for freeing the memory used in p_AU3_Result
	 */
	*p_AU3_Result		= pMyResult;
	*n_AU3_ErrorCode	= RetVal;
	*n_AU3_ExtCode		= 0;

	return AU3_PLUGIN_OK;
}

/****************************************************************************
 * SetLightDiffuse()
 *
 * SetLightDiffuse( LightNumber, Red, Green, Blue )
 *
 ****************************************************************************/
AU3_PLUGIN_DEFINE( SetLightDiffuse )
{

	AU3_PLUGIN_VAR	*pMyResult;
	int             LightNumber;
    TRGBA           Colour;

    LightNumber     = AU3_GetInt32(&p_AU3_Params[0]);
    Colour.Red      = AU3_GetDouble(&p_AU3_Params[1]);
    Colour.Green    = AU3_GetDouble(&p_AU3_Params[2]);
    Colour.Blue     = AU3_GetDouble(&p_AU3_Params[3]);
    Colour.Alpha    = 1.0;

    int RetVal = g_LightManage.SetLightDiffuse( LightNumber, Colour );

	/* Allocate and build the return variable */
	pMyResult = AU3_AllocVar();
	AU3_SetInt32(pMyResult, 0);


	/* Pass back the result, error code and extended code.
	 * Note: AutoIt is responsible for freeing the memory used in p_AU3_Result
	 */
	*p_AU3_Result		= pMyResult;
	*n_AU3_ErrorCode	= RetVal;
	*n_AU3_ExtCode		= 0;

	return AU3_PLUGIN_OK;
}

/****************************************************************************
 * SetLightSpecular()
 *
 * SetLightSpecular( LightNumber, Red, Green, Blue )
 *
 ****************************************************************************/
AU3_PLUGIN_DEFINE( SetLightSpecular )
{

	AU3_PLUGIN_VAR	*pMyResult;
	int             LightNumber;
    TRGBA           Colour;

    LightNumber     = AU3_GetInt32(&p_AU3_Params[0]);
    Colour.Red      = AU3_GetDouble(&p_AU3_Params[1]);
    Colour.Green    = AU3_GetDouble(&p_AU3_Params[2]);
    Colour.Blue     = AU3_GetDouble(&p_AU3_Params[3]);
    Colour.Alpha    = 1.0;

    int RetVal = g_LightManage.SetLightSpecular( LightNumber, Colour );


	/* Allocate and build the return variable */
	pMyResult = AU3_AllocVar();
	AU3_SetInt32(pMyResult, 0);


	/* Pass back the result, error code and extended code.
	 * Note: AutoIt is responsible for freeing the memory used in p_AU3_Result
	 */
	*p_AU3_Result		= pMyResult;
	*n_AU3_ErrorCode	= RetVal;
	*n_AU3_ExtCode		= 0;

	return AU3_PLUGIN_OK;
}

/****************************************************************************
 * SetLightPosition()
 *
 * SetLightPosition( LightNumber, X, Y, Z )
 *
 ****************************************************************************/
AU3_PLUGIN_DEFINE( SetLightPosition )
{

	AU3_PLUGIN_VAR	*pMyResult;
	int             LightNumber;
    TPOS3D          Position;

    LightNumber     = AU3_GetInt32(&p_AU3_Params[0]);
    Position.X      = AU3_GetDouble(&p_AU3_Params[1]);
    Position.Y      = AU3_GetDouble(&p_AU3_Params[2]);
    Position.Z      = AU3_GetDouble(&p_AU3_Params[3]);

    int RetVal = g_LightManage.SetLightPosition( LightNumber, Position );

	/* Allocate and build the return variable */
	pMyResult = AU3_AllocVar();
	AU3_SetInt32(pMyResult, 0);


	/* Pass back the result, error code and extended code.
	 * Note: AutoIt is responsible for freeing the memory used in p_AU3_Result
	 */
	*p_AU3_Result		= pMyResult;
	*n_AU3_ErrorCode	= RetVal;
	*n_AU3_ExtCode		= 0;

	return AU3_PLUGIN_OK;
}

/****************************************************************************
 * TextureSetMode( )
 *
 * TextureSetMode( Option )
 * By: EFF
 ****************************************************************************/
AU3_PLUGIN_DEFINE( TextureSetMode )
{
    int iUseOtherColours = AU3_GetInt32(&p_AU3_Params[0]);
	textureManager.textureMode = true;
	if( iUseOtherColours == 1 ) textureManager.onlyTextures = false;
	return AU3_PLUGIN_OK;
}

/****************************************************************************
 * TextureSetBuffer( )
 *
 * TextureSetBuffer( BufferSize )
 * By: EFF
 ****************************************************************************/
AU3_PLUGIN_DEFINE( TextureSetBuffer )
{
	int bufferSize;
	bufferSize		= AU3_GetInt32(&p_AU3_Params[0]);
	textureManager.defineTextureBufferSize(bufferSize);
	return AU3_PLUGIN_OK;
}

/****************************************************************************
 * TextureAdd( )
 *
 * TextureAdd( texName, texturePath )
 * By: EFF
 ****************************************************************************/
AU3_PLUGIN_DEFINE( TextureAdd )
{
	char *textureID = AU3_GetString(&p_AU3_Params[0]);
	char *texturePath = AU3_GetString(&p_AU3_Params[1]);
	textureManager.loadTextureFile(textureID,texturePath);
	return AU3_PLUGIN_OK;
}

/****************************************************************************
 * TextureBind()
 *
 * TextureBind( ObjId, ShapeIndex, texName )
 * By: EFF
 ****************************************************************************/
AU3_PLUGIN_DEFINE( TextureBind )
{
    int ObjId       = AU3_GetInt32(&p_AU3_Params[0]);
    int ShapeId     = AU3_GetInt32(&p_AU3_Params[1]);
	char *texName	= AU3_GetString(&p_AU3_Params[2]);
	textureManager.bindTexture( ObjId, ShapeId, texName );
	return AU3_PLUGIN_OK;
}

