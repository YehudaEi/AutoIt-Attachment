This project was made on Code::Blocks v1.0
just open "Au3GlPlugin.cbp" file and have fun