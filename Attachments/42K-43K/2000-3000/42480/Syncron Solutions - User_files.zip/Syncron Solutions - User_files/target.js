;(function() {
    var windowOptions = SyncUtils.externalLinkWindowOptions || "resizable=1";
    SyncUtils.externalLinkWindowOptions = windowOptions;

    SyncUtils.beforeResponse('ExternalLink', function(request, context) {
    	var redirectContext = SyncUtils.evalJSONFromRequest(request, 'partial-response:first extension#com\\.syncron\\.faces\\.redirect:first');
    
    	if (redirectContext) {
    		if (redirectContext.target) {
    			newWindow = window.open(redirectContext.url, redirectContext.target, SyncUtils.externalLinkWindowOptions);
    		} else {
    			window.location = redirectContext.url;
    		}
    	}
    });
})();