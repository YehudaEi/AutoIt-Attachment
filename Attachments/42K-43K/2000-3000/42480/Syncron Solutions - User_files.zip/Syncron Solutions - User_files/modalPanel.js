$(function() {
	
	/**
	 * Overrides for RichFaces handling of tab indexes (which is buggy). See WF-3106.
	 */
    	RichFaces.ui.PopupPanel.prototype.processAllFocusElements = function fixedProcessAllFocus(root, callback) {
    	    var stack = [document.body], current, children, childCount, tagName, tabIndex, modalRoot = this.cdiv[0];
    	    // NOTE: this code intentionally doesn't use jQuery and was hand optimized for IE7. 
    	    while(stack.length > 0) {
    	        current = stack.pop();
    	        if(current === modalRoot) {
    	            continue; // don't descent into modal
    	        }
                if(current.nodeType != 1)
                    continue;
    	        children = current.children;
    	        childCount = children.length;
    	        // add children
    	        for(i=0; i<childCount; i++) {
    	            stack.push(children[i]);
    	        }
    	        // process this element
    	        tagName = current.tagName.toUpperCase();
    	        tabIndex = current.attributes["tabIndex"]; 
    	        if((tagName == "A" && (current.href !== undefined)) 
    	           || tagName == "SELECT"
    	           || tagName == "INPUT"
    	           || (tabIndex !== undefined && tabIndex.specified)) {
    	            callback.call(this, current);
    	        };
    	    };
    	};
	
	RichFaces.ui.PopupPanel.prototype.processTabindexes = function(input) {
        if (input.prevTabIndex === undefined) {
        	var attr = input.attributes["tabIndex"]; 
        	input.prevTabIndex = (attr === undefined || !attr.specified) ? null : attr.value;
        	input.tabIndex = -1;
        }

        if (input.prevAccessKey === undefined) {
            input.prevAccessKey = input.getAttribute("accessKey");
            input.accessKey = "";
        }
    };

    RichFaces.ui.PopupPanel.prototype.restoreTabindexes = function(input) {
        if (input.prevTabIndex !== undefined) {
            if (input.prevTabIndex === null) {
                input.removeAttribute('tabIndex');
            } else {
                input.tabIndex = input.prevTabIndex;
            }
            input.prevTabIndex = undefined;
        }
        if (input.prevAccessKey !== undefined) {
            if (input.prevAccessKey == "") {
                input.removeAttribute('accesskey');
            } else {
                input.accessKey = input.prevAccessKey;
            }
            input.prevAccessKey = undefined;
        }
    };
});

var PopupUtils = {
	scrollbarFixOnShow: function(id) {
		if (SyncUtils.isIE()) {
			$(OpenPopupRegister).each(function() {
				if (this.id !== id) {
					var component = RichFaces.$(this.id);
					if (component && component.scrollerDiv) {
						component.scrollerDiv.css('position', 'static');
					}
				}
			});
		}
	},
	
	scrollbarFixOnHide: function(id) {
		if (SyncUtils.isIE()) {
			$(OpenPopupRegister).each(function() {
				if (this.id !== id) {
					var component = RichFaces.$(this.id);
					if (component && component.scrollerDiv) {
						component.scrollerDiv.css('position', 'relative');
					}
				}
			});
		}
	}
}