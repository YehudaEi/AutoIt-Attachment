/**
 * ComboBox JS implementation
 */
;(function($) {
	
	var ComboBox = Class.create({
		CLEAR_LOOKUP_DELAY: 500, /* in ms */
		SELECTABLE_CLASS: ":not(.unselectable)",
		//constructor
		init: function($element, onchange) {
			this._change_callback = onchange || $.noop;
			this.bindElement($element);

			// state of key handling
			this._$focused = null;
			this._lookupPrefix = "";
			this._clearLookupTask = undefined;
			
			// selected item
			this._$selected = this.getOptions().filter("*[data-selected]").data("selected", null);
			this._$current.text(this._$selected.text());
			this._focusItem(this._$selected);

			// state of options
			this._expanded = false;
			this.setMaxRows(this._$element.data("max-rows") || +Infinity);
		},
		
		isReadonly: function() {
			return this._$element.hasClass("readonly");
		},
		
		isDisabled: function() {
			return this._$element.hasClass("disabled");
		},
		/**
		 * [RichFaces] destroy this component.
		 */
		destroy: function() {
			this._$current = null;
			this._$selected = null;
			this._$focused = null;
			this._change_callback = null;

			this._$optionsBox.remove();
			this._$optionsBox = null;
			
			this._$input.unbind();
			this._$input = null;

			this._$element.unbind().undelegate().removeData();
			this._$element = null;
		},
		/**
		 * [RichFaces] detach from element.
		 */
		detach: function(source) {
			return RichFaces.BaseComponent.prototype.detach.call(this, source);
		},
		getValue: function() {
			return (this._$current !== null ? this._$current.attr("data-value") : null);
		},
		bindElement: function($element) {
			this.id = $element.attr("id"); 
			this._$input = $element;
			this._$element = this._$input.closest('.input');

			this._$current = this._$element.find(".value-showcase");
			this._$optionsBox = this._$element.find(".comboboxOptions");
			
			// event handlers
			this._$optionsBox.delegate("span"+this.SELECTABLE_CLASS, "click", $.proxy(this, "itemSelected"));
			this._$optionsBox.bind("mousedown", $.proxy(this, "_lockFocus"));
			this._$optionsBox.bind("mouseup", $.proxy(this, "_unlockFocus"));
			this._$optionsBox.bind("scroll", $.proxy(this, "_unlockFocus"));
			
			this._$optionsBox.detach();

			this._$element.keydown($.proxy(this, "onKey"));
			this._$element.blur($.proxy(this, "onBlur"));
			this._$element.focus($.proxy(this, "onFocus"));
			this._$element.click($.proxy(function(event) {
				if(this.isReadonly() || this.isDisabled()) {
					return false;
				}
				this.showOptions();
			}, this));

			this._$input.change($.proxy(this, "onInputChanged"));
			this._regainFocus = null;
		},
		onInputChanged: function(event) {
			try {
				/* The following code is a workaround the following issue:
				 * 
				 *  JSF uses triggered element's id as sourceId. This actually
				 *  works, but under IE7, getElementById() behaves strangely if
				 *  given an weird empty string returned that's returned as 
				 *  attribute value from element's without id.
				 *  
				 */
				//this._$element.attr("id", null);
				//this._$input.attr("id", this.id);
				this._change_callback.apply(event.target, arguments);
			}
			finally {
				//this._$input.attr("id", null);
				//this._$element.attr("id", this.id);
			}
		},
		_scheduleRegainFocus: function() {
			if(this._regain_focus != null) {
				clearTimeout(this._regain_focus);
			}
			this._regain_focus = setTimeout($.proxy(function(){
				this._focus_locked = false;
				this._$element.focus();
			}, this), 10);
		},
		_clearRegainFocus: function() {
			if(this._regain_focus != null) {
				clearTimeout(this._regain_focus);
			}
		},
		_lockFocus: function(event) {
			//console.log("LOCK", event.type);
			this._focus_locked = true;
			this._clearRegainFocus();
		},
		_unlockFocus: function(event) {
			//console.log("UNLOCK", event.type);
			this._scheduleRegainFocus();
		},
		hideOptions: function() {
			this._$optionsBox.hide();
			this._clearLookup();
			this._expanded = false;
		},
		showOptions: function() {
			if(this._$optionsBox.is(":visible"))
				return;
			//console.log("Options show", this.id);
			var $e = this._$element, offset = $e.offset();
			this._$optionsBox.detach().appendTo(document.body).css({
				top: offset.top + $e.outerHeight(),
				left: offset.left, 
				width: $e.outerWidth()-2,
				"text-align": $e.css("text-align"),
				"font-size": $e.css("font-size"),
				"font-family": $e.css("font-family"),
				"font-weight": "normal",
				"display": "block"
			});
			this.setMaxRows(this._maxRows);
			this._expanded = true;
		},
		onFocus: function() {
			//console.log("FOCUS", this.id);
		},
		onBlur: function(event) {
			if(this._focus_locked) {
				event.preventDefault();
				event.stopImmediatePropagation();
				//console.log("BLUR PREVENTED", this.id);
				return false;
			}
			//console.log("BLUR", this.id);
			this._clearRegainFocus();
			this.hideOptions();
		},
		getOptions: function() {
			return this._$optionsBox.children(this.SELECTABLE_CLASS);
		},
		getOptionPairs: function() {
		    return this.getOptions().map(function() { return [[$(this).text(), $(this).attr("data-option-value")]]});
		},
		setMaxRows: function(maxRows) {
			this._maxRows = maxRows;
			if(maxRows >= this.getOptions().length) {
				this._$optionsBox.css("height", null);
			}
			else {
				var $opt = this.getOptions().first(), lh;
				if($opt[0].currentStyle) {
					// jQuery misreads unitless values
					lh = $opt[0].currentStyle.lineHeight;
				} else {
					lh = $opt.css("line-height");
				}
				if(lh.substring(lh.length-2, lh.length) == "px") {
					lh = parseInt(lh);
				}
				else {
					var fontSize = parseInt($opt.css("font-size"), 10), ratio = parseFloat(lh);
					if(lh[lh.length-1] == "%") {
						ratio = ratio / 100;
					}
					lh = Math.round(ratio * fontSize);
				};

				var rowHeight = lh + parseInt($opt.css("padding-top"), 10) 
					+ parseInt($opt.css("padding-bottom"), 10);
				this._$optionsBox.css("height", rowHeight * this._maxRows);
			}
		},
		_selectItem: function($selection, stayFocused) {
			if($selection.hasClass("unselectable"))
				return;
			var newValue = $selection.attr("data-option-value");
			this._$current.text($selection.text());
			this._$input.val(newValue);
			this._$selected = $selection;
			this._focusItem(this._$selected);
			this.hideOptions();
			this._$input.change();
		},
		_ensureItemVisible: function($item) {
			if(!this._$optionsBox.is(":visible"))
				return;
			// check if item is within scroll area
			var scrollTop = this._$optionsBox.scrollTop(), height = this._$optionsBox.innerHeight();
			var top = $item.position().top;
			var bottom = top + $item.outerHeight() - height;
			if(top < 0) {
				this._$optionsBox.scrollTop(scrollTop + top);
				return;
			}
			
			if(bottom > 0) {
				this._$optionsBox.scrollTop(scrollTop + bottom);
			};
		},
		_focusItem: function($item) {
			if(this._$focused !== null) {
				this._$focused.removeClass("keyFocused");
			}
			$item.addClass("keyFocused");
			this._$focused = $item;
			this._ensureItemVisible($item);
		},
		_clearLookup: function() {
			if(this._clearLookupTask !== undefined) {
				clearTimeout(this._clearLookupTask);
				delete this._lookupTask;
			};
			this._lookupPrefix = "";
			this._$current.text(this._$selected !== null ? this._$selected.text() : ""); 
		},
		itemSelected: function(event) {
			this._selectItem($(event.target));
		},
		switchKeyFocus: function(next_focus) 
		{
			this._clearLookup();
			var $focused = this._$focused;
			if($focused === null || !$focused.length) {
				var $selection = this._$selected; 
				if($selection === null || $selection.length === 0) {
					// no item selected, select first
					$selection = this.getOptions().first();
				};
				this._focusItem($selection);
				return;
			}
			if(next_focus) {
				$focused = next_focus.call(this, $focused);
				if(!$focused || !$focused.length)
					return;
				$focused = $($focused[0]); // get rid of jQuery selector history
			}
			this._focusItem($focused);
		},
		findItemByValue: function(value) {
			return this.getOptions().filter(function() { return $(this).attr("data-option-value") === value; }).first();
		},
		findItemByLabel: function(label) {
			return this.getOptions().filter(function() { return $.trim($(this).text()) == label; }).first();
		},
		findItemByPrefix: function(prefix) {
			prefix = prefix.toLowerCase();
			return this.getOptions()
				.filter(function() {
					return $(this).text().substring(0, prefix.length).toLowerCase() == prefix;
				})
				.first();
		},
		onKey: function(event) {
			if (this.isReadonly() || this.isDisabled()) {
				return;
			}
			var preventDefault = true, next_focused = null;
			try {
				switch(event.which) {
					case Event.KEY_DOWN:
						next_focused = function(f) {  return f.nextAll(this.SELECTABLE_CLASS).first(); };
						break;
					case Event.KEY_PAGEDOWN:
					case Event.KEY_END:
						next_focused = function(f) {  return f.nextAll(this.SELECTABLE_CLASS).last(); };
						break;
					case Event.KEY_UP:
						next_focused = function(f) {  return f.prevAll(this.SELECTABLE_CLASS).first(); };
						break;
					case Event.KEY_PAGEUP:
					case Event.KEY_HOME:
						next_focused = function(f) {  return f.prevAll(this.SELECTABLE_CLASS).last(); };
						break;
					case Event.KEY_ENTER:
					case Event.KEY_RETURN:
						if(!this._expanded) {
						    preventDefault = false
							return;
						}
						this._clearLookup();
						this._selectItem(this._$focused);
						return;
					case Event.KEY_ESC:
						if(this._lookupPrefix) {
							this._clearLookup();
							break;
						}
						this.hideOptions();
						return;
					case Event.KEY_BACKSPACE:
						this._lookupPrefix = this._lookupPrefix.substring(0, this._lookupPrefix.length - 1);
						if(this._lookupPrefix.length == 0) {
							this._clearLookup();
							return;
						}

						this._$current.text(this._lookupPrefix);
						var $found = this.findItemByPrefix(this._lookupPrefix);
						if($found.length > 0) {
							this._focusItem($found);
						}
						return;

					case Event.KEY_TAB:
					case 16: /* SHIFT KEY */
						preventDefault = false;
						return;
					default:
						var char = String.fromCharCode(event.which);

						// Check if it's a letter
						if(char.length != 1) {
							preventDefault = false;
							return;
						}
						
						this.showOptions();

						char = String.prototype[event.shiftKey ? "toUpperCase" : "toLowerCase"].call(char);
						this._lookupPrefix += char;

						this._$current.text(this._lookupPrefix);
						var $found = this.findItemByPrefix(this._lookupPrefix);
						if($found.length > 0) {
							this._focusItem($found);
						}
						return;
				}
				this.showOptions();
				this.switchKeyFocus(next_focused);
			} finally {
				if(preventDefault) {
					event.preventDefault();
					event.stopImmediatePropagation();
				}
			}
		}
	});

	window.initComboBox = function(options) {
		if(!options.id) {
			throw new Error("Failed to initialize ComboBox, no ID given.");
		}
		var element = document.getElementById(options.id);
		if(element === null) {
			throw new Error("Element with ID: " + options.id + " is missing.");
		}
		
		var $element = $(element);
		var rfdata = (element[RichFaces.RICH_CONTAINER] || {});
		
		if(rfdata["component"]) {
			if(window.console && window.console.warn) {
				console.warn("ComboBox for id", options.id, "already initialized.");
				return false;
			}
		}
		
		// store the rf data
		rfdata.component = new ComboBox($element, options.onchange);
		element[RichFaces.RICH_CONTAINER] = rfdata;
		return true;
	};
})(jQuery);