/**
 * Checkbox component.
 */
;(function($, richfaces) {

var Checkbox = window.Checkbox = function(checkboxId, extraParams) {
	this.checkbox = $d(checkboxId);

	this.label = $d(extraParams.labelId);
	this.label.checkboxObj = this;
	this.maxSelected = extraParams.maxSelected;

	this.onclick = $.proxy(extraParams.onclick, this.checkbox);
	var $label = $(this.label);
	
	$label.bind('focus', $.proxy(this.changeImageFocus, this));
	$label.bind('click', $.proxy(this.toggleCheckboxClass, this));
	$label.bind('keypress', $.proxy(this.labelOnKeyPress, this));
	$label.bind('blur', $.proxy(this.changeImageBlur, this));
	
	/* Bind to element in RF style */
	richfaces.BaseComponent.prototype.attachToDom.call(this, this.checkbox);
};

$.extend(Checkbox.prototype, {
	destroy: function() {
		delete this.checkbox;
		delete this.$checkbox;
		delete this.onclick;

		$(this.label).unbind().removeData();
		if(this.label) {
			this.label.checkboxObj = null;
		}
		delete this.label;
		delete this.$label;
	},
	detach: richfaces.BaseComponent.prototype.detach,
	labelOnKeyPress: function(event) {
  			if ((event.charCode || event.keyCode) === " ".charCodeAt(0) /*32, KEY_SPACE*/) {
  				this.toggleCheckboxClass(event);
  				event.stopPropagation();
  			}
  		},
  		extendElements: function() {
  			this.$checkbox = $(this.checkbox);
  			this.$label = $(this.label);
  		},
  		toggleCheckboxClass: function(event, withFocus) {
  			if (withFocus == undefined){
  				withFocus = true;
  			}
  			
  			if (!this.checkbox.readOnly) {
  				this.toggleCheckboxClassInner(!this.isChecked(), event, withFocus);
  			}
  		},
  		
  		toggleCheckboxClassInner: function(enabled, event, withFocus) {
  			this.extendElements();
  			this.checkbox.checked = enabled;
  			this.onclick(event);
  			this.$label.removeClass("check_on");
  			this.$label.removeClass("check_on_focus");
  			this.$label.removeClass("check_off");
  			this.$label.removeClass("check_off_focus");
  			
  			if (this.isChecked()) {
  				this.$label.addClass("check_on");
  				if (withFocus) {
  					this.$label.addClass("check_on_focus");
  				}
  			} else {
  				this.$label.addClass("check_off");
  				if (withFocus) {
  					this.$label.addClass("check_off_focus");
  				}
  			}
  			this.toggleCheckboxesIfNecessary();

  		},
  		
  		toggleCheckboxesIfNecessary: function() {
  			this.extendElements();
  			if (!this.maxSelected || this.maxSelected < 0) {
  				return;
  			}
  			
  			var parent = this.$checkbox[0].originalParent || this.$checkbox.parent();
  			var selectManyCheckboxTable = parent.closest('.selectManyTable');
  			if (selectManyCheckboxTable.length == 0) {
  				return;
  			}
  			
  			var checkboxes = selectManyCheckboxTable[0].checkboxes ||
  				$(selectManyCheckboxTable).find('input.checkbox');
  			
  			var checkedAmount = 0;
  			
  			checkboxes.each(function(index, checkbox) {
  				if (checkbox.checked) {
  					++checkedAmount;
  				}
  			});
  			
  			var toggleEnabled = checkedAmount < this.maxSelected;
			checkboxes.each($.proxy(function(index, checkbox) {
  				if (!checkbox.checked) {
  					this.toggleCheckbox(checkbox, toggleEnabled);
  				}
  			},this));
  		},
  		toggleCheckbox: function(checkbox, toggleEnabled) {
  			if (!checkbox){
  				checkbox = this.checkbox;
  				toggleEnabled = true;
  			}
  			var $checkbox = $(checkbox);
  			if (!$checkbox.hasClass('alwaysDisabled')) {
	  			checkbox.readOnly = !toggleEnabled;
	  			var parent = checkbox.originalParent || $checkbox.parent(); 
	  			var $label = $(parent).children().first();
	  			var className = 'checkboxDisabled';
	  			if (toggleEnabled) {
	  				$label.removeClass(className);
	  			} else {
	  				$label.addClass(className);
	  			}
  			}
  		},
  		toggleCheckboxClassOff: function() {
  			this.extendElements();
  			this.$label.removeClass("check_on");
  			this.$label.removeClass("check_on_focus");
  			this.$label.addClass("check_off");
  		},
  		changeImageFocus: function() {
  			this.extendElements();
  			if (this.isChecked()) {
  				this.$label.addClass("check_on_focus");  				
  			} else {
  				this.$label.addClass("check_off_focus");
  			}
  		},

  		changeImageBlur: function() {
  			this.extendElements();
  			if (this.isChecked()) {
  				this.$label.removeClass("check_on_focus");  				
  			} else {
  				this.$label.removeClass("check_off_focus");
  			}
  		},
  		
  		isChecked: function() {
  			return this.checkbox.checked;
  		}
  		
});

})(window.jQuery, window.RichFaces);