// fake console
if(!window.console) {
    window.console = {
         log: function() {}
    }
};

function setFocusOn(elementId) {
    var element = $d(elementId);
    if (element == null) {
        return;
    }
    element.focus();
}

function toggle_compute(visible,params) {
	var forObj = $j(params.forId);
	var forObj2 = [];
	if (params.forId2) {
		forObj2 = $j(params.forId2);
	}
	if (visible) {
		if (forObj.length) {
			forObj.show();
			// due to a bug in IE that shows content of the table row even if it has display: none set*/
			// we also apply showing and hiding to the first child of the row, which for some reason solves the problem

			var child = forObj.find(':first');
			if (child.length) {
				if (child[0].displayStatus) {
					child[0].style.display = child[0].displayStatus;
				} else {
					child.show();
				}
			}

		}
		if (forObj2.length) {
			forObj2.show();
		}
		$d(params.id).src = params.srcOut;
		if (params.tipId) {
			var el = $j(params.tipId);
			if (el.length) {
				var node = el.find('.tooltipContainer:first');
				if (node.length) {
					node[0].innerHTML = params.tipOut;
				}
			}
		}
	} else {
		if (forObj.length) {
			// due to a bug in IE that shows content of the table row even if it has display: none set*/
			// we also apply showing and hiding to the first child of the row, which for some reason solves the problem
			var child = forObj.find(':first');
			if (child.length) {
				child[0].displayStatus = child[0].style.display;
				child.hide();
			}
			forObj.hide();
		}
		if (forObj2.length) {
			forObj2.hide();
		}
		$d(params.id).src = params.srcIn;
		if (params.tipId) {
			var el = $(params.tipId);
			if (el.length) {
				var node = el.find('.tooltipContainer');
				if (node.length) {
					node[0].innerHTML = params.tipIn;
				}
			}
		}
	}
};

function toggle_onmousedown(params) {
	var forObj = $d(params.forId);
	toggle_compute(forObj.style.display === 'none',params);
};

function toggle_setup(params) {
	toggle_compute(params.value == 'true', params);
};

var SyncUtils = {

	isFF: function() {
		return /Firefox[\/\s](\d+\.\d+)/.test(navigator.userAgent);
	},

	isIE: function() {
		return /MSIE (\d+\.\d+);/.test(navigator.userAgent);
	},

	fireEvent: function(element,event){
		if (typeof(element) === 'string') {
			element = $d(element);
		}
	    if (document.createEventObject){
		    // dispatch for IE
		    var evt = document.createEventObject();
		    return element.fireEvent('on' + event,evt)
	    } else {
		    // dispatch for firefox + others
		    var evt = document.createEvent("HTMLEvents");
		    evt.initEvent(event, false, true); // event type,bubbling,cancelable
		    return !element.dispatchEvent(evt);
	    }
	},

	isAncestor: function(element, potentialAncestor) {
		if (!element || !potentialAncestor) {
			return false;
		}
		element = SyncUtils.idToElement(element);
		potentialAncestor = SyncUtils.idToElement(potentialAncestor);

		while (element) {
			element = element.parentNode;
			if (element == potentialAncestor) {
				return true;
			}
		}

		return false;
	},

	idToElement: function(element) {
		if (typeof element === 'string') {
			element = document.getElementById(element);
		}
		return element;
	},

	unescape: function(text) {
		var e = document.createElement('div');
		e.innerHTML = text;
		if (e.childNodes.length > 0) {
			return e.childNodes[0].nodeValue;
		}
		return text;
	},

	registeredEvents: {
		beforeSubmit: {},
		afterSubmit: {},
		beforeResponse: {},
		afterResponse: {}
	},

	broadcast: function() {
		var name = arguments[0];
		var args = Array.prototype.slice.call(arguments, 1, arguments.length);
		var returnValue = true;
		$.each(this.registeredEvents[name], function(key, fun) {
			if (fun.apply(window, args) === false) {
				returnValue = false;
				return false;
			}
		});
		return returnValue;
	},

	evalJSONFromRequest: function(request, selector) {
	    var jsonStringHolder = $(request.responseXML).find(selector);
	    if (jsonStringHolder.length) {
	    	return eval('(' + jsonStringHolder.text() + ')');
	    }
	    return null;
	},

	getDataFromRequest: function(request) {
		return SyncUtils.evalJSONFromRequest(request,'partial-response:first extension#org\\.richfaces\\.extension data:first');
	},

	wrap: function (functionToWrap, wrapper, thisObj) {
	    return function () {
	        var args = Array.prototype.slice.call(arguments);
			args.splice(0,0,functionToWrap);
	        wrapper.apply(thisObj || this, args);
	    };
	},

	eventsBeforeResponse: 0,

	newEventBeforeResponse: function() {
		++this.eventsBeforeResponse;
	},

	eventBeforeResponseProcessed: function(request, context) {
		--this.eventsBeforeResponse;
		if (this.eventsBeforeResponse === 0) {
			context.afterBroadcast = true;
			SyncUtils.jsfAjaxResponse(request, context);
		}
	},

	replaceIfError: function(errorData) {
		if (errorData.responseCode >= 400) {
			SyncUtils.replacePage(errorData);
		}
	},

	ajaxBypassQueue: function(element) {
		var elementId = element.id;

		var ajaxParams = {
				'javax.faces.source': elementId,
				'javax.faces.partial.event': 'click',
				'javax.faces.partial.execute' : elementId + ' @component',
				'javax.faces.partial.render':'@component',
				'org.richfaces.ajax.component': elementId,
				'AJAX:EVENTS_COUNT':1,
				'javax.faces.partial.ajax':'true'
			};
		ajaxParams[elementId] = elementId;

		var ajaxOptions = {
			complete: function(jqXHR, textStatus) {
					if (window.SyncAjaxStatus) {
						++SyncAjaxStatus.ajaxRequests;
					}
					jsf.ajax.response(jqXHR, {});
				},
			headers: {'Faces-Request': 'partial/ajax'},
			contentType: 'application/x-www-form-urlencoded;charset=UTF-8',
			type: 'POST',
			data: $(element).closest('form').serialize() + '&amp;' + $.param(ajaxParams)
		};
		$.ajax(ajaxOptions);
	},

	textExpando: function(element, showLabel, hideLabel) {
	    var $e = $(element), $ex = $e.parent();
	    var maxWidth = $ex.data("max-width");
	    if(!maxWidth || $e.outerWidth() <= maxWidth) {
	        $ex.removeClass("expando");
	        return;
	    }
	    $ex.css("width", maxWidth);
	    $("<a href='#'>["+showLabel+"]</a>").toggle(function() {
           $(this).text("["+hideLabel+"]");
           $ex
               .css({"white-space": "normal", "height": "auto"})
                   .find("span").css({"white-space": "normal"});

	    }, function() {
	       $(this).text("["+showLabel+"]");
	       $ex.css({"white-space": "", "height": ""})
	           .find("span").css({"white-space": ""});
	    }).insertAfter($ex);
	}
}

//make sure we wrap after RF
$(function() {
	jsf.ajax.request = SyncUtils.wrap(jsf.ajax.request,
		function(proceed, source, event, options) {
			if (SyncUtils.broadcast('beforeSubmit', source, event, options)) {
				proceed(source,event,options);
			}
			SyncUtils.broadcast('afterSubmit', source, event, options);
		}
	);
});

//make sure we wrap after RF
$(function() {
	jsf.ajax.response = SyncUtils.wrap(jsf.ajax.response,
		function(proceed, request, context) {
			if (context.afterBroadcast) {
				proceed(request, context);
				SyncUtils.broadcast('afterResponse', request, context);
			} else {
				SyncUtils.newEventBeforeResponse();
				SyncUtils.broadcast('beforeResponse', request, context);
				SyncUtils.eventBeforeResponseProcessed(request, context);
			}
		}
	);
	SyncUtils.jsfAjaxResponse = jsf.ajax.response;
});


$.each(['beforeSubmit','afterSubmit','beforeResponse','afterResponse'], function(index, name) {
	SyncUtils[name] = function(id, fun) {
		this.registeredEvents[name][id] = fun;
	}
});

if (!window.Event) {
	var Event = {};
}


Event.KEY_BACKSPACE = 8;
Event.KEY_TAB = 9;
Event.KEY_RETURN = 13;
Event.KEY_ESC = 27;
Event.KEY_LEFT = 37;
Event.KEY_UP = 38;
Event.KEY_RIGHT = 39;
Event.KEY_DOWN = 40;
Event.KEY_DELETE = 46;
Event.KEY_HOME = 36;
Event.KEY_END = 35;
Event.KEY_PAGEUP = 33;
Event.KEY_PAGEDOWN = 34;
Event.KEY_INSERT = 45;
Event.KEY_SPACE = 32;


//Make rerendered forms work. See http://java.net/jira/browse/JAVASERVERFACES_SPEC_PUBLIC-790
jsf.ajax.addOnEvent(function(e){
    var xml = e.responseXML;
    var status = e.status;
    if(status === 'success'){
        var response = xml.getElementsByTagName('partial-response')[0];
        if(response !== null){
            var changes = response.getElementsByTagName('changes')[0];
            if(changes != undefined){
                var updates = changes.getElementsByTagName('update');
                if(updates != undefined){
                    for(var i = 0; i< updates.length; i++){
                        var update = updates[i];
                        var id = update.getAttribute('id');
                        if(id === 'javax.faces.ViewState'){
                            currentViewState = update.firstChild.data;
                            //update all forms
                            var forms = document.forms;
                            for(var j = 0; j < forms.length; j++){
                                var form = forms[j];
                                var field = form.elements["javax.faces.ViewState"];
                                if (typeof field == 'undefined') {
                                    field = document.createElement("input");
                                    field.type = "hidden";
                                    field.name = "javax.faces.ViewState";
                                    form.appendChild(field);
                                }
                                field.value = currentViewState;
                            }
                        }
                    }
                }
            }
        }
    }

});

SyncUtils.beforeResponse('Resources', function(request, context) {
    var resources = $(request.responseXML).find('partial-response:first extension#com\\.syncron\\.faces\\.resources *');
    var head = document.getElementsByTagName("head")[0];
    resources = resources.detach();
    var counter = resources.length;

    resources.each(function() {
    	if (this.nodeName.toUpperCase() === 'SCRIPT') {
	    	SyncUtils.newEventBeforeResponse();
    	}
    });

    //we have to process resources in order they came in.
    var processSingleResource = function() {

    	if (counter > 0) {

    		var onloadFunction = function() {
    			if (!this.readyState || this.readyState === "complete" || this.readyState === "loaded") {
    				SyncUtils.eventBeforeResponseProcessed(request, context);
    			}
    			processSingleResource();
    		}

    		var resource = resources[resources.length - counter];

    		var newResource;
        	if (resource.nodeName.toUpperCase() === 'SCRIPT') {
        		newResource = document.createElement("script");
        		newResource.type = "text/javascript";
        		newResource.src = resource.getAttribute("src");
        	} else {
        		newResource = document.createElement("link");
        		newResource.type = "text/css";
        		newResource.rel = "stylesheet";
        		newResource.href = resource.getAttribute("href");
        	}

        	head.appendChild(newResource);

        	if (resource.nodeName.toUpperCase() === 'SCRIPT') {
    	    	if(newResource.addEventListener) {
    	    		newResource.onload = onloadFunction;
    	    	} else {
    	    		newResource.onreadystatechange = onloadFunction;
    	    	}
        	}
        	--counter;
        	if (resource.nodeName.toUpperCase() === 'LINK') {
        		processSingleResource();
        	}
    	}
    }

    processSingleResource();
});

SyncUtils.beforeResponse('ActionResult', function(request,  context) {
    SyncActionData = SyncUtils.getDataFromRequest(request);
});

jsf.ajax.addOnError(function(errorData) {
	if (window.console && window.console.error) {
		console.error([errorData.description, errorData]);
	}
	SyncUtils.replaceIfError(errorData);

});

$d = function(id) {
	return document.getElementById(id);
}

$j = function(el) {
	if (typeof el === 'string') {
		el = $d(el);
	}
	return $(el);
}

$.fn.bindProxy = function(event, fun, context) {
	$(this).bind(event, context ? $.proxy(fun, context) : fun);
}

function _encodeStringToJSON(str) {
    return '"' + str.replace(/"/g, '\\"') + '"';
}

function _encodeArrayToJSON(arr) {
    var result = [];
    for(var i=0; i < arr.length; i++) {
        result.push(syncEncodeToJSON(arr[i]));
    }
    return "[" + result.join(", ") + "]";
}

function _encodeObjectToJSON(obj) {
    var key, result = [];
    for(key in obj) {
        result.push(_encodeStringToJSON(key) + ": " + syncEncodeToJSON(obj[key]));
    }
    return "{" + result.join(', ') + "}";
}

function syncEncodeToJSON(obj)
{
    /*if(window.JSON && window.JSON.stringify) {
        return window.JSON.stringify(obj);
    }*/
    var t = typeof obj;
    switch(t) {
        case "object":
            if(obj === null) {
                return "null";
            }
            if(obj instanceof window.Array) {
                return _encodeArrayToJSON(obj);
            }
            if(obj instanceof window.Date) {
                return obj.toString();
            }
            return _encodeObjectToJSON(obj);
        case "string":
            obj = _encodeStringToJSON(obj);
        default:
            return obj.toString();
    }
}

Array.prototype.syncToJSON = function() {
    return syncEncodeToJSON(this);
}

$.fn.mapWith = function mapWithjQueryMethod(name) {
    var callback = $.fn[name];
    if(callback == null) {
        throw new Error("jQuery prototype has no method: '"+name+"'.");
    }
    return this.map(function() {
        return callback.call($(this));
    });
};

SyncUtils.isFF = function(){
	return $.browser.mozilla;
}

//copied from AjaxScript in RichFaces 3.3.3 and slightly modified
SyncUtils.replacePage = function(req){
	if(!req.responseText){
		return;
	}
	var isIE = (navigator.appName.indexOf("Microsoft") != -1);
	var isFF = SyncUtils.isFF();
	// maksimkaszynski
	//Prevent "Permission denied in IE7"
	//Reset calling principal
	var oldDocOpen = window.document.open;
	if (isIE) {
		window.document.open = function(sUrl, sName, sFeatures, bReplace) {
			oldDocOpen(sUrl, sName, sFeatures, bReplace);
		}
	}
	// /maksimkaszynski
	window.setTimeout(function() {
		var isDocOpen=false;

		if (isFF) {
			var	oDomDoc = (new DOMParser()).parseFromString(req.responseText, "text/xml");
			if(oDomDoc){
				while(window.document.documentElement.firstChild){window.document.documentElement.removeChild(window.document.documentElement.firstChild);}
			  var docNodes = oDomDoc.documentElement.childNodes;
			  for(var i = 0;i<docNodes.length;i++){
				if(docNodes[i].nodeType == 1){

		    		var node = window.document.importNode(docNodes[i], true);
	    			window.document.documentElement.appendChild(node);
				}
			 }
			  //TODO - unloading cached observers?
			  //if (window.RichFaces && window.RichFaces.Memory) {
			  //	  window.RichFaces.Memory.clean(oldnode);
			  //}
			} else {

			}
			// TODO - scripts reloading ?
			return;
		}

		try {
			var contentType = "text/xml;charset=UTF-8";
				var responseText = req.responseText;

				window.document.open(contentType, "replace");

				isDocOpen=true;

				window.document.write(responseText);

				window.document.close();

			if(isIE){
		// For Ie , scripts on page not activated.
				window.location.reload(false);
			}
		} catch(e) {

			if(isDocOpen){
					window.document.close();
			}
			// Firefox/Mozilla in XHTML case don't support document.write()
			// Use dom manipulation instead.
			var	oDomDoc = (new DOMParser()).parseFromString(req.responseText, "text/xml");
			if(oDomDoc){
				while(window.document.documentElement.firstChild){window.document.documentElement.removeChild(window.document.documentElement.firstChild);}
			  var docNodes = oDomDoc.documentElement.childNodes;
			  for(var i = 0;i<docNodes.length;i++){
				if(docNodes[i].nodeType == 1){

		    		var node = window.document.importNode(docNodes[i], true);
	    			window.document.documentElement.appendChild(node);
				}
			 }
			  //TODO - unloading cached observers?
			  //if (window.RichFaces && window.RichFaces.Memory) {
			  //	  window.RichFaces.Memory.clean(oldnode);
			  //}
			} else {

			}
			// TODO - scripts reloading ?
		} finally {
			window.document.open = oldDocOpen;
		}

		},0);
}
