function turnOnPolling(progress) {
	if (progress == null) {
		return;
	}
	progress.enable();
}

function switchExportButtons(startButtonId, stopButtonId) {
	
	set_style_display(startButtonId, false);
	set_style_display(stopButtonId, true);
}

function set_style_display(elementId, visible) {
	var element = document.getElementById(elementId);
	if (element == null) {
		throw "No component with id =[" + elementId + "]";
	}
	element.style.display = visible ? '' : 'none';
}