PopupBox = {
		show: function(clientId, slideDownTime, fadeOutTime) {
			var popup = $j(clientId);
			var viewportWidth = $(window).width();
			var width = viewportWidth/2 - popup.width()/2;
			popup.css('left', width + 'px');
			popup.slideDown(slideDownTime, function() {
				popup.fadeOut(fadeOutTime);
			});
		}
}