var syncAutoDetectWidth = {
	overwrite: function() {
		this.detect(true);
	},
	check: function() {
		this.detect(false);
	},
	detect: function(alwaysOverwrite) {
		var detectedWidthElement = document.getElementById('autoDetectedWidth');
		if (detectedWidthElement) {
			var detectedWidth = detectedWidthElement.innerHTML;
			if (!detectedWidth || isNaN(detectedWidth)) {
				detectedWidth = -1;
			}
			if (alwaysOverwrite || detectedWidth == -1) {
				var newWidth = $(document).width();
				if (newWidth != detectedWidth) {
					this.saveWithTimeout(newWidth);
				}
			}
		}
	},
	doSave: function() {
		if (this.newWidth) {
			saveAutoDetectedWidth(this.newWidth);
		}
		this.timeoutId = null;
	},
	
	saveWithTimeout: function(width) {
		if (this.timeoutId) {
			window.clearTimeout(this.timeoutId);
			this.timeoutId = null;
			this.newWidth = null;
		}
		this.newWidth = width;
		this.timeoutId = window.setTimeout($.proxy(this.doSave, this), 1000);
	}
}

$(window).resize($.proxy(syncAutoDetectWidth.overwrite, syncAutoDetectWidth));
$($.proxy(syncAutoDetectWidth.check, syncAutoDetectWidth));