/**
 * DropDownMenu component. 
 */
;(function($, richfaces) {

	var DropDownMenu = window.DropDownMenu = Class.create({
	
	init: function(params){
		this.$handle = $j(params.handleId);
		this.menuId = params.menuId;
		this.$menu = $j(this.menuId);

		this.$panel = $j(params.panelId);
		
		this.width = params.width;
		this.minWidth = params.minWidth;
		this.$domAttachment = 
			params.domAttachment ? $j(params.domAttachment) : $(this.closestFixedAncestor() || document.body);
			
		this.maxHeight = params.maxHeight;
		
		/* Bind to element in RF style */
		richfaces.BaseComponent.prototype.attachToDom.call(this, this.$menu);
	},

	destroy: function() {
		this.$handle = null;
		this.$menu = null;
		this.$panel = null;
		this.$domAttachment = null;
	},

	detach: richfaces.BaseComponent.prototype.detach,
	
	open: function(){
		
		if (this.isOpen())
			return;

		this.$domAttachment.append(this.$menu.detach());
		this.$menu.find('input').each($.proxy(function(index, element){
			var input = $(element);
			if (input.css('display') == 'none'){
				element.originalParent = input.parent();
				this.$handle.append(input.detach());
			}
		}, this));
		
		var dropDownCoords = this.$panel.offset();
		var left = dropDownCoords.left - 1;
		var top = dropDownCoords.top + this.$panel.height() + 2;

		var viewportHeight = $(window).height();
		if (top + this.menuHeight > viewportHeight) {
			if (dropDownCoords.top - this.maxHeight - 2 >= 0) {
				top = dropDownCoords.top - this.maxHeight - 2;
			} else {
				if (viewportHeight - top - 3 > 0) {
					this.$menu.css('height', viewportHeight - top - 3 + "px");
				}
			}
		}

		var domAttachmentCoords = this.$domAttachment.offset();
		top = top - domAttachmentCoords.top - this.borderWidth(this.$domAttachment, 'top');
		left = left - domAttachmentCoords.left - this.borderWidth(this.$domAttachment, 'left');
		
		var width = this.width || this.$panel.width() + 'px'
			, minWidth = this.minWidth || this.$panel.width() + 'px'
		
		this.$menu.css({
			width: width
			, minWidth: minWidth
			, maxHeight: this.maxHeight
			, left: left + 'px'
			, top: top + 'px'
			, zIndex: '1000'
			, position: 'absolute'
		})
 		this.$menu.show();
 		
 		this.state = 'open';
 		
 		this.openAfterAjax(true);
 		
	},
	
	close: function(openAfterAjax){
		if (!this.isOpen())
			return;
		
		
		this.$menu.hide();
		this.$handle.append(this.$menu.detach());

		this.$menu.find('input').each(function(index, element)
		{
			var input = $(element);
			if (input.css('display') == 'none'){
				element.originalParent.append(input.detach());
			}
		});
	
		this.$menu.css('display','none');
		this.state = 'closed';
		
		this.openAfterAjax(openAfterAjax);
	},
	
	toggle: function() {
		if (this.isOpen()){
			this.close();
		} else {
			this.open();
		}
	},
	
	isOpen: function() {
		return this.state == 'open';
	},

	closestFixedAncestor: function(){
		var ancestors = this.$handle.parents();
		var i;
		for (i = 0; i < ancestors.length; i++)
			if ($(ancestors[i]).css('position') === 'fixed') return ancestors[i];
		return null;
	},
	
	borderWidth: function($element, whichBorder){
		var widthMatch = /(\d+)px/.exec($element.css('border-' + whichBorder + '-width'));
		if (widthMatch)
			return parseInt(widthMatch[1]);
		else 
			return 0;
	},
	
	openAfterAjax: function (val) {
		var id = this.menuId;
		if (val)
			DropDownMenu.openMenus[id] = true;
		else 
			delete DropDownMenu.openMenus[id];
	}

});

DropDownMenu.openMenus = {};

jsf.ajax.addOnEvent(function(data) {

	if (data.status === 'complete') {
		$.each(DropDownMenu.openMenus, function(id, ignore) {
			var menu = $d(id);
			if (menu && menu.rf && menu.rf.component) {
				menu.rf.component.close(true);
			}
		});
	}
	
	else if (data.status === 'success') {
		var opened = $.extend({}, DropDownMenu.openMenus);
		DropDownMenu.openMenus = {};
		$.each(opened,function(id, ignore) {
			var menu = $d(id);
			if (menu && menu.rf && menu.rf.component) {
				menu.rf.component.open();
			}
		});
	}
});

})(jQuery, RichFaces);