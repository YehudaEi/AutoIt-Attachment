function disableOnclick(event) {
	event = $.event.fix(event);
	var elem = event.target;
	if (elem) {
		elem = $(elem).closest('td');
	} 
	if (!elem.length) {
		return true;
	} 
	
	return typeof elem.attr('enableonclick') === 'undefined';
}