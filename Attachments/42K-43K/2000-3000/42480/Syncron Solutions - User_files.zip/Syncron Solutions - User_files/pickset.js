/**
 * DropDownMenu component. 
 */
;(function($, richfaces) {
	
var Pickset = window.Pickset = Class.create({

	init: function(id, extraParams) {
		this.id = id;

		var $component = $j(this.id);
		this.$input = $component.closest(".input");

		var $menu = this.$input.find('.picksetMenu');
		if($menu.length == 0) {
		    throw new Error("Failed to initialize pickset with id: " + this.id);
		}
		
		// update state handler
        $menu.delegate("input[type=checkbox]", "change", $.proxy(this, "refresh"));
		// We need to bind directly, because JSF generates onclick='return false' which
		// prevents the event from bubbling
	    $menu.find(".action-checkall").bind("click", $.proxy(this, "onCheckAll"));
	    $menu.find(".action-uncheckall").bind("click", $.proxy(this, "onUnCheckAll"));
	    this.$menu = $menu;

		this.maxSelected = extraParams.maxSelected;
		this.maxHeight = extraParams.maxHeight;
		this.topPanelHeight = this.$input.find('.topPanel').css('height') || '0px';
		this.disabled = extraParams.disabled;
		this.alwaysExpanded = extraParams.alwaysExpanded;

		if (!extraParams.alwaysExpanded)
		{
		    this.$panel = this.$input.children(".value-showcase-wrapper"); 
		    if (!extraParams.disabled) {
		        this.$panel.bind("click", $.proxy(this, "toggle"));
		    }
			this.dropDownId = id + 'DropDown';
			this.$dropDown = $j(this.dropDownId);
			this.$expandedContent = this.$dropDown;
			this.menu = new DropDownMenu({handleId: this.$input,
				menuId: this.dropDownId, panelId: this.$panel, maxHeight: extraParams.maxHeight, minWidth: '250px'});
		} else {
			this.$expandedContent = this.$input.find('.picksetExpandedContent');
		}
		this._blurHandle = $.proxy(this, "processWindowClick");
	    $(document).delegate("*", "click", this._blurHandle);

	    /* Bind to element in RF style */
		richfaces.BaseComponent.prototype.attachToDom.call(this, this.$input);

		this.refresh();
	},
	
	onCheckAll: function markAllAsChecked(evt) {
	    if(this.$input.is(".readonly"))
	        return;
        this.setValueToAll(true, evt);
	},
	
    onUnCheckAll: function markAllAsUnChecked(evt) {
        if(this.$input.is(".readonly"))
            return;
        this.setValueToAll(false, evt);
	},
	
	destroy: function() {
	    $(document).undelegate("*", "click", this._blurHandle);
		this.$input = null;
		if(this.menu) {
			this.menu.destroy();
			this.detach(this.$dropDown);
			this.$panel = null;
			this.$dropDown = null;
			this.menu = null;
		}
		this.$menu.undelegate();
		this.$menu = null;
		this.$checkedCounter = null;
		this.$expandedContent = null;
	},

	detach: richfaces.BaseComponent.prototype.detach,
	
	processWindowClick: function(event) {
		if (this.isClickEventOutside(event)){
			this.close();
		}
	},
	
	isClickEventOutside: function(event) {
		return !this.alwaysExpanded && !(this.isAncestorOrEqual(event.target, this.$panel[0]) || this.isAncestorOrEqual(event.target, this.$dropDown[0]));
	},
			
	close: function() {
		this.menu.close();
	},
	
	open: function() {
		this.$dropDown.find('.checkboxesPanel').css('maxHeight',
				(this.toInt(this.maxHeight) - this.toInt(this.topPanelHeight))+ 'px');
		this.menu.open();
	},
	
	toggle: function(evt) {
	    evt.preventDefault();
		if (this.menu.isOpen()){
			this.close();
		} else {
			this.open();
		}
	},
	
	refresh: function(){
	    this.refreshHighlight();
	    this.refreshCheckedCounter();
		if (!this.alwaysExpanded){
			this.refreshLabel();
		}
	},
	
	refreshLabel: function() 
	{
	    var newlabel = this.getLabel() 
	    this.$input.find(".value-showcase").text(newlabel);
	},
	
	getLabel: function() {
	    return this.$expandedContent.find(".selected label").mapWith("text").get().join(", ");
	},
	
	refreshCheckedCounter: function() {
		var checked = this.$expandedContent.find('input:checked').length;
		if (this.maxSelected){
			checked = checked + '/' + this.maxSelected;
		}
		this.$expandedContent.find(".checked-counter-value").text(checked);
	},
	
	refreshHighlight: function() {
	    this.$expandedContent.find('input[type=checkbox]').each(function() {
	        var $checkbox = $(this);
	        if($checkbox.is(":checked")) {
	            $checkbox.closest("li, tr").addClass("selected");
	        } else {
	            $checkbox.closest("li, tr").removeClass("selected");
	        };
	    });
	},
	
	isAncestorOrEqual: function(element, potentialAncestor){
		return (element == potentialAncestor) || SyncUtils.isAncestor(element, potentialAncestor)
	},

	setValueToAll: function(value, event) {
	    // NOTE: if jQuery >= 1.6 this should be .prop()
		this.$expandedContent.find('input[type=checkbox]').attr("checked", value)
		this.refresh();
	},
	
	toInt: function(lengthInPixels){
		return parseInt(/(\d+)px/.exec(lengthInPixels)[1]);
	}
	
});


})(jQuery, RichFaces);