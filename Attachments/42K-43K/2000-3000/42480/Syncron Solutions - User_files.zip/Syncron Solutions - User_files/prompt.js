function removeHints(f) {
	$(f).find('input.inputTextHintSet').each( function(index, el) {
		el.connector.removeHint();
	});	
};

var InputPrompt = Class.create({
	
	registeredIds: [],
	
	setupSubmit: function(inputID, formObj) {
		SyncUtils.beforeSubmit(inputID, function() {
			removeHints(formObj);
		});
		
		if ($.inArray(inputID, this.registeredIds) < 0) {
			this.registeredIds[this.registeredIds.length] = inputID;
			jsf.ajax.addOnEvent(function(data) {
				if (data.status === "success") {
					var $el = $j(inputID);
					if ($el.length) {
						$el[0].connector.prompt();
					}
				}
			});
		}
	}, 
	
	//constructor
	init: function(inputID,formID,promptStr) {
		this.inputControl = $d(inputID);
		this.$inputControl = $(this.inputControl);
		this.inputControl.promptStr = promptStr;
		this.inputControl.connector = this;
		var formObj = $d(formID);
		var $formObj = $(formObj);
		
		this.setupSubmit(inputID, formObj);
		
		if (!this.inputControl.setHint) {
			this.inputControl.setHint = $.proxy(this.prompt, this);	
			$(this.inputControl).bind('blur', this.inputControl.setHint);
		}
		
		if (!this.inputControl.removeHint) {
			this.inputControl.removeHint = $.proxy(this.removeHint, this);
			$(this.inputControl).bind('focus', this.inputControl.removeHint);
		}
		
		this.prompt();
	},
	
	prompt: function() {
		var inputObj = this.inputControl;
		var hintStr = inputObj.promptStr;
		if (!inputObj.value) {
			inputObj.value = hintStr;
		}
		if (inputObj.value === hintStr) {
			this.toggleClassNames(true);
		}
	},

	removeHint: function() {
		if (this.$inputControl.hasClass('inputTextHintSet')) {
			this.inputControl.value = '';
			this.toggleClassNames(false);
		}
	},

	classNameSuffixes: ['Set', 'Cut'],
	
	classNamePrefix: 'inputTextHint',
	
	toggleClassNames: function(showPrompt) {
		var indexToAdd = showPrompt ? 0 : 1;
		var classToAdd = this.classNamePrefix + this.classNameSuffixes[indexToAdd];
		var classToRemove = this.classNamePrefix + this.classNameSuffixes[1-indexToAdd];
		this.$inputControl.addClass(classToAdd);
		this.$inputControl.removeClass(classToRemove);
		
	}

});
