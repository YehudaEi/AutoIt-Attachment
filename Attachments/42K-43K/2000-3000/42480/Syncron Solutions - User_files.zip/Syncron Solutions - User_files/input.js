
function _setIfOnlyOneSuggested(suggestionBox, event) {
	if (suggestionBox.entryCount == 1) {
		var entry = suggestionBox.getEntry(0);
		if (entry == null)
			return
        var obj = entry.firstChild;
        while (obj != null && (!obj.tagName || obj.tagName.toLowerCase()!="td")) obj = obj.nextSibling;
        if (obj == null)
        	return
        var value = Element.collectTextNodes(obj);
        suggestionBox.insertValue(value);
	}
};

function _isLengthSmallerThanOrContains(input, number, char) {
	var val = $(input).getValue() || "";
	if (val.length < number) {
		return true;
	}
	return (val.indexOf(char) >= 0);
}


var _previousFocus = null;
var _onAjaxLastStopSet = false;

function _createKeyShortcutsForOnclick(ancestorId, className, key) {
	var descendants = $(ancestorId).select('.'+className);
	var getElemToFocus = function(focus){
		if ($(focus) == null){
			if (focus.indexOf('fastforward') != -1){
				return focus.replace('fastforward', 'fastrewind');
			}
			if (focus.indexOf('fastrewind') != -1){				
				return focus.replace('fastrewind', 'fastforward');
			} 
			if (focus.indexOf('last') != -1) 
				return focus.replace('last', 'fastrewind');
			if (focus.indexOf('first') != -1) 
				return focus.replace('first', 'fastforward');
		}
		return focus;
	}
	
	if	(!_onAjaxLastStopSet){
		SyncAjaxStatus.onAjaxLastStop(function() {
			if (_previousFocus != null)
				$(getElemToFocus(_previousFocus)).focus();
		});
		_onAjaxLastStopSet = true;
	}
	
	descendants.each(
			function(descendant){
				descendant.observe("sync:click", descendant.onclick);
				shortcut.add(key, function(){
					_previousFocus = descendant.id;
					descendant.fire("sync:click");
				},
				{type:"keydown", target:descendant, propagate:false});
			}
	)
}


;(function($) {
//    
//    var focusElement;
//
//    function input_focus(id) {
//        try {
//            $j(id).focus();
//        } catch (e) {}
//        if (SyncAjaxStatus && SyncAjaxStatus.isAjaxRequestInProgress()) {
//            if (!SyncAjaxStatus.focusFun) {
//                SyncAjaxStatus.focusFun = function() {
//                    if (focusElement) {
//                        try {                       
//                            $(focusElement).focus();
//                        } catch (e) {}
//                        finally {
//                            focusElement = null;                        
//                        }
//                    }               
//                } 
//                SyncAjaxStatus.onAjaxStop(SyncAjaxStatus.focusFun);             
//            }
//            focusElement = id;
//        }   
//    };
    $(function() {
        // after document is loaded, focus the first element
        var $input = $(".input[data-sync-autofocus]:visible").first();
        if(!$input.length)
            return;
        var tabIndex = $input[0].attributes["tabIndex"];
        if(tabIndex === undefined || !tabIndex.specified) {
            $input = $input.find("input:visible:not(:disabled)").first();
        }
        $input.focus();
    });
})(jQuery);

function input_focus(id) {
    try {
        $j(id).focus();
    } catch (e) {}
};