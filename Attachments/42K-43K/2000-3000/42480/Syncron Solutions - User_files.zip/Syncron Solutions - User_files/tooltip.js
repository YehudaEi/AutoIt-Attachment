/**
 * Not so fancy tooltip handler.
 */
;(function($, richfaces) {
    var exports = window.Tooltips = {};
    var CONNECTOR_MARGIN = 8;
    var CONNECTOR_LENGTH = 8;
    var TOOLTIP_COUNTER = 0;
    var TOOLTIP_DEFAULTS = {
        delay: 400
    };
    
    function TooltipBinding(elementId, fromTooltip) {
        var $element = $(elementId);
        // add the data
        this.options = $.extend({}, TOOLTIP_DEFAULTS, $element.data("sync-tooltip"));
        $element.removeAttr("data-sync-tooltip");

        this._timer = null;
        this.generated = false;
        this.embeded = false;
        this.initialized = false;
        this.name = "SyncTooltip"; // for NonVisualComponent.{attach/detach}

        if(fromTooltip) {
            // elem points to tooltip
            this.options.tooltipId = $element.attr("id");
            this.$tooltip = $element;
            richfaces.BaseComponent.prototype.attachToDom.call(this, this.$tooltip);
            this.$related = $j(this.options.relatedTo);
        }
        else {
            // elem points to related 
            this.$related = $element;
            this.$tooltip = null; // tooltip element is generated or embeded
            this.embeded = !!(this.options.tooltipId);
        }
        if(this.$related && this.$related.length > 0) {
            this.$related.bind("mouseover.tooltip", $.proxy(this, "onMouseOver"));
            this.$related.bind("mouseout.tooltip",  $.proxy(this, "onMouseOut"));
            richfaces.BaseNonVisualComponent.prototype.attachToDom.call(this, this.$related);
        }
    };
    
    TooltipBinding.prototype = {
        detach: richfaces.BaseComponent.prototype.detach,
        destroy: function() {
            clearTimeout(this._timer);
            if(this.$related !== null) {
                this.$related.unbind(".tooltip");
                this.$related = null;
            }
            if(this.generated || this.embeded) {
                $j(this.options.tooltipId).remove();
                this.initialized = this.generated = false;
            };
            this.$tooltip = null;
        },
        onMouseOver: function onTooltipMouseOver(event) {
            var element = event.currentTarget;
            clearTimeout(this._timer);
            this._timer = setTimeout($.proxy(this, "show"), this.options.delay);
        },
        onMouseOut: function onTooltipMouseOut(event) {
            clearTimeout(this._timer);
            this.hide();
        },
        show: function showTooltip() {
            var $tooltip = this.ensureInitialized();
            if(this.options.text) {
                $tooltip.children('.tooltip-container').html(this.options.text.join("<br>"));
            }
            $tooltip.show();
            setTooltipPosition($tooltip, this.$related);
        },
        hide: function hideTooltip() {
            var $tooltip = $j(this.options.tooltipId);
            $tooltip.hide();
            if(this.generated) {
                $tooltip.remove();
                this.initialized = this.generated = false;
            }
        },
        ensureInitialized: function ensureTooltipInitialized() {
            if(this.initialized) {
                return $j(this.options.tooltipId);
            }
            if(!this.options.tooltipId) {
                // generate an id
                this.options.tooltipId = "__sync-tooltip-"+ (TOOLTIP_COUNTER++);
            }
            var $e = $j(this.options.tooltipId);
            if($e.length == 0) {
                $e = $("<div style='display: none'></div>");
                $e.attr("id", this.options.tooltipId);
                $e.appendTo(document.body);
                this.generated = true;
            }
            $e.addClass("tooltip");
            $e.addClass(this.options.styleClass);
            $e.removeAttr("data-sync-tooltip");
            if($e.children('.tooltip-container').length == 0) {
                $e.css('position', 'absolute')
                    .wrapInner("<div class='tooltip-container'></div>")
                    .append("<div class='tooltip-arrow'><div></div></div>");
            };
            this.initialized = true;
            return $e;
        }

     };

    /** Exported for testing. */
    exports._ensureTooltipInitialized = function(options) {
        return TooltipBinding.prototype.ensureInitialized.call({"options": options});
    }

    /**
     * Calculate tooltip position and dimensions.
     * 
     * The preferred direction of tooltip is east. If there is not enough
     * space, try other directions in this order: west, north, south.
     * 
     */
    function calcTooltipPosition($tooltip, $attachPoint, boundingElement) {
        var $bound = $(boundingElement), tgtbox, tipbox = {}, bbox; 
        tgtbox = $attachPoint.offset();
        tgtbox.w = $attachPoint.outerWidth();
        tgtbox.h = $attachPoint.outerHeight();

        bbox = $bound.offset() || {top: 0, left: 0};
        bbox.w = $bound.width();
        bbox.h = $bound.height();

        //
        var tipMaxWidth = $tooltip.outerWidth() + CONNECTOR_MARGIN;

        // calculate expected width
        var eastwidth = (bbox.left + bbox.w) - (tgtbox.w + tgtbox.left);
        
        if(tipMaxWidth < eastwidth) {
            tipbox.side = "east";
            tipbox.top = tgtbox.top;
            tipbox.left = tgtbox.left + tgtbox.w + CONNECTOR_MARGIN;
            tipbox.w = eastwidth;
            tipbox.h = "auto";
            tipbox.connector = {
                top: 3,
                left: -CONNECTOR_MARGIN-1
            };
            return tipbox; 
        }
        
        // it won't fit east, try west
        var westwidth = (tgtbox.left - bbox.left);
        if(tipMaxWidth < westwidth) {
            tipbox.side = "west";
            tipbox.top = tgtbox.top;
            tipbox.left = tgtbox.left - tipMaxWidth;
            tipbox.w = westwidth - CONNECTOR_MARGIN;
            tipbox.h = "auto";
            tipbox.connector = {
                top: 3,
                right: -CONNECTOR_MARGIN-1
            };
            return tipbox;
        }

        $tooltip.css("max-width", (bbox.w * 0.8) + "px");
        // now that we fixed the width, we can calc the height
        var tipWidth = $tooltip.outerWidth();
        var tipMaxHeight = $tooltip.outerHeight() + CONNECTOR_MARGIN;
        
        var northHeight = (tgtbox.top - bbox.top);
        
        if(northHeight > tipMaxHeight) {
            tipbox.side = "north";
            tipbox.top = tgtbox.top - tipMaxHeight;
            tipbox.left = Math.min(Math.max(0, tgtbox.left + (tgtbox.w / 2) - tipWidth/2), bbox.left + bbox.w - tipWidth);
            tipbox.w = tipWidth;
            tipbox.h = "auto";
            tipbox.connector = {
                bottom: -CONNECTOR_MARGIN-1,
                left: ((tgtbox.left - tipbox.left) + tgtbox.w/2 - CONNECTOR_LENGTH/2)
            };
            return tipbox;
        }
        
        tipbox.side = "south";
        tipbox.top = tgtbox.top + tgtbox.h + CONNECTOR_MARGIN;
        tipbox.left = tgtbox.left + (tgtbox.w / 2) - tipWidth/2;
        tipbox.w = tipWidth;
        tipbox.h = "auto";
        tipbox.connector = {
            top: -CONNECTOR_MARGIN-1,
            left: ((tgtbox.left - tipbox.left) + tgtbox.w/2 - CONNECTOR_LENGTH/2)
        };
        return tipbox;
    };
    
    /**
     * Given tooltip element and an attach point, position the tooltip.
     * 
     */
    var setTooltipPosition = exports.fitTooltip = function setTooltipPosition($tooltip, $attachPoint, boundingElement) {
        boundingElement = boundingElement || window;
        // reattach to body
        $tooltip.detach().appendTo(document.body);
        
        var box = calcTooltipPosition($tooltip, $attachPoint, boundingElement);
        var bodyOffset = $(document.body).position();
        $tooltip.css({
            left: box.left - bodyOffset.left,
            top: box.top - bodyOffset.top,
            "max-width": box.w,
            "max-height": box.h,
            position: "absolute"
        });
        $tooltip.children('.tooltip-arrow').css(box.connector);

        $tooltip.removeClass("tooltip-east tooltip-west tooltip-north tooltip-south")
        $tooltip.addClass("tooltip-" + box.side);
    };

    $(document).delegate("*[data-sync-tooltip]", "mouseover", function lazyBind(event) {
        var binding = new TooltipBinding(event.currentTarget);
        binding.onMouseOver(event);
    });

    exports.init_tooltip = function initTooltipElement(elemId) {
        $(document).ready(function() { new TooltipBinding($j(elemId), true); });
    };

})(jQuery, window.RichFaces);