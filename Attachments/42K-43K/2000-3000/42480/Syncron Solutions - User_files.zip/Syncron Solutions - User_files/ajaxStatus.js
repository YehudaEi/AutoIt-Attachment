var SyncAjaxStatusClass = Class.create({
		
		init: function(params) {
			this.statusId = '_ajaxStatusEventConnector';
			this.ajaxStartEvent = 'sync:ajaxStart';
			this.ajaxStopEvent = 'sync:ajaxStop';
			this.ajaxRequests = 0;
		},
		
		fireStartAjax: function() {
			++this.ajaxRequests;
			this.getStatus().trigger(this.ajaxStartEvent);
		},
		
		fireStopAjax: function() {
			--this.ajaxRequests;
			this.getStatus().trigger(this.ajaxStopEvent);
		},
		
		onAjaxEvent: function(eventName,fun) {
			this.getStatus().bind(eventName,fun);
		},
		
		onAjaxStart: function(fun) {
			this.onAjaxEvent(this.ajaxStartEvent, fun);
		},
		
		onAjaxStop: function(fun) {
			this.onAjaxEvent(this.ajaxStopEvent, fun);
		},
		
		onAjaxFirstStart: function(fun) {
			this.onAjaxEvent(this.ajaxStartEvent, jQuery.proxy(function() {
				if (this.ajaxRequests == 1) {
					fun();
				}
			}, this));
		},
		
		onAjaxLastStop: function(fun) {
			this.onAjaxEvent(this.ajaxStopEvent, jQuery.proxy(function() {
				if (this.ajaxRequests == 0) {
					fun();
				}
			}, this));
		},
		
		isAjaxRequestInProgress: function() {
			return this.ajaxRequests > 0;
		},
		
		getStatus: function() {
			var currentWindow = window;
			var status = null;
			while (currentWindow && !status) {
				status = currentWindow.document.getElementById(this.statusId);
				if (!status && currentWindow.parent) {
					currentWindow = currentWindow.parent;
				}
			}
			return status ? $(status) : null;
		}
	});
	
	var SyncAjaxStatus = new SyncAjaxStatusClass();