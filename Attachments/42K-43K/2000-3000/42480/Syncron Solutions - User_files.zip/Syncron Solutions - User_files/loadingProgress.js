function soonShowLoadingProgress() {
	showLoadingProgressWithDelay(100);
}

function showLoadingProgressWithDelay(delay) {
	delay = delay || 1000;
	var progressElement = document.getElementById('loadingProgress');
	$(progressElement).show();
	
	if (progressElement.timeout == null) {
		progressElement.timeout = window.setTimeout('showProgress()', delay);
	}	
}

function showProgress() {
	var progressElement = document.getElementById('loadingProgress');
	if (progressElement.timeout != null) {
		var lp = document.getElementById('tohide'); 
		var off = (228 + $(document.body).scrollTop()) + 'px';
		lp.style.top = off;
		
		$(lp).fadeIn(600);
	}
	progressElement.timeout = null;
}

function hideLoadingProgress() {
	var progressElement = document.getElementById('loadingProgress');
	
	if (progressElement.timeout != null) {
		window.clearTimeout(progressElement.timeout);
		progressElement.timeout = null;
	}
	
	$(progressElement).hide();
	$('#tohide').fadeOut(600);
}

function observeAjaxCallsForLoadingProgress (delay) {
	$(function() {
		SyncAjaxStatus.onAjaxFirstStart(function() {
			showLoadingProgressWithDelay(delay);
		});
		
		SyncAjaxStatus.onAjaxLastStop(function() {
			hideLoadingProgress();
		});
	});
}	