function switchSearchButtons(searchButtonId, advSearchButtonId, open, parentControl) {
		
	if (parentControl && parentControl.style.display == 'none') {
		return;
	}
	
	if(open) {
	    $j(searchButtonId).closest(".btn-wrapper").hide();
	    $j(advSearchButtonId).closest(".btn-wrapper").show();
	}
	else {
	    $j(searchButtonId).closest(".btn-wrapper").show();
	    $j(advSearchButtonId).closest(".btn-wrapper").hide();
	}
};