/* Configurable Action */

window.Syncron = jQuery.extend(window.Syncron, {'Component': {}})
window.Syncron.Component.ConfigurableAction = (function() {
	
	return {
		open: function (clientId, modalDivCId, closePanelAjaxCallback) {
			closePanelAjaxCallback = closePanelAjaxCallback || function() {}
			$j(modalDivCId).fadeIn()
			
			var clickCallback = function(e) {
				var modal = $j(modalDivCId)
				  , button = $j(clientId)

				if (modal.length != 0) {
					// Modal still exists
					if (modal.has(e.target).length === 0 && button.has(e.target).length === 0) {
						// Click is outside
						modal.hide();
						closePanelAjaxCallback()
					}
				} else {
					// Modal no longer exists, let's remove the event handler
					$(document).unbind('mouseup', clickCallback)
				}
			}
			
			$(document).bind('mouseup', clickCallback)
		}
	}
})()
