var DualList = Class.create({
	LEFTLISTCSSCLASS: 'duallist-available',
	RIGHTLISTCSSCLASS: 'duallist-selected',
	MIDDLEPANECSSCLASS: 'duallist-buttons',
	uniqueID: 0,

	updateInput: function() {
		var self = this;
		var res = this.$rightPaneList.children('li').map(function() { return $(this).attr("data-item-value"); });
		this.hiddenInput.value = res.get().join(',');
	},
	
	selectionChanged: function(se,pane) {
		var $se = $(se);
		if (pane == 'right') {
			this.updateInput();	
			if (this.moveDownElementButton){
				this.moveDownElementButton.syncSetEnabled(se && $se.next().length);
			}
			if (this.moveUpElementButton){
				this.moveUpElementButton.syncSetEnabled(se && $se.prev().length);
			}
		}
	},
	
	valueChanged: function(event) {
		if (this.onchange) {
			this.onchange(event);
		}
	},

	selectElement: function(se,pane) {
		pane = pane || 'left';
		if (this.selectedPaneElement[pane]) {
			$(this.selectedPaneElement[pane]).removeClass('selected');
		}
		$(se).addClass('selected');
		this.selectedPaneElement[pane] = se;
		this[(pane == 'left' ? 'add' : 'delete')+'ElementButton'].syncSetEnabled(true);
		this.selectionChanged(se,pane);
	},

	deselectElement: function(se,pane) {
		pane = pane || 'left';
		var $se = $(se);
		$se.removeClass('selected');
		var newSelected = $se.next()[0] || $se.prev()[0];
		if (newSelected) $(newSelected).addClass('selected');
		this.selectedPaneElement[pane] = newSelected;
		if (!newSelected) {
			this[(pane == 'left' ? 'add' : 'delete')+'ElementButton'].syncSetEnabled(false);
		}
		$se.detach();
		this.selectionChanged(newSelected,pane);
	},
	
	paneElementClick: function(event,pane) {
		var listElem = $(event.target).closest('li');
		if (listElem.length) {
			this.selectElement(listElem[0],pane);
		}
	},

	moveFromLeftToRight: function(event) {
		var se = this.selectedPaneElement.left;
		if (se) {
			var $se = $(se);
			if (this.options.standardMode) {
				this.deselectElement(se,'left');
				$se.unbind('click');
			} else {
				var cloneSe = $se.clone(false);
				cloneSe[0].id = se.id+'@'+(this.uniqueID++);
				se = cloneSe;
			}			
			this.$rightPaneList.append(se);
			var self = this;
			$se.bind('click',function(ev) {
				self.paneElementClick(ev,se,'right');
			});
			this.selectElement(se,'right');
			this.valueChanged(event);
		}
		event.stopPropagation();
	},

	moveFromRightToLeft: function(event) {
		var se = this.selectedPaneElement.right;
		if (se) {
			var $se = $(se);
			this.deselectElement(se,'right');
			if (this.options.standardMode) {
				$se.unbind('click');
				var self = this;
				$se.bind('click',function(ev) {
					self.paneElementClick(ev,se,'left');
				});
				this.$leftPaneList.append(se);
				this.selectElement(se,'left');
				this.valueChanged(event);
			}
		}
		event.stopPropagation();
	},
	
	moveUpButtonClick: function(event) {
		this.moveButtonClick(event, 'up');
	},
	
	moveDownButtonClick: function(event) {
		this.moveButtonClick(event, 'down');
	},

	moveButtonClick: function(event,direction) {
		var se = this.selectedPaneElement.right;
		if (se) {
			var $se = $(se);
			var succ;
			if (direction == 'up') {
				succ = $se.prev();
				if (succ.length) {
					$se.insertBefore(succ);
				};
			};
			if (direction == 'down') {
				succ = $se.next();
				if (succ.length) {
					$se.insertAfter(succ);
				};
			};
			this.selectionChanged(se,'right');
			this.valueChanged(event);
		}
		event.stopPropagation();
	},

	//constructor
	init: function(dualListID,extraParams) 
	{
	    var $input = $j(dualListID);
		this.options = $.extend({
		    standardMode: true
		}, extraParams);

		this.hiddenInput = $input[0];
		
		var $wrapper = $input.closest(".input");

		this.$leftPaneList = $wrapper.find('.'+this.LEFTLISTCSSCLASS+" > ul");
		this.$rightPaneList = $wrapper.find('.'+this.RIGHTLISTCSSCLASS + " > ul");
		this.$middlePane = $wrapper.find('.'+this.MIDDLEPANECSSCLASS);

		this.addElementButton = this.$middlePane.find('.add_button');
		this.deleteElementButton = this.$middlePane.find('.delete_button');
		this.moveUpElementButton = this.$middlePane.find('.moveup_button');
		this.moveDownElementButton = this.$middlePane.find('.movedown_button');
		this.selectedPaneElement = {};

		if (extraParams.onchange) {
			this.onchange = new Function("event", extraParams.onchange);
		}

		var thisObj = this;

		this.$leftPaneList.bindProxy('click', function(event) {
			this.paneElementClick(event, 'left');
		}, this);
		
		this.$rightPaneList.bindProxy('click', function(event) {
			this.paneElementClick(event, 'right');
		}, this);

		$(this.addElementButton).bindProxy('click',this.moveFromLeftToRight, this);
		$(this.deleteElementButton).bindProxy('click',this.moveFromRightToLeft, this);
		if (this.moveUpElementButton != null) {
			$(this.moveUpElementButton).bindProxy('click',this.moveUpButtonClick, this);
		}
		if (this.moveDownElementButton != null) {
			$(this.moveDownElementButton).bindProxy('click',this.moveDownButtonClick, this);
		}
		this.updateInput();		
	}
});
