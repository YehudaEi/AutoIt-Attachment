var OpenPopupRegister = [];

PopupRegister = {
		
	indexOf: function(id) {
		for (var i=0; i<OpenPopupRegister.length; ++i) {
			if (OpenPopupRegister[i].id == id) {
				return i;
			}
		}
		return -1;
	},
		
	register: function(id, focusId) {
		if (PopupRegister.indexOf(id) < 0) {
			OpenPopupRegister.push({id: id, focusId: focusId});
		}
		PopupRegister.focusOn(focusId);
	},
	
	focusOn: function(id) {
		if (id) {
			var el = document.getElementById(id);
			if (el) {
				el.focus();
			}
		}
	},
	
	unregister: function(id, skipFocus, skipChildren) {
		var index = PopupRegister.indexOf(id);
		if (index >= 0) {
			OpenPopupRegister.splice(index, 1);
			if (!skipFocus && index > 0) {
				PopupRegister.focusOn(OpenPopupRegister[index - 1].focusId);
			}
		}

		if (!skipChildren) {
			var childPopups = PopupRegister.getOpenPopupsUnder(id);
			if (childPopups) {
				for (var i=0; i<childPopups.length; ++i) {
					var childPopup = $d(childPopups[i]);
					if (childPopup.closeDown) {
						childPopup.closeDown(null, true, true);
					}
				}
			}
		}
	},
	
	getOpenPopupsUnder: function(id) {
		var ret = [];
		var el = document.getElementById(id);
		for (var i=0; i<OpenPopupRegister.length; ++i) {
			if (SyncUtils.isAncestor(OpenPopupRegister[i].id, el)) {
				ret.push(OpenPopupRegister[i].id);
			}
		}
		return ret;
	}
}

