;(function($) {
	var active_button = null;
	$.fn.syncSetEnabled = function(state) {
		return (this[!state ? "addClass" : "removeClass"]).call(this, "disabled");
	};
	$(document).delegate('a.btn', 'mousedown', function(event) {
		var btn = event.currentTarget;
		if(active_button !== null) {
			$(active_button).removeClass("activated");
			active_button = null;
		}
		if(!$(btn).hasClass("disabled")) {
			$(btn).addClass("activated");
			active_button = this;
		}
		else {
		    return false;
		}
	});

	$(document).delegate('a.btn.disabled', 'click', function(event) {
	    event.preventDefault();
	});

	$(document).bind('mouseup', function(event) {
		if(active_button !== null) {
			$(active_button).removeClass("activated");
			active_button = null;
		}
	});
	/* IE likes to drag elements. */
	$(document).delegate('a.btn', 'dragstart', function(event) {
		$(active_button).removeClass("activated");
		active_button = null;
	});
})(jQuery);