var SyncSpinner = Class.create({

	//default values of options
	cycled:				true,
	enableManualInput:	true,
	disabled:			false,
	required:			false,
	clientErrorMessage:	null,
	min:				0,
	max:				100,
	step:				1,
	onupclick:			null,
	ondownclick:		null,
	onerror:			null,

	init: function(options) {
	    this.$input = $j(options.id);
	    this.content = this.$input.get(0);
	    this.$spinner = this.$input.closest(".input");

		$.extend(this, options);
		if (!this.disabled){
			this.buttonUp = null;
			this.buttonDown = null;
		}
		this.min = Number(this.minValue);
		this.max = Number(this.maxValue);
		
		this.error	= $.proxy(new Function("event","clientErrorMessage",this.onerror + ";return true;"), this.$input.get(0));

		this.attachControls();
		this._load();
		
		if (this.onchange) {
		    var fn = $.proxy(new Function("event", this.onchange + "; return true;"), this.$input[0]);
		    this.$input.bind("change", fn);
			this.controls.onchangeFunction = fn;
		}
	},

	switchItems: function( e ) {
		var editValue = this.content.value;
		if (e === 'up'){
			if (!editValue || "" == editValue) {
				this.content.value = this.min;
			} else {
				editValue -= this.step*-1;
				editValue = this.roundFloat(editValue);
				if ( editValue <= this.max && editValue >= this.min){
					this.content.value = editValue;
				} else {
					if (this.cycled){
						if (this.step>0){
							this.content.value = this.min;
						} else {
							this.content.value = this.max;
						}
					} else {
						this.content.value = this.max;
						return true;
					}
				}
			}
		} else {
			if ("" == editValue) {
				this.content.value = this.max;
			} else {
				editValue -= this.step;
				editValue = this.roundFloat(editValue);
				if (editValue >= this.min && editValue <= this.max){
					this.content.value = editValue;
				} else {
					if (this.cycled){
						if (this.step<0){
							this.content.value = this.min;
						} else {
							this.content.value = this.max;
						}
					} else {
						this.content.value = this.min;
						return true;
					}
				}
			}
		}
		return false;
	},

	roundFloat: function(x){
		var str = this.step.toString();
		var power = 0;
		if (!/\./.test(str)) {
			if (this.step >= 1) {
				return x;
			}
			if (/e/.test(str)) {
				power = str.split("-")[1];
			}
		} else {
			power = str.length - str.indexOf(".") - 1;
		}
		var ret = x.toFixed(power);
		return ret;
	},

	_load: function(){
		this.content.readOnly = this.enableManualInput ? "" : "readOnly";
		if (this.disabled) {
			this.content.readOnly = "readOnly";
			$(this.content).css({color: "gray"});
		} else {
			$(this.content).css({color: ""});
		}
	},

	attachControls: function(){
		var buttonUpDiv = this.$spinner.find(".sync-spinner-up");
		var buttonDownDiv = this.$spinner.find(".sync-spinner-down");
		this.controls = new SyncSpinner.Controls( this, buttonUpDiv, buttonDownDiv, this.content);
	}
});

SyncSpinner.Controls = Class.create({

	init: function( spinner, $up, $down, edit) {
		this.spinner= spinner;
		this.up = $up;
		this.down = $down;
		
		this.mousedown = false;
		this.onUpButton = false;
		this.onDownButton = false;
		
		this.edit = edit;
		this.originalColor = edit.style.color;
		this.prevEditValue = this.edit.value;
		this.edit.value = this.prevEditValue;
		this.previousMU = window.document.onmouseup;
		this.previousMM = window.document.onmousemove;
		if (!spinner.disabled){
			this.attachBehaviors();
			this.edit.style.color = this.originalColor;
		}
	},

	buttonMouseDown: function(e, direction) {
	   	if (e.preventDefault) {
	   		e.preventDefault();
	    }
		var isError = this.spinner.switchItems(direction);
		if(!isError){
			$(document).mouseup($.proxy(this.mouseUp));
			this.mousedown = true;
			this.timer = setTimeout($.proxy(
					function() {
						this.continueClick(direction)
					}, this), 750);
		}
	},
	
	continueClick: function(direction) {
		if (!this.mousedown) return;
		$(document).mousemove($.proxy(this.mouseMove, this));
		this.spinner.switchItems(direction);
		if (this.timer) {
			clearTimeout(this.timer);
		}
		this.timer = setTimeout($.proxy(
				function() {
					this.continueClick(direction)
				}, this), 100);
	},

	mouseUp: function(e){	    
		clearTimeout(this.timer);
		if (this.mousedown) {
			this.mousedown=false;
			this.fireEditEvent("change");
		}
	},

	mouseMove: function(e){
	   	if (e.preventDefault) {
	   		e.preventDefault();
	    }		    
		$(document).mousemove(this.previousMM);
		clearTimeout(this.timer);
		this.mousedown=false;
		this.fireEditEvent("change");
	},	

	handleBlurEvent: function(e)
	{
		if (isNaN(Number(this.edit.value))){
			this.edit.value = this.prevEditValue;
		} else if ("" != this.edit.value) {
			if (Number(this.edit.value) > this.spinner.max){
				this.edit.value = this.spinner.max;
			} else if (Number(this.edit.value) < this.spinner.min) {
				this.edit.value = this.spinner.min;
			}
		}
		if ("" != this.edit.value)
			this.prevEditValue = this.edit.value;		
		if (this.onchangeFunction)
			this.onchangeFunction();

	},

	editChange: function(e) {
		if ((this.edit.value < this.spinner.max) && (this.edit.value > this.spinner.min) && !isNaN(Number(this.edit.value)) && this.edit.value != ""){	
			this.prevEditValue = this.edit.value;
		}
		
        switch (e.keyCode) {
	        case Event.KEY_UP:
	        	this.spinner.switchItems('up');
	            return;
	        case Event.KEY_DOWN:
	        	this.spinner.switchItems('down');
	            return;
	        case Event.KEY_RETURN:
	        	if ("" != this.edit.value)
					this.edit.value = this.getValidValue(this.edit.value);
	        	break;
        }
	},
	
	getValidValue : function(value){
		if (isNaN(value) || value == "")
			return this.prevEditValue;
		if ( value > this.spinner.max)
			return this.spinner.max;
		if (value < this.spinner.min)
			return this.spinner.min;
		return value;
	},

	attachBehaviors: function() {
		this.up.mousedown($.proxy(function(event) { this.buttonMouseDown(event, 'up'); }, this));
		this.down.mousedown($.proxy(function(event) {this.buttonMouseDown(event, 'down'); }, this));
		this.up.mouseup($.proxy(this.mouseUp, this));
		this.down.mouseup($.proxy(this.mouseUp, this));
		$(this.edit).keydown($.proxy(this.editChange, this));
		$(this.edit).change($.proxy(this.handleBlurEvent, this));
		$(this.edit).blur($.proxy(this.handleBlurEvent, this));
	},
	
	fireEditEvent: function(e){
		$(this.edit).focus();
		if( document.createEvent ) {
			var evObj = document.createEvent('HTMLEvents');
			evObj.initEvent( e, true, false );
			this.edit.dispatchEvent(evObj);
		} else if( document.createEventObject ) {
			this.edit.fireEvent('on' + e);
		}
	}
});