var Popup = Class.create({

	shadowWidth: 8,

	init: function(anchorId, popupId, width, extra_params) {
		this.width = width;
		var params = extra_params || {};
		this.xoffset = params.xoffset || 0;
		this.yoffset = params.yoffset || 6;
		this.isDraggable = params.isDraggable || false;
		this.anchorObj = $d(anchorId);
		
		this.$anchorObj = $(this.anchorObj);
		//necessary for tests, WF-3531
		this.$anchorObj.attr('opensPopup', true);
		this.popupObj = $d(popupId);
		this.popupObj.popup = this;
		this.$popupObj = $(this.popupObj);
		this.$popupObj.css({width: width+'px'});
		this.explicitClose = params.explicitClose || false;
		this.$anchorObj.bindProxy('click', this.openUp, this);
		this.isOpen = false;
		/// We have to bind the closeDown method directly to the DOM element in order to simplify the implementation of the click event interceptor
		this.popupObj.closeDown = $.proxy(this.closeDown, this);
		this.popupObj.openUp = $.proxy(this.openUp, this);
		this.popupObj.anchorObj = this.anchorObj;
		this.popupObj.explicitClose = this.explicitClose;
		this.popupObj.implicityClose = params.implicityClose;
												
		if (this.isDraggable) {
			this.$popupObj.draggable({handle: $j(extra_params.dragHandleId)});
		}
		
		if (extra_params.showRendered) {
			this.openUp();
		}
	},

	openUp: function(e) {
		if (this.popupObj.isClosedByGlobalEvent == undefined) {
			var el = this.popupObj; 
			var isClosedByGlobalEvent = false;
			if (!el.implicityClosed) {
				var hasParentImplicitlyClosed = false; 
				while(el.$anchorObj && (el = el.$anchorObj.closest('div.popup'))) {
					if (!el.explicitClose) {
						hasParentImplicitlyClosed = true;
						break;
					}
				}
				isClosedByGlobalEvent = hasParentImplicitlyClosed || (!this.explicitClose);
			}
			this.popupObj.isClosedByGlobalEvent = isClosedByGlobalEvent;
		}
		if (this.isOpen == false) {
			var popup = this.$popupObj, popup_elem = popup[0];
			this.calculatePosition();
			popup.css({left: this.xpos+'px', top: this.ypos+'px'})

			// fadeIn after yielding
			setTimeout(function() {
				// notify CSS3PIE that the element has moved
				if(window.PIE && popup_elem.fireEvent) { 
					popup.css({display: 'block', visibility: 'hidden'});
					popup_elem.fireEvent("onmove");
					popup.css({visibility: ''});
				};
				popup.fadeIn(300);
			}, 4);
			this.isOpen = true;
		};
		
		PopupRegister.register(this.popupObj.id, this.popupObj.id);
		/// we will not allow this event to propagate any further
		if (e) e.stopPropagation();
	},

	closeDown: function(e, skipFocus, skipChildren) {
		if (this.isOpen) {
			var popup = this.$popupObj;
			popup.fadeOut(300, function() { 
				popup.hide();
			});
			this.isOpen = false;
			
			PopupRegister.unregister(this.popupObj.id, skipFocus, skipChildren);
		}
		if (e) e.stopPropagation();
	},

	calculateOffsetParent: function(element) {
		if (element === document.body)
			return $(element);
		
		while ((element = element.parentNode) && element != document.body) {
			if ($(element).css('position') !== 'static' && !this.firefoxTable(element))
				return $(element);
		}
		return $(document.body);
	},

	firefoxTable: function(element) {
		return $.browser.mozilla && element.tagName.toUpperCase() == 'TABLE';
	},

	calculatePosition: function() {
		var opaParent = this.calculateOffsetParent(this.anchorObj);
		var oppParent = this.calculateOffsetParent(this.popupObj);
		var opaAbsPos = opaParent.offset();
		var oppAbsPos = oppParent.offset();

		var relPos = this.$anchorObj.position();
		var absPos = this.$anchorObj.offset();

		this.xpos = relPos.left + opaAbsPos.left - oppAbsPos.left;
		this.ypos = relPos.top + opaAbsPos.top - oppAbsPos.top + this.yoffset;
		/// the following code makes neccessary adjustments if there is not enough space to display popup on the right of the anchor element
		var viewportWidth = $(window).width();
		var xmultiplier = 1;
		if (((viewportWidth-absPos.left) < this.width) && (absPos.left > (this.width+this.shadowWidth))) {
			/// we can try to shift the window to the left by width
			this.xpos -= (this.width+this.shadowWidth);
			xmultiplier = -1;
		};
		this.xpos += xmultiplier*this.xoffset;
	}
});

$(function() {

	$(document).bind('click' , function(e) { 
		var popups = {};

		$('div.popup').each(function() { popups[this.id] = this; });
		var el = $(e.target).closest('div.popup').get(0);

		if (el) {
			do {
				delete popups[el.id];
			} while(el = el.popup.$anchorObj.closest('div.popup').get(0));
		}

		$.each(popups, function(key, value) {
			if (value.isClosedByGlobalEvent) value.closeDown(null, true, false);
		});
	});
});