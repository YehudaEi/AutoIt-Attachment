﻿Imports System

Imports System.Collections.Generic
Imports System.ComponentModel
Imports System.Data
Imports System.Drawing
Imports System.Text
Imports System.Windows.Forms

Imports Tekla.Structures.Datatype
Imports Tekla.Structures.Dialog

Partial Public Class Form1
    Inherits Tekla.Structures.Dialog.PluginFormBase

    Private Sub btnOK_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnOK.Click
        Apply()
        Close()
    End Sub

    Private Sub btnModify_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnModify.Click
        Modify()
    End Sub

End Class
