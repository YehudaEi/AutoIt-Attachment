﻿
<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits Tekla.Structures.Dialog.PluginFormBase

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.btnOK = New System.Windows.Forms.Button
        Me.TextBox1 = New System.Windows.Forms.TextBox
        Me.Label1 = New System.Windows.Forms.Label
        Me.btnModify = New System.Windows.Forms.Button
        Me.SuspendLayout()
        '
        'btnOK
        '
        Me.structuresExtender.SetAttributeName(Me.btnOK, Nothing)
        Me.structuresExtender.SetAttributeTypeName(Me.btnOK, Nothing)
        Me.structuresExtender.SetBindPropertyName(Me.btnOK, Nothing)
        Me.btnOK.Location = New System.Drawing.Point(15, 129)
        Me.btnOK.Name = "btnOK"
        Me.btnOK.Size = New System.Drawing.Size(75, 23)
        Me.btnOK.TabIndex = 0
        Me.btnOK.Text = "OK"
        Me.btnOK.UseVisualStyleBackColor = True
        '
        'TextBox1
        '
        Me.structuresExtender.SetAttributeName(Me.TextBox1, "Height")
        Me.structuresExtender.SetAttributeTypeName(Me.TextBox1, "Distance")
        Me.structuresExtender.SetBindPropertyName(Me.TextBox1, Nothing)
        Me.TextBox1.Location = New System.Drawing.Point(147, 42)
        Me.TextBox1.Name = "TextBox1"
        Me.TextBox1.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.TextBox1.Size = New System.Drawing.Size(100, 20)
        Me.TextBox1.TabIndex = 1
        '
        'Label1
        '
        Me.structuresExtender.SetAttributeName(Me.Label1, Nothing)
        Me.structuresExtender.SetAttributeTypeName(Me.Label1, Nothing)
        Me.Label1.AutoSize = True
        Me.structuresExtender.SetBindPropertyName(Me.Label1, Nothing)
        Me.Label1.Location = New System.Drawing.Point(12, 45)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(74, 13)
        Me.Label1.TabIndex = 2
        Me.Label1.Text = "Column height"
        '
        'btnModify
        '
        Me.structuresExtender.SetAttributeName(Me.btnModify, Nothing)
        Me.structuresExtender.SetAttributeTypeName(Me.btnModify, Nothing)
        Me.structuresExtender.SetBindPropertyName(Me.btnModify, Nothing)
        Me.btnModify.Location = New System.Drawing.Point(96, 129)
        Me.btnModify.Name = "btnModify"
        Me.btnModify.Size = New System.Drawing.Size(75, 23)
        Me.btnModify.TabIndex = 0
        Me.btnModify.Text = "Modify"
        Me.btnModify.UseVisualStyleBackColor = True
        '
        'Form1
        '
        Me.structuresExtender.SetAttributeName(Me, Nothing)
        Me.structuresExtender.SetAttributeTypeName(Me, Nothing)
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.structuresExtender.SetBindPropertyName(Me, Nothing)
        Me.ClientSize = New System.Drawing.Size(334, 164)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.TextBox1)
        Me.Controls.Add(Me.btnModify)
        Me.Controls.Add(Me.btnOK)
        Me.Name = "Form1"
        Me.Text = "Windows Form plug-in using VB.NET"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents btnOK As System.Windows.Forms.Button
    Friend WithEvents TextBox1 As System.Windows.Forms.TextBox
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents btnModify As System.Windows.Forms.Button
End Class
