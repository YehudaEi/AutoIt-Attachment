﻿Imports System
Imports System.Windows.Forms
Imports System.Collections.Generic
Imports System.Text

Imports TS = Tekla.Structures
Imports TSG3D = Tekla.Structures.Geometry3d
Imports TSModel = Tekla.Structures.Model
Imports TSPlugins = Tekla.Structures.Plugins

Namespace VBPlugin

    Public Class StructuresData
        <TSPlugins.StructuresField("Height")> _
        Public height As Double
    End Class

    'Navn i listen (VBPlugin)
    <TSPlugins.Plugin("VBPlugin")> _
    <TSPlugins.PluginUserInterface("VBPlugin.Form1")> _
    <TSPlugins.SecondaryType(TSPlugins.ConnectionBase.SecondaryType.SECONDARYTYPE_ONE)> _
    <TSPlugins.AutoDirectionType(TS.AutoDirectionTypeEnum.AUTODIR_BASIC)> _
    <TSPlugins.PositionType(TS.PositionTypeEnum.MIDDLE_PLANE)> _
    Public Class VBPlugin
        Inherits TSPlugins.ConnectionBase

        Private ReadOnly _model As TSModel.Model

        Private ReadOnly _data As StructuresData


        Public Sub New(ByVal data As StructuresData)

            ' Link to model.
            _model = New TSModel.Model(True)

            ' Link to input values.
            _data = data

            'CreateObjRef(

            Run()

        End Sub

        Public Overrides Function Run() As Boolean
            Try

                Dim PrimaryBeam As Tekla.Structures.Model.Beam
                Dim SecBeam As Tekla.Structures.Model.Beam

                PrimaryBeam = _model.SelectModelObject(Primary)

                SecBeam = _model.SelectModelObject(Secondaries(0))

                If Not PrimaryBeam Is Nothing And Not SecBeam Is Nothing Then

                    'More...

                End If

            Catch e As Exception
                MessageBox.Show(e.ToString())
            End Try

            Return True
        End Function
    End Class

End Namespace
