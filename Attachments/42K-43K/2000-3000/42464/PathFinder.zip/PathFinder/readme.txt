Warning: This script make changes to your registry!!! Make a Backup before using!
          
Name: PathFinder
Does: Gets Absolute Path & Relative path of a file via Context Menu
Installation:
1. Copy the "PathFinder" folder to your Program Files Folder or wherever you like.
2. From there >Run RegWrite.exe to update the link in your context menu.
3. Finished
Usage: Now you can Right Click on any File and choose "PathFinder" to get and
           copy the Absolute or Relative path of the file

Uninstall: To remove the changes made to the registry just run RegDelete.
