Alexi requires an additional UDF library to work. It can be obtained here: http://autoitobject.origo.ethz.ch/

Documentation for Alexi is in the help file.