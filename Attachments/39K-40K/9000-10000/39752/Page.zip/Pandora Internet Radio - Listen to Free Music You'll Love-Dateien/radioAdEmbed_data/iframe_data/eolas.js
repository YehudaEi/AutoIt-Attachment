
// eolas.js - workaround for Eolas

if( plugin ) {
 d.write('<OBJECT ID="'+qID+'"');
 d.write(' DATA='+flash_name+qType+qWidth+qHeight);
 d.write('> <PARAM NAME="movie" VALUE='+flash_name+qFlashVars+qWmode);
 d.write('> <PARAM NAME="quality" VALUE="autohigh"');
 d.write('> <PARAM NAME="allowScriptAccess" VALUE="always"');
 d.write('> </OBJECT>');
}
else {
 d.write(qA+qImg);
}

