var te_tags = {
    plid: 0,
    crid: 0,
    cpid: 0,
    domain: '',

    Run: function () {
        te_tags.RenderTag('script', te_tags.domain + 'xl/PROD/TrackingTags/fetch.cp?cache=no-cache&default=default_pl_cr.js&file=/' + te_tags.cpid + '/PlacementTags/' + te_tags.plid + '.js');
    },

    RenderTag: function (type, tagsrc) {

        var TagToRender;
        var bodytag = document.getElementsByTagName('body')[0] || document.body;

        switch (type) {
            case "iframe":
                TagToRender = document.createElement('iframe');
                TagToRender.src = tagsrc;

                break;
            case "script":
                TagToRender = document.createElement('script');
                TagToRender.src = tagsrc;

                break;
            case "image":
                TagToRender = document.createElement('img');
                TagToRender.src = tagsrc;

                break;
        }

        bodytag.appendChild(TagToRender);
    }
};