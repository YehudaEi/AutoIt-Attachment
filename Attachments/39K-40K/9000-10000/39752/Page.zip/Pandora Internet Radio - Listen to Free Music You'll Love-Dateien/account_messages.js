
var ACCOUNT_MESSAGES = [
	{
		name : "mobile.valentine2013",
		message : "Listen to our Valentine's Day Stations",
		action : function() {
			Stage.launchGenrePanel({'genreName':"valentine's"}, null);
		},
		containerClass : "valentine2013",
		type: "mobile"
	},

	{
		name : "web.valentine2013",
		message : "Check out our Valentine's Day Stations",
		action : function() {
			Pandora.launchGenrePanel('valentines');
		},
		containerClass : "valentine2013"
	},

	{
		name : "web.workout2012",
		message : "Let Pandora DJ your workout.",
		action : function() {
			Pandora.launchGenrePanel('workout');
		},
		containerClass : "workout2012"
	},

	{
		name : "web.endofyear2012",
		message : "Listen to our End of Year Stations",
		action : function() {
			Pandora.launchGenrePanel('end_of_year');
		},
		containerClass : "endofyear2012"
	},

	{
		name : "web.holiday2012",
		message : "Celebrate the holidays with our holiday stations",
		action : function() {
			Pandora.launchGenrePanel('Holiday');
		},
		containerClass : "holiday2012"
	},

	{
		name : "web.holiday_p1_2012",
		message : "Pandora One is the Perfect Gift for a Music Lover",
		href : "http://www.pandora.com/p1_gift/gift_about.vm",
		containerClass : "holiday_p1_2012"
	},

	{
		name : "web.halloween2012",
		message : "Get in the Halloween Spirit with Our New Spooky Stations",
		href : "#",
		action : function() {
			Pandora.launchGenrePanel('Halloween');
		},
		containerClass : "halloween2012"
	},

	{
		name : "mobile.summer_stations_2012",
		message : "New on Pandora: Summertime Stations",
		action : function() {
			Stage.launchGenrePanel({'genreName':'summer'}, null);
		},
		containerClass : "summer_stations_2012",
		type: "mobile"
	},

		{
		name : "mobile.holiday_stations_2012",
		message : "Listen to Holiday Music On Pandora",
		action : function() {
			Stage.launchGenrePanel({'genreName':'Holiday'}, null);
		},
		containerClass : "holiday_stations_2012",
		type: "mobile"
	},
	
	{
		name : "stpats_2012_1",
		message : "Celebrate St. Patrick's Day with Pandora.",
		action : function() {
			Pandora.launchGenrePanel('st_patricks_day');
		},
		containerClass : "stpats_2012_1",
		bg: "/static/ribbon/bg_stpats_2012_1_1070x40.png"
	},
	
	{
		name : "p1_feature_tour",
		message : "Try out higher quality audio, custom skins and other Pandora One features!",
		href : "http://help.pandora.com/customer/portal/articles/84834 ",
		containerClass : "p1_feature_tour"
	},
	
	{
		name : "workout_stations_1",
		message : "Let Pandora DJ your workout.",
		action : function() {
			Pandora.launchGenrePanel('workout');
		},
		containerClass : "workout_stations_1",
		bg: "/static/ribbon/bg_workout_stations_1_1070x40.png"
	},

	{
		name : "valentines_genre_stations",
		message : "Check out our Valentine's stations: Love Songs, Love Stinks and more.",
		action : function() {
			Pandora.launchGenrePanel('valentines');
		},
		containerClass : "valentines_genre_stations"
	},
	
	{
		name : "valentines_pandora_gift",
		message : "Love Pandora? Give Pandora One to your Favorite Music Lover.",
		href : "http://www.pandora.com/p1_gift/gift_about.vm",
		containerClass : "valentines_pandora_gift"
	},
	
	{
		name : "love_pandora_gift_1",
		message : "Love Pandora? Give Pandora One",
		href : "http://www.pandora.com/p1_gift/gift_about.vm",
		containerClass : "love_pandora_gift_1"
	},
	
	{
		name : "top_songs_2011",
		message : "Check out our genre stations that play the most popular songs of 2011",
		action : function() {
			Pandora.launchGenrePanel('end_of_year');
		},
		containerClass : "top_songs_2011"
	},
	
	{
		name : "celebrate_holiday_stations_2011",
		message : "Celebrate Your Holiday With Our New Stations",
		action : function() {
			Pandora.launchGenrePanel('Holiday');
		},
		containerClass : "holiday_stations_2011"
	},
	
	{
		name : "holiday_stations_2011",
		message : "Get into the Holiday Spirit with our new stations",
		action : function() {
			Pandora.launchGenrePanel('Holiday');
		},
		containerClass : "holiday_stations_2011"
	},
	
	{
		name : "holiday_gifts_2011",
		message : "Pandora One is the Perfect Gift for a Music Lover",
		href : "http://www.pandora.com/p1_gift/gift_about.vm",
		containerClass : "holiday_gifts_2011"
	},
	
	{
		name : "halloween",
		message : "Get set for Halloween with our spooky new stations",
		href : "#",
		action : function() {
			Pandora.launchGenrePanel('Halloween');
		},
		containerClass : "halloween"
	},
	
	{
		name : "gift_msg1",
		message : "Introducing Pandora One Gift Subscriptions. The perfect gift for anyone who loves music.",
		bg : "/static/ribbon/holiday_bg.png"
	},

	{
		name : "gift_msg2",
		message : "Give Pandora One as a gift: no ads, unlimited listening + much more",
		bg : "/static/ribbon/holiday_bg.png"
	},

	{
		name : "gift_msg3",
		message : "Looking for a gift idea? Give a Pandora One Gift Subscription",
		bg : "/static/ribbon/holiday_bg.png"

	},

	{
		name : "gift_msg4",
		message : "Give the gift of music: Pandora One Gift Subscriptions",
		bg : "/static/ribbon/holiday_bg.png"

	},

	{
		name : "gift_msg5",
		message : "A Pandora One Gift Subscription is the perfect last-minute gift",
		bg : "/static/ribbon/holiday2_bg.png"

	},

	{
		name : "holiday_msg1",
		message : "Get into the holiday spirit. Find a holiday station.",
		href : "#",
		action : function() {
			Pandora.launchGenrePanel('Holiday');
		},
		bg : "/static/ribbon/holiday_bg.png"
	},

	{
		name : "topstations_msg1",
		message : "Listen to stations that play the most popular tracks from 2010.",
		href : "#",
		action : function() {
			Pandora.launchGenrePanel('Themed');
		},
		bg : "/static/ribbon/2010_bg.png"
	}
];

