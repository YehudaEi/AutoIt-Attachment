
// this is the list of available images for the gift choices
// drop new ones in here and static push them out

// small_image = the image that appears in the scroller
// selected_image = the image that appears in the current selection
// lightbox_image = the image that appears in the example lightbox box
// print_image = the image that gets printed
// email_image = the image that gets emailed
// enabled - whether this image appears in the current set of choices - 
// this flag allows us to keep halloween / seasonal images in the set,
// and have them still render properly later on, but without displaying
// them in the card catalog

var giftChoiceList = [
	
	  {
        name : "holiday7",
        title : "Holiday",
        small_image : "/static/images/p1_gift/choices/image17_thumbnail.jpg",
        selected_image : "/static/images/p1_gift/choices/image17_selected.png",
        lightbox_image_print : "/static/images/p1_gift/choices/image17_lightbox_print.jpg",
        lightbox_image_email : "/static/images/p1_gift/choices/image17_lightbox_email.jpg",
        print_image : "/static/images/p1_gift/choices/image17_print.jpg",
        email_image : "/static/images/p1_gift/choices/image17_email.jpg",
        email_bg_color: "#e4e3e3",
        enabled : false
    }, 
    
    {
        name : "valentines1",
        title : "Love",
        small_image : "/static/images/p1_gift/choices/image10_thumbnail.jpg",
        selected_image : "/static/images/p1_gift/choices/image10_selected.png",
        lightbox_image_print : "/static/images/p1_gift/choices/image10_lightbox_print.jpg",
        lightbox_image_email : "/static/images/p1_gift/choices/image10_lightbox_email.png",
        print_image : "/static/images/p1_gift/choices/image10_print.jpg",
        email_image : "/static/images/p1_gift/choices/image10_email.jpg",
        email_bg_color: "#e4e3e3",
        enabled : false
    },  
    
      {
        name : "valentines2",
        title : "Valentine's Day",
        small_image : "/static/images/p1_gift/choices/image11_thumbnail.jpg",
        selected_image : "/static/images/p1_gift/choices/image11_selected.png",
        lightbox_image_print : "/static/images/p1_gift/choices/image11_lightbox_print.jpg",
        lightbox_image_email : "/static/images/p1_gift/choices/image11_lightbox_email.png",
        print_image : "/static/images/p1_gift/choices/image11_print.jpg",
        email_image : "/static/images/p1_gift/choices/image11_email.jpg",
        email_bg_color: "#ece8e7",
        enabled : false
    },  

      {
        name : "valentines3",
        title : "Valentine's Day",
        small_image : "/static/images/p1_gift/choices/image12_thumbnail.jpg",
        selected_image : "/static/images/p1_gift/choices/image12_selected.png",
        lightbox_image_print : "/static/images/p1_gift/choices/image12_lightbox_print.jpg",
        lightbox_image_email : "/static/images/p1_gift/choices/image12_lightbox_email.png",
        print_image : "/static/images/p1_gift/choices/image12_print.jpg",
        email_image : "/static/images/p1_gift/choices/image12_email.jpg",
        email_bg_color: "#ececec",
        enabled : false
    },
	  
	  {
        name : "holiday4",
        title : "Holiday",
        small_image : "/static/images/p1_gift/choices/image16_thumbnail.jpg",
        selected_image : "/static/images/p1_gift/choices/image16_selected.png",
        lightbox_image_print : "/static/images/p1_gift/choices/image16_lightbox_print.jpg",
        lightbox_image_email : "/static/images/p1_gift/choices/image16_lightbox_email.png",
        print_image : "/static/images/p1_gift/choices/image16_print.jpg",
        email_image : "/static/images/p1_gift/choices/image16_email.jpg",
        email_bg_color: "#e6f5fc",
        enabled : false
    },
    
      {
        name : "holiday5",
        title : "Holiday",
        small_image : "/static/images/p1_gift/choices/image14_thumbnail.jpg",
        selected_image : "/static/images/p1_gift/choices/image14_selected.png",
        lightbox_image_print : "/static/images/p1_gift/choices/image14_lightbox_print.jpg",
        lightbox_image_email : "/static/images/p1_gift/choices/image14_lightbox_email.png",
        print_image : "/static/images/p1_gift/choices/image14_print.jpg",
        email_image : "/static/images/p1_gift/choices/image14_email.jpg",
        email_bg_color: "#e8f4f9",
        enabled : false
    },
    
      {
        name : "holiday6",
        title : "Holiday",
        small_image : "/static/images/p1_gift/choices/image15_thumbnail.jpg",
        selected_image : "/static/images/p1_gift/choices/image15_selected.png",
        lightbox_image_print : "/static/images/p1_gift/choices/image15_lightbox_print.jpg",
        lightbox_image_email : "/static/images/p1_gift/choices/image15_lightbox_email.png",
        print_image : "/static/images/p1_gift/choices/image15_print.jpg",
        email_image : "/static/images/p1_gift/choices/image15_email.jpg",
        email_bg_color: "#dbe0e3",
        enabled : false
    },
    
      {
        name : "holiday1",
        title : "Holiday",
        small_image : "/static/images/p1_gift/choices/image7_thumbnail.jpg",
        selected_image : "/static/images/p1_gift/choices/image7_selected.png",
        lightbox_image_print : "/static/images/p1_gift/choices/image7_lightbox_print.jpg",
        lightbox_image_email : "/static/images/p1_gift/choices/image7_lightbox_email.png",
        print_image : "/static/images/p1_gift/choices/image7_print.jpg",
        email_image : "/static/images/p1_gift/choices/image7_email.jpg",
        email_bg_color: "#cfd1d3",
        enabled : false
    },
   
	  {
        name : "holiday2",
        title : "Holiday",
        small_image : "/static/images/p1_gift/choices/image8_thumbnail.jpg",
        selected_image : "/static/images/p1_gift/choices/image8_selected.png",
        lightbox_image_print : "/static/images/p1_gift/choices/image8_lightbox_print.jpg",
        lightbox_image_email : "/static/images/p1_gift/choices/image8_lightbox_email.png",
        print_image : "/static/images/p1_gift/choices/image8_print.jpg",
        email_image : "/static/images/p1_gift/choices/image8_email.jpg",
        email_bg_color: "#e2e1dd",
        enabled : false
    },
      
      {
        name : "holiday3",
        title : "Holiday",
        small_image : "/static/images/p1_gift/choices/image9_thumbnail.jpg",
        selected_image : "/static/images/p1_gift/choices/image9_selected.png",
        lightbox_image_print : "/static/images/p1_gift/choices/image9_lightbox_print.jpg",
        lightbox_image_email : "/static/images/p1_gift/choices/image9_lightbox_email.png",
        print_image : "/static/images/p1_gift/choices/image9_print.jpg",
        email_image : "/static/images/p1_gift/choices/image9_email.jpg",
        email_bg_color: "#e9f7fb",
        enabled : false
    },
      
      {
        name : "mothersday",
        title : "Mother's Day",
        small_image : "/static/images/p1_gift/choices/image13_thumbnail.png",
        selected_image : "/static/images/p1_gift/choices/image13_selected.png",
        lightbox_image_print : "/static/images/p1_gift/choices/image13_lightbox_print.jpg",
        lightbox_image_email : "/static/images/p1_gift/choices/image13_lightbox_email.png",
        print_image : "/static/images/p1_gift/choices/image13_print.jpg",
        email_image : "/static/images/p1_gift/choices/image13_email.jpg",
        email_bg_color: "#e2e9f1",
        enabled : false
    },
     
      {
        name : "generic",
        title : "Generic",
        small_image : "/static/images/p1_gift/choices/image1_thumbnail.jpg",
        selected_image : "/static/images/p1_gift/choices/image1_selected.png",
        lightbox_image_print : "/static/images/p1_gift/choices/image1_lightbox_print.jpg",
        lightbox_image_email : "/static/images/p1_gift/choices/image1_lightbox_email.png",
        print_image : "/static/images/p1_gift/choices/image1_print.jpg",
        email_image : "/static/images/p1_gift/choices/image1_email.jpg",
        email_bg_color: "#e2e9f1",
        enabled : true
    },
        
    {
        name : "birthday1",
        title : "Happy Birthday",
        small_image : "/static/images/p1_gift/choices/image2_thumbnail.jpg",
        selected_image : "/static/images/p1_gift/choices/image2_selected.jpg",
        lightbox_image_print : "/static/images/p1_gift/choices/image2_lightbox_print.jpg",
        lightbox_image_email : "/static/images/p1_gift/choices/image2_lightbox_email.png",
        print_image : "/static/images/p1_gift/choices/image2_print.jpg",
        email_image : "/static/images/p1_gift/choices/image2_email.jpg",
        email_bg_color: "#d6e6e8",
        enabled : true
    },
        
    {
        name : "birthday2",
        title : "Happy Birthday",
        small_image : "/static/images/p1_gift/choices/image3_thumbnail.jpg",
        selected_image : "/static/images/p1_gift/choices/image3_selected.jpg",
        lightbox_image_print : "/static/images/p1_gift/choices/image3_lightbox_print.jpg",
        lightbox_image_email : "/static/images/p1_gift/choices/image3_lightbox_email.png",
        print_image : "/static/images/p1_gift/choices/image3_print.jpg",
        email_image : "/static/images/p1_gift/choices/image3_email.jpg",
        email_bg_color: "#d9ebec",
        enabled : true
    },
        
    {
        name : "thankyou1",
        title : "Thank You",
        small_image : "/static/images/p1_gift/choices/image4_thumbnail.jpg",
        selected_image : "/static/images/p1_gift/choices/image4_selected.jpg",
        lightbox_image_print : "/static/images/p1_gift/choices/image4_lightbox_print.jpg",
        lightbox_image_email : "/static/images/p1_gift/choices/image4_lightbox_email.png",
        print_image : "/static/images/p1_gift/choices/image4_print.jpg",
        email_image : "/static/images/p1_gift/choices/image4_email.jpg",
        email_bg_color: "#eaeef2",
        enabled : true
    },
        
    {
        name : "thankyou2",
        title : "Thank You",
        small_image : "/static/images/p1_gift/choices/image5_thumbnail.jpg",
        selected_image : "/static/images/p1_gift/choices/image5_selected.jpg",
        lightbox_image_print : "/static/images/p1_gift/choices/image5_lightbox_print.jpg",
        lightbox_image_email : "/static/images/p1_gift/choices/image5_lightbox_email.png",
        print_image : "/static/images/p1_gift/choices/image5_print.jpg",
        email_image : "/static/images/p1_gift/choices/image5_email.jpg",
        email_bg_color: "#eaeff8",
        enabled : true
    },
        
    {
        name : "gift1",
        title : "A Gift For You",
        small_image : "/static/images/p1_gift/choices/image6_thumbnail.jpg",
        selected_image : "/static/images/p1_gift/choices/image6_selected.jpg",
        lightbox_image_print : "/static/images/p1_gift/choices/image6_lightbox_print.jpg",
        lightbox_image_email : "/static/images/p1_gift/choices/image6_lightbox_email.png",
        print_image : "/static/images/p1_gift/choices/image6_print.jpg",
        email_image : "/static/images/p1_gift/choices/image6_email.jpg",
        email_bg_color: "#eae7ea",
        enabled : true
    }
    	
    
];


  
