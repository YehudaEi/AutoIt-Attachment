/*=====================
	MT_AutoIt.dll

	By FredAI 12/2012
	Open source Multi-thread dll for AutoIt
*/

#include <Windows.h>

//Declare our struct for the _ThreadProc3 Threadproc function
typedef struct ThreadProc3Data {HWND hwnd;int top;} *PThreadProc3Data;

//Declare our 4 thread proc functions
DWORD WINAPI _ThreadProc1(LPVOID lpParameter);
DWORD WINAPI _ThreadProc2(LPVOID lpParameter);
DWORD WINAPI _ThreadProc3(LPVOID lpParameter);
DWORD WINAPI _ThreadProc4(LPVOID lpParameter);

//Declare the Thread creation function
HANDLE WINAPI _AutoItThreadCreate(
	int index,
	LPVOID lpParameter,
	SIZE_T dwStackSize,
	DWORD dwCreationFlags,
	LPDWORD lpThreadId
	);

BOOLEAN APIENTRY DllMain(HINSTANCE hinstDLL,DWORD fdwReason,LPVOID lpvReserved)
{
	switch ( fdwReason )
   {
    case DLL_PROCESS_ATTACH:

      //  For optimization.

     DisableThreadLibraryCalls( hinstDLL );

      break;

    case DLL_PROCESS_DETACH:

      break;
   }
	return TRUE;
} // End of DllMain

DWORD WINAPI _ThreadProc1(LPVOID param)
{
	PWSTR wstr = (PWSTR)param;
	MessageBox(0,wstr,L"Thread message",MB_OK);
	return 0;
} // End of _ThreadProc1

DWORD WINAPI _ThreadProc2(LPVOID param)
{
	PWSTR wstr = (PWSTR)param;
	MessageBox(0,wstr,L"Thread message",MB_OK);
	return 0;
} // End of _ThreadProc1

DWORD WINAPI _ThreadProc3(LPVOID param)
{
	PThreadProc3Data thpd = (PThreadProc3Data) param;
	HWND desktopHwnd = GetDesktopWindow();
	HDC desktopDC = GetDC(desktopHwnd);
	int desktopwidth = GetDeviceCaps(desktopDC,HORZRES);
	HDC hdcpic = GetDC(thpd->hwnd);
	for (int i=0;i<desktopwidth;i++)
	{
		BitBlt(hdcpic, 0, 0, 240,180, desktopDC, i, thpd->top, SRCCOPY);
		//picgr.DrawImage(&desktopBmp,i,thpd->top,240,180);
		SleepEx(20,true);
		if (i == desktopwidth-240-1) i = 0;
	}
	return 0;
} // End of _ThreadProc1

DWORD WINAPI _ThreadProc4(LPVOID param)
{
	PWSTR wstr = (PWSTR)param;
	MessageBox(0,wstr,L"Thread message",MB_OK);
	return 0;
} // End of _ThreadProc1

HANDLE WINAPI _AutoItThreadCreate(int index, LPVOID lpParameter,
	SIZE_T dwStackSize,DWORD dwCreationFlags,LPDWORD lpThreadId)
{
	switch (index)
	{
	case 1:
		return CreateThread(NULL,dwStackSize,&_ThreadProc1,lpParameter,dwCreationFlags,lpThreadId);
	case 2:
		return CreateThread(NULL,dwStackSize,&_ThreadProc2,lpParameter,dwCreationFlags,lpThreadId);
	case 3:
		return CreateThread(NULL,dwStackSize,&_ThreadProc3,lpParameter,dwCreationFlags,lpThreadId);
	case 4:
		return CreateThread(NULL,dwStackSize,&_ThreadProc4,lpParameter,dwCreationFlags,lpThreadId);
	default:
		return 0;
	}
} // End of _AutoItThreadCreate