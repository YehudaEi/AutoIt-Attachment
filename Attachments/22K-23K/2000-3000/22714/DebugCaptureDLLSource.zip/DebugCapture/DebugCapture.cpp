// DebugCapture - helper DLL for AutoIt DebugCapture UDF
//
// Version : 1.0
// Date    : 19-10-2008
// Author  : Steven Scholte
//
// Code is based on an example from the book "Programming Windows Services"
// by Randy Charles Morin

#include "stdafx.h"
#include "DebugCapture.h"
#include "iostream.h"


// Globals
HANDLE hEventBufferReady;				// Handle to "DBWIN_BUFFER_READY"
HANDLE hEventDataReady;					// Handle to "DBWIN_DATA_READY"
HANDLE hBuffer;							// Handle to file mapping
void *lpDebugInfo;						// Pointer to shared memory

SECURITY_ATTRIBUTES sa;
SECURITY_DESCRIPTOR sd;

BOOL bInitialized = FALSE;				// Set to TRUE as soon as initialization is completed
BOOL bWriteStdOut = FALSE;				// Write debugging information to stdout if set tot TRUE


// Function Name	: DllMain
//
BOOL APIENTRY DllMain( HANDLE hModule,
                       DWORD  ul_reason_for_call,
                       LPVOID lpReserved
					 )
{
    switch (ul_reason_for_call)
	{
		case DLL_PROCESS_ATTACH :
			break;
		case DLL_THREAD_ATTACH  :
			break;
		case DLL_THREAD_DETACH  :
			break;
		case DLL_PROCESS_DETACH :
			// In case the caller forgot...
			if(bInitialized)
			{
				fnStopDebugCapture();
			}
			break;
    }
    return TRUE;
}

// Function Name	: fnStartDebugCapture
//
// Description		: Starts capturing debug information written by other processes
//					  using the OutputDebugString API.
// Parameter(s)		: nWriteStdOut - when set to a non-zero value, all functions in
//					  this DLL will output some debugging information on stdout.
//					  This output can be viewed when a script is run from SciTE, for example.
// Return value		: RETURN_OK - initialization completed.
//					  RETURN_ALREADY_INITIALIZED - fnStartDebugCapture was already
//					  called earlier.
//					  RETURN_INIT_FAILED - error creating events or filemapping.
//					  RETURN_DEBUGGER_ACTIVE - a debugger is already active.
DEBUGCAPTURE_API int fnStartDebugCapture(int nWriteStdOut)
{
	bWriteStdOut = (nWriteStdOut != 0);			// Set global flag
	if(bWriteStdOut) cout<<"DebugCapture.dll: fnStartDebugCapture" << endl;

	if(bInitialized)
	{
		return RETURN_ALREADY_INITIALIZED;
	}

	// Initialize security attributes struct
	sa.nLength = sizeof(SECURITY_ATTRIBUTES);
	sa.lpSecurityDescriptor = &sd;
	sa.bInheritHandle = TRUE;
	// Initialize security descriptor
	if(::InitializeSecurityDescriptor(&sd, SECURITY_DESCRIPTOR_REVISION) == FALSE)
	{
		if(bWriteStdOut) cout << "DebugCapture.dll: InitializeSecurityDescriptor failed" << endl;
		return RETURN_INIT_FAILED;
	}
	if(::SetSecurityDescriptorDacl(&sd, TRUE, (PACL)NULL, FALSE) == FALSE)
	{
		if(bWriteStdOut) cout << "DebugCapture.dll: SetSecurityDescriptorDacl failed" << endl;
		return RETURN_INIT_FAILED;
	}
	// Create "DBWIN_BUFFER_READY" event
	hEventBufferReady = ::CreateEvent(&sa, FALSE, FALSE, "DBWIN_BUFFER_READY");
	if(hEventBufferReady == NULL)
	{
		if(bWriteStdOut) cout << "DebugCapture.dll: CreateEvent DBWIN_BUFFER_READY failed" << endl;
		return RETURN_INIT_FAILED;
	}
	if (GetLastError() == ERROR_ALREADY_EXISTS)
	{
		if(bWriteStdOut) cout << "DebugCapture.dll: Debugger Already Running" << endl;
		::CloseHandle(hEventBufferReady);
		return RETURN_DEBUGGER_ACTIVE;
	}
	// Create "DBWIN_DATA_READY" event
	hEventDataReady = ::CreateEvent(&sa, FALSE, FALSE, "DBWIN_DATA_READY");
	if(hEventDataReady == NULL)
	{
		if(bWriteStdOut) cout << "DebugCapture.dll: CreateEvent DBWIN_DATA_READY failed" << endl;
		::CloseHandle(hEventBufferReady);
		return RETURN_INIT_FAILED;
	}
	if (GetLastError() == ERROR_ALREADY_EXISTS)
	{
		if(bWriteStdOut) cout << "DebugCapture.dll: Debugger Already Running" << endl;
		::CloseHandle(hEventBufferReady);
		::CloseHandle(hEventDataReady);
		return RETURN_DEBUGGER_ACTIVE;
	}
	// Create file mapping to "DBWIN_BUFFER"
	hBuffer = ::CreateFileMapping(INVALID_HANDLE_VALUE, &sa, PAGE_READWRITE, 0, 4096, "DBWIN_BUFFER");
	if(hBuffer == NULL)
	{
		if(bWriteStdOut) cout << "DebugCapture.dll: CreateFileMapping DBWIN_BUFFER failed" << endl;
		::CloseHandle(hEventBufferReady);
		::CloseHandle(hEventDataReady);
		return RETURN_INIT_FAILED;
	}
	if (GetLastError() == ERROR_ALREADY_EXISTS)
	{
		if(bWriteStdOut) cout << "DebugCapture.dll: Debugger Already Running" << endl;
		::CloseHandle(hEventBufferReady);
		::CloseHandle(hEventDataReady);
		::CloseHandle(hBuffer);
		return RETURN_DEBUGGER_ACTIVE;
	}
	// Initialize pointer to shared memory
	lpDebugInfo = ::MapViewOfFile(hBuffer, FILE_MAP_READ, 0, 0, 4096);
	if(lpDebugInfo == NULL)
	{
		if(bWriteStdOut) cout << "DebugCapture.dll: MapViewOfFile failed" << endl;
		::CloseHandle(hEventBufferReady);
		::CloseHandle(hEventDataReady);
		::CloseHandle(hBuffer);
		return RETURN_INIT_FAILED;
	}
	// Signal that we are ready to receive data
	if (::SetEvent(hEventBufferReady) == FALSE)
	{
		if(bWriteStdOut) cout << "DebugCapture.dll: SetEvent DBWIN_BUFFER_READY failed" << endl;
		::CloseHandle(hEventBufferReady);
		::CloseHandle(hEventDataReady);
		::UnmapViewOfFile(lpDebugInfo);
		::CloseHandle(hBuffer);
		return RETURN_INIT_FAILED;
	};
	// Everything OK
	bInitialized = TRUE;
	return RETURN_OK;
}

// Function Name	: fnStopDebugCapture
//
// Description		: Stops capturing debug information.
// Parameter(s)		: None
// Return value		: RETURN_OK - capturing is stopped.
//					  RETURN_NOT_INITIALIZED - fnStartDebugCapture has not been called before.
DEBUGCAPTURE_API int fnStopDebugCapture(void)
{
	if(bWriteStdOut) cout<<"DebugCapture.dll: fnStopDebugCapture" << endl;

	if(bInitialized)
	{
		::CloseHandle(hEventBufferReady);
		::CloseHandle(hEventDataReady);
		::UnmapViewOfFile(lpDebugInfo);
		::CloseHandle(hBuffer);
		bInitialized = FALSE;
		return RETURN_OK;
	}
	else
	{
		return RETURN_NOT_INITIALIZED;
	}
}

// Function Name	: fnGetDebugOutput
//
// Description		: checks if debug information is available and returns that information.
// Parameter(s)		: pdwProcessId (in/out) - [input] the PID of the process you want to read
//					  the debug information from. If this is set to 0, then all debug
//					  information is returned.
//					  [output] the PID of the process the debug information came from. Is
//					  set to 0, when no information is available.
//					  pszDebugOutput (out) - pointer to a buffer where the debug information
//					  is to be stored. Buffer must have room for 4092 chars. String is always
//					  NULL terminated.
// Return value		: RETURN_OK - no errors.
//					  RETURN_NOT_INITIALIZED - fnStartDebugCapture has not been called before.
//					  RETURN_INIT_FAILED - error setting the DBWIN_BUFFER_READY event.
DEBUGCAPTURE_API int fnGetDebugOutput(DWORD *pdwProcessId, char *pszDebugOutput)
{
	if(!bInitialized)
	{
		return RETURN_NOT_INITIALIZED;
	}

	DWORD dwFilterPid = *pdwProcessId;		// Save parameter

	// Initialize returned values. If there is no data available from the
	// selected PID or there is no data available at all, then a PID of 0 and
	// an empty string are returned.
	*pdwProcessId = 0;
	pszDebugOutput[0] = NULL;

	// Check if new debug information is available. Time-out interval is set to 0,
	// so we just check the state of the object and don't wait on it.
	if(::WaitForSingleObject(hEventDataReady, 0) == WAIT_OBJECT_0)
	{
		// State of hEventDataReady object is signaled: data is available
		struct debug_buffer *buf = (struct debug_buffer*)lpDebugInfo;
		if((dwFilterPid == 0) || (dwFilterPid == buf->dwProcessId))
		{
			// Copy the data to the buffers supplied by the caller
			*pdwProcessId = buf->dwProcessId;
			strcpy(pszDebugOutput, buf->data);
		}
		// Signal that buffer is ready to be filled again
		if (::SetEvent(hEventBufferReady) == FALSE)
		{
			if(bWriteStdOut) cout << "DebugCapture.dll: SetEvent DBWIN_BUFFER_READY failed" << endl;
			return RETURN_INIT_FAILED;
		}
	}

	return RETURN_OK;
}
