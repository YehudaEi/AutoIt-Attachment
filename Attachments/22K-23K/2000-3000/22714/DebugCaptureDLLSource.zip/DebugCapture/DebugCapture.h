// Return values
#define	RETURN_OK					0
#define	RETURN_INIT_FAILED			2
#define	RETURN_DEBUGGER_ACTIVE		3
#define	RETURN_NOT_INITIALIZED		4
#define	RETURN_ALREADY_INITIALIZED	5

#pragma pack(1)

// Structure of the Debug Information. Total size is 4k.
struct debug_buffer
{
	DWORD	dwProcessId;
	char	data[4096-sizeof(DWORD)];
};

#pragma pack()

// The following ifdef block is the standard way of creating macros which make exporting 
// from a DLL simpler. All files within this DLL are compiled with the DEBUGCAPTURE_EXPORTS
// symbol defined on the command line. this symbol should not be defined on any project
// that uses this DLL. This way any other project whose source files include this file see 
// DEBUGCAPTURE_API functions as being imported from a DLL, wheras this DLL sees symbols
// defined with this macro as being exported.
#ifdef DEBUGCAPTURE_EXPORTS
#define DEBUGCAPTURE_API __declspec(dllexport)
#else
#define DEBUGCAPTURE_API __declspec(dllimport)
#endif

extern "C" DEBUGCAPTURE_API int fnStartDebugCapture(int nWriteStdOut);
extern "C" DEBUGCAPTURE_API int fnStopDebugCapture(void);
extern "C" DEBUGCAPTURE_API int fnGetDebugOutput(DWORD *pdwProcessId, char *szDebugOutput);
