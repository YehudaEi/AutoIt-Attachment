Please name files with this formula:

GameName & Your name (Abrv.)

Is also suggested you use the "SportsWriter.au3" first in order to ensure proper formatting of your game.


Thank you!
