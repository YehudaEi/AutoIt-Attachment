// dllmain.cpp : Defines the entry point for the DLL application.

#include "stdafx.h"

/****************************************************************************
* Function List
*
* This is where you define the functions available to AutoIt.  Including
* the function name (Must be the same case as your exported DLL name), the
* minimum and maximum number of parameters that the function takes.
*
****************************************************************************/

/* "FunctionName", min_params, max_params */
AU3_PLUGIN_FUNC g_AU3_Funcs[] = 
{
	{"ActivateTab", 1, 1},
	{"AddTab", 1, 1},
	{"DeleteTab", 1, 1},
	{"SetActiveAlt", 1, 1}
};


/****************************************************************************
* AU3_GetPluginDetails()
*
* This function is called by AutoIt when the plugin dll is first loaded to
* query the plugin about what functions it supports.  DO NOT MODIFY.
*
****************************************************************************/

AU3_PLUGINAPI int AU3_GetPluginDetails(int *n_AU3_NumFuncs, AU3_PLUGIN_FUNC **p_AU3_Func)
{
	/* Pass back the number of functions that this DLL supports */
	*n_AU3_NumFuncs	= sizeof(g_AU3_Funcs)/sizeof(AU3_PLUGIN_FUNC);

	/* Pack back the address of the global function table */
	*p_AU3_Func = g_AU3_Funcs;

	return AU3_PLUGIN_OK;
}


/****************************************************************************
* DllMain()
*
* This function is called when the DLL is loaded and unloaded.  Do not 
* modify it unless you understand what it does...
*
****************************************************************************/

BOOL WINAPI DllMain(HANDLE hInst, ULONG ul_reason_for_call, LPVOID lpReserved)
{
	switch (ul_reason_for_call)
	{
	case DLL_PROCESS_ATTACH:
	case DLL_THREAD_ATTACH:
	case DLL_THREAD_DETACH:
	case DLL_PROCESS_DETACH:
		break;
	}
	return TRUE;
}


/****************************************************************************
* ActivateTab()
*
* Activates an item on the taskbar. The window is not actually activated;
* the window's item on the taskbar is merely displayed as active.
* 
* ActivateTab(hWnd)
*
****************************************************************************/

AU3_PLUGIN_DEFINE(ActivateTab)
{
	/* The inputs to a plugin function are:
	*		n_AU3_NumParams		- The number of parameters being passed
	*		p_AU3_Params		- An array of variant like variables used by AutoIt
	*
	* The outputs of a plugin function are:
	*		p_AU3_Result		- A pointer to a variant variable for the result
	*		n_AU3_ErrorCode		- The value for @Error
	*		n_AU3_ExtCode		- The value for @Extended
	*/

	AU3_PLUGIN_VAR	*pMyResult;
	HWND			hWnd;

	/* Allocate and build the return variable */
	pMyResult = AU3_AllocVar();
	/* default returns to failure */
	AU3_SetInt32(pMyResult, 1);
	*n_AU3_ErrorCode = 1;

	/* Get window HWND to act on */
	hWnd = AU3_GethWnd(&p_AU3_Params[0]);

	/* Do it */
	ITaskbarList* pTList = NULL;
	if (SUCCEEDED(CoInitializeEx(NULL, COINIT_MULTITHREADED)))
	{
		if (SUCCEEDED(CoCreateInstance(CLSID_TaskbarList, NULL, CLSCTX_SERVER, IID_ITaskbarList, (void**)&pTList)))
		{
			pTList->HrInit();
			pTList->ActivateTab(hWnd);
			pTList->Release();
			/* return success */
			AU3_SetInt32(pMyResult, 0);
			*n_AU3_ErrorCode = 0;
		}
		CoUninitialize();
	}

	/* Pass back the result, error code and extended code.
	* Note: AutoIt is responsible for freeing the memory used in p_AU3_Result
	*/
	*p_AU3_Result	= pMyResult;
	*n_AU3_ExtCode	= 0;

	return AU3_PLUGIN_OK;
}


/****************************************************************************
* AddTab()
*
* Adds an item to the taskbar.
* 
* AddTab(hWnd)
*
****************************************************************************/

AU3_PLUGIN_DEFINE(AddTab)
{
	/* The inputs to a plugin function are:
	*		n_AU3_NumParams		- The number of parameters being passed
	*		p_AU3_Params		- An array of variant like variables used by AutoIt
	*
	* The outputs of a plugin function are:
	*		p_AU3_Result		- A pointer to a variant variable for the result
	*		n_AU3_ErrorCode		- The value for @Error
	*		n_AU3_ExtCode		- The value for @Extended
	*/

	AU3_PLUGIN_VAR	*pMyResult;
	HWND			hWnd;

	/* Allocate and build the return variable */
	pMyResult = AU3_AllocVar();
	/* default returns to failure */
	AU3_SetInt32(pMyResult, 1);
	*n_AU3_ErrorCode = 1;

	/* Get window HWND to act on */
	hWnd = AU3_GethWnd(&p_AU3_Params[0]);

	/* Do it */
	ITaskbarList* pTList = NULL;
	if (SUCCEEDED(CoInitializeEx(NULL, COINIT_MULTITHREADED)))
	{
		if (SUCCEEDED(CoCreateInstance(CLSID_TaskbarList, NULL, CLSCTX_SERVER, IID_ITaskbarList, (void**)&pTList)))
		{
			pTList->HrInit();
			pTList->AddTab(hWnd);
			pTList->Release();
			/* return success */
			AU3_SetInt32(pMyResult, 0);
			*n_AU3_ErrorCode = 0;
		}
		CoUninitialize();
	}

	/* Pass back the result, error code and extended code.
	* Note: AutoIt is responsible for freeing the memory used in p_AU3_Result
	*/
	*p_AU3_Result	= pMyResult;
	*n_AU3_ExtCode	= 0;

	return AU3_PLUGIN_OK;
}


/****************************************************************************
* DeleteTab()
*
* Deletes an item from the taskbar. 
* 
* DeleteTab(hWnd)
*
****************************************************************************/

AU3_PLUGIN_DEFINE(DeleteTab)
{
	/* The inputs to a plugin function are:
	*		n_AU3_NumParams		- The number of parameters being passed
	*		p_AU3_Params		- An array of variant like variables used by AutoIt
	*
	* The outputs of a plugin function are:
	*		p_AU3_Result		- A pointer to a variant variable for the result
	*		n_AU3_ErrorCode		- The value for @Error
	*		n_AU3_ExtCode		- The value for @Extended
	*/

	AU3_PLUGIN_VAR	*pMyResult;
	HWND			hWnd;

	/* Allocate and build the return variable */
	pMyResult = AU3_AllocVar();
	/* default returns to failure */
	AU3_SetInt32(pMyResult, 1);
	*n_AU3_ErrorCode = 1;

	/* Get window HWND to act on */
	hWnd = AU3_GethWnd(&p_AU3_Params[0]);

	/* Do it */
	ITaskbarList* pTList = NULL;
	if (SUCCEEDED(CoInitializeEx(NULL, COINIT_MULTITHREADED)))
	{
		if (SUCCEEDED(CoCreateInstance(CLSID_TaskbarList, NULL, CLSCTX_SERVER, IID_ITaskbarList, (void**)&pTList)))
		{
			pTList->HrInit();
			pTList->DeleteTab(hWnd);
			pTList->Release();
			/* return success */
			AU3_SetInt32(pMyResult, 0);
			*n_AU3_ErrorCode = 0;
		}
		CoUninitialize();
	}

	/* Pass back the result, error code and extended code.
	* Note: AutoIt is responsible for freeing the memory used in p_AU3_Result
	*/
	*p_AU3_Result	= pMyResult;
	*n_AU3_ExtCode	= 0;

	return AU3_PLUGIN_OK;
}


/****************************************************************************
* SetActiveAlt()
*
* Marks a taskbar item as active but does not visually activate it. 
* 
* SetActiveAlt(hWnd)
*
****************************************************************************/

AU3_PLUGIN_DEFINE(SetActiveAlt)
{
	/* The inputs to a plugin function are:
	*		n_AU3_NumParams		- The number of parameters being passed
	*		p_AU3_Params		- An array of variant like variables used by AutoIt
	*
	* The outputs of a plugin function are:
	*		p_AU3_Result		- A pointer to a variant variable for the result
	*		n_AU3_ErrorCode		- The value for @Error
	*		n_AU3_ExtCode		- The value for @Extended
	*/

	AU3_PLUGIN_VAR	*pMyResult;
	HWND			hWnd;

	/* Allocate and build the return variable */
	pMyResult = AU3_AllocVar();
	/* default returns to failure */
	AU3_SetInt32(pMyResult, 1);
	*n_AU3_ErrorCode = 1;

	/* Get window HWND to act on */
	hWnd = AU3_GethWnd(&p_AU3_Params[0]);

	/* Do it */
	ITaskbarList* pTList = NULL;
	if (SUCCEEDED(CoInitializeEx(NULL, COINIT_MULTITHREADED)))
	{
		if (SUCCEEDED(CoCreateInstance(CLSID_TaskbarList, NULL, CLSCTX_SERVER, IID_ITaskbarList, (void**)&pTList)))
		{
			pTList->HrInit();
			pTList->SetActiveAlt(hWnd);
			pTList->Release();
			/* return success */
			AU3_SetInt32(pMyResult, 0);
			*n_AU3_ErrorCode = 0;
		}
		CoUninitialize();
	}

	/* Pass back the result, error code and extended code.
	* Note: AutoIt is responsible for freeing the memory used in p_AU3_Result
	*/
	*p_AU3_Result	= pMyResult;
	*n_AU3_ExtCode	= 0;

	return AU3_PLUGIN_OK;
}