Copy CustomBox (directory) to your desktop or an other location
Keep the pictures in the same directory as the CustomBox.au3 file (if you run it for the first time).
If you want to use the old pictures then just put the old pictures in the same
directory as CustomBox.au3 then edit the following lines in CustomBox.au3:

;FileDelete(@TempDir&'\button.bmp')
;FileDelete(@TempDir&'\leave.bmp')
;FileDelete(@TempDir&'\Titlebar.bmp')

To

FileDelete(@TempDir&'\button.bmp')
FileDelete(@TempDir&'\leave.bmp')
FileDelete(@TempDir&'\Titlebar.bmp')

Run it once. Edit it back to normal..

Enjoy!  ^_^