Credits:

TehWhale - Main scripting functions all, except GDI+
Monoceres - Created the GUI with GDI+
Jon - AutoIt scripting language

Http://www.autoitscript.com/

Readme:

Launch the executable unless you have AutoIt installed
Click MENU and select a music directory (Not recursive yet)
Use ||> for playing/pausing your music
|>> for going to the next song in your list
<<| for going to the previous song in your list

Enjoy :)