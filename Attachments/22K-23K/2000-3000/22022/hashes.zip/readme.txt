The following files are included within this archive.

	Example.au3 (example usage for Hashes UDF)
	Hashes.au3 (Hashes UDF)
	Hashes_lib.au3 (embeded hashes.dll file)
	readme.txt (this file)
	MemoryDll.au3 (MemoryDLL UDF)
	hashes_dll.zip (unmodified hashes.dll archive)
	Sample.au3 (Sample program usage)

Changelog:
	v1.0a - Sep 1, 2008: 
		Minor fix for _Hashes_Init(), should be roughly 5x faster now.
	v1.0 - Sep 1, 2008: 
		Initial release.