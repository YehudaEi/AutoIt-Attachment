TrIDLib - Free version - (C) 2008-2011 By Marco Pontello

Info: http://mark0.net/code-tridlib-e.html
      http://mark0.net/soft-trid-e.html
E-Mail: marcopon@gmail.com

Be sure to check the TrIDLib-License.txt file.
See the website for more info, changes log and samples in various
programming languages. A certain degree of familiarity with how TrID
works will also surely help.

N.B. More detailed docs will come very soon, but for the moment the samples
should enough to start coding.


If you like the free library, you may consider sending a postcard of your
city to the author at the following address:

Marco Pontello
Via Circonvallazione 137
30030 Maerne VE
Italy

Thanks! :-)

