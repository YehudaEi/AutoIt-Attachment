/////////////////////////////////////////////////////////////////////
var clear_calendar  = 1;
var obj_calendar  = '';
var data_calendar;
var picker_is_opened=false;

var today_cal = new Date();
var start_day   = today_cal.getDate();
var start_month = today_cal.getMonth();
var start_year  = today_cal.getYear();
var sel_day   = today_cal.getDate();
var sel_month = today_cal.getMonth();
var sel_year  = today_cal.getYear();

/////////////////////////////////////////////////////////////////////

if (!document.all) {
    document.captureEvents(Event.MOUSEMOVE);
    document.onmousemove = captureMousePosition;
	document.captureEvents(Event.MOUSEDOWN);
	document.onmousedown = mouseClick;
}

var xMousePos, yMousePos, xMousePosMax, yMousePosMax;
function captureMousePosition(e) {
    xMousePos = e.pageX;
    yMousePos = e.pageY;
    xMousePosMax = window.innerWidth+window.pageXOffset;
    yMousePosMax = window.innerHeight+window.pageYOffset;
}

function mouseClick(e) {
	var warunek=true;
	if (e.target.name=='cal_button') {warunek=false};
	if (picker_is_opened==true && warunek==true) {
		var kal=Cal_findObj('tab_kalendarz');
		var clickX;
		var clickY;
		clickX = e.pageX;
		clickY = e.pageY;
		if (!((clickX > parseInt(kal.style.left)) && (clickX < parseInt(kal.style.left)+parseInt(kal.width)) && (clickY > parseInt(kal.style.top)) && (clickY < parseInt(kal.style.top)+parseInt(kal.height)))) {
			kal.style.display="none";
			picker_is_opened=false;
		}
	}
}

/////////////////////////////////////////////////////////////////////

function document_onclick() {
	var warunek=true;
	if (event.srcElement.name=='cal_button') {warunek=false};
	if (picker_is_opened==true && warunek==true) {
		var kal=Cal_findObj('tab_kalendarz');
		var clickX;
		var clickY;
		clickX = event.x+document.body.scrollLeft;
		clickY = event.y+(document.body.scrollTop);
		if (!((clickX > parseInt(kal.style.left)) && (clickX < parseInt(kal.style.left)+parseInt(kal.width)) && (clickY > parseInt(kal.style.top)) && (clickY < parseInt(kal.style.top)+parseInt(kal.height)))) {
			kal.style.display="none";
			picker_is_opened=false;
		}
	}

}

if (document.all && typeof document.attachEvent!='undefined') {
	document.attachEvent('onclick', document_onclick);
}

/////////////////////////////////////////////////////////////////////

function data_picker2(elem,clr, x, y) {
	y=y+40;
	if (clr==0) {
		warstwa_polozenie(180,180,x,y);
	}
	else {
		warstwa_polozenie(180,200,x,y);
	}
	data_picker_show(elem,clr);
}

/////////////////////////////////////////////////////////////////////

function data_picker(elem,clr) {
	var poz=0, pozy=0;
	if (document.all) {
		poz=event.screenX-105;
		pozy=event.y+10;
	}
	else {
		poz=xMousePos-105;
		pozy=yMousePos+10;
	}
	poz=parseInt(poz/10)*10;
	if (poz<0) {poz=0;}
	if (pozy<0) {pozy=0;}

	if (clr==0) {
		warstwa_polozenie(180,180,poz,pozy);
	}
	else {
		warstwa_polozenie(180,220,poz,pozy);
	}
	data_picker_show(elem,clr);
}

/////////////////////////////////////////////////////////////////////

function data_picker_show(elem,clr) {
	var objt, s;
	if (typeof document.getElementById!='undefined') {
		objt=document.getElementById(elem);
    }
	else {
		objt=document.all(elem);
    }
	var today;
	today=objt.value.split("-");
	if (objt.value!='') {
		day   = today[2];
		month = today[1]-1;
		year  = today[0];
		start_day   = today[2];
		start_month = today[1]-1;
		start_year  = today[0];
		sel_day   = today[2];
		sel_month = today[1]-1;
		sel_year  = today[0];
    }
	else {
		var data = new Date();
		start_day   = data.getDate();
		start_month = data.getMonth();
		start_year  = data.getYear();
		sel_day   = data.getDate();
		sel_month = data.getMonth();
		sel_year  = data.getYear();
	}

	obj_calendar=elem;
	clear_calendar=clr
	var kal=Cal_findObj('kalendarz');
	kal.innerHTML=Calendar(start_day,start_month,start_year);
	var kal=Cal_findObj('tab_kalendarz');
	kal.style.display="";
	setTimeout("picker_is_opened=true", 100);
}

/////////////////////////////////////////////////////////////////////

function przepisz_calendar(elem) {
	var obj;
	if (typeof document.getElementById!='undefined') {
	    obj=document.getElementById(elem);
    }
	else  {
	    obj=document.all(elem);
	}
	obj.value=data_calendar;
}

/////////////////////////////////////////////////////////////////////

function Cal_findObj(n, d) { //v4.01
  var p,i,x;  if(!d) d=document; if((p=n.indexOf("?"))>0&&parent.frames.length) {
    d=parent.frames[n.substring(p+1)].document; n=n.substring(0,p);}
  if(!(x=d[n])&&d.all) x=d.all[n]; for (i=0;!x&&i<d.forms.length;i++) x=d.forms[i][n];
  for(i=0;!x&&d.layers&&i<d.layers.length;i++) x=MM_findObj(n,d.layers[i].document);
  if(!x && d.getElementById) x=d.getElementById(n); return x;
}

/////////////////////////////////////////////////////////////////////

function styl() {
  var output='';
  output += '<STYLE>';
  output += 'INPUT.Cal {';
  output += '	FONT-SIZE: 8pt; FONT-FAMILY: MS Shell Dlg';
  output += '}';
  output += 'SELECT.Cal {';
  output += '	FONT-SIZE: 8pt; FONT-FAMILY: MS Shell Dlg';
  output += '}';
  output += 'TD.Cal {';
  output += '	FONT-SIZE: 8pt; FONT-FAMILY: MS Shell Dlg';
  output += '}';
  output += 'a.Cal:link {';
  output += '	FONT-SIZE: 8pt; FONT-FAMILY: MS Shell Dlg;';
  output += '   text-decoration: none;';
  output += '   color: #000000;';
  output += '}';
  output += 'a.Cal:active {';
  output += '	FONT-SIZE: 8pt; FONT-FAMILY: MS Shell Dlg;';
  output += '   text-decoration: none;';
  output += '   color: #000000;';
  output += '}';
  output += 'a.Cal:visited {';
  output += '	FONT-SIZE: 8pt; FONT-FAMILY: MS Shell Dlg;';
  output += '   text-decoration: none;';
  output += '   color: #000000;';
  output += '}';
  output += 'a.Cal:hover {';
  output += '	FONT-SIZE: 8pt; FONT-FAMILY: MS Shell Dlg;';
  output += '   text-decoration: none;';
  output += '   color: #666666;';
  output += '}';
  output += '</STYLE>';
  return output;
}

/////////////////////////////////////////////////////////////////////

function padout(number) { return (number < 10) ? '0' + number : number; }

/////////////////////////////////////////////////////////////////////

function Calendar(Day,Month,Year) {
  var output = '';
  var rows = 1;
  var today = new Date();

  if (clear_calendar!=1) {
  	wysokosc=180;
	wysokosc2=160;
  }
  else {
  	wysokosc=200;
	wysokosc2=180;
  }

  output += '<TABLE BORDER=0 cellpadding=0 cellspacing=0 width=100% height='+wysokosc+' bgcolor=#ffffff><TR><TD class=Cal ALIGN=CENTER WIDTH=100%>';

  output += '<FORM NAME="Cal"><TABLE BORDER=0 cellpadding=0 cellspacing=1 width=100% height=30 style="background: #EFEBEF"><TR><TD class=Cal ALIGN=CENTER WIDTH=20>';
  output += ' <a class=Cal href=\'javascript: moveBackward()\'><<</a> ';
  output += '</TD><TD class=Cal ALIGN=CENTER>';

  output += '<SELECT class=Cal NAME="Month" onChange="changeMonth();" style="width: 80">';

  for (month=0; month<12; month++)
   {
    if ((month) == Month) output += '<OPTION VALUE="' + (month) + '" SELECTED>' + names[month] + '<\/OPTION>';
    else                output += '<OPTION VALUE="' + (month) + '">'          + names[month] + '<\/OPTION>';
   }

  output += '<\/SELECT><SELECT  class=Cal NAME="Year" onChange="changeYear();" style="width: 50">';

  var ystart = today.getYear();

  if (parseInt(ystart)<1000) {
    ystart = parseInt(ystart)+1900;
  }
  if (parseInt(Year)<1000) {
	Year = parseInt(Year)+1900;
  }
  var yend = ystart + 5;

  for (year=ystart-5; year<yend; year++)
   {
    if (year == Year) output += '<OPTION VALUE="' + year + '" SELECTED>' + year + '<\/OPTION>';
    else              output += '<OPTION VALUE="' + year + '">'          + year + '<\/OPTION>';
   }

  output += '<\/SELECT>';
  output += '</TD><TD class=Cal ALIGN=CENTER width=20>';
  output += ' <a class=Cal href=\'javascript: moveForward()\'>>></a> ';
  output += '<\/TD><\/TR><\/TABLE>';


  firstDay = new Date(Year,Month,1);
  startDay = firstDay.getDay() -1 ;
  if (startDay < 0) startDay = 6;

  if (((Year % 4 == 0) && (Year % 100 != 0)) || (Year % 400 == 0))
       days[1] = 29;
  else
       days[1] = 28;


  output += '<TABLE CALLSPACING=0 CELLPADDING=0 BORDER=0 height='+wysokosc2+'><TR>';

  for (i=0; i<6; i++)
      output += '<TD width=20 class=Cal ALIGN=CENTER VALIGN=MIDDLE><B id=v9>' + dow[i] +'<\/B><\/TD>';

  output += '<TD width=20 class=Cal ALIGN=CENTER VALIGN=MIDDLE><B id=v9><FONT COLOR="#FF0000">' + dow[i] +'<\/FONT><\/B><\/TD>';

  output += '<\/TR><TR height=20 ALIGN=CENTER VALIGN=MIDDLE>';

  var column = 0;
  var lastMonth = Month - 1;
  if (lastMonth == -1) lastMonth = 11;

  for (i=0; i<startDay; i++, column++)
      output += '<TD class=Cal><\/TD>';

  var yellow_span = '';
  for (i=1; i<=days[Month]; i++, column++)
   {
	    if (i == sel_day && (Month == sel_month)  && (Year == sel_year)) {
			yellow_span = ' style="background: #ffff00"';
		}
		else {
			yellow_span = '';
		}
    if (column == 6)
      if (i == today.getDate())
   	    output += '<TD width=20 class=Cal '+yellow_span+'>' + '<a class=Cal HREF="javascript:changeDay(' + i + ')"><B id=v9><FONT COLOR="#FF0000">' + i + '<\/FONT><\/b><\/A>' +'<\/TD>';
      else
        output += '<TD width=20 class=Cal '+yellow_span+'>' + '<a class=Cal HREF="javascript:changeDay(' + i + ')"><B id=v9><FONT COLOR="#FF0000">' + i + '<\/FONT><\/b><\/A>' +'<\/TD>';
  	else
     {
      if (Month == 123)
        output += '<TD width=20 class=Cal>' + '<a class=Cal HREF="javascript:changeDay(' + i + ')"><B id=v9>' + i + '<\/b><\/A>' +'<\/TD>';

      else
       {
	    if (i == sel_day && (Month == sel_month)  && (Year == sel_year)) {
			yellow_span = ' style="background: #ffff00"';
		}
		else {
			yellow_span = '';
		}
        if (i == today.getDate())
       		output += '<TD width=20 class=Cal '+yellow_span+'>' + '<a class=Cal HREF="javascript:changeDay(' + i + ')"><b id=v10>' + i + '<\/b><\/A>' +'<\/TD>';
        else
          output += '<TD width=20 class=Cal '+yellow_span+'>' + '<a class=Cal HREF="javascript:changeDay(' + i + ')">' + i + '<\/A>' +'<\/TD>';
       }
     }
    if (column == 6)
     {
	  if (i!=days[Month]) {
		  rows++;
	      output += '<\/TR><TR  height=20 ALIGN=CENTER VALIGN=MIDDLE>';
	  }
      column = -1;
     }
   }

  if (column > 0)
   {
    for (i=1; column<6; i++, column++)
        output +=  '<TD class=Cal>\&nbsp;<\/TD>';
    output +=  '<TD class=Cal>\&nbsp;<\/TD>';

   }

  if (clear_calendar==1) {
	  if (rows<6 && clear_calendar==1) {
		  output += '<\/TR><TR ALIGN=CENTER VALIGN=MIDDLE HEIGHT=10><TD colspan=7 class=Cal></TD>';
		  output += '<\/TR><TR ALIGN=CENTER VALIGN=MIDDLE HEIGHT=30><TD colspan=7 class=Cal style="border-top: solid 1px #000000">';
	  }
	  else {
		  output += '<\/TR><TR ALIGN=CENTER VALIGN=MIDDLE HEIGHT=20><TD colspan=7 class=Cal>';
	  }
	  }
  else {
	  if (rows<6) {
		  output += '<\/TR><TR ALIGN=CENTER VALIGN=MIDDLE HEIGHT=20><TD colspan=7 class=Cal></TD>';
	 }
	  //output += '<\/TR><TR ALIGN=CENTER VALIGN=MIDDLE><TD colspan=7 class=Cal>';
  }


  if (clear_calendar==1) {
	 output += '<a class=Cal href="javascript:data_calendar=\'\';przepisz_calendar(obj_calendar);ukryj_warstwe();">wyczyść pole<\/b> <\/TD>';
  }

  output += '<\/FORM><\/TR><\/TABLE>';

  output += ' <\/TD><\/TR><\/TABLE>';

  return output;
}

/////////////////////////////////////////////////////////////////////

function changeDay(day) {
    start_day = day + '';
    if (parseInt(start_year)<1000) {
  	  start_year = parseInt(start_year)+1900;
    }
	data_calendar='' + parseInt(start_year) + '-' + padout(parseInt(start_month)+1) + '-' + padout(parseInt(start_day));
    przepisz_calendar(obj_calendar);
	ukryj_warstwe();
}

/////////////////////////////////////////////////////////////////////

function changeMonth() {
    start_month = document.Cal.Month.options[document.Cal.Month.selectedIndex].value;
	var kal=Cal_findObj('kalendarz');
	kal.innerHTML=Calendar(start_day,start_month,start_year);
}

/////////////////////////////////////////////////////////////////////

function changeYear() {
    start_year = document.Cal.Year.options[document.Cal.Year.selectedIndex].value;
	var kal=Cal_findObj('kalendarz');
	kal.innerHTML=Calendar(start_day,start_month,start_year);
}

/////////////////////////////////////////////////////////////////////

function moveForward() {
    if (document.Cal.Month.selectedIndex==11) {
		if (document.Cal.Year.selectedIndex<9) {
			document.Cal.Month.selectedIndex=0;
			document.Cal.Year.selectedIndex=document.Cal.Year.selectedIndex+1;
		    start_year = document.Cal.Year.options[document.Cal.Year.selectedIndex].value;
		}
	}
	else {
		document.Cal.Month.selectedIndex=document.Cal.Month.selectedIndex+1;
	}
    start_month = document.Cal.Month.options[document.Cal.Month.selectedIndex].value;
	var kal=Cal_findObj('kalendarz');
	kal.innerHTML=Calendar(start_day,start_month,start_year);
}

/////////////////////////////////////////////////////////////////////

function moveBackward() {
    if (document.Cal.Month.selectedIndex==0) {
		if (document.Cal.Year.selectedIndex>0) {
			document.Cal.Month.selectedIndex=11;
			document.Cal.Year.selectedIndex=document.Cal.Year.selectedIndex-1;
		    start_year = document.Cal.Year.options[document.Cal.Year.selectedIndex].value + '';
		}
	}
	else {
		document.Cal.Month.selectedIndex=document.Cal.Month.selectedIndex-1;
	}
    start_month = document.Cal.Month.options[document.Cal.Month.selectedIndex].value + '';
	var kal=Cal_findObj('kalendarz');
	kal.innerHTML=Calendar(start_day,start_month,start_year);
}

/////////////////////////////////////////////////////////////////////

function makeArray0() {
    for (i = 0; i<makeArray0.arguments.length; i++)
        this[i] = makeArray0.arguments[i];
}

/////////////////////////////////////////////////////////////////////

function warstwa(w,h,x,y) {
	var output='';
	output +=  '<table id=tab_kalendarz cellspacing=0 HEIGHT=180 WIDTH=180 style=\'display:none;position:absolute;left: 535px;top: 200px;  z-index:1; background-color: #ffffff; border-collapse: collapse;filter:progid:DXImageTransform.Microsoft.dropshadow(OffX=2,OffY=2,Color=#bbbbbb,Positive=true\' bordercolor=#777777 border=1 align=right>';
	output +=  '<tr height=50><td align=center valign=top>';
	output +=  '<div id=kalendarz><\/div>';
	output +=  '<\/td><\/tr><\/table>';
	return output;
}

/////////////////////////////////////////////////////////////////////

function warstwa_polozenie(w,h,x,y) {
	var kal=Cal_findObj('tab_kalendarz');
	kal.style.display='';
	kal.style.left=x;
	kal.style.top=y;
	kal.width=w;
	kal.height=h;
}

/////////////////////////////////////////////////////////////////////

function ukryj_warstwe() {
	var kal=Cal_findObj('tab_kalendarz');
	kal.style.display='none';
	picker_is_opened=false;
}

/////////////////////////////////////////////////////////////////////

var names     = new makeArray0('Styczeń','Luty','Marzec','Kwiecień','Maj','Czerwiec','Lipiec','Sierpień','Wrzesień','Październik','Listopad','Grudzień');
var days      = new makeArray0(31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31);
var dow       = new makeArray0('Po','Wt','Śr','Cz','Pt','So','Ni');

/////////////////////////////////////////////////////////////////////

document.write(warstwa(0,0,0,0));
document.write(styl());

/////////////////////////////////////////////////////////////////////
