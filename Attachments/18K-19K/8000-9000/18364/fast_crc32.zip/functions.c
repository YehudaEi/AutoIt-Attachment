// Prototypes of CRC32 functions
// Made by Laszlo

typedef unsigned long uint; 

void CRC32_Init(uint* table) { // uint table[256] 
  uint i, j, poly = 0xEDB88320, CRC; 

  for(i = 0; i < 256; i++) { 
    CRC = i; 
    for(j = 0; j < 8; j++) 
      if(CRC & 1) 
        CRC = (CRC >> 1) ^ poly; 
      else 
        CRC >>= 1; 
    table[i] = CRC; 
  } 
} 

uint CRC32(unsigned char* buffer, uint len, uint crc32val, uint* table) { // init: crc32val = 0xFFFFFFFF 
  uint i; 
  for (i = 0; i < len; i++) 
    crc32val = table[(crc32val ^ buffer[i]) & 255] ^ (crc32val >> 8); 
  return ~crc32val; 
}