DerBens Digital Dancer

Dance to your own music!

This is a DDR-like Dance Game. I found it hard to find a DDR game that had music I heard of,
so I made a PC version that uses the Mp3s already on most users systems.

You can press ESC to close it.



Requirements:

-Autoit 3.2.10.0
  (with 3.2.10.0 you have to replace Sound.au3 in the include folder)

-DDR compatable dance mat OR a game console dancemat and adapter
  (I use a ps2 DDR mat and a PS2-USB adapter -DDR compatable, Check Ebay)
  Joystick will NOT work..

-A PC, chances are you have that.. I'm guessing it will run on any windows PC
  that can play an mp3. Check Autoit's specs if it seems to run slow..
  My slowest computer is 1.5 GHz with 512 MB ram, runs fine.

-Mat needs to be game device one, or the only game device plugged in.

-Works best at screen resolution 800x600 (so it's full screen)


Source Comments:

; Program and design by Colin (aka DerBen, http://www.ctg3d.tk)
; Version 3
;
; Originally the plan was to match the moves with the beat,
; however beat detection is difficult. There is a possible
; method with AUDACITY and it's beat finder. You can save
; the beats out to a text file. Then parse the file with
; Autoit. Another feature is an MP3 length finder and
; progress bar that I am not sure how to make.
;
; Joystick controls by:
;      Original program by Ejoc 
;      Improved by Adam1213 (autoit 3.2 compatiblity + improved labels
;   * Found on the autoit forum *
;
;
; Warning: don't steal this code and call it your own with no mention
;  of me whatsoever.. if you are to compile it, please include my name
;  (DerBen) and website (www.ctg3d.tk) in a readme file along with
;  the information for the joystick function programmers.
;
;     -Thanks, DerBen
;




Known Problems:

-Some mp3s report wrong length and arrows don't run out before the music
  stops.. which is what's supposed to happen.

-Not really a bug, but standing on a button won't let you score points, you
  have to step and lift. This can be hard to do with a small mat and big feet.



