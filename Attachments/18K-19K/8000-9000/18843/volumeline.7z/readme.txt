VolumeLine 1.0 (c) 2002, by Slava Glory (Omsk, Russia) 
----------------------------------------------------------------------------
June 24, 2002
----------------------------------------------------------------------------

VolumeLine is a command line utility for adjusting volume level through 
command line parameters.Supports all available volume, recording and other 
mixer controls (master volume, wave, midi, line-in, etc).

How to use:

To get all audio mixers, groups and controls information use:
VolumeLine.exe GET:ALL

To get info about specified audio mixer, group or control use:
VolumeLine.exe GET:<MixerId>[:<GroupId>[:<ControlId>]]

To set volume level for specified audio control use:
VolumeLine.exe SET:<MixerId>:<GroupId>:<ControlId> VOLUME:<0-100>

To set mute for specified audio control use:
VolumeLine.exe SET:<MixerId>:<GroupId>:<ControlId> MUTE:<ON|OFF>

To select specified audio control use:
VolumeLine.exe SET:<MixerId>:<GroupId>:<ControlId> SELECT

Contacts:

E-Mail: slava_glory@mail.ru
Web: http://glorysoft.omsk.ru

VolumeLine IS DISTRIBUTED "AS IS". NO WARRANTY OF ANY KIND IS EXPRESSED
OR IMPLIED. USE AT YOUR OWN RISK. THE AUTHOR WILL NOT BE LIABLE FOR DATA
LOSS, DAMAGES, LOSS OF PROFITS OR ANY OTHER KIND OF LOSS WHILE USING OR
MISUSING THIS SOFTWARE.
