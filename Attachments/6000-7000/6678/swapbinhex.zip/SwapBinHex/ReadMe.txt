Readme for SwapBinHex.exe 1.0  14/10/2000

*** Reccomended use: drag the file and drop it on the SwapBinHex.exe ***

SwapBinHex is a utility to convert bin file to hex file and vice versa.
Hex and bin file format refers to the common format uset to program
Microcontrollers such as Microchip PICs and E2Prom 24LC16.

It's a long time I wanted to rewrite the original Intel(r) utilities that
are really frustrating to use. SwapBinHex replace, as far as I could test,
the three Intel(r) utility bin2hex.exe, hex2bin.exe and hex2hex.exe.

The format conversion from bin to hex format is actually fixed:
16 byte per row.

Although SwapBinHex supports a file name on the command line, I really
suggest to use it by dragging a bin or hex file onto SwapBinHex.exe.
As soon as the drop operation has completed, the file will be converted
in the same folder of the original one.


Command line samples:
SwapBinHex file.hex  (convert the file in file.bin)
SwapBinHex file.bin  (convert the file in file.hex)


SwapBinHex 1.0 is freeware. You may use it free of charge. You may also
distribute it freely provided you do so in the form of the original
SwapBinHex.zip archive, including this readme.txt.


Comments, bugs and suggestion can be emailed me at malta@vevy.com.

Ciao,
Raffaele