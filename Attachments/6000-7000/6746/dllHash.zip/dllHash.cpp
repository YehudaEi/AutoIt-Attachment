/*
 * Plugin for AutoItv3
 * FileHash() and StringHash()
 * Currenly MD5 is the only hash option.
 * MD5 functions by Jarvis Stubblefield (jjs at vortexrevolutions dot com)
 * Plugin_SDK and AutoItv3 Jon Bennett and his team of Developers
 *
 * dllHash.cpp
 */

#include <stdio.h>
#include <windows.h>
#include <string.h>
#include "au3plugin.h"
#include "JSmd5.h"


/****************************************************************************
 * Function List
 *
 * This is where you define the functions available to AutoIt.  Including
 * the function name (Must be the same case as your exported DLL name), the
 * minimum and maximum number of parameters that the function takes.
 *
 ****************************************************************************/

/* "FunctionName", min_params, max_params */
AU3_PLUGIN_FUNC g_AU3_Funcs[2] = 
{
    {"FileHash", 1, 2},
    {"StringHash", 1, 2}
};


/*
Multiple Function Example

AU3_PLUGIN_FUNC g_AU3_Funcs[NUMFUNCS] = 
{
	{"PluginFunc1", 2, 2},
	{"PluginFunc2", 1, 1},
	{"PluginFunc3", 1, 5}
};
*/


/****************************************************************************
 * AU3_GetPluginDetails()
 *
 * This function is called by AutoIt when the plugin dll is first loaded to
 * query the plugin about what functions it supports.  DO NOT MODIFY.
 *
 ****************************************************************************/

AU3_PLUGINAPI int AU3_GetPluginDetails(int *n_AU3_NumFuncs, AU3_PLUGIN_FUNC **p_AU3_Func)
{
	/* Pass back the number of functions that this DLL supports */
	*n_AU3_NumFuncs	= sizeof(g_AU3_Funcs)/sizeof(AU3_PLUGIN_FUNC);;

	/* Pack back the address of the global function table */
	*p_AU3_Func = g_AU3_Funcs;

	return AU3_PLUGIN_OK;
}


/****************************************************************************
 * DllMain()
 *
 * This function is called when the DLL is loaded and unloaded.  Do not 
 * modify it unless you understand what it does...
 *
 ****************************************************************************/

BOOL WINAPI DllMain(HANDLE hInst, ULONG ul_reason_for_call, LPVOID lpReserved)
{
    switch (ul_reason_for_call)
	{
		case DLL_PROCESS_ATTACH:
		case DLL_THREAD_ATTACH:
		case DLL_THREAD_DETACH:
		case DLL_PROCESS_DETACH:
			break;
    }
    return TRUE;
}

/****************************************************************************
 * FileHash()
 *
 * This function should return a hash of the chosen file, it accepts 2
 * parameters:
 * 
 * FileHash("filename.exe", 1)
 * 
 * 1st Parameter = The file you wish to return a hash value of.
 * 2nd Parameter = Type of hash to be done. Currently only MD5.
 *
 ****************************************************************************/

AU3_PLUGIN_DEFINE(FileHash)
{
	/* The inputs to a plugin function are:
	 *		n_AU3_NumParams		- The number of parameters being passed
	 *		p_AU3_Params		- An array of variant like variables used by AutoIt
	 *
	 * The outputs of a plugin function are:
	 *		p_AU3_Result		- A pointer to a variant variable for the result
	 *		n_AU3_ErrorCode		- The value for @Error
	 *		n_AU3_ExtCode		- The value for @Extended
	 */

	AU3_PLUGIN_VAR	*p_HashResult;
	char            *s_FileName, *s_MD5Hash;
	int             i_Hash;

	/* Allocate and build the return variable */
	p_HashResult = AU3_AllocVar();

	/* Get string representations of the two parameters passed - this works even if we
	 * were passed numbers or floats.
	 * Note: AU3_GetString() allocates some memory that we must manually free later.
	 */

	 
	s_FileName	= AU3_GetString(&p_AU3_Params[0]);
	if ( GetFileAttributes(s_FileName) == 0xffffffff )
	{
		AU3_SetString(p_HashResult, "");
		*n_AU3_ErrorCode	= 1;
	}
	else
	{
        /*Checks if the second parameter is passed.*/
		if (n_AU3_NumParams>1)
        {
			i_Hash = AU3_GetInt32(&p_AU3_Params[1]);
        }
        else
        {
            i_Hash = 1;
        }
        /*Checks to see which hash to run.*/
        if (i_Hash == 1)
        {
		    s_MD5Hash = FileMD5Encrypt(s_FileName);
		    strupr(s_MD5Hash);
        }
        else
        {
            AU3_SetString(p_HashResult, "");
            *n_AU3_ErrorCode = 2;
        }
		
		/* Set the return variable */
		AU3_SetString(p_HashResult, s_MD5Hash);
		*n_AU3_ErrorCode	= 0;
	}

	/* Free temporary storage */
	AU3_FreeString(s_FileName);

	/* Pass back the result, error code and extended code.
	 * Note: AutoIt is responsible for freeing the memory used in p_AU3_Result
	 */
	*p_AU3_Result		= p_HashResult;
	*n_AU3_ExtCode		= 0;

	return AU3_PLUGIN_OK;
}

AU3_PLUGIN_DEFINE(StringHash)
{
	/* The inputs to a plugin function are:
	 *		n_AU3_NumParams		- The number of parameters being passed
	 *		p_AU3_Params		- An array of variant like variables used by AutoIt
	 *
	 * The outputs of a plugin function are:
	 *		p_AU3_Result		- A pointer to a variant variable for the result
	 *		n_AU3_ErrorCode		- The value for @Error
	 *		n_AU3_ExtCode		- The value for @Extended
	 */

	AU3_PLUGIN_VAR	*p_HashResult;
	char            *s_String, *s_MD5Hash;
	int             i_Hash;

	/* Get string representations of the two parameters passed - this works even if we
	 * were passed numbers or floats.
	 * Note: AU3_GetString() allocates some memory that we must manually free later.
	 */
	 
	s_String	= AU3_GetString(&p_AU3_Params[0]);
    /*Checks if the second parameter is passed.*/
	if (n_AU3_NumParams>1)
    {
		i_Hash = AU3_GetInt32(&p_AU3_Params[1]);
    }
    else
    {
        i_Hash = 1;
    }
    /*Checks to see which hash to run.*/
    if (i_Hash == 1)
    {
	    s_MD5Hash = StringMD5Encrypt(s_String);
        strupr(s_MD5Hash);
    }
    else
    {
        AU3_SetString(p_HashResult, "");
        *n_AU3_ErrorCode = 2;
    }

	/* Free temporary storage */
	AU3_FreeString(s_String);
	
	/* Allocate and build the return variable */
	p_HashResult = AU3_AllocVar();

	/* Set the return variable */
	AU3_SetString(p_HashResult, s_MD5Hash);
	

	/* Pass back the result, error code and extended code.
	 * Note: AutoIt is responsible for freeing the memory used in p_AU3_Result
	 */
	*p_AU3_Result		= p_HashResult;
	*n_AU3_ErrorCode	= 0;
	*n_AU3_ExtCode		= 0;

	return AU3_PLUGIN_OK;
}
