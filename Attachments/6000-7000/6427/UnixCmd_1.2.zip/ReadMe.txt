==========================
UnixCmd  ver 1.2 1/25/2006
==========================

UnixCmd is a Unix Shell Management based on PuTTY, a free implementation of Telnet and SSH. Starts a PuTTY Telnet/SSH session,
executes the login and any other command listed in the UnixCmd.ini file.
Programs:
UnixCmd:	Main program
UnixPwd:	Crypt passwords and any other value you want and write them to the INI file

Configuration:
1. Start PuTTY and save sessions (typically with the server HostName)
2. Manually create your UnixCmd.INI file in the same directory of the main program with any string uncrypted.
   Be carefully that the Section name have to correspond to a previously saved PuTTY session.
   See the INI paragraph below for a detailed description of Keys/Values.
3. Execute UnixPwd to crypt the Pwd value (Password) and any other command you decide.


INI file example:
[MyServer]								Server HostName
IP=nn.nn.nn.nnn							IP Address of the server
User=report								User Name
Pwd=0B2D1CAFA033DA8A5CC1C7EE19980BD0	Password (crypted)
Sleep=3000								Time wait of the user prompt (default 1 second) <Optional>
SendKeyDelay=100						Time in milliseconds to pause between sent keystrokes (default 50 milliseconds) <Optional>
Cmd1=su -								Commands <Optional>
Cmd2=D12D1CAFA033DA8A5FC5C6E91CEC0B0C	""
Cmd3=ksh -o vi							""
Cmd4=stty erase {TAB}					""
Cmd5=cd /usr/local/squid/etc			""


How UnixCmd works: 
1. Shows a dialog box where you have to choose the server HostName.
2. Search the HostName Section in the INI file and loads the entries.
3. Decrypt passwords and any other crypted string in the INI file
3. Starts a PuTTY Telnet/SSH to the choosed server and executes any other commands listed under the section (Key "Cmd").


Requirements:
- PuTTY (http://www.chiark.greenend.org.uk/~sgtatham/putty/)
- PuTTY saved sessions of your Unix servers
- UnixCmd.ini file with Sections corresponding to PuTTY saved sessions


ChangeLog: 
1.0 6/9/2005
- Initial release

1.0.1 5/7/2005
- Changed: Send => ControlSend for security reasons
- Changed: BlockInput before starting PuTTY

1.1 5/7/2005
- Changed: InputBox -> GUI with a Servers listbox
- Added: Option SendKeyDelay. Time in milliseconds to pause between sent keystrokes (default 50 milliseconds).

1.2 1/25/2006
- Added: DoubleClick in ListBox


------------------------------------------------------------------------------------------------------------------

Author: Giuseppe Criaco <gcriaco@quipo.it>
