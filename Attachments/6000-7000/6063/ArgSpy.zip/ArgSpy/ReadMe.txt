#~ Plateform: Windows 9x or better
#~ AutoIt ver: 3.1.1 or better

#~ I AM NOT RESPONSIBLE FOT ITS USE!!!

#~ Questions, comments, or feedback...
#~ nfolinks@gmail.com  -  Subject: ArgSpy

#~  ArgSpy is designed to safely spy on the command line arguments of other programs by
#~ placing the arguments on the clipboard, such as zip programs etc. When choosing ArgSpy
#~ from the Send To menu it will only allow one program to be replaced at a time. It does
#~ this by automatically restoring any previous file replacement before replacing any new
#~ executable.

#~ --Features--
#~ (1)Free :)
#~ (2)Ini file configuration to avoid registry writes and ease of configuring.
#~ (3)No new running processes. Designed to do its job and exit.
#~ (4)Ease of restoring previously backed up files even if you've forgotten where or what they are.
#~ (5)A silent option in ArgSpy.ini so you aren't hassled by unnecessary message boxes.
#~ (6)Will not attempt to replace in use files.

#~ There are 5 ways to restore an ArgSpy replaced file.
#~ (1)Sending File.???.ArgSpy backup file to ArgSpy.exe via the Send To menu. Created in the same
#~    directory as the program being spied on.
#~ (2)Clicking ArgSpy.exe without any arguments passed.
#~ (3)Clicking the ArgSpy Restore link in the Start Menu.
#~ (4)Replacing any new executable with ArgSpy.exe using the Send To menu.
#~ (5)Placing a shortcut to ArgSpy.exe in the startup folder to restore any backups when the computer restarts.

#~ Experienced users may way to play with ArgSpy.ini and shell swapping but I don't recommend it.
#~ Certain windows files will cause windows to insist the installation is broken even after the files
#~ are fixed. Speaking from experience :) so be warned!!! Although drastic measures would have to be
#~ taken to get ArgSpy to corrupt these files I am NOT responsible for it's use.


No installer with this version...
-Instructions-
Place a shortcut to ArgSpy.exe in your send to menu.
Place a shortcut to ArgSpy.exe in your start menu.
Send an exe to ArgSpy via send to, such as winzip.exe.
Open, unzip, etc any zip file. Nothing happens...
Paste the cammand line aguement wherever you need it.
Run ArgSpy.exe from the start menu and winzip is restored.

-Note-
Or just drag and drop an exe onto ArgSpy.exe.
Drag and drop a .ArgSpy onto ArgSpy.exe to repair.
Placeing a shortcut in the startup group 
insures that any replaced files are restored at
starup even if you've forgotten where or what
they are.

-Registry option-
Personally I hate app writters putting crap in my registry :(
If you want it past this into notepad name it argspy.reg
chang path to and double click it. If you don't understand
don't do it, this programs not for you anyway.. :)

***************
REGEDIT4

[HKEY_CLASSES_ROOT\.ArgSpy]

[HKEY_CLASSES_ROOT\.ArgSpy\Shell]
@="ArgSpy"

[HKEY_CLASSES_ROOT\.ArgSpy\Shell\ArgSpy]
@=""

[HKEY_CLASSES_ROOT\.ArgSpy\Shell\ArgSpy\Command]
@="C:\\Path\\to\\ArgSpy\\ArgSpy.exe %1"
***************

