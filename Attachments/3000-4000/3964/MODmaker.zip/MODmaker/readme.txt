Welcome to phpbb MOD maker, the quick and easy way to create fully working MODs!

Features:
* Easy to use
* comes with executable file and source
* MODs created _should_ be installable with EasyMOD. This has not been tested, but it follows the MOD template completely

Problems:
(the following 3 are features not included and so will have to be changed manually in the txt or mod file)
* Installatiion time is left at "x minutes"
* Installation level is left at "(Easy/Intermediate/Advanced)"
* cannot change license
* can not read actions already existing in a MOD
Please tell me if you see any more problems!

The .au3 file included is the source, and can be opened with any text editor.