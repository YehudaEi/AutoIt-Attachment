Version 0.4a - (29.08.2005)
        * Added the eXeo.ini - Now eXeo automatic save and read the 
configuration with eXeo.ini
        * Now eXeo sets itself to Above Normal Priority, no matter 
which filename it has / if its compiled/uncompiled
        * Changed some random timers for precised work

Version 0.3c - (28.08.2005)
        * Added 2 random timers to slow down the tool a bit. Server may 
not response anymore, if its too fast.

Version 0.3b - (28.08.2005)
        * Rewrote all pixelscans, modified search- and clickmode [works 
now with EO Window at ANY position]
        * Fixed some bugs [GUI doesnt react if AutoLogIn succeed, 
script clicks login on datafield before enters data, ...]
        * Fixed PauseKey [PauseKey only works AFTER the GUI does 
something, not if its just idling...]
        * Added a Exitfunction if EO isnt longer running [in PauseMode 
and in LogInMode it will quit eXeo then]
        * If you have chosen another number then 1 - 3 for 
characterselect in GUI, then AutoLogIn will stop on characterscreen
        * Added random timer for waitloop after clicking on choosen 
char

Version 0.3a - (28.08.2005)
        * Fixed a massive bug which killed the program all 384 loops 
[full rewritten code]
        * Added a temporary HOLD Command [CTRL + h] to stop the 
LogIn-Function and go back to GUI.
        * Changed some timers to random timers [50 - 200ms]
        * Sets Winamp and itself to Above Normal Priority, EO to Below 
Normal Priority for speed purposes.

Version 0.2 - (27.08.2005)
        * Fixed alot of bugs, timers, and so on..
        * Added PauseKey [configurable over GUI]
        * Fixed some GUI errors

Version 0.1 - Initial Release (25.08.2005)
        eXeo, the EO Extension Tool is born! :D
        Alot of Bugs, alot of Errors, but the first part is finished
        Just autoclicks, not much status check yet
