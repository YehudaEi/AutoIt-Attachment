AutoPermit�
"Because you wouldn't have downloaded the file...
...if you didn't want to use it!"

**************************************************************************
Are you tired of the "Open File - Security Warning" that appears
every time you download anything to the desktop ever since
you downloaded that pesky Service Pack 2 for Windows XP?

AutoPermit� runs in the background and cleans the nag screen from any
file you download to the desktop.  No longer will the annoying 
"Open File - Security Warning" pop-up nag ever bother you again!

**************************************************************************

Requirements:

***Windows XP with Service Pack 2 installed.
(or else you wouldn't be having this problem, now would you?)

***Streams.exe (in a 19kb zip file)--- from the Sysinternals website:
http://www.sysinternals.com/ntw2k/source/misc.shtml#streams

***You must download files by only using Internet Explorer for the
elimination of the nag screen to work.  No 3rd party download managers, 
or other web browsers, are supported.


Instructions:

***Place the Streams.exe file in your \windows\System32\ directory, 
then you can make an AutoPermit� folder in Program Files for tidy
storage of the AutoPermit files.

***Now, if you want the program to run automatically in the background
upon boot (or login) either:
   
   **Place a new string value of the path to AutoPermit.exe into the
     registry under:
     HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\Windows\CurrentVersion\Run
     if you have administrator priviledges, to make it load for
     everyone on boot (login) or,

   **Copy a shortcut that you make of AutoPermit.exe and place the
     shortcut into the "Startup" folder in "All Programs" from the
     Start Menu.  This will start AutoPermit� on boot (login) so that
     only your account is cool.

***When AutoPermit is running, you'll see a quick window flash on
your screen to indicate that the nag screen is eliminated, simple as
that!  Now when you open the file, or a compressed file inside of a
ZIP for example, your file will open cleanly.


Limitations and Warnings:

***No "Open File - Security Warning" window should appear for any file
downloaded into the desktop folder after AutoPermit has started.  
It is possible to take care of nag screens that would appear on files
already downloaded, but before AutoPermit� has been started.  To do this
requires that you download any file to the desktop after AutoPermit� is
started.  Then, no nag screens will appear for ANY of the downloaded
files, regardless of when AutoPermit� was started.

***You must download files by only using Internet Explorer for the
elimination of the nag screen to work.  No 3rd party download managers, 
or other web browsers, are supported.

***AutoPermit� deletes all NTFS file streams attached to any file in
the desktop folder only.  So far, it appears that the deletion of
these streams is inconsequential to the integrity of the downloaded
file.  However, as with any software you download, use at your own risk!


Disclaimer:

***The author of this software is not liable for the use or installation
of AutoPermit� in any way.


Legal:

***AutoPermit� is Freeware, but this ReadMe.txt must accompany any
integration or redistribution of this software, AND full credit must be
given of the author of AutoPermit�.  The author's name and email address
must be included in the documentation bundled with any commercial or
non-commercial repackaging of this software into other software packages.


Donations:

***Donations are unbelievably appreciated, but absolutely not required.
If you really dig this software and want to show your appreciation, feel
free to donate any amount by using PayPal's "Send Money" feature, and
enter the email address below as the recipient.


Acknowledgements:

***Thanks to Jonathan Bennett and the AutoIt Team for creating such an
awesome scripting language, AutoIt v3, without which AutoPermit� would
cease to be.  http://www.autoitscript.com


Contact:

***Feel free to send any comments, suggestions, flames, etc. to the email
address below.  Thank you very much for using this software!

Author: Jerod Durbin
Email: jdurbinfl@yahoo.com



Copyright � 2004 by Jerod Durbin. All rights reserved.






